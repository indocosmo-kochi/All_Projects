//import { ReactReduxContext } from 'react-redux';
import { createStore, combineReducers, applyMiddleware } from 'redux';
import reducers from '../reducers';
import moduleReducers from '../redux/reducers';
import thunk from 'redux-thunk'
//import {composeDevTools} from 'redux-devtools-extension'

export default function configureStore() {
  return createStore(
    combineReducers({
      ...reducers,
      ...moduleReducers
    }),
    applyMiddleware(thunk)
    //composeDevTools(applyMiddleware(thunk))
    
  );
}