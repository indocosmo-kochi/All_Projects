import Axios from 'axios'
//common function 
import * as commonFunction from '../../Function/getGlobalVariable';
//Get Action Conststant
import * as ActionType from '../../constant';

/**
 * postTocart
 * @param {*} data 
 * @param {*} API 
 * @returns 
 */
export const postTocart = (data, API) => {

  //Get Login Token
  const token = commonFunction.getToken();

  return async (dispatch, getstate) => {

    dispatch({ type: ActionType.ORDER_POSTTOCART_REQUEST });

    try {
      const response = await Axios.post(process.env.REACT_APP_MEDESAVER_API_ROOT_URL + API, data, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        }
      });

      dispatch({ type: ActionType.ORDER_POSTTOCART_SUCCESS, payload: response.data })
    } catch (error) {
      dispatch({ type: ActionType.ORDER_POSTTOCART_FAILURE, error: error })
    }
  }
}