import Axios from 'axios'
//common function 
import * as commonFunction from '../../Function/getGlobalVariable';
//Get Action Conststant
import * as ActionType from '../../constant';

/**
 * saveData
 * @param {*} data 
 * @param {*} SAVE_API 
 * @returns 
 */
export const saveData = (data, SAVE_API) => {

  //Get Login Token
  const token = commonFunction.getToken();

  return async (dispatch, getstate) => {

    dispatch({ type: ActionType.SAVE_REQUEST });

    try {
      const response = await Axios.post(process.env.REACT_APP_MEDESAVER_API_ROOT_URL + SAVE_API, data, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,

        }
      });

      dispatch({ type: ActionType.SAVE_SUCCESS, payload: response.data })
    } catch (error) {
      dispatch({ type: ActionType.SAVE_FAILURE, error: error })
    }
  }
}

/**
 * updateData
 * @param {*} data 
 * @param {*} UPDATE_API 
 * @returns 
 */
export const updateData = (data, UPDATE_API) => {

  //Get Login Token
  const token = commonFunction.getToken();

  return async (dispatch, getstate) => {

    dispatch({ type: ActionType.UPDATE_REQUEST })

    try {
      const response = await Axios.post(process.env.REACT_APP_MEDESAVER_API_ROOT_URL + UPDATE_API , data, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,

        }
      });

      dispatch({ type: ActionType.UPDATE_SUCCESS, payload: response.data })
    } catch (error) {
      dispatch({ type: ActionType.UPDATE_FAILURE, error: error })
    }
  }
}

/**
 * fetchDataByParams
 * @param {*} GET_API 
 * @param {*} param 
 * @returns 
 */
export const fetchDataByParams = (GET_API, param) => {
  //Get Login Token
  const token = commonFunction.getToken();

  return async (dispatch, getstate) => {

    dispatch({ type: ActionType.FETCH_DATA_BYPARAM_REQUEST });

    try {
      const response = await Axios.get(process.env.REACT_APP_MEDESAVER_API_ROOT_URL + GET_API, {
        params: param,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        }
      });     
      dispatch({ type: ActionType.FETCH_DATA_BYPARAM_SUCCESS, payload: response.data })
    } catch (error) {
      dispatch({ type: ActionType.FETCH_DATA_BYPARAM_FAILURE, error: error })
    }
  }
}

/**
 * fetchDataList
 * @param {*} GET_API 
 * @param {*} paramVal 
 * @returns 
 */
export const fetchDataList = (GET_API, paramVal) => {

  //Get Login Token
  const token = commonFunction.getToken();

  return async (dispatch, getstate) => {

    dispatch({ type: ActionType.FETCH_DATA_LIST_REQUEST });

    let param = {};

    let paramComp;
    if (paramVal !== undefined && paramVal !== '' && paramVal !== null) {
      paramComp = { ...param, ...paramVal }
    } else {
      paramComp = param;
    }

    try {
      const response = await Axios.get(process.env.REACT_APP_MEDESAVER_API_ROOT_URL + GET_API, {
        params: paramComp,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,

        }
      });

      dispatch({ type: ActionType.FETCH_DATA_LIST_SUCCESS, payload: response.data['data'] })
    } catch (error) {
      dispatch({ type: ActionType.FETCH_DATA_LIST_FAILURE, error: error })
    }
  }
}

/**
 * uploadFile
 * @param {*} FILE_UPLOAD_API 
 * @param {*} params 
 * @returns 
 */
export const uploadFile = (FILE_UPLOAD_API, params) => {

  //Get Login Token
  const token = commonFunction.getToken();

  return async (dispatch, getstate) => {

    dispatch({ type: ActionType.FILE_UPLOAD_REQUEST })       

    try {
      const response = await Axios.post(process.env.REACT_APP_MEDESAVER_API_ROOT_URL + FILE_UPLOAD_API,params, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${token}`,

        }
      });

      dispatch({ type: ActionType.FILE_UPLOAD_SUCCESS, payload: response.data })
    } catch (error) {
      dispatch({ type: ActionType.FILE_UPLOAD_FAILURE, error: error })
    }
  }
}

/**
 * uploadFile
 * @param {*} FILE_DOWNLOAD_API 
 * @param {*} params 
 * @returns 
 */
 export const downloadFile = (FILE_DOWNLOAD_API, params) => {

  //Get Login Token
  const token = commonFunction.getToken();

  return async (dispatch, getstate) => {

    dispatch({ type: ActionType.FILE_DOWNLOAD_REQUEST })       

    try {
      const response = await Axios.get(process.env.REACT_APP_MEDESAVER_API_ROOT_URL + FILE_DOWNLOAD_API, {
        params : params,
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${token}`,
        },
        responseType: 'arraybuffer',
        dataType:'binary',
      });

      console.log(response);

      dispatch({ type: ActionType.FILE_DOWNLOAD_SUCCESS, payload: response.data })
    } catch (error) {
      dispatch({ type: ActionType.FILE_DOWNLOAD_FAILURE, error: error })
    }
  }
}