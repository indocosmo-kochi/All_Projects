import axios from 'axios'
//Get Action Conststant
import * as ActionType from '../../constant';

/**
 * resetPasswordAction
 * @param {*} email 
 * @param {*} newPassword 
 * @returns 
 */
export const resetPasswordAction = (param) => {

  return async (dispatch, getstate) => {
    dispatch({ type: ActionType.RESETPASSWORD_REQUEST })
    try {
      const response = await axios.post(process.env.REACT_APP_MEDESAVER_API_ROOT_URL + ActionType.API_EMAILCONFIRMATION, param, {
        headers: {
          'Content-Type': 'application/json',
        }
      });
      dispatch({ type: ActionType.RESETPASSWORD_SUCCESS, payload: response.data.data })
    } catch (error) {
      dispatch({ type: ActionType.RESETPASSWORD_FAILURE, payload: error });
    }
  }
}

/**
 * sentEmailConfirmation
 * @param {*} email 
 * @returns 
 */
export const sentEmailConfirmation = (param) => {

  return async (dispatch, getstate) => {
    dispatch({ type: ActionType.EMAIL_CONFIRMATION_REQUEST })
    try {
      const response = await axios.post(process.env.REACT_APP_MEDESAVER_API_ROOT_URL + ActionType.API_EMAILCONFIRMATION, param, {
        headers: {
          'Content-Type': 'application/json',
        }
      });
      dispatch({ type: ActionType.EMAIL_CONFIRMATION_SUCCESS, payload: response.data })
    } catch (error) {
      dispatch({ type: ActionType.EMAIL_CONFIRMATION_FAILURE, payload: error });
    }
  }
}
