import axios from 'axios'
//Get Action Conststant
import * as ActionType from '../../constant';

/**
 * login
 * @param {*} email 
 * @param {*} password 
 * @returns 
 */
export const login = (id, password) => {
  return async (dispatch, getstate) => {
   dispatch({ type: ActionType.LOGIN_REQUEST })
    try {
      
      const param = {
        'pharmacy_id': id,
        'password': password
      }
      
      const response = await axios.post(process.env.REACT_APP_MEDESAVER_API_ROOT_URL + ActionType.API_LOGIN, param ,{
        headers: {
          'Content-Type': 'application/json',          
        }
      });
        dispatch({ type: ActionType.LOGIN_SUCCESS, payload: response.data });
    } catch (error) {   
      dispatch({ type: ActionType.LOGIN_FAILURE, payload: error });
    }
  }
}

