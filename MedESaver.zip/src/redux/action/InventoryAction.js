import Axios from 'axios'
//common function 
import * as commonFunction from '../../Function/getGlobalVariable';
//Get Action Conststant
import * as ActionType from '../../constant';

/**
 * funGetSearchMedicine
 * @param {*} param 
 * @param {*} API 
 * @returns 
 */
export const funGetSearchMedicine = (param, API) => {

    //Get Login Token
    const token = commonFunction.getToken();

    return async (dispatch, getstate) => {

        dispatch({ type: ActionType.GET_SEARCH_MEDICINE_REQUEST });

        try {
            const response = await Axios.post(process.env.REACT_APP_MEDESAVER_API_ROOT_URL + API, param, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,

                }
            });

            dispatch({ type: ActionType.GET_SEARCH_MEDICINE_SUCCESS, payload: response.data })
        } catch (error) {
            dispatch({ type: ActionType.GET_SEARCH_MEDICINE_FAILURE, error: error })
        }
    }
}
