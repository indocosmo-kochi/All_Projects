import Axios from 'axios'
//common function 
import * as commonFunction from '../../Function/getGlobalVariable';
//Get Action Conststant
import * as ActionType from '../../constant';

/**
 * fetchData
 * @param {*} page 
 * @param {*} limit 
 * @param {*} sortBy 
 * @param {*} filterBy 
 * @param {*} GET_API 
 * @param {*} paramVal 
 * @returns 
 */
export const fetchData = (page, limit, sortBy, filterBy, GET_API, paramVal) => {

  //Get Login Token
  const token = commonFunction.getToken();
  //Pharmacy Id
  const pharmacyId = commonFunction.getPharmacyId();

  return async (dispatch, getstate) => {
    dispatch({ type: ActionType.FETCH_DETAILS_REQUEST });
    let param = {};
    if (page !== undefined && limit !== undefined && sortBy !== undefined) {
      if (Object.keys(sortBy).length !== 0) {
        let order_by_column;
        let order_by;
        Object.keys(sortBy).map(key => {
          order_by_column = key;
          order_by = sortBy[key];
        })
        param = { "page": page + 1, "limit": limit, "order_by_column" : order_by_column, "order_by": order_by };
      } else {
        param = { "page": page + 1, "limit": limit };
      }
      //set filter data
      if (filterBy !== undefined) {
        if (filterBy.length > 0) {
          for (let filter of filterBy) {
            param[filter.id] = filter.value;
          }
        }
      }
    }

    if (pharmacyId !== '' && pharmacyId !== undefined && pharmacyId !== null) {
      param['pharmacy_id'] = pharmacyId;
    }

    let paramComp;
    if (paramVal !== undefined && paramVal !== '' && paramVal !== null) {
      paramComp = { ...param, ...paramVal }
    } else {
      paramComp = param;
    }

    try {
      const response = await Axios.get(process.env.REACT_APP_MEDESAVER_API_ROOT_URL + GET_API, {
        params: paramComp,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          
        }
      });     
     dispatch({ type: ActionType.FETCH_DETAILS_SUCCESS, payload: response.data, totalData: response.data['total_count'], })
    } catch (error) {
      dispatch({ type: ActionType.FETCH_DETAILS_FAILURE, error: error })
    }
  }
}

/**
 * deleteData
 * @param {*} deleteIds 
 * @param {*} DELETE_API 
 * @returns 
 */
export const deleteData = (deleteIds, DELETE_API) => {

  //Get Login Token
  const token = commonFunction.getToken();

  return async (dispatch, getstate) => {

    dispatch({ type: ActionType.DELETE_REQUEST })

    try {
      const response = await Axios.delete(process.env.REACT_APP_MEDESAVER_API_ROOT_URL + DELETE_API, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          
        },
        data: deleteIds

      });
      dispatch({ type: ActionType.DELETE_SUCCESS, payload: response.data })
    } catch (error) {
      dispatch({ type: ActionType.DELETE_FAILURE, error: error })
    }
  }
}