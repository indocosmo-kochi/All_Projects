import * as ActionType from "../../constant";
/*
 *Set initial state 
 */
const initState = {
    itemsWithParam: [],
    totalDataCount: 0,
    loading: false,
    error: null,
    saveResponse: [],
    updateResponse: [],
    fileUploadResponse: [],
    fileDlownloadResponse: [],
}

/**
 * BasicFormReducer
 * @param {*} state 
 * @param {*} action 
 * @returns 
 */
const BasicFormReducer = (state = initState, action) => {
    switch (action.type) {

        /* Fetch Data with param*/
        case ActionType.FETCH_DATA_BYPARAM_REQUEST:
            return {
                ...state,
                loading: true,
                error: null
            }
        case ActionType.FETCH_DATA_BYPARAM_SUCCESS:
            return {
                ...state,
                loading: false,
                itemsWithParam: action.payload,
            }
        case ActionType.FETCH_DATA_BYPARAM_FAILURE:
            return {
                ...state,
                loading: false,
                error: action.error
            }
        /* Save Data */
        case ActionType.SAVE_REQUEST:
            return {
                ...state,
                loading: true,
                error: null
            }
        case ActionType.SAVE_SUCCESS:
            return {
                ...state,
                loading: false,
                saveResponse: action.payload,
            }
        case ActionType.SAVE_FAILURE:
            return {
                ...state,
                loading: false,
                error: action.error
            }
        /* Save Data */
        case ActionType.UPDATE_REQUEST:
            return {
                ...state,
                loading: true,
                error: null
            }
        case ActionType.UPDATE_SUCCESS:
            return {
                ...state,
                loading: false,
                updateResponse: action.payload,
            }
        case ActionType.UPDATE_FAILURE:
            return {
                ...state,
                loading: false,
                error: action.error
            }
        /* File upload */
        case ActionType.FILE_UPLOAD_REQUEST:
            return {
                ...state,
                loading: true,
                error: null
            }
        case ActionType.FILE_UPLOAD_SUCCESS:
            return {
                ...state,
                loading: false,
                fileUploadResponse: action.payload,
            }
        case ActionType.FILE_UPLOAD_FAILURE:
            return {
                ...state,
                loading: false,
                error: action.error
            }
        /* File download */
        case ActionType.FILE_DOWNLOAD_REQUEST:
            return {
                ...state,
                loading: true,
                error: null
            }
        case ActionType.FILE_DOWNLOAD_SUCCESS:
            return {
                ...state,
                loading: false,
                fileDlownloadResponse: action.payload,
            }
        case ActionType.FILE_DOWNLOAD_FAILURE:
            return {
                ...state,
                loading: false,
                error: action.error
            }
        default:
            return state;
    }
}
export default BasicFormReducer;