import * as ActionType from "../../constant"

const initState = {
    user: [],
    items: [],
    token: null,
    currentUser: null,
    loading: false,
    error: null,
    useraccess:[]
}

/**
 * LoginReducer
 * @param {*} state 
 * @param {*} action 
 * @returns 
 */
const LoginReducer = (state = initState, action) => {
    const data = action.payload;
    switch (action.type) {
        case ActionType.LOGIN_REQUEST:
            return {
                ...state,
                loading: true,
                error: null,
                token: null,
                currentUser: null
            }
        case ActionType.LOGIN_SUCCESS:
            return {
                ...state,
                loading: false,
                items: action.payload,
                token: data.token ? data.token : null,
                currentUser: data._id ? data._id : null,
                error: null
            }
        case ActionType.LOGIN_FAILURE:
            return {
                ...state,
                loading: false,
                error: action.payload
            }         
        default:
            return state;
    }

}

export default LoginReducer;

