import * as ActionType from "../../constant"
const initState = {
    items: [],
    emailConfirmResponse: [],
    loading: false,
    error: null
}

const resetPasswordReducer = (state = initState, action) => {
    switch (action.type) {
        case ActionType.RESETPASSWORD_REQUEST:
            return {
                ...state,
                loading: true,
                error: null
            }
        case ActionType.RESETPASSWORD_SUCCESS:
            return {
                ...state,
                loading: false,
                items: action.payload,
            }
        case ActionType.RESETPASSWORD_FAILURE:
            return {
                ...state,
                loading: false,
                error: action.payload
            }
        case ActionType.EMAIL_CONFIRMATION_REQUEST:
            return {
                ...state,
                loading: true,
                error: null
            }
        case ActionType.EMAIL_CONFIRMATION_SUCCESS:
            return {
                ...state,
                loading: false,
                emailConfirmResponse: action.payload,
            }
        case ActionType.EMAIL_CONFIRMATION_FAILURE:
            return {
                ...state,
                loading: false,
                error: action.payload
            }
        default:
            return state;
    }
}

export default resetPasswordReducer;

