import basicTableReducer from './BasicTableReducer';
import basicFormReducer from './BasicFormReducer';
import InventoryReducer from './InventoryReducer';
import LoginReducer from './LoginReducer';
import ResetPasswordReducer from './ResetPasswordReducer';
import OrderReducer from './OrderReducer';

export default { 
  basicTableReducer ,
  basicFormReducer,
  InventoryReducer,
  LoginReducer,
  ResetPasswordReducer,
  OrderReducer
};
