import * as ActionType from "../../constant";
/*
 *Set initial state 
 */
const initState = {
    medicineDataFinal: [],
    item: [],  
    loading: false,
    error: null,
}

/**
 * InventoryReducer
 * @param {*} state 
 * @param {*} action 
 * @returns 
 */
const InventoryReducer = (state = initState, action) => {
    switch (action.type) {
        case ActionType.SET_MEDICINE_DATA:
            return {
                ...state,
                medicineDataFinal: action.payload,
            }
        /* Post to cart*/
        case ActionType.ORDER_POSTTOCART_REQUEST:
            return {
                ...state,
                loading: true,
                error: null
            }
        case ActionType.ORDER_POSTTOCART_SUCCESS:
            return {
                ...state,
                loading: false,
                item: action.payload,
            }
        case ActionType.ORDER_POSTTOCART_FAILURE:
            return {
                ...state,
                loading: false,
                error: action.error
            }     
        default:
            return state;
    }
}
export default InventoryReducer;
