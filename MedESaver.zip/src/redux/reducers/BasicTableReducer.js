import * as ActionType from "../../constant";
/*
 *Set initial state 
 */
const initState = {
    items: [],
    itemsList: [],
    itemsById: [],
    totalDataCount: 0,
    loading: false,
    error: null,
    saveResponse: [],
    updateResponse: [],
    deleteResponse: [],
    reportResponse: [],
}

/**
 * BasicReducer
 * @param {*} state 
 * @param {*} action 
 * @returns 
 */
const BasicReducer = (state = initState, action) => {
    switch (action.type) {
        /* Fetch Data */
        case ActionType.FETCH_DETAILS_REQUEST:
            return {
                ...state,
                loading: true,
                error: null
            }
        case ActionType.FETCH_DETAILS_SUCCESS:
            return {
                ...state,
                loading: false,
                items: action.payload,
                totalDataCount: action.totalData
            }
        case ActionType.FETCH_DETAILS_FAILURE:
            return {
                ...state,
                loading: false,
                error: action.error
            }
        /* Delete Data */
        case ActionType.DELETE_REQUEST:
            return {
                ...state,
                loading: true,
                error: null
            }
        case ActionType.DELETE_SUCCESS:
            return {
                ...state,
                loading: false,
                deleteResponse: action.payload,
            }
        case ActionType.DELETE_FAILURE:
            return {
                ...state,
                loading: false,
                error: action.error
            }
        default:
            return state;
    }
}
export default BasicReducer;