import * as ActionType from "../../constant";
/*
 *Set initial state 
 */
const initState = {
    item: [],    
    loading: false,
    error: null,    
}

/**
 * InventoryReducer
 * @param {*} state 
 * @param {*} action 
 * @returns 
 */
const InventoryReducer = (state = initState, action) => {
    switch (action.type) {

        /* Fetch Medicine List*/
        case ActionType.GET_SEARCH_MEDICINE_REQUEST:
            return {
                ...state,
                loading: true,
                error: null
            }
        case ActionType.GET_SEARCH_MEDICINE_SUCCESS:
            return {
                ...state,
                loading: false,
                item: action.payload,
            }
        case ActionType.GET_SEARCH_MEDICINE_FAILURE:
            return {
                ...state,
                loading: false,
                error: action.error
            }       
        default:
            return state;
    }
}
export default InventoryReducer;
