import React from "react";
import {
    Dialog,    
    DialogContent,
    DialogActions,
    Button,
    makeStyles,
    Slide
} from "@material-ui/core";
import clsx from "clsx";
import red from "@material-ui/core/colors/red";
import { blue, blueGrey } from "@material-ui/core/colors";
import { Form, FormGroup, Col } from 'reactstrap';

const useStyles = makeStyles(() => ({
    dialog: {
        borderRadius: 12,
        width: '40% !important'
    },
    button: {
        borderRadius: 24,
        textTransform: "none",
        padding: 5,
        height: '48.29px',
        width:'30%'
    },
    select: {
        color: "#fff",
        backgroundColor: blue[500],
        "&:hover": {
            backgroundColor: blue[700]
        }
    },
    cancel: {
        color: "#fff",
        backgroundColor: blueGrey[500],
        "&:hover": {
            backgroundColor: blueGrey[700]
        }
    },
    content: {
        color: red[700]
    }
}));

const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />;
});

//const SessionTimeoutDialog = ({  open, countdown, onLogout,onContinue }) => {
const CustomerDataDialog = ({ open, data, onSelect, onCancel }) => {
    const classes = useStyles();

    return (
        <Dialog
            open={open}
            classes={{ paper: classes.dialog }}
            TransitionComponent={Transition}>
            <DialogContent>
                <ul className="list-group list-group-light">
                    <li className="list-group-item d-flex justify-content-between align-items-center">
                        <div className="d-flex align-items-center">
                            <img src={data.image} alt="" style={{ width: '65px', height: '55px' }}
                                className="rounded-circle" />
                            <div className="ml-3 ms-3 text-left">
                                <p className="fw-bold mb-1 ctm-data-head">{data.customerName}</p>
                                <p className="mb-1 ctm-data-id">{data.id}</p>
                                <p className="mb-0 ctm-data-content-1">{data.data}</p>
                            </div>
                        </div>
                    </li>
                </ul>
                <Form className="mt-2">
                    <FormGroup row>
                        <label className="ctm-data-content-2 col-lg-3">Phone No</label>                       
                        <Col className="col-lg-8">
                            <label className="ctm-data-phn">911234567812</label>                            
                        </Col>
                    </FormGroup>
                    <FormGroup row>
                        <label className="ctm-data-content-2 col-lg-3">Heading</label>                    
                        <Col className="col-lg-8">
                            <label className="ctm-data-content-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</label>                           
                        </Col>
                    </FormGroup>
                    <FormGroup row>
                        <label className="ctm-data-content-2 col-lg-3">Heading</label>
                        <Col className="col-lg-8">
                            <label className="ctm-data-content-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</label> 
                        </Col>
                    </FormGroup>
                </Form>
            </DialogContent>
            <DialogActions>
                <Button
                    onClick={onSelect}
                    variant="contained"
                    className={clsx(classes.select, classes.button)}
                >
                    Select
                </Button>
                <Button
                    onClick={onCancel}
                    color="primary"
                    variant="contained"
                    className={clsx(classes.cancel, classes.button)}
                > Cancel
                </Button>

            </DialogActions>
        </Dialog>
    );
}


export default CustomerDataDialog;