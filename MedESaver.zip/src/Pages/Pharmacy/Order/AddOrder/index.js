import React, {Fragment} from 'react'
import AddOrder from './AddOrder' ;

/**AddOrderRequest Index*/
function AddOrderRequest(){
        return (
            <Fragment>
               <AddOrder/>
            </Fragment>
        )    
}
export default AddOrderRequest;