import React, { useState, Fragment } from 'react';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import PageTitle from '../../../../Layout/AppMain/PageTitle';
import { Row, Col,  Input, Label } from 'reactstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faSearch } from '@fortawesome/free-solid-svg-icons';
import * as Constant from "../../../../constant";
import '../../../../css/Pharmacy.css';
/** customer data dialog */
import CustomerDataDialog from './CustomerDataDialog'

/**AddOrderList */
function AddOrderList() {   

    const [showCustomerData, setShowCustomerData] = useState(false);

    const [customersList, setCustomersList] = useState([{ id: 'ID1245427', customerName: 'John', medicine_id: 'ID124143', data: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.', image: '/images/avatars/001.png' },
    { id: 'ID1245427', customerName: 'Michel', medicine_id: 'ID537856', data: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.', image: '/images/avatars/001.png' },
    { id: 'ID1245427', customerName: 'Sumi', medicine_id: 'ID124143', data: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.', image: '/images/avatars/001.png' },
    { id: 'ID1245427', customerName: 'Anju', medicine_id: 'ID124143', data: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. ', image: '/images/avatars/001.png' },
    { id: 'ID1245427', customerName: 'Anju', medicine_id: 'ID124143', data: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. ', image: '/images/avatars/001.png' },
    { id: 'ID1245427', customerName: 'Anju', medicine_id: 'ID124143', data: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. ', image: '/images/avatars/001.png' },
    ]);

    const funShowCustomerData = () => {
        setShowCustomerData(true);
    }

    const funcSelectCustomer = () => {
        //setShowCustomerData(true);
    }

    const funcCancelCustomer = () => {
        setShowCustomerData(false);
    }


    return (
        <Fragment>
            <PageTitle heading={Constant.ORDER_ADD_PAGE_TITTLE} />
            <ReactCSSTransitionGroup
                component="div"
                transitionName="TabsAnimation"
                transitionAppear={true}
                transitionAppearTimeout={0}
                transitionEnter={false}
                transitionLeave={false}>
                <div>
                    <Row className='mt-3'>
                        <Col md="1">
                            <Label className="mb-1 customer-head">{Constant.ORDER_CUSTOMER_TXT}</Label>
                        </Col>
                        <Col md="11">
                            <div className="input-group"><div className="input-group-prepend">
                                <span className="input-group-text search-input-span">
                                    <FontAwesomeIcon className="opacity-8" icon={faSearch} style={{ color: "rgb(89 182 236)" }} />
                                </span></div><Input placeholder={Constant.ORDER_SEARCH_TXT} type="text" className='search-input' /></div>
                        </Col>
                        <Col md="12 mt-3 bcg-clr-e8f4ff">
                            <h4 className='card-title mt-3 mb-2 text-left'>{Constant.ORDER_RECENT}</h4>
                            <div className='card div-customer-item-list'>
                                <div className='card-content'>
                                    <div className='card-body p-0'>
                                        <ul className="list-group list-group-light">
                                            {customersList.map((data) => (
                                                <li className="list-group-item d-flex justify-content-between align-items-center">
                                                    <div className="d-flex align-items-center">
                                                        <img src={data.image} alt="" style={{ width: '65px', height: '55px' }}
                                                            className="rounded-circle" />
                                                        <div className="ml-3 ms-3 text-left">
                                                            <p className="fw-bold ctm-data-head mb-1">{data.customerName}</p>
                                                            <p className="mb-0 ctm-data-id">{data.id}</p>
                                                            <p className="text-muted mb-0">{data.data}</p>
                                                        </div>
                                                    </div>
                                                    <a className="btn btn-link btn-rounded btn-sm text-primary" onClick={funShowCustomerData} role="button"><FontAwesomeIcon className="ml-2 opacity-8 text-info mr-1" icon={faEye} />{Constant.ORDER_VIEW}</a>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </Col>
                    </Row>
                    <CustomerDataDialog
                        open={showCustomerData}
                        data={{ id: 'ID1245427', customerName: 'Anju', medicine_id: 'ID124143', data: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. ', image: '/images/avatars/001.png' }}
                        onSelect={funcSelectCustomer}
                        onCancel={funcCancelCustomer}
                    />
                </div>
            </ReactCSSTransitionGroup>
        </Fragment>
    )

}
export default AddOrderList