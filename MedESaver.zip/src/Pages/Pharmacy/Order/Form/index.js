import React, {Fragment} from 'react'
import OrderEdit from './OrderEdit' ;

/**OrderAccept Index*/
function OrderAccept(){
        return (
            <Fragment>
               <OrderEdit/>
            </Fragment>
        )    
}
export default OrderAccept;