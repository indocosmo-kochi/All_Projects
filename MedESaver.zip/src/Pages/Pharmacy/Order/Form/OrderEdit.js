import React, { Fragment, useEffect, useState } from 'react';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import PageTitle from '../../../../Layout/AppMain/PageTitle';
import { Form, FormGroup, Row, Col, Card, CardBody, Label, Button, ListGroup, ListGroupItem, ListGroupItemHeading, ListGroupItemText, Input } from 'reactstrap';
import { fetchDataByParamAction, updateAction, funFileDownload } from '../../../../Function/Form/FormAction';
import * as Constant from "../../../../constant";
import { useHistory } from "react-router-dom";
import { useDispatch, useStore } from 'react-redux';
import * as commonFunction from '../../../../Function/getGlobalVariable';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPhone, faDownload, faSearch, faTrash, faSearchPlus, faSearchMinus, faArrowsAlt } from '@fortawesome/free-solid-svg-icons';
/** defualt image */
import defaultImage from "../../../../assets/utils/images/noImage.png";
/** dialog */
import ConfirmDailog from '../../../../Function/ConfirmDailog'
/** medicne add */
import { Typeahead, Menu, MenuItem } from 'react-bootstrap-typeahead';
/** Get Search Medicine List */
import { funGetSearchMedicine } from '../../../../redux/action/InventoryAction'
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader  
/**image */
import { Carousel } from 'react-responsive-carousel';
import { TransformWrapper, TransformComponent } from "react-zoom-pan-pinch";
/**selected medicine data  */
import MedicineAddDialog from '../Cart/MedicineAddDialog';


/**OrderEdit */
function OrderEdit() {

    const history = useHistory();
    const dispatch = useDispatch();
    const store = useStore();

    /**Pharmacy Id */
    const pharamcyId = commonFunction.getPharmacyId();

    const [orderId, setOrderId] = useState('');
    const [status, setStatus] = useState('');
    const [pharmacyAacceptStatus, setPharmacyAacceptStatus] = useState('');
    const [medicineSlipImg, SetMedicineSlipImg] = useState([]);
    const [medicineSlipImgName, setMedicineSlipImgName] = useState('Prescription-image.jpeg');
    const [orderUserId, setOrderUserId] = useState('');
    const [medicineData, setMedicineData] = useState([]);
    const [customerPhNo, setCustomerPhNo] = useState();
    const [note, setNote] = useState('');
    const [isAccept, setIsAccept] = useState(false);
    /**Dialog box */
    const [dialogText, setDialogText] = useState('');
    const [showConfirm, setShowConfirm] = useState(false);
    const [dialogState, setDialogState] = useState(false);
    const [isConfirm, setIsConfirm] = useState(false);
    /** search medicine */
    const [medicineList, setMedicineList] = useState([]);
    const [selected, setSelected] = useState([]);
    const [selectedMedicine, setSelectedMedicine] = useState({});
    const [showMedicineData, setShowMedicineData] = useState(false);
    const [openMediciceList, setOpenMediciceList] = useState(false);

    /** set confirm box */
    useEffect(() => {
        setShowConfirm(dialogState);
    }, [dialogState]);

    /**set dialog box */
    useEffect(() => {
        const funcWindowload = async () => {
            let row_id = sessionStorage.getItem('row_id');
            let order_id = sessionStorage.getItem('order_id');
            if (row_id !== "" && row_id !== undefined && row_id !== null) {
                setOrderId(order_id);
                await funGetOrderDataByParam({ "order_id": order_id });
            } else {

            }
        }
        funcWindowload();
    }, []);


    /** get data of medicine */
    const funGetOrderDataByParam = async (params) => {
        let param_pharmacy_id = { "pharmacy_id": pharamcyId };
        let param = { ...param_pharmacy_id, ...params }
        const response = await fetchDataByParamAction(dispatch, store, Constant.API_GET_ORDER_DATA, param);
        if (response.error) {
            funSetDialog(<span style={{ color: 'red' }}>{response.itemsList.message}</span>, false, true);
        } else {
            funSetOrderValues(response.itemsList);
        }
    }

    /** set medicine data */
    const funSetOrderValues = (rowData) => {
        /** Order Data */
        let orderDetails = rowData.order_details;
        setStatus(orderDetails[0].status);
        setNote(orderDetails[0].notes);
        SetMedicineSlipImg(orderDetails[0].prescription_images);
        if(orderDetails[0].prescription_images !== null){
            const imgName = orderDetails[0].prescription_images[0].split(/[\s/]+/)
            setMedicineSlipImgName(imgName[imgName.length - 1]);
        }  
        setOrderUserId(orderDetails[0].user_id);
        setPharmacyAacceptStatus(orderDetails[0].pharmacy_accept_status);
        setCustomerPhNo(orderDetails[0].customer_phone_no);

        /** Medicine Data */
        let medicineDetails = orderDetails[0].medicines.map((e) => ({
            medicine_id: e.id,
            name: e.name,
            amount: e.amount,
            qty: e.quantities,
            price: e.amount,
            imageUrl: e.imageUrl,
        }));
        setMedicineData(medicineDetails);
    }

    /** function accept order data */
    const funOrderAccept = () => {
        if (funMedicineListValidation()) {
            setIsAccept(true);
            funSetDialog('Confirm Accepting this order?', true, true);
        } else {
            funSetDialog(<span style={{ color: 'red' }}>Please add medicine data</span>, false, true);
        }
    }

    /** function reject order data */
    const funOrderReject = async () => {
        setIsAccept(false);
        funSetDialog('Confirm Rejecting this order?', true, true);
    }    

    /** function cancel order data */
    const funOrderCancel = () => {
        if(isAccept && pharmacyAacceptStatus === 1){
            sessionStorage.setItem("order_id",orderId);           
            history.push({ pathname: '/Pharmacy/Order/Cart', state: orderId });
        }else{
            setDialogState(false);
        }       
    }

    /** medicine list validation */
    const funMedicineListValidation = () => {
        let orderIsValid = true;
        if (medicineData.length <= 0) {
            orderIsValid = false;
        } else {
            orderIsValid = true;
        }
        return orderIsValid;
    }

    /** function accept order data confirm */
    const funOrderAcceptConfirm = async () => {
        if (isAccept) {
            let medicineItems = medicineData.map((e) => ({
                medicine_id: e.medicine_id,
                qty: e.qty
            }));
            let param = {
                "user_id": orderUserId,
                "order_medicines": medicineItems,
                "order_id": orderId,
                "pharmacy_id": pharamcyId
            };
            await funUpdateOrderData(param, Constant.API_ACCEPT_ORDER, true);
        } else {
            let param = {
                "pharmacy_id": pharamcyId,
                "order_id": orderId
            }
            await funUpdateOrderData(param, Constant.API_REJECT_ORDER, false);
        }
    }

    /**
     * funUpdateOrderData
     * @param {*} param 
     * @param {*} API 
     * @param {*} isAccept 
     */
    const funUpdateOrderData = async (param, API, isAccept) => {
        const response = await updateAction(param, dispatch, store, API);
        if (response.error) {
            setPharmacyAacceptStatus(0);
            funSetDialog(<span style={{ color: 'red' }}>{response.setNotificationMessage.message}</span>, false, true);
        } else {
            if (isAccept) {
                setPharmacyAacceptStatus(1);
                funSetDialog(<span style={{ color: 'green' }}>{orderId} : Order Accepted successfully</span>, false, true);
            } else {
                setPharmacyAacceptStatus(-1);
                funSetDialog(<span style={{ color: 'green' }}>{param.order_id} : Order Rejected successfully</span>, false, true);
            }
        }
    }

    /** set dailog */
    const funSetDialog = (text, isConfirm, state) => {
        setDialogText(text);
        setIsConfirm(isConfirm);
        setDialogState(state);
    }

    /**set sttatus */
    const setFormStatus = () => {
        if (status === 0 && pharmacyAacceptStatus === 0) {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg badge-danger pull-right badge-status-new-form">{Constant.ORDER_STATUS_NEW}</div></div>);
        } else if (status === 0 && pharmacyAacceptStatus === 1) {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg badge-danger pull-right badge-status-inprogress-form">{Constant.ORDER_STATUS_INPROGRESS}</div></div>);
        } else if (status === 0 && pharmacyAacceptStatus === -1) {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg badge-warning pull-right badge-status-rejected-form">{Constant.ORDER_STATUS_REJECT}</div></div>);
        } else if (status === 1 && pharmacyAacceptStatus === 1) {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg badge-danger pull-right badge-status-success-form">{Constant.ORDER_STATUS_SUCCESS}</div></div>);
        } else if (status === 2 && pharmacyAacceptStatus === 1) {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg badge-danger pull-right badge-status-rejected-form">{Constant.ORDER_STATUS_FAILED}</div></div>);
        } else {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg badge-danger pull-right badge-status-new-form">{Constant.ORDER_STATUS_PENDING}</div></div>);
        }
    }

    /** Download Image */
    const funDownloadImage = async () => {
        let param = { "file_name": medicineSlipImgName }
        const response = await funFileDownload(dispatch, store, Constant.API_ORDER_PRISCRIPTION_DWLD, param);
        if (response.error) {
            funSetDialog(<span style={{ color: 'red' }}>{medicineSlipImgName} : {response.setNotificationMessage.message}</span>, false, true);
        } else {
            const originalImage = response.itemsList;
            const url = window.URL.createObjectURL(new Blob([originalImage]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', param.file_name);
            document.body.appendChild(link);
            link.click();
        }
    }

    const medicineRef = React.useRef();
    /**
     * function for get medicien search
     * @param {} medicine 
     */
    const funChangeMedicineInput = async (medicine) => {
        if (medicine !== '') {
            setOpenMediciceList(false);
            let medicineItems;
            let param = {
                "search_name": medicine,
                "pagination_limit": 20,
                "pharmacy_id": pharamcyId,
                "offset_id": 0
            }
            let response = {};
            if (medicine.trim() !== undefined && medicine.trim() !== null && medicine.trim() !== '') {
                await dispatch(funGetSearchMedicine(param, Constant.API_SEARCH_MEDICINE), [dispatch]);
                const actionState = store.getState();
                response = actionState.InventoryReducer;
                if (response.error) {
                    setMedicineList([]);
                } else {
                    medicineItems = response.item.message.map((e) => ({
                        id: e.id,
                        label: e.name,
                        image: e.imageUrl,
                        price: (e.price === "" ? 0 : e.price)
                    }));
                    setMedicineList(medicineItems);
                }
                setOpenMediciceList(true);
            } else {
                setMedicineList([]);
            }
        } else {
            setMedicineList([]);
            setOpenMediciceList(false);
        }
    }

    /** serach medicine name onchange */
    const onChangeMedicineName = async (name) => {
        setSelected(name);
        setOpenMediciceList(false);
        let selectedMedicine = {
            medicine_id: name[0].id,
            name: name[0].label,
            amount: name[0].price,
            qty: 1,
            price: name[0].price,
            imageUrl: name[0].image,
        };
        setSelectedMedicine(selectedMedicine);
        setShowMedicineData(true);
    }

    /** select mediicne */
    const funAddToMedicne = async (qty) => {
        setShowMedicineData(false);
        selectedMedicine.qty = qty;
        selectedMedicine.price = qty * selectedMedicine.amount;
        let isAlreadyExist = medicineData.findIndex(obj => obj.medicine_id === selectedMedicine.medicine_id);
        if (isAlreadyExist === -1) {
            let selectedMedicineList = [...medicineData, { ...selectedMedicine }]
            await dispatch({ type: Constant.SET_MEDICINE_DATA, payload: selectedMedicineList }, [dispatch]);
            const actionState = store.getState();
            const fetchResponse = actionState.OrderReducer;
            setMedicineData(fetchResponse.medicineDataFinal);
            setSelected([]);
            setMedicineList([]);
        } else {
            funSetDialog(selectedMedicine.name + ": This medicine has already added", false, true);
        }
    }

    /** cancel mediicne from cart */
    const funCancelAddMedicine = async () => {
        setShowMedicineData(false);
        setSelected([]);
        setMedicineList([]);
    }

    /** funRemoveMedicine from cart */
    const funRemoveMedicine = async (id) => {
        await dispatch({ type: Constant.SET_MEDICINE_DATA, payload: medicineData.filter(item => item.medicine_id !== id) }, [dispatch]);
        const actionState = store.getState();
        const fetchResponse = actionState.OrderReducer;
        setMedicineData(fetchResponse.medicineDataFinal);
    }

    /**nlote */
    const funOnchangeNote = (event) =>{        
        let val = event.target.value;
        setNote(val);
    }

    /**set Image name */
    const funGetSlipName = (imgIndex) => {    
        const imgName = medicineSlipImg[imgIndex].split(/[\s/]+/)        
        setMedicineSlipImgName(imgName[imgName.length - 1]);
    }

    return (
        <Fragment>
            <PageTitle heading={Constant.ORDER_PAGE_TITTLE} />
            <ReactCSSTransitionGroup
                component="div"
                transitionName="TabsAnimation"
                transitionAppear={true}
                transitionAppearTimeout={0}
                transitionEnter={false}
                transitionLeave={false}>
                <div>
                    <Row>
                        <Col md="12">
                            <Form id="order">
                                <FormGroup row>
                                    <Col lg={{ size: 5 }}>
                                        <Label className="mt-2" style={{ fontSize: '15px' }}>#{orderId}</Label>
                                        <p className='order-edit-sub-txt-1'>Please accept/reject the order.</p>
                                    </Col>
                                    {/* <Col lg={{ size: 3 }}>
                                    <Label className="pull-right" style={{ fontSize: '15px' }}><FontAwesomeIcon className="opacity-8" icon={faPhone} style={{ color: "rgb(255 255 255)", fontSize: 'smaller' }} />{customerPhNo}</Label>
                                    </Col> */}
                                    <Col lg={{ size: 7 }}>
                                        <Button id='orderCall' className="pull-right contact-btn" size="sm" disabled>
                                            {customerPhNo} {' '}
                                            <FontAwesomeIcon className="opacity-8" icon={faPhone} style={{ color: "rgb(73 88 102)", fontSize: 'smaller' }} />
                                        </Button>
                                        {setFormStatus()}
                                    </Col>
                                </FormGroup>
                            </Form>
                        </Col>
                    </Row>
                    <Card className="main-card mb-3">
                        <CardBody>
                            <Row>
                                <Col lg="12">
                                    <label lg={12} className='mb-3 order-edit-sub-txt-2'>You can Add and delete the items here.</label>
                                </Col>
                                <Col md="5">
                                    <h4 className='mb-3 order-edit-prescription'>{Constant.ORDER_PRESCRIPTION}</h4>
                                    <Col lg="12">
                                        <div className="card add-product-card img-card" >
                                            <div className="card-body d-flex flex-column">
                                                <div className="card-text">
                                                    {medicineSlipImg !== null && medicineSlipImg !== undefined && medicineSlipImg !== '' ?
                                                        <React.Fragment>
                                                            <TransformWrapper>
                                                                {({ zoomIn, zoomOut, resetTransform, ...rest }) => (
                                                                    <Row>
                                                                        <Col lg={12}>
                                                                            <div className="tools pull-right">
                                                                                <Button className="mb-2 mr-0 border-0 btn-transition" size="md"
                                                                                    color="link" onClick={() => zoomIn()}><FontAwesomeIcon className="opacity-8" icon={faSearchPlus} style={{ color: "#5c5391" }} /></Button>
                                                                                <Button className="mb-2 mr-0 border-0 btn-transition" size="md"
                                                                                    color="link" onClick={() => zoomOut()}><FontAwesomeIcon className="opacity-8" icon={faSearchMinus} style={{ color: "#5c5391" }} /></Button>
                                                                                <Button className="mb-2 mr-0 border-0 btn-transition" size="md"
                                                                                    color="link" onClick={() => resetTransform()}><FontAwesomeIcon className="opacity-8" icon={faArrowsAlt} style={{ color: "#5c5391" }} /></Button>
                                                                            </div>
                                                                        </Col>
                                                                        <Col lg={12}>
                                                                            <TransformComponent width='100%' style={{ display: 'block' }}>
                                                                                <Carousel showThumbs={false} autoPlay={false} infiniteLoop={false} onChange={(e) => funGetSlipName(e)}>
                                                                                    {medicineSlipImg.map((data) => (
                                                                                        <div>
                                                                                            <img src={data} className='rounded mx-auto d-block w-100' alt='' width='100%' height='276px' />
                                                                                        </div>
                                                                                    ))}
                                                                                </Carousel>
                                                                            </TransformComponent>
                                                                        </Col>
                                                                    </Row>
                                                                )}
                                                            </TransformWrapper></React.Fragment>
                                                        : <img src={defaultImage} className='rounded mx-auto d-block w-100' alt='' style={{ height: '276px' }} />}
                                                </div>
                                            </div>
                                        </div>
                                    </Col>
                                    {medicineSlipImg !== null && medicineSlipImg !== undefined && medicineSlipImg !== '' ?
                                        <Col lg="12">
                                            <ListGroup>
                                                <ListGroupItem style={{ paddingBottom: '0px' }} className='bcg-clr-e8f4ff'>
                                                    <ListGroupItemHeading style={{ fontSize: '14px' }} className='order-edit-list-hd'>
                                                        Customer prescription
                                                        <div className='pull-right'><Button className="btn-rounded pull-right order-slip-download-btn" size="sm" onClick={funDownloadImage}>
                                                            <FontAwesomeIcon className="opacity-8" icon={faDownload} style={{ color: "rgb(115 147 212)" }} /> Download</Button>
                                                        </div>
                                                    </ListGroupItemHeading>
                                                    <ListGroupItemText style={{ fontSize: '12px', marginBottom: '5px' }}>{medicineSlipImgName}
                                                    </ListGroupItemText>
                                                </ListGroupItem>
                                            </ListGroup>
                                        </Col>
                                        : null}
                                    <Col lg="12" className='mt-2'>
                                        <Label for="additionalNote" lg={12} className='pl-0'> {Constant.ORDER_ADDITIONAL_DESCRIPTION}</Label>
                                        <Input type="textarea" name="additionalNote" value={note} onChange={funOnchangeNote}></Input>
                                    </Col>
                                </Col>
                                <Col md="7">
                                    {status === 0 && pharmacyAacceptStatus === -1 ? null :
                                        <Typeahead
                                            open={openMediciceList}
                                            id="name"
                                            align='justify'
                                            onInputChange={funChangeMedicineInput}
                                            onChange={onChangeMedicineName}
                                            options={medicineList}
                                            selected={selected}
                                            emptyLabel={<span style={{ color: 'red' }}>No matches found.</span>}
                                            placeholder={Constant.ORDER_ITEM_ADD_IN_CART_SAERCH}
                                            renderInput={({ inputRef, referenceElementRef, ...inputProps }) => {
                                                return (
                                                    <div className="input-group">
                                                        <Input style={{ borderRight: 0, borderRadius: 0 }}
                                                            {...inputProps}
                                                            ref={(input) => {
                                                                inputRef(input);
                                                                //referenceElementRef(input);
                                                            }}
                                                        />
                                                        <div className="input-group-append">
                                                            <span className="input-group-text search-input-span">
                                                                <FontAwesomeIcon className="opacity-8" icon={faSearch} style={{ color: "rgb(89 182 236)" }} />
                                                            </span>
                                                        </div>
                                                    </div>
                                                );
                                            }}
                                            renderMenu={(results, menuProps) => (
                                                <Menu {...menuProps} style={{ padding: 0 }}>
                                                    {results.map((option, position) => (
                                                        <MenuItem option={option} position={position} key={`${option}_${position}`} style={{ padding: 0 }}>
                                                            <ul className="list-group list-group-light">
                                                                <li className="list-group-item d-flex justify-content-between align-items-center">
                                                                    <div className="d-flex align-items-center w-100">
                                                                        {option.imageUrl !== null && option.imageUrl !== undefined && option.imageUrl !== '' ?
                                                                            <img src={option.imageUrl} className='rounded-circle' alt='' style={{ width: '50px', height: '50px' }} />
                                                                            : <img src={defaultImage} className='rounded-circle' alt='' style={{ width: '50px', height: '50px' }} />}
                                                                        <div className='pl-2 w-100'>
                                                                            <p className="fw-bold mb-1 ctm-data-head">{option.label}</p>
                                                                            <p className="mb-1 ctm-data-id">₹{option.price}</p>
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                            </ul>
                                                        </MenuItem>
                                                    ))}
                                                </Menu>
                                            )}
                                            ref={medicineRef}
                                        />}
                                    <h4 className='mb-3 order-edit-item'>{Constant.ORDER_ITEM}</h4>
                                    <div className='div-order-item-list bcg-clr-e8f4ff'>
                                        {medicineData.map((data) => (
                                            <ListGroup key={data.medicine_id}>
                                                <ListGroupItem style={{ paddingBottom: '0px' }} className='bcg-clr-e8f4ff'>
                                                    <ListGroupItemHeading style={{ fontSize: '14px' }} className='order-edit-list-hd'>
                                                        {data.name}
                                                        <div className='pull-right font-family-roboto' style={{ fontSize: '14px' }}>₹{data.price}</div>
                                                    </ListGroupItemHeading>
                                                    <ListGroupItemText style={{ fontSize: '12px', marginBottom: '5px' }}>{data.qty} Strips
                                                        {status === 0 && pharmacyAacceptStatus === -1 ? null : <ListGroupItemText className="pull-right" tag={Button} action="true" style={{ background: 'transparent', marginBottom: '5px', border: 0 }} onClick={(e) => funRemoveMedicine(data.medicine_id)}>
                                                            <FontAwesomeIcon className="opacity-8" icon={faTrash} style={{ color: "rgb(115 147 212)" }} />
                                                        </ListGroupItemText>}
                                                    </ListGroupItemText>
                                                </ListGroupItem>
                                            </ListGroup>
                                        ))}
                                    </div>
                                </Col>
                            </Row>
                            {(() => {
                                if (status === 0 && pharmacyAacceptStatus === -1) {
                                    return (null);
                                } else {
                                    return (<Row className='mt-5'>
                                        <Col lg="12">
                                            <Button id='cancel' color="dark" className="mb-2 mr-2 pull-right btn-style save-btn" size="lg" onClick={funOrderAccept}>{Constant.ORDER_ACCEPT_BTN}</Button>
                                            <Button id='save' color="dark" className="mb-2 mr-2 pull-right btn-style cancel-btn" size="lg" onClick={funOrderReject}>{Constant.ORDER_RECJECT_BTN}</Button>
                                        </Col>
                                    </Row>);
                                }
                            })()}
                        </CardBody>
                    </Card>
                    <ConfirmDailog
                        text={dialogText}
                        heading={''}
                        onYes={funOrderAcceptConfirm}
                        isConfirm={isConfirm}
                        onNo={funOrderCancel}
                        open={showConfirm}
                    />
                    <MedicineAddDialog
                        open={showMedicineData}
                        data={selectedMedicine}
                        onSelect={funAddToMedicne}
                        onCancel={funCancelAddMedicine}
                        qty={1}
                    />
                </div>
            </ReactCSSTransitionGroup>
        </Fragment>
    )
}
export default OrderEdit
