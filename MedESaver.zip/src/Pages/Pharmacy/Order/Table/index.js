import React, {Fragment} from 'react'
import Order from './Order' ;

/**Inventory Index*/
function TableOrder(){
        return (
            <Fragment>
               <Order/>
            </Fragment>
        )    
}
export default TableOrder;