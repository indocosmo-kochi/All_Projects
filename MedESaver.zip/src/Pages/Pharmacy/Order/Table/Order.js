import React, { useState, useCallback, Fragment } from 'react';
import { useDispatch, useStore } from 'react-redux';
import { useHistory } from "react-router-dom";
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import PageTitle from '../../../../Layout/AppMain/PageTitle';
import { Form, Alert, FormGroup, Row, Col, Card, CardBody, CardTitle, Label } from 'reactstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye } from '@fortawesome/free-solid-svg-icons';
import * as Constant from "../../../../constant";
import { Button, } from 'reactstrap';
import OrderTable from '../../../../Components/Table/MedESaverTable';
import { getTableData } from '../../../../Function/Table/TableFormAction';
import '../../../../css/Pharmacy.css';

/**Order */
function Order() {

  const history = useHistory();
  const dispatch = useDispatch();
  const store = useStore();

  const [notificationShow, setNotificationShow] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState({ 'message': '', 'className': '' });
  // const [searchProduct, setSearchProduct] = React.useState();
  const [data, setData] = React.useState([]);
  const [loading, setLoading] = React.useState(false);
  const [pageCount, setPageCount] = React.useState(1);
  const fetchIdRef = React.useRef(0);

  //Table Columns Settings
  const columns = React.useMemo(
    () => [
      {
        id: 'id',
        Header: 'id',
        accessor: 'id',
        isVisible: false,
      },
      {
        Header: 'Order ID',
        accessor: 'order_id',
      },
      {
        Header: 'Status',
        accessor: 'order_status',
        disableSortBy: true,
        Cell: ({ row }) => {
          if (row.original.order_status === 0 && row.original.pharmacy_accept_status === 0) {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg badge-status-new">{Constant.ORDER_STATUS_NEW}</div></div>);
          } else if (row.original.order_status === 0 && row.original.pharmacy_accept_status === 1) {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg badge-status-inprogress">{Constant.ORDER_STATUS_INPROGRESS}</div></div>);
          } else if (row.original.order_status === 0 && row.original.pharmacy_accept_status === -1) {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg badge-status-rejected">{Constant.ORDER_STATUS_REJECT}</div></div>);
          } else if (row.original.order_status === 1 && row.original.pharmacy_accept_status === 1) {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg badge-status-success">{Constant.ORDER_STATUS_SUCCESS}</div></div>);
          } else if (row.original.order_status === 2 && row.original.pharmacy_accept_status === 1) {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg badge-status-rejected">{Constant.ORDER_STATUS_FAILED}</div></div>);
          } else if (row.original.order_status === 3 && row.original.pharmacy_accept_status === 1) {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg badge-status-completed">{Constant.ORDER_STATUS_COMPLETED}</div></div>);
          }else {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg badge-status-inprogress">{Constant.ORDER_STATUS_PENDING}</div></div>);
          }
        }
      },
      {
        Header: 'Medicine',
        accessor: 'medicines',
      },
      {
        Header: <div style={{ textAlign: 'center' }}><FontAwesomeIcon className="ml-2 opacity-8 mr-1" icon={faEye} />{Constant.ORDER_VIEW}</div>,
        accessor: 'view',
        disableSortBy: true,
        Cell: ({ row }) => {
          return (<Button id='addOrder' className="pull-right view-button" size="md" onClick={() => funRowOnclick(row.original)}>
            <FontAwesomeIcon className="opacity-8" icon={faEye} />   {Constant.ORDER_VIEW}</Button>)
        }
      },
    ],
    []
  );

  /** table data view click */
  const funRowOnclick = (rowData) => {
    sessionStorage.setItem("row_id", rowData.id);
    sessionStorage.setItem("order_id", rowData.order_id);
    if ((rowData.order_status === 0 && rowData.pharmacy_accept_status === 0) ||
      (rowData.order_status === 0 && rowData.pharmacy_accept_status === -1)) {
      history.push({ pathname: '/Pharmacy/Order/Form', state: rowData.order_id });
    } else if ((rowData.order_status === 0 && rowData.pharmacy_accept_status === 1) ||
      (rowData.order_status === 1 && rowData.pharmacy_accept_status === 1) ||
      (rowData.order_status === 2 && rowData.pharmacy_accept_status === 1) ||
      (rowData.order_status === 3 && rowData.pharmacy_accept_status === 1)) {
      history.push({ pathname: '/Pharmacy/Order/Cart', state: rowData.order_id });
    } else {
      history.push({ pathname: '/Pharmacy/Order/Form', state: rowData.order_id });
    }
  };

  //set callback function for ser ver side pagination
  const paginationRef = React.useRef();
  const fetchData = async ({ pageSize, pageIndex, sort, filters }) => {
    paginationRef.current = { pageSize, pageIndex, sort, filters };
    const fetchId = ++fetchIdRef.current;
    setLoading(true);
    if (fetchId === fetchIdRef.current) {
      await funSetTableData(pageIndex, pageSize, sort, filters);
    }
    setLoading(false);
  }

  /** Function for fecth table data */
  const funSetTableData = useCallback(async (pageIndex, pageSize, sort, filterData, param) => {
    const tableData = await getTableData(pageIndex, pageSize, sort, filterData, dispatch, store, Constant.API_GET_ORDER_LIST, param);
    if (tableData.error) {
      setNotificationMessage(tableData.setNotificationMessage);
      setNotificationShow(true);
    } else {
      setPageCount(tableData.setPageCount);
      //set order data     
      setData(tableData.setData.orders);
    }
  });

  //Render Table with column and data
  const renderOrder = () => {
    return <OrderTable columns={columns} data={data} handleClick={null} fetchData={fetchData} loading={loading} pageCount={pageCount} isDisableFilter={true} isEditable={false} />
  };

  //hide notification message
  const onDismissNotification = () => {
    setNotificationShow(false);
  }

  return (

    <Fragment><PageTitle heading={Constant.ORDER_PAGE_TITTLE} />
      <ReactCSSTransitionGroup
        component="div"
        transitionName="TabsAnimation"
        transitionAppear={true}
        transitionAppearTimeout={0}
        transitionEnter={false}
        transitionLeave={false}>
        <div>
          <Row>
            <Col md="12"> <Card className="main-card mb-3">
              <CardBody>
                <CardTitle><Alert color={notificationMessage["className"]} isOpen={notificationShow} toggle={onDismissNotification}>
                  {notificationMessage["message"]}
                </Alert>
                </CardTitle>
                <Form id="order">
                  <FormGroup row>
                    <Col lg={{ size: 6 }}>
                      <Label className="mb-1 order-head">{Constant.ORDER_MOST_RECENT_REQUEST}</Label>
                    </Col>
                    {/*  <Col lg={{ size: 6 }}>
                      <Link to={{ pathname: '/Pharmacy/Order/AddOrder', state: '' }}><Button id='addProduct' className="btn-rounded pull-right add-button" size="lg"><FontAwesomeIcon className="opacity-8" icon={faPlus} style={{ color: "rgb(255 255 255)" }} /> | {Constant.ORDER_ADD_BTN}</Button>
                      </Link>
                    </Col> */}
                  </FormGroup>
                </Form>
                {renderOrder()}
              </CardBody>
            </Card></Col>
          </Row>
        </div>
      </ReactCSSTransitionGroup>
    </Fragment>
  )
}
export default Order