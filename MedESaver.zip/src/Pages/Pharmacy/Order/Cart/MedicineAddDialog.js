import React, { useState, useEffect } from "react";
import {
    Dialog,    
    DialogContent,
    DialogActions,
    Button,    
    makeStyles,
    Slide
} from "@material-ui/core";
import clsx from "clsx";
import red from "@material-ui/core/colors/red";
import { blue, blueGrey } from "@material-ui/core/colors";
import { Row, FormGroup, Col, ListGroup, ListGroupItem, ListGroupItemHeading, ListGroupItemText } from 'reactstrap';
import NumericInput from 'react-numeric-input';
/** defualt image */
import defaultImage from "../../../../assets/utils/images/noImage.png";

const useStyles = makeStyles(() => ({
    dialog: {
        borderRadius: 12,
        width: '30% !important'
    },
    button: {
        borderRadius: 24,
        textTransform: "none",
        padding: 5,
        height: '48.29px',
        width: '30%'
    },
    select: {
        color: "#fff",
        backgroundColor: blue[500],
        "&:hover": {
            backgroundColor: blue[700]
        }
    },
    cancel: {
        color: "#fff",
        backgroundColor: blueGrey[500],
        "&:hover": {
            backgroundColor: blueGrey[700]
        }
    },
    content: {
        color: red[700]
    }
}));

const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />;
});

//const SessionTimeoutDialog = ({  open, countdown, onLogout,onContinue }) => {
const MedicineAddDialog = ({ open, data, onSelect, onCancel, qty }) => {
    const classes = useStyles();
    const [stripCount, setStripCount] = useState(1);
    const [amount, setAmount] = useState(0);

    /** set confirm box */
    useEffect(() => {
        setStripCount(1);
    }, [open]);

    /** set confirm box */
    useEffect(() => {
        setAmount(data.amount);
    }, [data]);

    /** set confirm box */
    useEffect(() => {
        setAmount(stripCount * data.amount);
    }, [stripCount]);

    /** set Qty count */
    const funSetupMedicineQty = (qty) => {
        setStripCount(qty);
    }

    return (
        <Dialog
            open={open}
            classes={{ paper: classes.dialog }}
            TransitionComponent={Transition}>
            <DialogContent>
                <Row>
                    <Col lg="12">
                        <div className="card add-product-card img-card" >
                            <div className="card-body d-flex flex-column">
                                <div className="card-text">
                                    {data.imageUrl !== null && data.imageUrl !== undefined && data.imageUrl !== '' ?
                                        <img src={data.imageUrl} className='rounded mx-auto d-block w-100' alt='' style={{ height: '276px' }} />
                                        : <img src={defaultImage} className='rounded mx-auto d-block w-100' alt='' style={{ height: '276px' }} />}
                                </div>
                            </div>
                        </div>
                    </Col>
                    <Col lg="12">
                        <ListGroup>
                            <ListGroupItem style={{ paddingBottom: '0px' }} className='bcg-clr-e8f4ff'>
                                <ListGroupItemHeading style={{ fontSize: '20px' }} className='order-edit-list-hd mb-2'>
                                    {data.name}
                                </ListGroupItemHeading>
                                <ListGroupItemText style={{ fontSize: '12px', marginBottom: '5px' }}>
                                    <FormGroup row>
                                        <label className="ctm-data-content-2 col-lg-4">Price : </label>
                                        <Col className="col-lg-7">
                                            <label className="ctm-data-content-2">₹ {amount}</label>
                                        </Col>
                                    </FormGroup>
                                </ListGroupItemText>
                                <ListGroupItemText style={{ fontSize: '12px', marginBottom: '5px' }}>
                                    <FormGroup row>
                                        <label className="ctm-data-content-2 col-lg-4">Quantity : </label>
                                        <Col className="col-lg-7">
                                            <NumericInput mobile className="form-control" value={stripCount} min={1} onChange={funSetupMedicineQty}
                                                style={{
                                                    wrap: {
                                                        width: '100px'
                                                    },
                                                    input: {
                                                        border: '0'
                                                    },
                                                }}
                                            />
                                        </Col>
                                    </FormGroup>
                                </ListGroupItemText>
                            </ListGroupItem>
                        </ListGroup>
                    </Col>
                </Row>
            </DialogContent>
            <DialogActions>
                <Button
                    onClick={(e) => onSelect(stripCount)}
                    variant="contained"
                    className={clsx(classes.select, classes.button)}
                >
                    Add
                </Button>
                <Button
                    onClick={onCancel}
                    color="primary"
                    variant="contained"
                    className={clsx(classes.cancel, classes.button)}
                > Cancel
                </Button>

            </DialogActions>
        </Dialog>
    );
}


export default MedicineAddDialog;