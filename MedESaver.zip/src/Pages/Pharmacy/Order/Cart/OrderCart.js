import React, { Fragment, useEffect, useState } from 'react';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import PageTitle from '../../../../Layout/AppMain/PageTitle';
import { Form, FormGroup, Row, Col, Card, CardBody, Label, Button, ListGroup, ListGroupItem, ListGroupItemHeading, ListGroupItemText, Input } from 'reactstrap';
import { funFileDownload, fetchDataByParamAction, updateAction } from '../../../../Function/Form/FormAction';
import * as Constant from "../../../../constant";
import { useDispatch, useStore } from 'react-redux';
import * as commonFunction from '../../../../Function/getGlobalVariable';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPhone, faDownload, faSearch, faTrash, faSearchPlus, faSearchMinus, faArrowsAlt, faUpload } from '@fortawesome/free-solid-svg-icons';
/** defualt image */
import defaultImage from "../../../../assets/utils/images/noImage.png";
/** dialog */
import ConfirmDailog from '../../../../Function/ConfirmDailog';
import { postTocart } from '../../../../redux/action/OrderAction';
import { Typeahead, Menu, MenuItem } from 'react-bootstrap-typeahead';
/** Get Search Medicine List */
import { funGetSearchMedicine } from '../../../../redux/action/InventoryAction'
/** pdf view */
import { saveAs } from 'file-saver';
/**image */
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader  
import { Carousel } from 'react-responsive-carousel';
import { TransformWrapper, TransformComponent } from "react-zoom-pan-pinch";
import NumericInput from 'react-numeric-input';
/**selected medicine data  */
import MedicineAddDialog from './MedicineAddDialog';

/**OrderCart */
function OrderCart() {
   
    const dispatch = useDispatch();
    const store = useStore();

    /**Pharmacy Id */
    const pharamcyId = commonFunction.getPharmacyId();

    const ref = React.useRef();

    const [orderId, setOrderId] = useState('');
    const [deliveryType, setDeliveryType] = useState(0);
    const [status, setStatus] = useState('');
    const [note, setNote] = useState('');
    const [pharmacyAacceptStatus, setPharmacyAacceptStatus] = useState('');
    const [orderUserId, setOrderUserId] = useState('');
    const [medicineSlipImg, setMedicineSlipImg] = useState([]);
    const [medicineSlipImgName, setMedicineSlipImgName] = useState('');
    const [medicineData, setMedicineData] = useState([]);
    const [totalAmount, setTotalAmount] = useState(0);
    const [customerPhNo, setCustomerPhNo] = useState();
    const [file, setFile] = useState([]);
    /**Dialog box */
    const [dialogText, setDialogText] = useState('');
    const [showConfirm, setShowConfirm] = useState(false);
    const [dialogState, setDialogState] = useState(false);
    const [isConfirm, setIsConfirm] = useState(false);
    /** search mediceList */
    const [selected, setSelected] = useState([]);
    const [selectedMedicine, setSelectedMedicine] = useState({});
    const [medicineList, setMedicineList] = useState([]);
    const [openMediciceList, setOpenMediciceList] = useState(false);
    const [showMedicineData, setShowMedicineData] = useState(false);

    /** set confirm box */
    useEffect(() => {
        setShowConfirm(dialogState);
    }, [dialogState]);

    useEffect(() => {
        setMedicineSlipImg(file);
    }, [file]);

    /**set dialog box */
    useEffect(() => {
        const funcWindowload = async () => {           
            let order_id = sessionStorage.getItem('order_id');
            if (order_id !== "" && order_id !== undefined && order_id !== null) {
                setOrderId(order_id);
                await funGetOrderDataByParam({ "order_id": order_id });
            } else {
                funSetDialog(<span style={{ color: 'red' }}>Invalid Medicine Data</span>, false, true);
            }
        }
        funcWindowload();
    }, []);

    /** get data of medicine */
    const funGetOrderDataByParam = async (params) => {
        let param_pharmacy_id = { "pharmacy_id": pharamcyId };
        let param = { ...param_pharmacy_id, ...params }
        const response = await fetchDataByParamAction(dispatch, store, Constant.API_GET_ORDER_DATA, param);
        if (response.error) {
            funSetDialog(<span style={{ color: 'red' }}>{response.itemsList.message}</span>, false, true);
        } else {
            funSetCartData(response.itemsList.order_details[0]);
        }
    }

    /** add to cart */
    const funPostAddToCart = async (params) => {
        await dispatch(postTocart(params, Constant.API_ORDER_ADDTOCART), [dispatch]);
        const actionState = store.getState();
        const response = actionState.OrderReducer;
        if (response.error) {
            funSetDialog(<span style={{ color: 'red' }}>Error occureing in this process</span>, false, true);
        } else {
            let param = { "order_id": orderId }
            const fileResponse = await fetchDataByParamAction(dispatch, store, Constant.API_MAKE_ORDER_PAYMENT, param);
            if (fileResponse.error) {
                funSetDialog(<span style={{ color: 'red' }}>Error in making Invoice</span>, false, true);
            } else {
                setDialogState(false);
                saveAs(fileResponse.itemsList.message.invoice_url, orderId + '.pdf');
            }
        }
    }

    /** set medicine data */
    const funSetCartData = (data) => {
        /** Medicine Data */
        let medicineDetails = data.medicines.map((e) => ({
            medicine_id: e.id,
            name: e.name,
            amount: e.amount,
            qty: e.quantities,
            price: e.amount,
            imageUrl: e.imageUrl,
        }));
        setMedicineData(medicineDetails);
        setOrderUserId(data.user_id);
        setTotalAmount(data.total_amount);
        setMedicineSlipImg(data.prescription_images);
        if (data.prescription_images !== null) {
            const imgName = data.prescription_images[0].split(/[\s/]+/)
            setMedicineSlipImgName(imgName[imgName.length - 1]);
        }
        setPharmacyAacceptStatus(data.pharmacy_accept_status);
        setCustomerPhNo(data.customer_phone_no);
        setStatus(data.status);
    }

    /** function send cart and pay order data */
    const funOrdeSendCart = () => {
        let isValidate = funMedicineListValidation();
        if (isValidate) {
            funSetDialog("Are you sure want to request the payment?", true, true);
        } else {
            funSetDialog(<span style={{ color: 'red' }}>Please add medicine data</span>, false, true);
        }
    }


    /** function cancel order data */
    const funOrderSentCancel = () => {
        setDialogState(false);
    }

    /** function accept order data confirm */
    const funOrderSentConfirm = async () => {
        let medicineItems = medicineData.map((e) => ({
            medicine_id: e.medicine_id,
            qty: e.qty
        }));
        let param = {
            "user_id": orderUserId,
            "order_medicines": medicineItems,
            "pharmacy_id": pharamcyId
        };
        await funPostAddToCart(param);
    }

    /** set dailog */
    const funSetDialog = (text, isConfirm, state) => {
        setDialogText(text);
        setIsConfirm(isConfirm);
        setDialogState(state);
    }

    const setFormStatus = () => {
        if (status === 0 && pharmacyAacceptStatus === 0) {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg pull-right badge-status-new-form">{Constant.ORDER_STATUS_NEW}</div></div>);
        } else if (status === 0 && pharmacyAacceptStatus === 1) {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg pull-right badge-status-inprogress-form">{Constant.ORDER_STATUS_INPROGRESS}</div></div>);
        } else if (status === 0 && pharmacyAacceptStatus === -1) {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg pull-right badge-status-rejected-form">{Constant.ORDER_STATUS_REJECT}</div></div>);
        } else if (status === 1 && pharmacyAacceptStatus === 1) {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg pull-right badge-status-success-form">{Constant.ORDER_STATUS_SUCCESS}</div></div>);
        } else if (status === 2 && pharmacyAacceptStatus === 1) {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg pull-right badge-status-rejected-form">{Constant.ORDER_STATUS_FAILED}</div></div>);
        } else if (status === 3 && pharmacyAacceptStatus === 1) {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg pull-right badge-status-completed-form">{Constant.ORDER_STATUS_COMPLETED}</div></div>);
        } else {
            return (<div><div className="mb-2 mr-2 badge badge-pill badge-pill-lg pull-right badge-status-new-form">{Constant.ORDER_STATUS_PENDING}</div></div>);
        }
    }

    /** Download Image */
    const funDownloadImage = async () => {
        let param = { "file_name": medicineSlipImgName }
        const response = await funFileDownload(dispatch, store, Constant.API_ORDER_PRISCRIPTION_DWLD, param);
        if (response.error) {
            funSetDialog(<span style={{ color: 'red' }}>{medicineSlipImgName} : {response.setNotificationMessage.message}</span>, false, true);
        } else {
            const originalImage = response.itemsList;
            const url = window.URL.createObjectURL(new Blob([originalImage]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', param.file_name);
            document.body.appendChild(link);
            link.click();
        }
    }

    const medicineRef = React.useRef();
    /**
     * function for get medicien search
     * @param {} medicine 
     */
    const funChangeMedicineInput = async (medicine) => {
        if (medicine !== '') {
            setOpenMediciceList(false);
            let medicineItems;
            let param = {
                "search_name": medicine,
                "pharmacy_id": pharamcyId,
                "pagination_limit": 20,
                "offset_id": 0
            }
            let response = {};
            if (medicine.trim() !== undefined && medicine.trim() !== null && medicine.trim() !== '') {
                await dispatch(funGetSearchMedicine(param, Constant.API_SEARCH_MEDICINE), [dispatch]);
                const actionState = store.getState();
                response = actionState.InventoryReducer;
                if (response.error) {
                    setMedicineList([]);
                } else {
                    medicineItems = response.item.message.map((e) => ({
                        id: e.id,
                        label: e.name,
                        image: e.imageUrl,
                        price: (e.price === '' ? 0 : e.price)
                    }));
                    setMedicineList(medicineItems);
                }
                setOpenMediciceList(true);
            } else {
                setMedicineList([]);
            }
        } else {
            setMedicineList([]);
            setOpenMediciceList(false);
        }
    }

    /** serach medicine name onchange */
    const onChangeMedicineName = async (name) => {
        setSelected(name);
        setOpenMediciceList(false);
        let selectedMedicine = {
            medicine_id: name[0].id,
            name: name[0].label,
            amount: name[0].price,
            qty: 1,
            price: name[0].price,
            imageUrl: name[0].image,
        };
        setSelectedMedicine(selectedMedicine);
        setShowMedicineData(true);
    }

    /** select mediicne */
    const funAddToMedicne = async (qty) => {
        setShowMedicineData(false);
        selectedMedicine.qty = qty;
        selectedMedicine.price = qty * selectedMedicine.amount;
        let isAlreadyExist = medicineData.findIndex(obj => obj.medicine_id === selectedMedicine.medicine_id);
        if (isAlreadyExist === -1) {
            let selectedMedicineList = [...medicineData, { ...selectedMedicine }]
            await dispatch({ type: Constant.SET_MEDICINE_DATA, payload: selectedMedicineList }, [dispatch]);
            const actionState = store.getState();
            const fetchResponse = actionState.OrderReducer;
            setMedicineData(fetchResponse.medicineDataFinal);
            setSelected([]);
            setMedicineList([]);
            let total = totalAmount + (selectedMedicine.qty * selectedMedicine['amount']);
            setTotalAmount(Math.floor(total * 100) / 100);
        } else {
            funSetDialog(selectedMedicine.name + ": This medicine has already added to the cart", false, true);
        }
    }

    /** cancel mediicne from cart */
    const funCancelAddMedicine = async () => {
        setShowMedicineData(false);
        setSelected([]);
        setMedicineList([]);
    }

    /** funRemoveMedicine from cart */
    const funRemoveMedicine = async (id) => {
        await dispatch({ type: Constant.SET_MEDICINE_DATA, payload: medicineData.filter(item => item.medicine_id !== id) }, [dispatch]);
        const actionState = store.getState();
        const fetchResponse = actionState.OrderReducer;
        setMedicineData(fetchResponse.medicineDataFinal);
        if (fetchResponse.medicineDataFinal.length > 0) {
            let totalamount = fetchResponse.medicineDataFinal.map(item => (item.amount * item.qty)).reduce((a, b) => parseFloat(a) + parseFloat(b));
            setTotalAmount(Math.floor(totalamount * 100) / 100);
        } else {
            setTotalAmount(0.00);
        }
    }

    /** set qty of medicine */
    function medicineFormat(num) {
        return num + ' Strips';
    }

    /** set Qty count */
    const funSetMedicineQty = async (e, id, amount) => {
        medicineData.find(v => v.medicine_id === id).qty = e;
        medicineData.find(v => v.medicine_id === id).price = e * amount;
        await dispatch({ type: Constant.SET_MEDICINE_DATA, payload: medicineData }, [dispatch]);
        const actionState = store.getState();
        const fetchResponse = actionState.OrderReducer;
        setMedicineData(fetchResponse.medicineDataFinal);
        const sumItems = fetchResponse.medicineDataFinal.map(item => item.price).reduce((a, b) => parseFloat(a) + parseFloat(b));
        setTotalAmount(Math.floor(sumItems * 100) / 100);
    }

    /** medicine list validation */
    const funMedicineListValidation = () => {
        let orderIsValid = true;
        if (medicineData.length <= 0) {
            orderIsValid = false;
        } else {
            orderIsValid = true;
        }
        return orderIsValid;
    }


    /**set Image name */
    const funGetSlipName = (imgIndex) => {
        const imgName = medicineSlipImg[imgIndex].split(/[\s/]+/)
        setMedicineSlipImgName(imgName[imgName.length - 1]);
    }

    /** image upload */
    const funFileHandler = (event) => {
        let fileloaded = Array.from(event.target.files);
        if (fileloaded !== null && fileloaded !== undefined) {
            if (fileloaded.size !== 0) {
                let imageArry = [];
                fileloaded.forEach((el) => {
                    if (!el.name.match(/\.(gif|jpe?g|tiff?|png|webp|bmp)$/i)) {
                        funSetDialog(<span style={{ color: 'red' }}>Please upload image file</span>, false, true);
                    } else {
                        setMedicineSlipImgName(el.name);
                        var reader = new FileReader();
                        reader.readAsDataURL(el);
                        reader.onloadend = function () {
                            var base64String = reader.result;
                            imageArry.push(base64String);
                            setFile(imageArry);
                        }
                    }
                })
            } else {
                funSetDialog(<span style={{ color: 'red' }}>Selected image size is {fileloaded.size}</span>, false, true);
            }
        }
    };

    /** change delivery type */
    const funInputChangeHandler = (event) => {
        let val = event.target.value;
        setDeliveryType(val);
    }

    /**complte the order */
    const funCompleteOrder = async () => {
        let param = {
            "pharmacy_id": pharamcyId,
            "order_id": orderId,
        }
        await funUpdateStataus(param, Constant.API_ORDER_COMPLETED);
    }


    /**
     * funUpdateOrderData
     * @param {*} param 
     * @param {*} API    
     */
    const funUpdateStataus = async (param, API) => {
        const response = await updateAction(param, dispatch, store, API);
        if (response.error) {
            funSetDialog(<span style={{ color: 'red' }}>{response.setNotificationMessage.message}</span>, false, true);
        } else {
            setStatus(3);
            funSetDialog(<span style={{ color: 'green' }}>{orderId} : Order Completed</span>, false, true);
        }
    }

    /**nlote */
    const funOnchangeNote = (event) => {
        let val = event.target.value;
        setNote(val);
    }


    return (
        <Fragment>
            <PageTitle heading={Constant.ORDER_PAGE_TITTLE} />
            <ReactCSSTransitionGroup
                component="div"
                transitionName="TabsAnimation"
                transitionAppear={true}
                transitionAppearTimeout={0}
                transitionEnter={false}
                transitionLeave={false}>
                <div>
                    <Row>
                        <Col md="12">
                            <Form id="order">
                                <FormGroup row>
                                    <Col lg={{ size: 5 }}>
                                        <Label className="mt-2" style={{ fontSize: '15px' }}>#{orderId}</Label>
                                        <p className='order-edit-sub-txt-1'>Please review the cart.</p>
                                    </Col>
                                    <Col lg={{ size: 6 }}>
                                        <Button id='orderCall' className="pull-right contact-btn" size="sm" disabled>
                                            {customerPhNo} {' '}
                                            <FontAwesomeIcon className="opacity-8" icon={faPhone} style={{ color: "rgb(73 88 102)", fontSize: 'smaller' }} />
                                        </Button>
                                        {setFormStatus()}
                                    </Col>
                                </FormGroup>
                            </Form>
                        </Col>
                        {status === 1 && pharmacyAacceptStatus === 1 ?
                            <Col md="12 justify-content-end">
                                <div class="float-right">
                                    <div className="input-group">
                                        <Input type="select" name="deliveryType" value={deliveryType} onChange={funInputChangeHandler}>
                                            <option value={0}>Home Delivery</option>
                                            <option value={1}>Pickup</option>
                                        </Input>
                                        <div className="input-group-append">
                                            <Button className="btn-rounded p-2 btn-success" size="md" onClick={funCompleteOrder}>Complete this Order</Button>
                                        </div>
                                    </div></div>
                            </Col> : null}
                    </Row>
                    <Card className="main-card mb-3">
                        <CardBody>
                            <Row>
                                <Col lg="12">
                                    <label lg={12} className='mb-3 order-edit-sub-txt-2'>You can Add , Edit and delete the items here.</label>
                                </Col>
                                <Col md="5">
                                    <h4 className='mb-3 order-edit-prescription'>{Constant.ORDER_PRESCRIPTION}</h4>
                                    <Col lg="12">
                                        <div className="card add-product-card img-card" >
                                            <div className="card-body d-flex flex-column">
                                                <div className="card-text">
                                                    {medicineSlipImg !== null && medicineSlipImg !== undefined && medicineSlipImg !== '' ?
                                                        <React.Fragment>
                                                            <TransformWrapper>
                                                                {({ zoomIn, zoomOut, resetTransform, ...rest }) => (
                                                                    <Row>
                                                                        <Col lg={12}>
                                                                            <div className="tools pull-right">
                                                                                <Button className="mb-2 mr-0 border-0 btn-transition" size="md"
                                                                                    color="link" onClick={() => zoomIn()}><FontAwesomeIcon className="opacity-8" icon={faSearchPlus} style={{ color: "#5c5391" }} /></Button>
                                                                                <Button className="mb-2 mr-0 border-0 btn-transition" size="md"
                                                                                    color="link" onClick={() => zoomOut()}><FontAwesomeIcon className="opacity-8" icon={faSearchMinus} style={{ color: "#5c5391" }} /></Button>
                                                                                <Button className="mb-2 mr-0 border-0 btn-transition" size="md"
                                                                                    color="link" onClick={() => resetTransform()}><FontAwesomeIcon className="opacity-8" icon={faArrowsAlt} style={{ color: "#5c5391" }} /></Button>
                                                                            </div>
                                                                        </Col>
                                                                        <Col lg={12}>
                                                                            <TransformComponent width='100%' style={{ display: 'block' }}>
                                                                                <Carousel showThumbs={false} autoPlay={false} infiniteLoop={false} onChange={(e) => funGetSlipName(e)}>
                                                                                    {medicineSlipImg.map((data) => (
                                                                                        <div>
                                                                                            <img src={data} className='rounded mx-auto d-block w-100' alt='' width='100%' height='276px' />
                                                                                        </div>
                                                                                    ))}
                                                                                </Carousel>
                                                                            </TransformComponent>
                                                                        </Col>
                                                                    </Row>
                                                                )}
                                                            </TransformWrapper></React.Fragment>
                                                        : <img src={defaultImage} className='rounded mx-auto d-block w-100' alt='' style={{ height: '276px' }} />}
                                                </div>
                                            </div>
                                        </div>
                                    </Col>
                                    {medicineSlipImg !== null && medicineSlipImg !== undefined && medicineSlipImg !== '' ?
                                        <Col lg="12">
                                            <ListGroup>
                                                <ListGroupItem style={{ paddingBottom: '0px' }} className='bcg-clr-e8f4ff'>
                                                    <ListGroupItemHeading style={{ fontSize: '14px' }} className='order-edit-list-hd'>
                                                        Customer prescription
                                                        <div className='pull-right'><Button className="btn-rounded pull-right order-slip-download-btn" size="sm" onClick={funDownloadImage}>
                                                            <FontAwesomeIcon className="opacity-8" icon={faDownload} style={{ color: "rgb(115 147 212)" }} /> Download</Button>
                                                        </div>
                                                    </ListGroupItemHeading>
                                                    <ListGroupItemText style={{ fontSize: '12px', marginBottom: '5px' }}>{medicineSlipImgName}
                                                    </ListGroupItemText>
                                                </ListGroupItem>
                                            </ListGroup>
                                        </Col> :
                                        ((status === 1 && pharmacyAacceptStatus === 1) || (status === 3 && pharmacyAacceptStatus === 1) ? null :
                                            <Col lg="12">
                                                <ListGroup>
                                                    <ListGroupItem style={{ paddingBottom: '0px' }} className='bcg-clr-e8f4ff'>
                                                        <ListGroupItemHeading style={{ fontSize: '14px' }} className='order-edit-list-hd'>
                                                            {medicineSlipImgName}
                                                            <div className='pull-right'><label className="btn btn-rounded pull-right order-slip-download-btn">
                                                                <FontAwesomeIcon className="opacity-8" icon={faUpload} style={{ color: "rgb(115 147 212)" }} /> {Constant.INVENTORY_ADD_PRODUCT_FILEUPLOAD_BTN}
                                                                <Input type="file" ref={ref} hidden accept={"image/*"} onChange={funFileHandler} multiple />
                                                            </label>
                                                            </div>
                                                        </ListGroupItemHeading>
                                                    </ListGroupItem>
                                                </ListGroup>
                                            </Col>)
                                    }
                                    <Col lg="12" className='mt-2'>
                                        <Label for="additionalNote" lg={12} className='pl-0'> {Constant.ORDER_ADDITIONAL_DESCRIPTION}</Label>
                                        <Input type="textarea" name="additionalNote" onChange={funOnchangeNote} value={note} disabled={(status === 1 && pharmacyAacceptStatus === 1) || (status === 3 && pharmacyAacceptStatus === 1)}></Input>
                                    </Col>
                                </Col>
                                <Col md="7">
                                    {(status === 1 && pharmacyAacceptStatus === 1) || (status === 3 && pharmacyAacceptStatus === 1) ? null :
                                        <Typeahead
                                            open={openMediciceList}
                                            id="name"
                                            align='justify'
                                            onInputChange={funChangeMedicineInput}
                                            onChange={onChangeMedicineName}
                                            options={medicineList}
                                            selected={selected}
                                            emptyLabel={<span style={{ color: 'red' }}>No matches found.</span>}
                                            placeholder={Constant.ORDER_ITEM_ADD_IN_CART_SAERCH}
                                            renderInput={({ inputRef, referenceElementRef, ...inputProps }) => {
                                                return (
                                                    <div className="input-group">
                                                        <Input style={{ borderRight: 0, borderRadius: 0 }}
                                                            {...inputProps}
                                                            ref={(input) => {
                                                                inputRef(input);
                                                                //referenceElementRef(input);
                                                            }}
                                                        />
                                                        <div className="input-group-append">
                                                            <span className="input-group-text search-input-span">
                                                                <FontAwesomeIcon className="opacity-8" icon={faSearch} style={{ color: "rgb(89 182 236)" }} />
                                                            </span>
                                                        </div>
                                                    </div>
                                                );
                                            }}
                                            renderMenu={(results, menuProps) => (
                                                <Menu {...menuProps} style={{ padding: 0 }}>
                                                    {results.map((option, position) => (
                                                        <MenuItem option={option} position={position} key={`${option}_${position}`} style={{ padding: 0 }}>
                                                            <ul className="list-group list-group-light">
                                                                <li className="list-group-item d-flex justify-content-between align-items-center">
                                                                    <div className="d-flex align-items-center w-100">
                                                                        {option.imageUrl !== null && option.imageUrl !== undefined && option.imageUrl !== '' ?
                                                                            <img src={option.imageUrl} className='rounded-circle' alt='' style={{ width: '50px', height: '50px' }} />
                                                                            : <img src={defaultImage} className='rounded-circle' alt='' style={{ width: '50px', height: '50px' }} />}
                                                                        <div className='pl-2 w-100'>
                                                                            <p className="fw-bold mb-1 ctm-data-head">{option.label}</p>
                                                                            <p className="mb-1 ctm-data-id">₹{option.price}</p>
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                            </ul>
                                                        </MenuItem>
                                                    ))}
                                                </Menu>
                                            )}
                                            ref={medicineRef}
                                        />}
                                    {/* </div> */}
                                    <h4 className='mb-1 mt-2 order-edit-item'>{Constant.ORDER_ITEM_FROM_CUSTOMER}</h4>
                                    <div className='div-order-item-list-from-customer bcg-clr-e8f4ff'>
                                        {medicineData.map((data) => (
                                            <ListGroup key={data.medicine_id}>
                                                <ListGroupItem style={{ paddingBottom: '0px' }} className='bcg-clr-e8f4ff'>
                                                    <ListGroupItemHeading style={{ fontSize: '14px' }} className='order-edit-list-hd'>
                                                        {data.name}
                                                        <div className='pull-right font-family-roboto' style={{ fontSize: '14px' }}>₹{data.price}</div>
                                                    </ListGroupItemHeading>
                                                    <ListGroupItemText className='input-group' style={{ fontSize: '12px', marginBottom: '5px' }}>
                                                        {(status === 1 && pharmacyAacceptStatus === 1) || (status === 3 && pharmacyAacceptStatus === 1) ? <div className='pull-right font-family-roboto' style={{ fontSize: '14px' }}>{data.qty} Strips</div>
                                                            : <NumericInput mobile className="form-control" min={1} value={data.qty} format={medicineFormat} onChange={(e) => funSetMedicineQty(e, data.medicine_id, data.amount)} disabled={(status === 1 && pharmacyAacceptStatus === 1) || (status === 3 && pharmacyAacceptStatus === 1)}
                                                                style={{
                                                                    wrap: {
                                                                        width: '100px'
                                                                    },
                                                                    input: {
                                                                        border: '0'
                                                                    },
                                                                    'input:focus': {
                                                                        border: '1px inset #69C',
                                                                        outline: 'none'
                                                                    },
                                                                }}
                                                            />
                                                        }
                                                        {(status === 1 && pharmacyAacceptStatus === 1) || (status === 3 && pharmacyAacceptStatus === 1) ? null :
                                                            <ListGroupItemText className="pull-right" tag={Button} action="true" style={{ background: 'transparent', marginBottom: '5px', border: 0 }} onClick={(e) => funRemoveMedicine(data.medicine_id)}>
                                                                <FontAwesomeIcon className="opacity-8" icon={faTrash} style={{ color: "rgb(115 147 212)" }} />
                                                            </ListGroupItemText>
                                                        }
                                                    </ListGroupItemText>
                                                </ListGroupItem>
                                            </ListGroup>
                                        ))}
                                    </div>
                                    <div className='bcg-clr-e8f4ff mt-3'>
                                        <ListGroup>
                                            <ListGroupItem style={{ paddingBottom: '0px' }} className='bcg-clr-e8f4ff'>
                                                <ListGroupItemHeading style={{ fontSize: '14px' }} className='order-edit-list-hd'>
                                                    {Constant.ORDER_DATA_TOTAL}
                                                    <div className='pull-right font-family-roboto' style={{ fontSize: '14px' }}>₹ {totalAmount}</div>
                                                </ListGroupItemHeading>
                                            </ListGroupItem>
                                        </ListGroup>
                                    </div>
                                </Col>
                            </Row>
                            {(status === 1 && pharmacyAacceptStatus === 1) || (status === 3 && pharmacyAacceptStatus === 1) ? null
                                :
                                <Row className='mt-5'>
                                    <Col lg="12">
                                        <Button id='cancel' color="dark" className="mb-2 mr-2 pull-right btn-style save-btn" size="lg" onClick={funOrdeSendCart}>{Constant.ORDER_SEND_CART_RQ_PAY_BTN}</Button>
                                    </Col>
                                </Row>
                            }
                        </CardBody>
                    </Card>
                    <ConfirmDailog
                        text={dialogText}
                        heading={''}
                        onYes={funOrderSentConfirm}
                        isConfirm={isConfirm}
                        onNo={funOrderSentCancel}
                        open={showConfirm}
                    />
                    <MedicineAddDialog
                        open={showMedicineData}
                        data={selectedMedicine}
                        onSelect={funAddToMedicne}
                        onCancel={funCancelAddMedicine}
                        qty={1}
                    />
                </div>
            </ReactCSSTransitionGroup>
        </Fragment>
    )
}
export default OrderCart
