import React, {Fragment} from 'react'
import OrderCart from './OrderCart' ;

/**OrderCartList Index*/
function OrderCartList(){
        return (
            <Fragment>
               <OrderCart/>
            </Fragment>
        )    
}
export default OrderCartList;