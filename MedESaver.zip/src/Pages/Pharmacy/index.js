import React, { Fragment } from 'react';
import { Route, Switch } from 'react-router-dom';
import ErrorPage from '../ErrorPages/erro404';

import AppHeader from '../../Layout/AppHeader';
import AppSidebar from '../../Layout/AppSidebar';
import AppFooter from '../../Layout/AppFooter';

import Login from './Login';
import PasswordRecovery from './Login/PasswordRecovery';
import EmailConfirmation from './Login/EmailConfirmation';
/** Inventory */
import Inventory from './Inventory/Table';
import InventoryForm from './Inventory/Form';
import MedicineForm from './Inventory/AddManullay';
/**order */
import Order from './Order/Table';
import OrderAccept from './Order/Form';
import OrderCart from './Order/Cart';
import AddOrder from './Order/AddOrder';

const Forms = ({ match }) => (

    <Fragment>

        <Switch>

            <Route path={`${match.url}/Login`} >
                <Login />
            </Route>

            <Route path={`${match.url}/forget-password`} >
                <PasswordRecovery/>
            </Route>

            <Route path={`${match.url}/email-confirm`} >
                <EmailConfirmation/>
            </Route>

            <Route path={`${match.url}/Inventory/table`}>
                <Fragment>
                    <AppHeader />
                    <div className="app-main">
                        <AppSidebar />
                        <div className="app-main__outer">
                            <div className="app-main__inner" >
                                <Inventory />
                            </div>
                            <AppFooter />
                        </div>
                    </div>
                </Fragment>
            </Route>

            <Route path={`${match.url}/Inventory/form`}>
                <Fragment>
                    <AppHeader />
                    <div className="app-main">
                        <AppSidebar />
                        <div className="app-main__outer">
                            <div className="app-main__inner" >
                                <InventoryForm />
                            </div>
                            <AppFooter />
                        </div>
                    </div>
                </Fragment>
            </Route>
            <Route path={`${match.url}/Inventory/add-manullay`}>
                <Fragment>
                    <AppHeader />
                    <div className="app-main">
                        <AppSidebar />
                        <div className="app-main__outer">
                            <div className="app-main__inner" >
                                <MedicineForm />
                            </div>
                            <AppFooter />
                        </div>
                    </div>
                </Fragment>
            </Route>

            <Route path={`${match.url}/Order/table`}>
                <Fragment>
                    <AppHeader />
                    <div className="app-main">
                        <AppSidebar />
                        <div className="app-main__outer">
                            <div className="app-main__inner" >
                                <Order />
                            </div>
                            <AppFooter />
                        </div>
                    </div>
                </Fragment>
            </Route>

            <Route path={`${match.url}/Order/Form`}>
                <Fragment>
                    <AppHeader />
                    <div className="app-main">
                        <AppSidebar />
                        <div className="app-main__outer">
                            <div className="app-main__inner" >
                                <OrderAccept />
                            </div>
                            <AppFooter />
                        </div>
                    </div>
                </Fragment>
            </Route>

            <Route path={`${match.url}/Order/Cart`}>
                <Fragment>
                    <AppHeader />
                    <div className="app-main">
                        <AppSidebar />
                        <div className="app-main__outer">
                            <div className="app-main__inner" >
                                <OrderCart />
                            </div>
                            <AppFooter />
                        </div>
                    </div>
                </Fragment>
            </Route>

            <Route path={`${match.url}/Order/AddOrder`}>
                <Fragment>
                    <AppHeader />
                    <div className="app-main">
                        <AppSidebar />
                        <div className="app-main__outer">
                            <div className="app-main__inner" >
                                <AddOrder />
                            </div>
                            <AppFooter />
                        </div>
                    </div>
                </Fragment>
            </Route>

            <Route component={ErrorPage} />

        </Switch>

    </Fragment>

);

export default Forms;