import React, { Fragment, useEffect, useState } from 'react';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import { useDispatch, useStore } from 'react-redux';
import { Link, useHistory } from "react-router-dom";
import PageTitle from '../../../../Layout/AppMain/PageTitle';
import * as Constant from "../../../../constant";
import { Form, FormGroup, Row, Col, Input, Label, Button, Alert } from 'reactstrap';
import { RadioGroup, Radio } from 'react-radio-group'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faArrowLeft, faSearchPlus, faSearchMinus, faArrowsAlt } from '@fortawesome/free-solid-svg-icons';
import { fetchDataByParamAction, saveAction } from '../../../../Function/Form/FormAction';
import { Typeahead } from 'react-bootstrap-typeahead';
import '../../../../css/Pharmacy.css';
import ConfirmDailog from '../../../../Function/ConfirmDailog';
/** defualt image */
import defaultImage from "../../../../assets/utils/images/noImage.png";
/** Get Search Medicine List */
import { funGetSearchMedicine } from '../../../../redux/action/InventoryAction'
import * as commonFunction from '../../../../Function/getGlobalVariable';
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader 
import { TransformWrapper, TransformComponent } from "react-zoom-pan-pinch";


/**MedicineForm */
function MedicineForm() {

    const history = useHistory();
    const dispatch = useDispatch();
    const store = useStore();

    // Autocomplete Medicine Name   
    const [selected, setSelected] = useState([]);
    const [medicineList, setMedicineList] = useState([]);
    /** saveStatus */
    const [saveResponse, setSaveResponse] = useState(false);
    /** Notification */
    const [notificationShow, setNotificationShow] = useState(false);
    const [notificationMessage, setNotificationMessage] = useState({ 'message': '', 'className': '' });
    /**Dialog box */
    const [dialogText, setDialogText] = useState('');
    const [showConfirm, setShowConfirm] = useState(false);
    const [dialogState, setDialogState] = useState(false);
    const [isConfirm, setIsConfirm] = useState(false);
    const [isEditMode, setIsEditMode] = useState(false);
    const [isNewMode, setIsNewMode] = useState(true);
    /**Pharmacy Id */
    const pharamcyId = commonFunction.getPharmacyId();

    //set initial medicine Details state    
    const [medicineFields, setMedicineFields] = useState({ "pharmacy_price": "", "pharmacy_discount": "", "name": "", "id": "", "description": "", "sideEffects": "", "prescription": "", "composition": "", "manufacturer": "", "imageUrl": "", "units": "", "hsn_code": "", "mrp1mg": "", "bestPrice1mg": "", "discountCondition": "", "namePharmeasy": "", "mrpPharmeasy": "", "bestPricePharmeasy": "", "offersPharmeasy": "", "nameNetmeds": "", "mrpNetmeds": "", "bestPriceNetmeds": "", "offersNetmeds": "", "nameAppolo": "", "mrpAppolo": "", "bestPriceAppolo": "", "offersAppolo": "" });
    const [id, setId] = useState('');
    const [pharmacy_price, setPharmacyPrice] = useState('');
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [prescription, setPrescription] = useState('');
    const [composition, setComposition] = useState([]);
    const [manufacturer, setManufacturer] = useState('');
    const [imageUrl, setImageUrl] = useState('');
    const [units, setUnits] = useState('');
    //const [hsn_code, setHsn_code] = useState('');
    const [mrp1mg, setMrp1mg] = useState('');
    const [bestPrice1mg, setBestPrice1mg] = useState('');
    const [discountCondition, setDiscountCondition] = useState('');
    const [status, setStatus] = useState('');

    const [openMediciceList, setOpenMediciceList] = useState(false);

    /**set dialog box */
    useEffect(() => {
        setShowConfirm(dialogState);
    }, [dialogState]);

    /** set form data */
    useEffect(() => {
        const funcWindowload = async () => {
            let isNewMode = sessionStorage.getItem('isNewMode');
            setIsNewMode(isNewMode);
            let row_id = sessionStorage.getItem('row_id');
            if (row_id !== "" && row_id !== undefined && row_id !== null) {
                setIsEditMode(true);
                await funGetMedicineDataByParam({ "medicine_id": row_id });
            } else {
                setIsEditMode(false);
            }
        }
        funcWindowload();
    }, []);

    /** get data of medicine */
    const funGetMedicineDataByParam = async (params) => {
        let param_pharmacy_id = { "pharmacy_id": pharamcyId };
        let param = { ...param_pharmacy_id, ...params }
        const response = await fetchDataByParamAction(dispatch, store, Constant.API_GET_PHARMACY_MEDICINE_BY_PARAM, param);
        if (response.error) {
            setNotificationMessage(response.setNotificationMessage);
            setNotificationShow(true);
        } else {
            funSetMedicineValues(response.itemsList.result);
        }
    }

    /** set medicine data */
    const funSetMedicineValues = (rowData) => {
        setId(rowData.id);
        setPharmacyPrice(rowData.pharmacy_price);
        setName(rowData.name);
        setSelected([rowData.name]);
        setPrescription(rowData.prescription);
        setDescription(rowData.description);
        setComposition(rowData.composition);
        setManufacturer(rowData.manufacturer);
        setImageUrl(rowData.imageUrl);
        setUnits(rowData.units);
        setMrp1mg(rowData.mrp1mg);
        setBestPrice1mg(rowData.bestPrice1mg);
        let discountData = funGetDiscount(rowData.mrp1mg, rowData.pharmacy_price);
        setDiscountCondition(discountData);
        setStatus(rowData.availability);
        setMedicineFields(rowData);
    }

    /**funGetDiscount */
    const funGetDiscount = (mrp, price) => {
        let discountData = 0;
        /** Discount */
        if (+mrp > +price) {
            let discountAmount = Math.floor((mrp - price) * 100) / 100;
            let discountPercentage = ((discountAmount) / mrp) * 100;
            discountData = discountAmount + ' (' + Math.floor(discountPercentage * 100) / 100 + '%)';

        } else {
            discountData = 0 + ' (0%)';
        }
        return discountData;
    }

    //Inputs Change Event and set values in state 
    const funInputChangeHandler = (event) => {
        let inputname = event.target.name;
        let val = event.target.value;

        //MedicineName
        if (inputname === 'name') {
            setName(val);
            setMedicineFields[name] = val;
        }
        //Price
        if (inputname === 'pharmacy_price') {
            val = event.target.value.replace(/[^0-9]/g, '');
            setPharmacyPrice(val);
            setMedicineFields[pharmacy_price] = val;
            let discountData = funGetDiscount(mrp1mg, val);
            setDiscountCondition(discountData);
        }
        //Status
        if (inputname === 'status') {
            setStatus(val);
        }
    }

    //Inputs Change Event and set values in state 
    const funCencelEdit = async () => {
        if (isNewMode === '1') {
            await funGetMedicineDataByParam({ "medicine_id": id });
            setIsEditMode(true);
        } else {
            history.push({ pathname: '/Pharmacy/Inventory/form', state: '' });
        }
    }

    //validation
    const handleValidation = () => {
        let formIsValid = true;
        if (pharmacy_price === undefined || pharmacy_price === null || pharmacy_price === '') {
            formIsValid = false;
            funSetDialog(<span style={{ color: 'red' }}>Please add medicine price</span>, false, true);
        }
        if (name.trim() === undefined || name.trim() === null || name.trim() === '') {
            formIsValid = false;
            funSetDialog(<span style={{ color: 'red' }}>Please add valid medicine data</span>, false, true);
        } else {

        }
        return formIsValid;
    };

    //save and update data action
    const formSubmit = async () => {
        if (handleValidation()) {
            let saveMedicineData = {
                "pharmacy_id": pharamcyId,
                "medicine_id": id,
                "price": pharmacy_price,
                "status": status
            }
            let response;
            //for update medicine Data
            if (saveMedicineData.medicine_id !== '') {
                response = await saveAction(saveMedicineData, dispatch, store, Constant.API_SAVE_PHARMACY_MEDICINE_DATA);
                if (response.error) {
                    funSetDialog(<span style={{ color: 'red' }}>Error in saving data</span>, false, true);
                } else {
                    funGetMedicineDataByParam({ "medicine_id": id });
                    setSaveResponse(true);
                    funSetDialog(<span style={{ color: 'green' }}>Medicine data update successfully</span>, false, true);
                }
            } else {
                funSetDialog('Please add medicine details.', false, true);
            }
        }
    };

    /** Dialog OK */
    const onOkDailogBtn = async () => {
        setDialogState(false);
        if (saveResponse) {
            history.push({ pathname: "/Pharmacy/Inventory/table", state: "" });
        }
    }

    /** serach medicine name onchange */
    const onChangeMedicineName = async (name) => {
        setSelected(name);
        setName(name[0].label);
        setMedicineFields[name] = name[0].label;
        setIsNewMode();
        setOpenMediciceList(false);
        await funGetMedicineDataByParam({ "medicine_id": name[0].id });
    }

    /**
     * function for get medicien search
     * @param {} medicine 
     */
    const funChangeMedicineInput = async (medicine) => {
        if (medicine !== '') {
            setOpenMediciceList(false);
            let medicineItems;
            let param = {
                "search_name": medicine,
                "pagination_limit": 20,
                "offset_id": 0
            }
            let response = {};
            if (medicine.trim() !== undefined && medicine.trim() !== null && medicine.trim() !== '') {
                await dispatch(funGetSearchMedicine(param, Constant.API_SEARCH_MEDICINE), [dispatch]);
                const actionState = store.getState();
                response = actionState.InventoryReducer;
                if (response.error) {
                    setMedicineList([]);
                } else {
                    medicineItems = response.item.message.map((e) => ({
                        id: e.id,
                        label: e.name
                    }));
                    setMedicineList(medicineItems);
                }
                setOpenMediciceList(true);
            } else {
                setMedicineList([]);
            }
        } else {
            setMedicineList([]);
            setOpenMediciceList(false);
        }
    }

    /** set dailog */
    const funSetDialog = (text, isConfirm, state) => {
        setDialogText(text);
        setIsConfirm(isConfirm);
        setDialogState(state);
    }

    //hide notification message
    const onDismissNotification = () => {
        setNotificationShow(false);
    }

    const medicineRef = React.useRef();

    const funcClearInputForm = () => {
        setId("");
        setPharmacyPrice("");
        setName("");
        setSelected([]);
        setMedicineList([]);
        setOpenMediciceList(false);
        setPrescription("");
        setDescription("");
        setComposition([]);
        setImageUrl("");
        setUnits("");
        setMrp1mg("");
        setBestPrice1mg("");
        setDiscountCondition("");
        setStatus("");
        setMedicineFields({ "pharmacy_price": "", "pharmacy_discount": "", "name": "", "id": "", "description": "", "sideEffects": "", "prescription": "", "composition": "", "manufacturer": "", "imageUrl": "", "units": "", "hsn_code": "", "mrp1mg": "", "bestPrice1mg": "", "discountCondition": "", "namePharmeasy": "", "mrpPharmeasy": "", "bestPricePharmeasy": "", "offersPharmeasy": "", "nameNetmeds": "", "mrpNetmeds": "", "bestPriceNetmeds": "", "offersNetmeds": "", "nameAppolo": "", "mrpAppolo": "", "bestPriceAppolo": "", "offersAppolo": "" });
    }

    return (
        <Fragment>
            <PageTitle heading={Constant.INVENTORY_ADD_MEDICINE_TXT} />
            <ReactCSSTransitionGroup
                component="div"
                transitionName="TabsAnimation"
                transitionAppear={true}
                transitionAppearTimeout={0}
                transitionEnter={false}
                transitionLeave={false}>
                <div>
                    <Alert color={notificationMessage["className"]} isOpen={notificationShow} toggle={onDismissNotification}>
                        {notificationMessage["message"]}
                    </Alert>
                    <Form id="addproductForm">
                        <FormGroup row>
                            <Col lg="6">
                                {isNewMode === '1'
                                    ? <Link className='pull-left' to={{ pathname: '/Pharmacy/Inventory/table' }}><FontAwesomeIcon className="opacity-8" icon={faArrowLeft} style={{ color: "#5c5391" }} />
                                    </Link>
                                    :
                                    <Link className='pull-left' to={{ pathname: '/Pharmacy/Inventory/form' }}><FontAwesomeIcon className="opacity-8" icon={faArrowLeft} style={{ color: "#5c5391" }} />
                                    </Link>
                                }
                            </Col>
                            <Col lg="6">
                                {isEditMode ?
                                    <Button id='edit' className="btn-rounded pull-right add-button" size="lg" onClick={() => setIsEditMode(false)}><FontAwesomeIcon className="opacity-8" icon={faEdit} style={{ color: "rgb(255 255 255)" }} /> | {Constant.INVENTORY_EDIT_PRODUCT_BTN}</Button>
                                    : ''}
                            </Col>
                        </FormGroup>
                        <FormGroup row>
                            <Col lg="6">
                                <div className="card add-product-card img-card" >
                                    <div className="card-body d-flex flex-column">
                                        <div className="card-text">
                                            {imageUrl !== null && imageUrl !== undefined && imageUrl !== '' ?
                                                <React.Fragment>
                                                    <TransformWrapper>
                                                        {({ zoomIn, zoomOut, resetTransform, ...rest }) => (
                                                            <Row>
                                                                <Col lg={12}>
                                                                    <div className="tools pull-right">
                                                                        <Button className="mb-2 mr-0 border-0 btn-transition" size="md"
                                                                            color="link" onClick={() => zoomIn()}><FontAwesomeIcon className="opacity-8" icon={faSearchPlus} style={{ color: "#5c5391" }} /></Button>
                                                                        <Button className="mb-2 mr-0 border-0 btn-transition" size="md"
                                                                            color="link" onClick={() => zoomOut()}><FontAwesomeIcon className="opacity-8" icon={faSearchMinus} style={{ color: "#5c5391" }} /></Button>
                                                                        <Button className="mb-2 mr-0 border-0 btn-transition" size="md"
                                                                            color="link" onClick={() => resetTransform()}><FontAwesomeIcon className="opacity-8" icon={faArrowsAlt} style={{ color: "#5c5391" }} /></Button>
                                                                    </div>
                                                                </Col>
                                                                <Col lg={12}>
                                                                    <TransformComponent width='100%' style={{ display: 'block' }}>
                                                                        <div>
                                                                            <img src={imageUrl} className='rounded mx-auto d-block w-100' alt='' width='100%' height='276px' />
                                                                        </div>
                                                                    </TransformComponent>
                                                                </Col>
                                                            </Row>
                                                        )}
                                                    </TransformWrapper>
                                                </React.Fragment>
                                                : <img src={defaultImage} className='rounded mx-auto d-block w-100' alt='' style={{ height: '276px' }} />}
                                        </div>
                                    </div>
                                </div></Col>
                            <Col lg="6">
                                <FormGroup row>
                                    <Col lg="6">
                                        <Label for="id" lg={2}> {Constant.INVENTORY_MID_TXT}</Label><Label for="id" lg={2}>{id}</Label>
                                    </Col>
                                    <Col lg="6">
                                        <Label for="status" lg={2}> {Constant.INVENTORY_STATUS_TXT}</Label>
                                        <Input type="select" name="status" disabled={isEditMode} value={status} onChange={funInputChangeHandler}>
                                            <option value={1}>Available</option>
                                            <option value={0}>Not Available</option>
                                        </Input>
                                    </Col>
                                </FormGroup>
                                <FormGroup row>
                                    <Col lg="12" id='input-name'>
                                        <Label for="name" lg={12} className='pl-0'> {Constant.INVENTORY_MEDICINE_NAME_TXT}</Label>
                                        <Typeahead
                                            open={openMediciceList}
                                            id="name"
                                            align='justify'
                                            onInputChange={funChangeMedicineInput}
                                            onChange={onChangeMedicineName}
                                            options={medicineList}
                                            selected={selected}
                                            emptyLabel={<span style={{ color: 'red' }}>No matches found.</span>}
                                            renderInput={({ inputRef, referenceElementRef, ...inputProps }) => {
                                                return (
                                                    <div className="input-group">
                                                        <Input
                                                            {...inputProps}
                                                            ref={(input) => {
                                                                inputRef(input);
                                                                //referenceElementRef(input);
                                                            }}
                                                        />
                                                        <div className="input-group-append">
                                                            <Button onClick={() => {
                                                                medicineRef.current.clear();
                                                                funcClearInputForm();
                                                            }} className="btn medicine-clear-btn" disabled={isNewMode === '1' ? true : false}>×</Button>
                                                        </div>
                                                    </div>
                                                );
                                            }}
                                            disabled={isNewMode === '1' ? true : false}
                                            ref={medicineRef}
                                        />
                                    </Col>
                                </FormGroup>
                                {/* <FormGroup row>
                                    <Col lg="12">
                                        <Label for="description" lg={12} className='pl-0'> {Constant.INVENTORY_DESCRIPTION_TXT}</Label>
                                        <Input type="textarea" name="description" defaultValue={description} disabled={true}></Input>
                                    </Col>
                                </FormGroup> */}
                                <FormGroup row>
                                    <Col lg="12">
                                        <Label for="pharmacy_price" lg={12} className='pl-0'> {Constant.INVENTORY_PRICE_TXT}</Label>
                                        <Input type="text" name="pharmacy_price" value={pharmacy_price} onChange={funInputChangeHandler} disabled={isEditMode}></Input>
                                    </Col>
                                </FormGroup>
                                <FormGroup row>
                                    <Col lg="12">
                                        <Label for="manufacturer" lg={12} className='pl-0'> {Constant.INVENTORY_MANUFACTURE_TXT}</Label>
                                        <Input type="text" name="manufacturer" defaultValue={manufacturer} disabled={true}></Input>
                                    </Col>
                                </FormGroup>
                            </Col>
                        </FormGroup>
                        <FormGroup row>
                            <Col lg="6">
                                <Label for="prescription" lg={12} className='pl-0'> {Constant.INVENTORY_PRESCRIPTION_TXT}</Label>
                                <RadioGroup className='mt-2' selectedValue={prescription === 'Prescription Required' ? 1 : 2}>
                                    <label radio-inline="true" className="mr-2">
                                        <Radio value={1} disabled={true} /><Label className='pl-1'>{Constant.INVENTORY_REQUIRED_TXT}</Label>
                                    </label>
                                    <label radio-inline="true" className="mr-2">
                                        <Radio value={2} disabled={true} /><Label className='pl-1'>{Constant.INVENTORY_NOT_REQUIRED_TXT}</Label>
                                    </label>
                                </RadioGroup>
                            </Col>
                            <Col lg="6">
                                <Label for="units" lg={12} className='pl-0'> {Constant.INVENTORY_UNIT_TXT}</Label>
                                <Input type="text" name="units" value={units} onChange={funInputChangeHandler} disabled={true}></Input>
                            </Col>
                        </FormGroup>
                        <FormGroup row>
                            <Label for="composition" lg={12}> {Constant.INVENTORY_COMPOSITIONS_TXT}</Label>
                            {composition.length > 0 ?
                                <Col lg="6" className='composition-div mt-3'>
                                    {composition.map((data, i) => (
                                        <FormGroup row key={i}>
                                            <Col lg="12">
                                                <Input type="text" name="composition" defaultValue={data} disabled={true}></Input>
                                            </Col>
                                        </FormGroup>
                                    ))}
                                </Col> :
                                <Col lg="6" className='bg-color-light-blue mt-3'>
                                    <FormGroup row>
                                        <Col lg="12">
                                            <Input type="text" name="composition" defaultValue={''} disabled={true}></Input>
                                        </Col>
                                    </FormGroup>
                                    <FormGroup row>
                                        <Col lg="12">
                                            <Input type="text" name="composition" defaultValue={''} disabled={true}></Input>
                                        </Col>
                                    </FormGroup>
                                    <FormGroup row>
                                        <Col lg="12">
                                            <Input type="text" name="composition" defaultValue={''} disabled={true}></Input>
                                        </Col>
                                    </FormGroup>
                                    <FormGroup row>
                                        <Col lg="12">
                                            <Input type="text" name="composition" defaultValue={''} disabled={true}></Input>
                                        </Col>
                                    </FormGroup>
                                </Col>}
                            <Col lg="6">
                                <FormGroup row>
                                    <Label for="mrp1mg" lg={12}> {Constant.INVENTORY_MRP_TXT}</Label>
                                    <Col lg="12">
                                        <Input type="text" name="mrp1mg" defaultValue={mrp1mg} disabled={true}></Input>
                                    </Col>
                                </FormGroup>
                                <FormGroup row>
                                    <Label for="bestPrice1mg" lg={12}> {Constant.INVENTORY_BESTPRICE_TXT}</Label>
                                    <Col lg="12">
                                        <Input type="text" name="bestPrice1mg" defaultValue={bestPrice1mg} disabled={true}></Input>
                                    </Col>
                                </FormGroup>
                                <FormGroup row>
                                    <Label for="discountCondition" lg={12}> {Constant.INVENTORY_DISCOUNT_TXT}</Label>
                                    <Col lg="12">
                                        <Input type="text" name="discountCondition" defaultValue={discountCondition} disabled={true}></Input>
                                    </Col>
                                </FormGroup>
                            </Col>
                        </FormGroup>
                        <FormGroup row>
                            <Col lg="12">
                                <Label for="description" lg={12} className='pl-0'> {Constant.INVENTORY_DESCRIPTION_TXT}</Label>
                                <Input type="textarea" name="description" defaultValue={description} disabled={true} style={{height:'100px'}}></Input>
                            </Col>
                        </FormGroup>
                        <Row>
                            <Col lg="8">
                            </Col>
                            <Col lg="2">
                                <Button id='cancel' color="dark" className="mb-2 mr-2 pull-right btn-block cancel-btn" size="lg" onClick={funCencelEdit} disabled={isEditMode}>{Constant.INVENTORY_CANCEL_PRODUCT_BTN}</Button>
                            </Col>
                            <Col lg="2">
                                <Button id='save' color="dark" className="mb-2 mr-2 pull-right btn-block save-btn" size="lg" disabled={isEditMode} onClick={formSubmit}>{Constant.INVENTORY_SAVE_PRODUCT_BTN}</Button>
                            </Col>
                        </Row>
                    </Form>
                    <ConfirmDailog
                        text={dialogText}
                        content={''}
                        heading={''}
                        isConfirm={isConfirm}
                        onNo={onOkDailogBtn}
                        open={showConfirm}
                    />
                </div>
            </ReactCSSTransitionGroup>
        </Fragment>
    )
}
export default MedicineForm