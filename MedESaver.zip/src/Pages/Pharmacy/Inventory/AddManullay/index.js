import React, {Fragment} from 'react'
import MedicineForm from './Medicine' ;

/**Inventory Index*/
function FormInventory(){
        return (
            <Fragment>
               <MedicineForm/>
            </Fragment>
        )    
}
export default FormInventory;