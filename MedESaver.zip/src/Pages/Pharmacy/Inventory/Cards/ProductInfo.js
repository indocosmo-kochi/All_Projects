import React, { useEffect, useState } from 'react';
import { useDispatch, useStore } from 'react-redux';
import * as Constant from "../../../../constant";
import { fetchDataByParamAction } from '../../../../Function/Form/FormAction';
import * as commonFunction from '../../../../Function/getGlobalVariable';
import { Spinner } from 'reactstrap';

/**
 * ProductInfo
 * @returns 
 */
function ProductInfo({ param }) {

  const dispatch = useDispatch();
  const store = useStore();

  const [productTotalCount, setProductTotalCount] = useState(-1);
  const [productAvailableCount, setProductAvailableCount] = useState(-1);
  const [productNotAvailableCount, setProductNotAvailableCount] = useState(-1);

  /**Pharmacy Id */
  const pharamcyId = commonFunction.getPharmacyId();

  useEffect(() => {
    const funcWindowload = async () => {
      let param = { "pharmacy_id": pharamcyId };
      const response = await fetchDataByParamAction(dispatch, store, Constant.API_GET_MEDICINE_STATUS_COUNT, param);
      if (response.error) {

      } else {
        setProductTotalCount(response.itemsList.total_products_count);
        setProductAvailableCount(response.itemsList.available_products_count);
        setProductNotAvailableCount(response.itemsList.unavailable_products_count);
      }
    }
    funcWindowload();
  }, [param]);


  return (
    <div>
      <div className="row">
        <div className="col-md-4">
          <div className="card widget-chart">
            <div className="icon-wrapper rounded-circle" style={{ height: 'auto' }}>
              <i className="text-primary" style={{ fontSize: 'x-large' }}><i className="fa-solid fa-cart-flatbed" style={{ color: '#59b6ec' }}></i></i></div>
            <div className="widget-numbers" style={{ fontSize: 'x-large' }}>
              {productTotalCount !== -1 ? productTotalCount : <Spinner color="primary" size='sm' as="span" />}
            </div>
            <div className="widget-subheading">{Constant.INVENTORY_TOTAL_PRODUCT}</div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card widget-chart">
            <div className="icon-wrapper rounded-circle" style={{ height: 'auto' }}>
              <i className="text-primary" style={{ fontSize: 'x-large' }}><i className="fa-solid fa-boxes-stacked" style={{ color: '#59b6ec' }}></i></i></div>
            <div className="widget-numbers" style={{ fontSize: 'x-large' }}>
              {productAvailableCount !== -1 ? productAvailableCount : <Spinner color="primary" size="sm" />}
            </div>
            <div className="widget-subheading">{Constant.INVENTORY_AVAILABLE}</div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card widget-chart">
            <div className="icon-wrapper rounded-circle" style={{ height: 'auto' }}>
              <i className="text-primary" style={{ fontSize: 'x-large' }}><i className="fa-solid fa-pallet" style={{ color: '#59b6ec' }}></i></i></div>
            <div className="widget-numbers" style={{ fontSize: 'x-large' }}>
              {productNotAvailableCount !== -1 ? productNotAvailableCount : <Spinner color="primary" size="sm" />}
            </div>
            <div className="widget-subheading">{Constant.INVENTORY_NOT_AVAILABLE}</div>
          </div>
        </div>
      </div>
    </div>

  );
}
export default ProductInfo;