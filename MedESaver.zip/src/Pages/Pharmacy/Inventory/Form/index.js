import React, {Fragment} from 'react'
import InventoryForm from './Form' ;

/**Inventory Index*/
function FormInventory(){
        return (
            <Fragment>
               <InventoryForm/>
            </Fragment>
        )    
}
export default FormInventory;