import React, { Fragment, useState, useEffect } from 'react';
import { useDispatch, useStore } from 'react-redux';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import { useHistory, Link } from "react-router-dom";
import PageTitle from '../../../../Layout/AppMain/PageTitle';
import * as Constant from "../../../../constant";
import { FormGroup, Row, Col, Input, Button } from 'reactstrap';
import ProductInfo from '../Cards/ProductInfo'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUpload, faPlus, faArrowLeft } from '@fortawesome/free-solid-svg-icons';
import '../../../../css/Pharmacy.css';
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css
import { funFileUpload } from '../../../../Function/Form/FormAction';
import ConfirmDailog from '../../../../Function/ConfirmDailog'
import * as commonFunction from '../../../../Function/getGlobalVariable';



/**InventoryForm */
function InventoryForm() {

    const history = useHistory();
    const dispatch = useDispatch();
    const store = useStore();

    const ref = React.useRef();

    const [fileName, setFileName] = useState('');
    const [file, setFile] = useState('');
    const [fileUploadStatus, seFileUploadStatus] = useState(false);
    const [dialogText, setDialogText] = useState('');
    const [showConfirm, setShowConfirm] = useState(false);
    const [dialogState, setDialogState] = useState(false);
    const [isConfirm, setIsConfirm] = useState(false);

    /** pharmacy id */
    const pharamcyId = commonFunction.getPharmacyId();

    /** produuct info */
    const [productInfoLoad, setProductInfoLoad] = React.useState(false);


    /** set confirm box */
    useEffect(() => {
        setShowConfirm(dialogState);
    }, [dialogState]);

    /** product info */
    useEffect(() => {
        setProductInfoLoad(fileUploadStatus);
    }, [fileUploadStatus]);

    /** function add manullay*/
    const funAddManually = () => {
        sessionStorage.setItem("isNewMode", 0);
        history.push({ pathname: "/Pharmacy/Inventory/add-manullay", state: "" });
    }

    /** File upload */
    const funFileHandler = (event) => {
        let fileloaded = (event.target.files[0]);
        if (fileloaded !== null && fileloaded !== undefined) {
            setFileName(fileloaded.name);
            setFile(fileloaded);
            if (fileloaded.size !== 0) {
                if (!fileloaded.name.match(/\.(csv)$/i)) {
                    setDialogText(<span style={{ color: 'red' }}>Please upload csv file</span>);
                    setDialogState(true);
                } else {
                    setDialogText('Are you sure want to upload this file ?');
                    setIsConfirm(true);
                    setDialogState(true);
                }
            } else {
                setDialogText(<span style={{ color: 'red' }}>Selected file size is {fileloaded.size}</span>);
                setDialogState(true);
            }
        }
    };

    /** upload file */
    const onUploadFile = async () => {
        const uploadFileInfo = new FormData();
        uploadFileInfo.append('file', file);
        uploadFileInfo.append('pharmacy_id', pharamcyId);
        let response;
        response = await funFileUpload(dispatch, store, Constant.API_UPLOAD_PHARMACY_DATA_FILE, uploadFileInfo);
        if (response.error) {
            setDialogText(<span style={{ color: 'red' }}>Error in File uploading</span>);
        } else {
            setFileName(file.name);
            setDialogText(<span style={{ color: 'green' }}>File upload successfully</span>);
            seFileUploadStatus(!productInfoLoad);
        }
        setIsConfirm(false);
        setDialogState(true);
    }

    /** cancel upload  */
    const onCancelUpload = () => {
        setFileName('');
        setFile('');
        setDialogState(false);
    }

    return (
        <Fragment><PageTitle heading={Constant.INVENTORY_PAGE_ADD_TITTLE} />
            <ReactCSSTransitionGroup
                component="div"
                transitionName="TabsAnimation"
                transitionAppear={true}
                transitionAppearTimeout={0}
                transitionEnter={false}
                transitionLeave={false}>
                <div>
                    <FormGroup row>
                        <Col lg="6">
                            <Link className='pull-left' to={{ pathname: '/Pharmacy/Inventory/table' }}><FontAwesomeIcon className="opacity-8" icon={faArrowLeft} style={{ color: "#5c5391" }} />
                            </Link>
                        </Col>
                    </FormGroup>
                    <Row className='mb-4'>
                        <Col lg="12" className="mb-0">
                            <ProductInfo param={productInfoLoad} />
                        </Col>
                    </Row>
                    <Row>
                        <div className="col-lg-6 mb-3 d-flex align-items-stretch">
                            <div className="card add-product-card">
                                <div className="card-body d-flex flex-column">
                                    <p className="card-text mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.
                                    </p>
                                    <p>{fileName}</p>
                                    <label className="btn btn-secondary text-white mt-auto align-self-start upload-file-btn">
                                        {Constant.INVENTORY_ADD_PRODUCT_FILEUPLOAD_BTN} <Input type="file" ref={ref} hidden accept={".csv"} onChange={funFileHandler} /> | <FontAwesomeIcon className="opacity-8" icon={faUpload} style={{ color: "#5c5391" }} />
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6 mb-3 d-flex align-items-stretch">
                            <div className="card add-product-card">
                                <div className="card-body d-flex flex-column">
                                    <p className="card-text mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.</p>
                                    <Button id='addProduct' onClick={funAddManually} className="btn btn-secondary text-white mt-auto align-self-start add-manually-btn" size="lg">{Constant.INVENTORY_ADD_PRODUCT_MANUALLY_BTN} | <FontAwesomeIcon className="opacity-8" icon={faPlus} style={{ color: "#5c5391" }} />
                                    </Button>
                                </div>
                            </div>
                        </div>
                    </Row>
                    <ConfirmDailog
                        text={dialogText}
                        content={fileName}
                        heading={''}
                        onYes={onUploadFile}
                        isConfirm={isConfirm}
                        onNo={onCancelUpload}
                        open={showConfirm}
                    />
                </div>
            </ReactCSSTransitionGroup>
        </Fragment>
    )
}
export default InventoryForm