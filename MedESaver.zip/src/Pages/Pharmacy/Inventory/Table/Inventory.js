import React, { useState, useCallback, Fragment, useEffect } from 'react';
import { useDispatch, useStore } from 'react-redux';
import { useHistory, Link } from "react-router-dom";
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import PageTitle from '../../../../Layout/AppMain/PageTitle';
import { Form, Alert, FormGroup, Row, Col, Card, CardBody, CardTitle, Input, Label } from 'reactstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faPlus, faSearch } from '@fortawesome/free-solid-svg-icons';
import * as Constant from "../../../../constant";
import { Button, } from 'reactstrap';
import ProductTable from '../../../../Components/Table/MedESaverTable';
import { getTableData } from '../../../../Function/Table/TableFormAction';
import { saveAction } from '../../../../Function/Form/FormAction';
import ProductInfo from '../Cards/ProductInfo'
import '../../../../css/Pharmacy.css';
import * as commonFunction from '../../../../Function/getGlobalVariable';
import ConfirmDailog from '../../../../Function/ConfirmDailog';

/**Inventory */
function Inventory() {

  const history = useHistory();
  const dispatch = useDispatch();
  const store = useStore();

  const [notificationShow, setNotificationShow] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState({ 'message': '', 'className': '' });
  const [searchProduct, setSearchProduct] = React.useState();
  const [data, setData] = React.useState([]);
  const [loading, setLoading] = React.useState(false);
  const [pageCount, setPageCount] = React.useState(1);
  const fetchIdRef = React.useRef(0);

  /**Dialog box */
  const [dialogText, setDialogText] = useState('');
  const [showConfirm, setShowConfirm] = useState(false);
  const [dialogState, setDialogState] = useState(false);
  const [isConfirm, setIsConfirm] = useState(false);

  /**Pharmacy Id */
  const pharamcyId = commonFunction.getPharmacyId();

  /** produuct info */
  const [productInfoLoad, setProductInfoLoad] = React.useState(false);

  //Table Columns Settings
  const columns = React.useMemo(
    () => [
      {
        Header: <div><FontAwesomeIcon className="ml-2 opacity-8 mr-1" icon={faEye} />{Constant.ORDER_VIEW}</div>,
        accessor: 'view',
        disableSortBy: true,
        Cell: ({ row }) => { return (<a onClick={() => funRowOnclick(row.original)} style={{ cursor: 'pointer' }}><FontAwesomeIcon className="ml-2 opacity-8 text-info mr-1" icon={faEye} />  {Constant.INVENTORY_VIEW}</a>) }
      },
      {
        Header: 'MID',
        accessor: 'id',
      },
      {
        Header: 'Medicine Name',
        accessor: 'name',
      },
      {
        Header: 'Price',
        accessor: 'pharmacy_price',
        Cell: ({ value, column, row }) => {
          return (<div>₹{value}</div>);
        }
      },
      {
        Header: 'Units',
        accessor: 'units',
      },
      {
        Header: 'Prescription',
        accessor: 'prescription',
      },
      {
        Header: 'Image',
        accessor: 'imageUrl',
        disableSortBy: true,
        Cell: ({ value }) => { return (<div><img src={value} className='invetery-list-img' alt='' /></div>) }
      },
      {
        Header: 'Status',
        accessor: 'availability_status',
        Cell: ({ value, column, row }) => {
          return (
            <label className="switch">
              <input type="checkbox" checked={value} onChange={() => changeStatus(row, value)} />
              <div className="slider round"></div>
            </label>
          )
        }
      },
    ],
    []
  );

  const changeStatus = useCallback(async (rowData, value) => {
    let saveMedicineData = {
      "pharmacy_id": pharamcyId,
      "medicine_id": rowData.original.id,
      "price": rowData.original.pharmacy_price,
      "status": !value
    }
    let response;
    //for update medicine Data
    if (saveMedicineData.medicine_id !== '') {
      response = await saveAction(saveMedicineData, dispatch, store, Constant.API_SAVE_PHARMACY_MEDICINE_DATA);
      if (response.error) {
        funSetDialog(<span style={{ color: 'red' }}>{rowData.original.id} : Error in updating medicine status</span>, false, true);
      } else {
        let param = {};
        if (paginationRef.current.searchProduct !== '') {
          param = { 'name': paginationRef.current.searchProduct };
        }
        await funSetTableData(paginationRef.current.pageIndex, paginationRef.current.pageSize, paginationRef.current.sort, paginationRef.current.filters, param);
        funSetDialog(<span style={{ color: 'green' }}>{rowData.original.id} : Medicine status update successfully</span>, false, true);
      }
    }
  });

  /**set dialog box */
  useEffect(() => {
    setShowConfirm(dialogState);
  }, [dialogState]);

  /**product info */
  useEffect(() => {
    setProductInfoLoad(!productInfoLoad);
  }, [data]);

  /** fetch Table data by search*/
  useEffect(() => {
    const funcSearchProduct = async () => {
      let param = {};
      if (searchProduct !== '') {
        param = { 'name': searchProduct };
        paginationRef.current.searchProduct = searchProduct;
      }
      setLoading(true);
      await funSetTableData(paginationRef.current.pageIndex, paginationRef.current.pageSize, paginationRef.current.sort, paginationRef.current.filters, param);
      setLoading(false);
    }
    funcSearchProduct();
  }, [searchProduct]);

  /** table data view click */
  const funRowOnclick = (rowData) => {
    sessionStorage.setItem("row_id", rowData.id);
    sessionStorage.setItem("isNewMode", 1);
    history.push({ pathname: '/Pharmacy/Inventory/add-manullay', state: rowData.id });
  };

  //set callback function for ser ver side pagination
  const paginationRef = React.useRef();
  const fetchData = async ({ pageSize, pageIndex, sort, filters }) => {
    paginationRef.current = { pageSize, pageIndex, sort, filters };
    const fetchId = ++fetchIdRef.current;
    setLoading(true);
    if (fetchId === fetchIdRef.current) {
      let param = {};
      if (searchProduct !== '') {
        param = { 'name': searchProduct };
        paginationRef.current.searchProduct = searchProduct;
      }
      await funSetTableData(pageIndex, pageSize, sort, filters, param);
    }
    setLoading(false);
  }

  /** Function for fecth table data */
  const funSetTableData = useCallback(async (pageIndex, pageSize, sort, filterData, param) => {
    const tableData = await getTableData(pageIndex, pageSize, sort, filterData, dispatch, store, Constant.API_GET_PHARMACY_MEDICINE_LIST, param);
    if (tableData.error) {
      setNotificationMessage(tableData.setNotificationMessage);
      setNotificationShow(true);
    } else {
      setPageCount(tableData.setPageCount);
      //set medicine data     
      setData(tableData.setData.medicines);
    }
  });

  //Render Table with column and data
  const renderProduct = () => {
    return <ProductTable columns={columns} data={data} handleClick={null} fetchData={fetchData} loading={loading} pageCount={pageCount} isDisableFilter={true} isEditable={false} />
  };

  //hide notification message
  const onDismissNotification = () => {
    setNotificationShow(false);
  }

  /** Medicine Search */
  const funSearchProduct = async (e) => {
    let val = e.target.value;
    setSearchProduct(val);
  }

  /** set dailog */
  const funSetDialog = (text, isConfirm, state) => {
    setDialogText(text);
    setIsConfirm(isConfirm);
    setDialogState(state);
  }

  /** Dialog OK */
  const onOkDailogBtn = async () => {
    setDialogState(false);
  }

  return (

    <Fragment><PageTitle heading={Constant.INVENTORY_PAGE_TITTLE} />
      <ReactCSSTransitionGroup
        component="div"
        transitionName="TabsAnimation"
        transitionAppear={true}
        transitionAppearTimeout={0}
        transitionEnter={false}
        transitionLeave={false}>
        <div>
          <Row className='mb-4'>
            <Col lg="12" className="mb-0">
              <ProductInfo param={productInfoLoad} />
            </Col>
          </Row>
          <Row>
            <Col md="12"> <Card className="main-card mb-3">
              <CardBody>
                <CardTitle><Alert color={notificationMessage["className"]} isOpen={notificationShow} closeVariant='white' toggle={onDismissNotification}>
                  {notificationMessage["message"]}
                </Alert>
                </CardTitle>
                <Form id="product">
                  <FormGroup row>
                    <Col lg={{ size: 1 }}>
                      <Label className="mb-1 product-head">{Constant.INVENTORY_PRODUCT}</Label>
                    </Col>
                    <Col lg={{ size: 7 }}>
                      <div className="input-group"><div className="input-group-prepend">
                        <span className="input-group-text search-input-span">
                          <FontAwesomeIcon className="opacity-8" icon={faSearch} style={{ color: "rgb(89 182 236)" }} />
                        </span></div><Input placeholder={Constant.INVENTORY_PRODUCT} type="text" className='search-input' onChange={funSearchProduct} /></div>
                    </Col>
                    <Col lg={{ size: 4 }}>
                      <Link to={{ pathname: '/Pharmacy/Inventory/form', state: '' }}><Button id='addProduct' className="btn-rounded pull-right add-button" size="lg"><FontAwesomeIcon className="opacity-8" icon={faPlus} style={{ color: "rgb(255 255 255)" }} /> | {Constant.INVENTORY_ADD_PRODUCT_BTN}</Button>
                      </Link>
                    </Col>
                  </FormGroup>
                </Form>
                {renderProduct()}
              </CardBody>
            </Card></Col>
          </Row>
          <ConfirmDailog
            text={dialogText}
            content={''}
            heading={''}
            isConfirm={isConfirm}
            onNo={onOkDailogBtn}
            open={showConfirm}
          />
        </div>
      </ReactCSSTransitionGroup>
    </Fragment>
  )
}
export default Inventory