import React, {Fragment} from 'react'
import Inventory from './Inventory' ;

/**Inventory Index*/
function TableInventory(){
        return (
            <Fragment>
               <Inventory/>
            </Fragment>
        )    
}
export default TableInventory;