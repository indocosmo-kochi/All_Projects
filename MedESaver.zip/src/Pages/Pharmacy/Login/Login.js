import React, { useState } from 'react';
import { useDispatch, useStore } from 'react-redux';
import { useHistory, Link } from "react-router-dom";
import { login } from '../../../redux/action/LoginAction';
/**login footer */
import LoginFooter from '../../../Layout/AppLogin/Footer';
import {
  Form,
  Alert,
  Input,
  Col,
} from 'reactstrap';
/**CSS */
import '../../../assets/components/Pages/console-core.css'
import '../../../assets/components/Pages//login-product.css'
import '../../../assets/components/Pages/console-minimal-with-product.css'
import '../../../assets/components/Pages/login-paste-styles.css'
import '../../../assets/components/Pages/login.css';

/**
 * Login
 * @returns 
 */
function Login() {

  const dispatch = useDispatch();
  const history = useHistory();
  const store = useStore();

  /**Set Login Fields and Errors*/
  const [pharmacyLoginfields, setPharmacyLoginFields] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});

  const [notificationShow, setNotificationShow] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState({ 'message': '', 'className': '' });
  const onDismissNotification = () => {
    setNotificationShow(false);
  }

  /** Read the Input Values */
  const onChangeHandler = (event) => {
    let name = event.target.name;
    let val = event.target.value;
    pharmacyLoginfields[name] = val;
    setPharmacyLoginFields(pharmacyLoginfields);
  }

  /**Input Validation */
  const validation = () => {
    let errors = {};
    let formIsValid = true;
    if (pharmacyLoginfields.email === '') {
      formIsValid = false;
      errors['email'] = 'Please Enter User ID';
    }
    if (pharmacyLoginfields.password === '') {
      formIsValid = false;
      errors['password'] = 'Please Enter Password';
    }
    setErrors(errors);
    return formIsValid;
  }

  /**Login submission */
  const onSubmit = async (ev) => {
    ev.preventDefault();
    if (validation()) {
      let id = pharmacyLoginfields.email;
      let password = pharmacyLoginfields.password;
      await dispatch(login(id, password));
      const actionState = store.getState();
      const loginResponse = actionState.LoginReducer;
      if (loginResponse.items.message === 'Success') {
        sessionStorage.setItem(['pharamcyId'], id ? id : null);
        //sessionStorage.setItem(['jwt'], loginResponse.items.token ? loginResponse.items.token : null);
        sessionStorage.setItem(['pharamcyName'], loginResponse.items.name ? loginResponse.items.name : null);
        history.push({ pathname: "/Pharmacy/Inventory/Table" });
      } else {
        setNotificationMessage({ 'message': loginResponse.error.response.data.message, 'className': 'danger' });
        setNotificationShow(true);
      }
    }
  }

  return (
    <div>
      <Form id="loginForm" onSubmit={(ev) => onSubmit(ev)}>
        <div className="login__container">
          <noscript>
            <iframe src=""
              height="0" width="0" className="login__frame" title='login'>
            </iframe>
          </noscript>
          <nav className="navbar navbar-inverse navbar-fixed-top">
            <div className="row">
              <div className="col-sm-8 col-md-10">
                <nav className="collapse navbar-collapse">
                  <div className="navbar-header">
                  </div>
                </nav>
              </div>
            </div>
          </nav>
          <div id="minimal">
            <div className="col-md-12">
              <noscript>
                <div className="alert alert-warning" data-s="warning-javascript">
                  <a href="/console">
                    MedESaver Console
                  </a> is designed for javascript enabled browsers. Please enable javascript before proceeding.
                </div>
              </noscript>
              <div id="content">
                <div className="col-md-20 col-md-offset-2">
                  <div id="alert-container" className="hidden" data-s="flash-messages">
                  </div>
                </div>
                <header>
                  <h1>
                  </h1>
                </header>
                <div className="row" style={{ marginTop: '35px' }}>
                  <Col lg={12}>
                    <Alert color={notificationMessage["className"]} isOpen={notificationShow} toggle={onDismissNotification}>
                      {notificationMessage["message"]}
                    </Alert>
                  </Col>
                </div>
                <div className="row">
                  <div className="col-sm-20 col-md-16 col-sm-offset-2 col-md-offset-4">
                    <h1 className="paste-page-header">Log in</h1>
                    <div className="form-group">
                      <div className="col-md-24">
                        <label className="paste-input-label">User ID
                        </label>
                        <div className="paste-input-wrapper">
                          <Input type="text" name="email" maxLength="50" onChange={onChangeHandler} placeholder="User ID" tabIndex="1" className="paste-input sl_whiteout" autoFocus="autoFocus" />
                        </div>
                        <div><span style={{ color: "red" }}>{errors["email"]}</span></div>
                        <label className="paste-input-label input__container">Password
                        </label>
                        <div className="paste-input-wrapper">
                          <Input type="password" name="password" onChange={onChangeHandler} placeholder="Password" tabIndex="1" className="paste-input sl_whiteout" autoFocus="autoFocus" maxLength="255" />
                        </div>
                        <div><span style={{ color: "red" }}>{errors["password"]}</span></div>
                      </div>
                    </div>
                    <div className="form-group col-md-24">
                      <button
                        type="submit"
                        tabIndex="2"
                        className="paste-primary-button login__button common__top"
                        data-loading-text="<i className='icon icon-spinner icon-spin'></i>"
                        value="Log in"
                      >Login
                      </button>
                    </div>
                    <span className="paste-text">
                      <Link to="/Pharmacy/email-confirm">Forgot password</Link>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <LoginFooter footerClassName='col-md-12 login-product-section' />
        </div>
      </Form>
      <footer className="footer">
        <div className="container text-center">
          Copyright &copy; 2025
          <a target="_parent" href="#" className="link-unadorned"> MedESaver Inc
          </a> ,
          <a target="_parent" href="https://www.indocosmo.com/jp/" className="link-unadorned"> Indocosmo Systems Pvt Ltd
          </a> Inc. All rights reserved.
        </div>
      </footer>
    </div>
  )
}
export default Login;