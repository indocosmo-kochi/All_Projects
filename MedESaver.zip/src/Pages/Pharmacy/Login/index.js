import React, {Fragment} from 'react'
import Login from './Login' ;

/**Login Index*/
function FormLogin(){
        return (
            <Fragment>
               <Login/>
            </Fragment>
        )    
}
export default FormLogin;