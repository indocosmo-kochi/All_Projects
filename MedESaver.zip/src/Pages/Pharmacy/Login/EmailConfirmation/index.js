import React, {Fragment} from 'react'

import EmailConfirmation from './EmailConfirmation';
function EmailConfirmationForm(){
        return (
            <Fragment>
               <EmailConfirmation/>
            </Fragment>
        )
    
}
export default EmailConfirmationForm;



