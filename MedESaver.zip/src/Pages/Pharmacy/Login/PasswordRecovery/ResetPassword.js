import React, { useState } from 'react';
import { useDispatch, useStore } from 'react-redux';
import { Link, useLocation } from "react-router-dom";
/**login footer */
import LoginFooter from '../../../../Layout/AppLogin/Footer';
/**CSS */
import '../../../../assets/components/Pages/console-core.css'
import '../../../../assets/components/Pages//login-product.css'
import '../../../../assets/components/Pages/console-minimal-with-product.css'
import '../../../../assets/components/Pages/login-paste-styles.css'
import '../../../../assets/components/Pages/login.css';
import { Button, Form, Alert, Input, Col, } from 'reactstrap';
/**Action */
import { resetPasswordAction } from '../../../../redux/action/ResetPasswordAction';

function ForgetPasswordOwner() {

  const dispatch = useDispatch();  
  const store = useStore();
  const location = useLocation();

  const [notificationShow, setNotificationShow] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState({ 'message': '', 'className': '' });
  const [forgotLoginFields, setforgotLoginFields] = useState({ email: '', password: '', confirm_password: '',pharmacy_id : '' })
  const [errors, setErrors] = useState({});

  const onDismissNotification = () => {
    setNotificationShow(false);
  }

  /**change value of input */
  const onChangeHandler = (ev) => {
    let name = ev.target.name;
    let val = ev.target.value;
    forgotLoginFields[name] = val;
    setforgotLoginFields(forgotLoginFields);
  }

  /** function for reset password */
  const onSubmit = async (ev) => {
    ev.preventDefault();    
    if (validation()) {
      let param = {
        "email": forgotLoginFields.email,
        "pharmacy_id" : forgotLoginFields.pharmacy_id,
        "password_reset_token": new URLSearchParams(location.search).get("token"),
        "password": forgotLoginFields.password,
        "confirm_password": forgotLoginFields.confirm_password,
      }
      await dispatch(resetPasswordAction(param));
      const actionState = store.getState();
      const response = actionState.ResetPasswordReducer;
      if (response.error === null) {
        setNotificationMessage({ 'message': 'Password reset successfully', 'className': 'success' });
        setNotificationShow(true);
      } else {
        setNotificationMessage({ 'message': response.error.response.data.message, 'className': 'danger' });
        setNotificationShow(true);
      }
    }
  }

  /** validation */
  const validation = () => {
    let errors = {};
    let formIsValid = true;
    if (forgotLoginFields.pharmacy_id === '') {
      formIsValid = false;
      errors['pharmacy_id'] = 'Please Enter User ID';
    }
    if (forgotLoginFields.email === '') {
      formIsValid = false;
      errors['email'] = 'Please Enter Email';
    } else {
      if (forgotLoginFields.password === '') {
        formIsValid = false;
        errors['password'] = 'Please Enter New Password';
      } else {
        if (forgotLoginFields.confirm_password === '') {
          formIsValid = false;
          errors['confirm_password'] = 'Please Enter Confirm Password';
        } else {
          if (forgotLoginFields.confirm_password !== forgotLoginFields.password) {
            formIsValid = false;
            errors['confirm_password'] = 'New Password and Confirm Password does not match';
          }
        }
      }
    }
    setErrors(errors)
    return formIsValid;
  }

  return (
    <div >
      <Form id="loginForm" onSubmit={(ev) => onSubmit(ev)}>
        <div className="login__container">
          <noscript>
            <iframe src=""
              height="0" width="0" className="login__frame" title='login'>
            </iframe>
          </noscript>
          <nav className="navbar navbar-inverse navbar-fixed-top">
            <div className="row">
              <div className="col-sm-8 col-md-10">
                <nav className="collapse navbar-collapse">
                  <div className="navbar-header">
                  </div>
                </nav>
              </div>
            </div>
          </nav>
          <div id="minimal">
            <div className="col-md-12">
              <noscript>
                <div className="alert alert-warning" data-s="warning-javascript">
                  <a href="/console">
                    MedESaver Console
                  </a> is designed for javascript enabled browsers. Please enable javascript before proceeding.
                </div>
              </noscript>
              <div id="content">
                <div className="col-md-20 col-md-offset-2">
                  <div id="alert-container" className="hidden" data-s="flash-messages">
                  </div>
                </div>
                <header>
                  <h1>
                  </h1>
                </header>
                <div className="row" style={{ marginTop: '35px' }}>
                  <Col lg={12}>
                    <Alert color={notificationMessage["className"]} isOpen={notificationShow} toggle={onDismissNotification}>
                      {notificationMessage["message"]}
                    </Alert>
                  </Col>
                </div>
                <div className="row">
                  <div className="col-sm-20 col-md-16 col-sm-offset-2 col-md-offset-4">
                    <h1 className="paste-page-header">Forgot Password
                    </h1>
                    <div className="form-group">
                      <div className="col-md-24  mb-2">
                        <label className="paste-input-label">User ID
                        </label>
                        <div className="paste-input-wrapper">
                          <Input type="text" name="pharmacy_id" maxLength="50" onChange={onChangeHandler} className="form-control paste-input sl_whiteout" autoFocus="autoFocus" placeholder='User ID' />
                        </div>
                        <div><span style={{ color: "red" }}>{errors["pharmacy_id"]}</span></div>
                        <label className="paste-input-label">Email
                        </label>
                        <div className="paste-input-wrapper">
                          <Input type="text" name="email" maxLength="50" onChange={onChangeHandler} className="form-control paste-input sl_whiteout" autoFocus="autoFocus" placeholder="Email" />
                        </div>
                        <div><span style={{ color: "red" }}>{errors["email"]}</span></div>
                        <div className="col-md-24">
                          <label className="paste-input-label">New Password
                          </label>
                          <div className="paste-input-wrapper">
                            <Input type="password" name="password" placeholder="New Password" onChange={onChangeHandler} className="paste-input sl_whiteout form-control" autoFocus="autoFocus" />
                          </div>
                          <div><span style={{ color: "red" }}>{errors["password"]}</span></div>
                        </div>
                        <div className="col-md-24">
                          <label className="paste-input-label">Confirm Password
                          </label>
                          <div className="paste-input-wrapper">
                            <input type="password" name="confirm_password" placeholder="Confirm Password" onChange={onChangeHandler} className="paste-input sl_whiteout form-control input-small" autoFocus="autoFocus" />
                          </div>
                          <div><span style={{ color: "red" }}>{errors["confirm_password"]}</span></div>
                        </div>
                      </div>
                    </div>
                    <div className="form-group col-md-24">
                      <Button
                        //role="login-button"                          
                        tabIndex="2"
                        className="paste-primary-button common__top"
                        data-loading-text="<i className='icon icon-spinner icon-spin'></i>"
                        type="submit" >Reset Password
                      </Button>
                    </div>
                    <span className="paste-text mt-2">
                      <Link to="/Pharmacy/Login">Login</Link>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <LoginFooter footerClassName='col-md-12 login-product-section' />
        </div>
      </Form>
      <footer className="footer">
        <div className="container text-center">
          Copyright &copy; 2025
          <a target="_parent" href="#" className="link-unadorned"> MedESaver Inc
          </a> ,
          <a target="_parent" href="https://www.indocosmo.com/jp/" className="link-unadorned"> Indocosmo Systems Pvt Ltd
          </a> Inc. All rights reserved.
        </div>
      </footer>
    </div>
  );
}

export default ForgetPasswordOwner;