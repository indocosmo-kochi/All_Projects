import React, {Fragment} from 'react'

import ForgetPassword from './ResetPassword';
//class FormElementsControls extends React.Component {
function ForgetPasswordForm(){
        return (
            <Fragment>
               <ForgetPassword/>
            </Fragment>
        )
    
}
export default ForgetPasswordForm;



