import React, { Fragment } from 'react'
import Dashboard from './Dashboard';

/**Dashboard Index*/
function FormDashboard() {
    return (
        <Fragment>
            <Dashboard />
        </Fragment>
    )
}
export default FormDashboard;