import React, { useState, useEffect } from 'react';
import '../../../css/Dashboard.css';
import Header from '../../../Layout/Header';
import Sidebar from '../../../Layout/Sidebar';
import PageTitle from '../../../Layout/PageTitle';
import { Row, Col, Input } from 'reactstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShop, faCartShopping, faBarsProgress, faTasks, faSort, faTag } from '@fortawesome/free-solid-svg-icons';

/**Dashboard */
function Dashboard() {
    const [isMobile, setIsMobile] = useState(window.innerWidth < 1200);   
    useEffect(() => {
        window.addEventListener("resize", () => {
            const ismobile = window.innerWidth < 1200;
            if (ismobile !== isMobile) setIsMobile(ismobile);
        }, false);
    }, [isMobile]);
    return (
        <div className={"app-container app-theme-whitet fixed-sidebar fixed-footer " + (isMobile ? 'closed-sidebar closed-sidebar-mobile' : '')}>
            <Header />
            <div className="app-main">
                <Sidebar />
                <div className="app-main__outer">
                    <div className="app-main__inner" >
                        <div className="dashboard__container">
                            <Row>
                                <Col lg="10" className="mb-1">
                                    <PageTitle
                                        heading={"Dashborad"} />
                                        {/* <span className='mb-3 card-title text-left'>STATISTICS</h1> */}
                                </Col>
                                <Col lg="2" className="mb-1">
                                    <Input type='select' className='form-control form-control-sm'>
                                    <option value="">Today</option>
                                    <option value="">This Month</option>
                                    <option value="">Last Month</option>
                                    <option value="">This Week</option>
                                    <option value="">Last Week</option>
                                    </Input>
                                </Col>
                            </Row>
                            <Row className='mb-4'>
                                <Col lg="12" className="mb-0">
                                    <div className="row-eq-height row">                                        
                                        <div className="col-sm-12 col-md-6 col-xl-2">
                                            <div className="gradient-blackberry card">
                                                <div className="card-content">
                                                    <div className="pt-2 pb-2 card-body" style={{padding: ".7rem"}}>
                                                        <div className="media">
                                                            <div className="white media-body text-left">
                                                                <h3 className="mb-1">Total Orders</h3>
                                                                <span className='font-weight-bold'>2000</span>
                                                            </div>
                                                            <FontAwesomeIcon className="ml-2 opacity-8" icon={faShop} style={{color: "#5c5391"}}/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-sm-12 col-md-6 col-xl-2">
                                            <div className="gradient-blackberry card">
                                                <div className="card-content">
                                                    <div className="pt-2 pb-2 card-body" style={{padding: ".7rem"}}>
                                                        <div className="media">
                                                            <div className="white media-body text-left">
                                                                <h3 className="mb-1">New Orders</h3>
                                                                <span className='font-weight-bold'>50</span>
                                                            </div>
                                                            <FontAwesomeIcon className="ml-2 opacity-8" icon={faCartShopping} style={{color: "#5c5391"}}/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-sm-12 col-md-6 col-xl-2">
                                            <div className="gradient-blackberry card">
                                                <div className="card-content">
                                                    <div className="pt-2 pb-2 card-body" style={{padding: ".7rem"}}>
                                                        <div className="media">
                                                            <div className="white media-body text-left">
                                                                <h3 className="mb-1">In Progress</h3>
                                                                <span className='font-weight-bold'>100</span>
                                                            </div>
                                                            <FontAwesomeIcon className="ml-2 opacity-8" icon={faBarsProgress} style={{color: "#5c5391"}}/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-sm-12 col-md-6 col-xl-2">
                                            <div className="gradient-blackberry card">
                                                <div className="card-content">
                                                    <div className="pt-2 pb-2 card-body" style={{padding: ".7rem"}}>
                                                        <div className="media">
                                                            <div className="white media-body text-left">
                                                                <h3 className="mb-1">Completed</h3>
                                                                <span className='font-weight-bold'>500</span>
                                                            </div>
                                                            <FontAwesomeIcon className="ml-2 opacity-8" icon={faTasks} style={{color: "#5c5391"}}/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-sm-12 col-md-6 col-xl-2">
                                            <div className="gradient-blackberry card">
                                                <div className="card-content">
                                                    <div className="pt-2 pb-2 card-body" style={{padding: ".7rem"}}>
                                                        <div className="media">
                                                            <div className="white media-body text-left">
                                                                <h3 className="mb-1">Total Sales</h3>
                                                                <span className='font-weight-bold'>₹500</span>
                                                            </div>
                                                            <FontAwesomeIcon className="ml-2 opacity-8" icon={faTag} style={{color: "#5c5391"}}/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>                                        
                                    </div>
                                </Col>
                            </Row>
                            <Row className='mb-4'>
                                <div className="col-xl-6 col-lg-12 col-12 mb-3">
                                    <h4 className='card-title mb-3 text-left'>Top Selling Product</h4>
                                    <div className='card'>
                                        <div className='card-content'>
                                            <div className='card-body p-0'>
                                                <div className='table-responsive'>
                                                    <table className='table text-center m-0'>
                                                        <thead className='bg-light'>
                                                            <tr>
                                                                <th>PRODUCT <FontAwesomeIcon className="ml-2 opacity-8" icon={faSort} style={{color: "#5c5391"}}/></th>
                                                                <th>TOTAL AMOUNT <FontAwesomeIcon className="ml-2 opacity-8" icon={faSort} style={{color: "#5c5391"}}/></th>
                                                                <th>TOTAL ORDERS <FontAwesomeIcon className="ml-2 opacity-8" icon={faSort} style={{color: "#5c5391"}}/></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>Medicin Name</td>
                                                                <td className='text-primary'>₹18000</td>
                                                                <td className='text-primary'>1.5K</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Medicin Name</td>
                                                                <td className='text-primary'>₹15000</td>
                                                                <td className='text-primary'>1.1K</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Medicin Name</td>
                                                                <td className='text-primary'>₹13000</td>
                                                                <td className='text-primary'>1.0K</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Medicin Name</td>
                                                                <td className='text-primary'>₹11000</td>
                                                                <td className='text-primary'>0.52K</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Medicin Name</td>
                                                                <td className='text-primary'>₹8000</td>
                                                                <td className='text-primary'>0.31K</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Medicin Name</td>
                                                                <td className='text-primary'>₹5000</td>
                                                                <td className='text-primary'>0.25K</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-xl-6 col-lg-12 col-12 mb-3">
                                    <h4 className='card-title mb-3 text-left'>Top Customers</h4>
                                    <div className='card'>
                                        <div className='card-content'>
                                            <div className='card-body p-0'>
                                                <div className='table-responsive'>
                                                <table className='table text-center m-0'>
                                                        <thead className='bg-light'>
                                                            <tr>
                                                                <th>CUSTOMER <FontAwesomeIcon className="ml-2 opacity-8" icon={faSort} style={{color: "#5c5391"}}/></th>
                                                                <th>TOTAL AMOUNT <FontAwesomeIcon className="ml-2 opacity-8" icon={faSort} style={{color: "#5c5391"}}/></th>
                                                                <th>TOTAL ORDERS <FontAwesomeIcon className="ml-2 opacity-8" icon={faSort} style={{color: "#5c5391"}}/></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>Customer Name</td>
                                                                <td className='text-primary'>₹3000</td>
                                                                <td className='text-primary'>50</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Customer Name</td>
                                                                <td className='text-primary'>₹1000</td>
                                                                <td className='text-primary'>10</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Customer Name</td>
                                                                <td className='text-primary'>₹2900</td>
                                                                <td className='text-primary'>25</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Customer Name</td>
                                                                <td className='text-primary'>₹1560</td>
                                                                <td className='text-primary'>14</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Customer Name</td>
                                                                <td className='text-primary'>₹1450</td>
                                                                <td className='text-primary'>16</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Customer Name</td>
                                                                <td className='text-primary'>₹1450</td>
                                                                <td className='text-primary'>16</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </Row>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default Dashboard