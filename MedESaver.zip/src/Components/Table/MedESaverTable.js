import React, { useState } from 'react';
import { useTable, useFilters, useRowSelect, useSortBy, usePagination } from 'react-table';
import { Table } from 'reactstrap';
import { Button, Form, FormGroup, Input, InputGroup, InputGroupAddon, Spinner, Label } from 'reactstrap';
import { CheckboxGroup } from '@createnl/grouped-checkboxes';
import '../../assets/components/Pages/teraTable.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSort, faSortAlphaDown, faSortAlphaUp } from '@fortawesome/free-solid-svg-icons';

const IndeterminateCheckbox = React.forwardRef(
  ({ indeterminate, ...rest }, ref) => {
    const defaultRef = React.useRef();
    const resolvedRef = ref || defaultRef;

    React.useEffect(() => {
      resolvedRef.current.indeterminate = indeterminate;
    }, [resolvedRef, indeterminate]);

    return <input type='checkbox' ref={resolvedRef} {...rest} />;
  },
);

// Define a default UI for filtering
function DefaultColumnFilter({ column: { filterValue, preFilteredRows, setFilter }, }) {
  const [filterText, setFilterText] = useState(filterValue);
  //set filter text
  const onchangeSetFilterValue = (text) => {
    if (text !== '' && text !== undefined) {
      setFilterText(text);
    } else {
      setFilter('');
      setFilterText('');
    }
  }

  //set filter text on button click
  const onClickSetFilterValue = (text) => {
    setFilter(text);
  }

  return (
    <div className="filter_container">
      <InputGroup style={{ 'flexWrap': 'inherit', minWidth: '150px' }}>
        <Input bsSize="sm"
          defaultValue={filterText || ''}
          className="filter_txt"
          onChange={e => {
            onchangeSetFilterValue(e.target.value || undefined) // Set undefined to remove the filter entirel
          }}
          placeholder={"Search records..."}
        />
        <InputGroupAddon addonType="append">
          <Button color="secondary" size="sm" onClick={() => onClickSetFilterValue(filterText)}><i className="pe-7s-search"> </i></Button>
        </InputGroupAddon>
      </InputGroup>

    </div>
  )
}

function fuzzyTextFilterFn(rows, id, filterValue) {
  //return matchSorter(rows, filterValue, { keys: [row => row.values[id]] })
}
fuzzyTextFilterFn.autoRemove = (val) => !val;

// Create a default prop getter
const defaultPropGetter = () => ({})

function TeraTable({ columns, data, handleClick, fetchData,
  loading,
  pageCount: controlledPageCount, onChangeSort, checkboxGroup, isDisableFilter, pagination, isEditable,
  getCellProps = defaultPropGetter }) {

  //filter function in keystroke
  const filterTypes = React.useMemo(
    () => ({
      // Add a new fuzzyTextFilterFn filter type.
      fuzzyText: fuzzyTextFilterFn,
    }),
    []
  )

  const defaultColumn = React.useMemo(
    () => ({
      // Let's set up our default Filter UI
      Filter: DefaultColumnFilter,
    }),
    []
  )

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    prepareRow,
    selectedFlatRows,
    page,
    canPreviousPage,
    canNextPage,
    pageOptions,
    pageCount,
    gotoPage,
    nextPage,
    previousPage,
    setPageSize,
    state: { pageIndex, pageSize, sortBy, filters },
  } = useTable(
    {
      columns,
      data,
      initialState: {
        hiddenColumns: columns.filter(column => !column.show).map(column => column.id),
        pageIndex: 0,
        filters: eval(sessionStorage.getItem("filters") != undefined ? sessionStorage.getItem("filters") : []),
        pageSize: 5,
      },
      defaultColumn,
      filterTypes,
      manualPagination: true,
      pageCount: controlledPageCount,
      manualSortBy: true,
      manualFilters: true,
    },
    useFilters, // useFilters!
    useSortBy,
    usePagination,
    useRowSelect,
    (hooks) => {
      if (handleClick !== null) {
        hooks.visibleColumns.push((columns) => [
          // Let's make a column for selection
          {
            id: 'selection',
            // The header can use the table's getToggleAllRowsSelectedProps method
            // to render a checkbox
            Header: ({ getToggleAllRowsSelectedProps }) => (
              <div>
                <IndeterminateCheckbox {...getToggleAllRowsSelectedProps({ title: "Toggle All Row Selection" })} />
              </div>
            ),
            // The cell can use the individual row's getToggleRowSelectedProps method
            // to the render a checkbox
            Cell: ({ row }) => (
              <div>
                <IndeterminateCheckbox {...row.getToggleRowSelectedProps({ title: "Toggle Row Selection" })} />
              </div>
            ),
          },
          ...columns,
        ]);
      } else {
        hooks.visibleColumns.push((columns) => [
          ...columns,
        ]);
      }

    }
  );

  React.useEffect(() => {

    let sort = {};
    if (sortBy.length !== 0) {
      if (sortBy[0].desc === true) {
        const key = sortBy[0].id
        sort[key] = 'DESC'
      } else if (sortBy[0].desc === false) {
        const key = sortBy[0].id
        sort[key] = 'ASC'
      }
    }
    sessionStorage.removeItem('filters');
    sessionStorage.setItem("filters", JSON.stringify(filters));

    fetchData({ pageIndex, pageSize, sort, filters })

  }, [pageIndex, pageSize, sortBy, filters])

  React.useEffect(() => {
    if (handleClick !== null) {
      handleClick(selectedFlatRows);
    }
  }, [selectedFlatRows]);

  const nextPageHandler = () => {
    nextPage();
  }

  // Render the UI for your table
  return (
    <div>
      {loading ? (<div className="spiner__container"> <Spinner style={{ width: '3rem', height: '3rem', color: '#0066ff' }} /> </div>) : ""}
      <Table {...getTableProps()} hover responsive className="mb-0 table">
        <thead className='bg-color-light-grey'>
          {headerGroups.map((headerGroup) => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map((column) => (
                <th className='th-width' scope="col" {...column.getHeaderProps(column.getSortByToggleProps({ title: "Toggle SortBy" }))} >{column.render('Header')}

                  <span className="">
                    {column.isSorted
                      ? column.isSortedDesc
                        ? <FontAwesomeIcon className="ml-2 opacity-8" icon={faSortAlphaDown} style={{ color: "#5c5391" }} />
                        : <FontAwesomeIcon className="ml-2 opacity-8" icon={faSortAlphaUp} style={{ color: "#5c5391" }} />
                      : column.disableSortBy ? '' : <FontAwesomeIcon className="ml-2 opacity-8" icon={faSort} style={{ color: "#5c5391" }} />}
                  </span>
                </th>
              ))}
            </tr>
          ))}
          {isDisableFilter === undefined ? (
            headerGroups.map((headerGroup) => (
              <tr {...headerGroup.getHeaderGroupProps()}>
                {headerGroup.headers.map((column) => (
                  <th className='th-width' scope="col" {...column.getHeaderProps()}>
                    <div className='th-width'>{column.canFilter ? column.render("Filter") : null}</div>
                  </th>
                ))}
              </tr>
            ))
          ) : (
            null
          )}
        </thead>
        <tbody {...getTableBodyProps()}>

          {loading ? <tr><td colSpan={columns.length} className="textAlignCenter">{"No records"}</td></tr> :
            page.length === 0 ? (
              <tr><td colSpan={columns.length} className="textAlignCenter">{"No records"}</td></tr>
            ) : (
              page.map((row, i) => {
                prepareRow(row);
                return (
                  <tr {...row.getRowProps()}>
                    {checkboxGroup ? (<CheckboxGroup>
                      {row.cells.map((cell) => {
                        return (
                          <td {...cell.getCellProps()} className={isEditable === undefined || isEditable === true ? "table-tr-td-hover" : ""}>{cell.render('Cell')}</td>
                        );
                      })}</CheckboxGroup>
                    ) : (
                      row.cells.map((cell) => {
                        return (
                          <td {...cell.getCellProps([
                            getCellProps(cell),
                          ])} className={isEditable === undefined || isEditable === true ? "table-tr-td-hover" : ""}>{cell.render('Cell')}</td>
                        );
                      })
                    )}
                  </tr>
                );
              })
            )

          }

        </tbody>
      </Table>
      {pagination === undefined || pagination === true ?
        <div className="pagination pull-right">
          <Form inline>
            <FormGroup row>
              <Button outline className="mb-2 mr-2 btn-transition" size="sm" color="dark" onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
                {'<<'}
              </Button>{' '}
              {/*  <Col lg="12"> */}             
              <Button outline className="mb-2 mr-2 btn-transition pull-right" size="sm" color="dark" onClick={() => previousPage()} disabled={!canPreviousPage}>
                {'<'}
              </Button>{' '}
              <Button outline className="mb-2 mr-2 btn-transition pull-right" size="sm" color="dark" onClick={nextPageHandler} disabled={!canNextPage}>
                {/*  <button onClick={nextPageHandler} >  */}
                {'>'}
              </Button>{' '}
              {/* </Col> */}
              <Button outline className="mb-2 mr-2 btn-transition" size="sm" color="dark" onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage}>
                {'>>'}
              </Button>{' '}

              <Label>
                {'Page'}{' '}
                <strong>
                  {pageIndex + 1} / {pageOptions.length}
                </strong>{' '}
              </Label>

              <Input className="textAlignCenter"
                type="number"
                value={pageIndex + 1}
                onChange={e => {

                  const page = e.target.value ? Number(e.target.value) - 1 : 0
                  if (Number(e.target.value) <= pageCount) {
                    gotoPage(page)
                  } else {
                    // gotoPage(pageCount - 1)
                    const page_val = pageIndex + 1
                    e.target.value = page_val
                  }
                }} style={{ width: '100px' }}

              />{' '}
              <Label lg={0}>{' Go to page'}{' '}</Label>
              <Input type="select"
                value={pageSize}
                onChange={e => {
                  setPageSize(Number(e.target.value))
                }}
              >
                {[5, 10, 20, 30, 40, 50].map(pageSize => (
                  <option key={pageSize} value={pageSize}>
                    {pageSize}{''}
                  </option>
                ))}
              </Input>
            </FormGroup></Form>
        </div> : null
      }
    </div>
  );
}
export default TeraTable;