/**################Login################################## */
export const API_LOGIN = '/postPharmacyLogin';
export const API_RESETPASSWORD = '/';
export const API_EMAILCONFIRMATION = '/postForgotPassword';
/**Login */
export const LOGIN_REQUEST = "LOGIN_REQUEST"
export const LOGIN_SUCCESS = "LOGIN_SUCCESS"
export const LOGIN_FAILURE = "LOGIN_FAILURE"
/** Reset password */
export const RESETPASSWORD_REQUEST = 'RESETPASSWORD_REQUEST';
export const RESETPASSWORD_SUCCESS = 'RESETPASSWORD_SUCCESS';
export const RESETPASSWORD_FAILURE = 'RESETPASSWORD_FAILURE';
/** Email confirmation */
export const EMAIL_CONFIRMATION_REQUEST = 'EMAIL_CONFIRMATION_REQUEST';
export const EMAIL_CONFIRMATION_SUCCESS = 'EMAIL_CONFIRMATION_SUCCESS';
export const EMAIL_CONFIRMATION_FAILURE = 'EMAIL_CONFIRMATION_FAILURE';
/**################Dashborad############################## */
/**################Order Request########################## */
/** API */
export const API_GET_ORDER_LIST = '/getPharmacyOrders';
export const API_GET_ORDER_DATA = '/getPharmacyOrderDetails';
export const API_ACCEPT_ORDER = '/postAcceptOrder';
export const API_REJECT_ORDER = '/postRejectOrder';
export const API_ORDER_ADDTOCART = '/postAddToCart';
export const API_ORDER_PRISCRIPTION_DWLD = '/getDownloadPrescription';
export const API_ORDER_PRISCRIPTION_UPLOAD = '/postUploadPrescription';
export const API_MAKE_ORDER_PAYMENT = '/getOrderInvoice';
export const API_ORDER_COMPLETED = '/postCompleteOrder';
/**Constant*/
export const ORDER_PAGE_TITTLE = 'Order Request';
export const ORDER_ADD_PAGE_TITTLE = 'Add Order';
export const ORDER_MOST_RECENT_REQUEST = 'Most recent request';
export const ORDER_PRESCRIPTION = 'Prescription';
export const ORDER_ITEM = 'Item';
export const ORDER_ITEM_FROM_CUSTOMER = 'Items from customer’s cart';
export const ORDER_ITEM_FROM_PHARMACY = 'Items from pharmacy';
export const ORDER_ADD_BTN = 'Add Order';
export const ORDER_STATUS_NEW = 'NEW';
export const ORDER_STATUS_INPROGRESS = 'PROGRESS ';
export const ORDER_STATUS_SUCCESS = 'PAYMENT SUCCESS';
export const ORDER_STATUS_REJECT = 'REJECTED';
export const ORDER_STATUS_FAILED = 'PAYMENT FAILED';
export const ORDER_STATUS_PENDING = 'PENDING';
export const ORDER_STATUS_COMPLETED = 'COMPLETED';
export const ORDER_VIEW = 'View';
export const ORDER_ADDITIONAL_DESCRIPTION = 'Additional notes';
export const ORDER_ACCEPT_BTN = 'Accept'
export const ORDER_RECJECT_BTN = 'Reject'
export const ORDER_GEN_CART_BTN = 'Generate Cart'
export const ORDER_SEND_CART_RQ_PAY_BTN = 'Send Cart & Request Payment'
export const ORDER_DATA_TOTAL = 'Total price(Exclude all taxes)'
export const ORDER_ITEM_ADD_IN_CART_SAERCH = 'Search item to add'
export const ORDER_RECENT = 'Recent'
export const ORDER_SEARCH_TXT = 'Search'
export const ORDER_CUSTOMER_TXT = 'Customer';
export const SET_MEDICINE_DATA = 'SET_MEDICINE_DATA';
export const ORDER_DELIVERY_TYPE = 'Delivery Type';
/** POST TO CART */
export const ORDER_POSTTOCART_REQUEST = "ORDER_POSTTOCART_REQUEST"
export const ORDER_POSTTOCART_SUCCESS = "ORDER_POSTTOCART_SUCCESS"
export const ORDER_POSTTOCART_FAILURE = "ORDER_POSTTOCART_FAILURE"
/**###############Inentory################################ */
//API
export const API_GET_PHARMACY_MEDICINE_LIST = '/getPharmacyMedicinesList';
export const API_GET_PHARMACY_MEDICINE_BY_PARAM = '/getPharmacyMedicine';
export const API_SAVE_PHARMACY_MEDICINE_DATA = '/postPharmacyMedicine';
export const API_UPLOAD_PHARMACY_DATA_FILE = '/postImportPharmacyMedicines';
export const API_SEARCH_MEDICINE = '/postSearchMedicine';
export const API_GET_MEDICINE_STATUS_COUNT = '/getPharmacyProductDashboardData';
// Top Data
export const INVENTORY_PRODUCT = 'Product';
export const INVENTORY_PAGE_TITTLE = 'Manage Inventory';
export const INVENTORY_PAGE_ADD_TITTLE = 'Add Product to Inventory';
export const INVENTORY_TOTAL_PRODUCT = 'Total Product';
export const INVENTORY_AVAILABLE = 'Available';
export const INVENTORY_NOT_AVAILABLE = 'Not Available';
export const INVENTORY_EXPIRED = 'Expired';
// List Data
export const INVENTORY_RECENT = 'RECENT';
export const INVENTORY_VIEW = 'View';
// Add Product
export const INVENTORY_ADD_PRODUCT_BTN = 'Add Products';
export const INVENTORY_ADD_PRODUCT_MANUALLY_BTN = 'Add Manually';
export const INVENTORY_ADD_PRODUCT_FILEUPLOAD_BTN = 'Upload File';
export const INVENTORY_SAVE_PRODUCT_BTN = 'Save';
export const INVENTORY_CANCEL_PRODUCT_BTN = 'Cancel';
export const INVENTORY_EDIT_PRODUCT_BTN = 'EDIT';
export const INVENTORY_ADD_MEDICINE_TXT = 'Add Medicine';
//Add form 
export const INVENTORY_ADD_PRODUCT_IMAGE_BTN = 'Upload Image';
export const INVENTORY_MID_TXT = 'MID';
export const INVENTORY_STATUS_TXT = 'Status';
export const INVENTORY_MEDICINE_NAME_TXT = 'Medicine name';
export const INVENTORY_DESCRIPTION_TXT = 'Description';
export const INVENTORY_PRESCRIPTION_TXT = 'Prescription';
export const INVENTORY_PRICE_TXT = 'Price';
export const INVENTORY_UNIT_TXT = 'Unit';
export const INVENTORY_NOT_REQUIRED_TXT = 'Not Required';
export const INVENTORY_REQUIRED_TXT = 'Required';;
export const INVENTORY_MANUFACTURE_TXT = 'Manufacture';
export const INVENTORY_COMPOSITIONS_TXT = 'Compositions';
export const INVENTORY_MRP_TXT = 'MRP(1mg)';
export const INVENTORY_BESTPRICE_TXT = 'Best Price(1mg)';
export const INVENTORY_DISCOUNT_TXT = 'Discount';
export const INVENTORY_NAME_PHARMACY_TXT = 'Name(Pharmacy)';
export const INVENTORY_MRP_PHARMACY_TXT = 'mrp';
export const INVENTORY_BESTPRICE_PHARMACY_TXT = 'Best price';
export const INVENTORY_OFFERS_PHARMACY_TXT = 'Offers';
export const INVENTORY_NAME_NETMEDS_TXT = 'Name(Netmeds)';
export const INVENTORY_MRP_NETMEDS_TXT = 'mrp';
export const INVENTORY_BESTPRICE_NETMEDS_TXT = 'Best price';
export const INVENTORY_OFFERS_NETMEDS_TXT = 'Offers';
export const INVENTORY_NAME_APPOLO_TXT = 'Name(Appolo)';
export const INVENTORY_MRP_APPOLO_TXT = 'mrp';
export const INVENTORY_BESTPRICE_APPOLO_TXT = 'Best price';
export const INVENTORY_OFFERS_APPOLO_TXT = 'Offers';
export const ADD_MORE = 'Add More';
//Actions APIs
export const INVENTORY_GET_PRODUCT_API = 'getproductData';
// CONSTANT FOR ACTION
/**GET SEARCH MEDICINE */
export const GET_SEARCH_MEDICINE_REQUEST = "GET_SEARCH_MEDICINE_REQUEST"
export const GET_SEARCH_MEDICINE_SUCCESS = "GET_SEARCH_MEDICINE_SUCCESS"
export const GET_SEARCH_MEDICINE_FAILURE = "GET_SEARCH_MEDICINE_FAILURE"

/**##############Report################################### */

/** BASIC CONSTANT */
/**Delete */
export const DELETE_REQUEST = "DELETE_REQUEST"
export const DELETE_SUCCESS = "DELETE_SUCCESS"
export const DELETE_FAILURE = "DELETE_FAILURE"
/** Fetch Data */
export const FETCH_DETAILS_REQUEST = "FETCH_DETAILS_REQUEST"
export const FETCH_DETAILS_SUCCESS = "FETCH_DETAILS_SUCCESS"
export const FETCH_DETAILS_FAILURE = "FETCH_DETAILS_FAILURE"
/**Save */
export const SAVE_REQUEST = "SAVE_REQUEST"
export const SAVE_SUCCESS = "SAVE_SUCCESS"
export const SAVE_FAILURE = "SAVE_FAILURE"
/**Update */
export const UPDATE_REQUEST = "UPDATE_REQUEST"
export const UPDATE_SUCCESS = "UPDATE_SUCCESS"
export const UPDATE_FAILURE = "UPDATE_FAILURE"
/**Fetch Data By Id */
export const FETCH_BYID_REQUEST = "FETCH_BYID_REQUEST"
export const FETCH_BYID_SUCCESS = "FETCH_BYID_SUCCESS"
export const FETCH_BYID_FAILURE = "FETCH_BYID_FAILURE"
/**Fetch Data List by param */
export const FETCH_DATA_BYPARAM_REQUEST = "FETCH_DATA_BYPARAM_REQUEST"
export const FETCH_DATA_BYPARAM_SUCCESS = "FETCH_DATA_BYPARAM_SUCCESS"
export const FETCH_DATA_BYPARAM_FAILURE = "FETCH_DATA_BYPARAM_FAILURE"
/**Fetch Data List For DropDown */
export const FETCH_DATA_LIST_REQUEST = "FETCH_DATA_LIST_REQUEST"
export const FETCH_DATA_LIST_SUCCESS = "FETCH_DATA_LIST_SUCCESS"
export const FETCH_DATA_LIST_FAILURE = "FETCH_DATA_LIST_FAILURE"
/**File upload */
export const FILE_UPLOAD_REQUEST = "FILE_UPLOAD_REQUEST"
export const FILE_UPLOAD_SUCCESS = "FILE_UPLOAD_SUCCESS"
export const FILE_UPLOAD_FAILURE = "FILE_UPLOAD_FAILURE"
/**File dowload */
export const FILE_DOWNLOAD_REQUEST = "FILE_DOWNLOAD_REQUEST"
export const FILE_DOWNLOAD_SUCCESS = "FILE_DOWNLOAD_SUCCESS"
export const FILE_DOWNLOAD_FAILURE = "FILE_DOWNLOAD_FAILURE"
