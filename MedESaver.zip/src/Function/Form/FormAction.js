import { saveData, updateData, fetchDataList, fetchDataByParams, uploadFile, downloadFile } from '../../redux/action/BasicFormAction';

/**
 * saveAction
 * @param {*} id 
 * @param {*} formData 
 * @param {*} dispatch 
 * @param {*} store 
 * @param {*} SAVE_UPDATE_API  
 * @returns 
 */
export const saveAction = async (formData, dispatch, store, SAVE_UPDATE_API) => {
  let response = {};  
  await dispatch(saveData(formData, SAVE_UPDATE_API), [dispatch]); 
  //get state value for get API response
  const actionState = store.getState();
  const saveUpdateResponse = actionState.basicFormReducer;
  if (saveUpdateResponse.saveResponse.id !== undefined) {
    response.error = false;
      if (Object.keys(saveUpdateResponse.saveResponse).length > 0) {
        response.message = {
          'message':saveUpdateResponse.saveResponse.message, 'className': 'success'
        };
        response.saveUpdateResponse = saveUpdateResponse.saveResponse;
      }   
  } else {
    response.error = true;       
    const responseError = saveUpdateResponse.error.response.data.message;
    response.setNotificationMessage = { 'message': responseError, 'className': 'danger' };
    response.setNotificationShow = true;
  }
  return response;
}

/**
 * updateAction
 * @param {*} data 
 * @param {*} dispatch 
 * @param {*} store 
 * @param {*} UPDATE_API 
 * @returns 
 */
export const updateAction = async (data, dispatch, store, UPDATE_API) => {
  let response = {};  
  await dispatch(updateData(data, UPDATE_API), [dispatch]); 
  //get state value for get API response
  const actionState = store.getState();
  const updateResponse = actionState.basicFormReducer;  
  if (updateResponse.error == null) {
    response.error = false;
      if (Object.keys(updateResponse.updateResponse).length > 0) {
        response.message = {
          'message':updateResponse.updateResponse.message, 'className': 'success'
        };
        response.saveUpdateResponse = updateResponse.updateResponse;
      }   
  } else {
    response.error = true;
    const responseError = updateResponse.error.response.data.message;
    response.setNotificationMessage = { 'message': responseError, 'className': 'danger' };
    response.setNotificationShow = true;
  }
  return response;
}

/**
 * fetchDataListAction
 * @param {*} dispatch 
 * @param {*} store 
 * @param {*} GET_API 
 * @param {*} param 
 * @returns 
 */
export const fetchDataListAction = async (dispatch, store, GET_API, param) => {
  let response = {};
  await dispatch(fetchDataList(GET_API, param), [dispatch]);
  const actionState = store.getState();
  const fetchResponse = actionState.basicFormReducer;
  if (fetchResponse.error == null) {
    response.error = false;
    if (Object.keys(fetchResponse.itemsList).length > 0) {
      response.itemsList = fetchResponse.itemsList;       
    } else {
      response.itemsList = [];
    }
  } else {
    response.error = true;
    const responseError = fetchResponse.itemsList.message;
    response.setNotificationMessage = { 'message': responseError, 'className': 'danger' };
    response.setNotificationShow = true
  }
  return response;
}

/**
 * fetchDataByParamAction
 * @param {*} dispatch 
 * @param {*} store 
 * @param {*} GET_API 
 * @param {*} param 
 * @returns 
 */
export const fetchDataByParamAction = async (dispatch, store, GET_API, param) => {
  let response = {};
  await dispatch(fetchDataByParams(GET_API, param), [dispatch]);
  const actionState = store.getState();
  const fetchResponse = actionState.basicFormReducer;
  if (fetchResponse.error == null) {
    response.error = false;
    if (Object.keys(fetchResponse.itemsWithParam).length > 0) {
      response.itemsList = fetchResponse.itemsWithParam;      
    } else {
      response.itemsList = [];
    }
  } else {
    response.error = true;
    const responseError = fetchResponse.itemsWithParam.message;
    response.setNotificationMessage = { 'message': responseError, 'className': 'danger' };
    response.setNotificationShow = true;
  }
  return response;
}


/**
 * funFileUpload
 * @param {*} dispatch 
 * @param {*} store 
 * @param {*} GET_API 
 * @param {*} param 
 * @returns 
 */
 export const funFileUpload = async (dispatch, store, GET_API, param) => {
  let response = {};
  await dispatch(uploadFile(GET_API, param), [dispatch]);
  const actionState = store.getState();
  const fetchResponse = actionState.basicFormReducer;
  if (fetchResponse.error == null) {
    response.error = false;
    if (Object.keys(fetchResponse.fileUploadResponse).length > 0) {
      response.itemsList = fetchResponse.fileUploadResponse;     
    } else {
      response.itemsList = [];
    }
  } else {
    response.error = true;
    const responseError = fetchResponse.fileUploadResponse.message;
    response.setNotificationMessage = { 'message': responseError, 'className': 'danger' };
    response.setNotificationShow = true;
  }
  return response;
}

/**
 * funFileDownload
 * @param {*} dispatch 
 * @param {*} store 
 * @param {*} GET_API 
 * @param {*} param 
 * @returns 
 */
 export const funFileDownload = async (dispatch, store, GET_API, param) => {
  let response = {};
  await dispatch(downloadFile(GET_API, param), [dispatch]);
  const actionState = store.getState();
  const fetchResponse = actionState.basicFormReducer;
  console.log(fetchResponse);
  if (fetchResponse.error == null) {
    response.error = false;
    if (fetchResponse.fileDlownloadResponse) {
      response.itemsList = fetchResponse.fileDlownloadResponse;     
    } else {
      response.itemsList = [];
    }
  } else {
    response.error = true;
    const responseError = fetchResponse.fileDlownloadResponse.message;
    response.setNotificationMessage = { 'message': responseError, 'className': 'danger' };
    response.setNotificationShow = true;
  }
  return response;
}