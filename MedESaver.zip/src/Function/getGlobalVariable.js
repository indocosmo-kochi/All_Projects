/**Get Token */
export const getToken = () => {
    return window.sessionStorage.getItem('jwt');
}

/**Get User Id */
export const getPharmacyId = () => {
    return window.sessionStorage.getItem('pharamcyId');    
}