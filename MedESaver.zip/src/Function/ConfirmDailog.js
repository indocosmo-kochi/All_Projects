import React from "react";
import {
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Button,
    Typography,
    makeStyles,
    Slide
} from "@material-ui/core";
import clsx from "clsx";
import red from "@material-ui/core/colors/red";
import { blue, blueGrey } from "@material-ui/core/colors";

const useStyles = makeStyles(() => ({
    dialog: {
        borderRadius: 12
    },
    button: {
        borderRadius: 20,
        textTransform: "none",
        padding: 5
    },
    yes: {
        color: "#fff",
        backgroundColor: blue[500],
        "&:hover": {
            backgroundColor: blue[700]
        }
    },
    no: {
        color: "#fff",
        backgroundColor: blueGrey[500],
        "&:hover": {
            backgroundColor: blueGrey[700]
        }
    },
    content: {
        color: red[700]
    }
}));

const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />;
});

const ConfirmDailog = ({ open, text, content, heading, onYes, onNo, isConfirm }) => {
    const classes = useStyles();

    return (
        <Dialog
            open={open}
            classes={{ paper: classes.dialog }}
            TransitionComponent={Transition}
        >
            {heading ? <DialogTitle>
                {heading}
            </DialogTitle> : null}           
            <DialogContent>
              <Typography variant="body2">
                    {text}
                </Typography>             
                <Typography variant="body2">
                    <span className={classes.content}>{content}</span>
                </Typography>
            </DialogContent>
            <DialogActions>
            {isConfirm ?                
                <Button
                    onClick={onYes}
                    variant="contained"
                    className={clsx(classes.yes, classes.button)}
                >
                    YES
                </Button>
                : ''}
                <Button
                    onClick={onNo}
                    color="primary"
                    variant="contained"                    
                    className={clsx(classes.no, classes.button)}
                > {isConfirm ?  'NO' : 'OK'}                   
                </Button>
                
            </DialogActions>
        </Dialog>
    );
}


export default ConfirmDailog;