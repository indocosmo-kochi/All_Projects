import { fetchData, deleteData} from '../../redux/action/BasicTableAction';

/**
 * getTableData
 * @param {*} pageIndex 
 * @param {*} pageSize 
 * @param {*} sort 
 * @param {*} filterData 
 * @param {*} dispatch 
 * @param {*} store 
 * @param {*} GET_API 
 * @param {*} param 
 * @returns 
 */
export var getTableData = async (pageIndex, pageSize, sort, filterData, dispatch, store, GET_API, param) => {
  //call action for fetch data   
  delete sessionStorage.row_id;
  let tableData = {};  
  await dispatch(fetchData(pageIndex , pageSize, sort, filterData, GET_API, param), [dispatch]);
  const actionState = store.getState();
  const fetchResponse = actionState.basicTableReducer;  
  if (fetchResponse.error === null) {
    if (Object.keys(fetchResponse.items).length > 0) {
      tableData.error = false;
      tableData.setPageCount = Math.ceil(fetchResponse.totalDataCount / pageSize)
      tableData.setData = fetchResponse.items;
    } else {
      tableData.error = false;
      tableData.setPageCount = 1
      tableData.setData = []
    }
  } else {    
    const responseError = fetchResponse.error.message;
    tableData.error = true;
    tableData.setNotificationMessage = { 'message': responseError, 'className': 'danger' }
    tableData.setNotificationShow = true
  }
  return tableData;
};

/**
 * deleteTableRows
 * @param {*} current 
 * @param {*} dispatch 
 * @param {*} store 
 * @param {*} paginationRef 
 * @param {*} GET_API 
 * @param {*} DELETE_API 
 * @param {*} param 
 * @returns 
 */
export const deleteTableRows = async (current, dispatch, store, paginationRef, GET_API, DELETE_API, param) => {
  let tableData = {};
  const deleteDataIds = getSelectedRows(current);
  if (deleteDataIds.length !== 0) {
    let selectedRowDatas = { "ids": [] }
    selectedRowDatas["ids"] = deleteDataIds;
    await dispatch(deleteData(selectedRowDatas, DELETE_API), [dispatch]);
    const actionState = store.getState();
    const deleteResponse = actionState.basicTableReducer;
    if (deleteResponse.error === null) {      
      if (Object.keys(deleteResponse.deleteResponse).length > 0) {
        tableData = await getTableData(paginationRef.current.pageIndex, paginationRef.current.pageSize, paginationRef.current.sort, paginationRef.current.filters, dispatch, store, GET_API, param);
        tableData.setNotificationMessage = {
          'message': "Data Deleted Successfully", 'className': 'success'
        }
        tableData.setNotificationShow = true
        tableData.error = false;
      }
    } else {      
      const responseError = deleteResponse.error.response.data.errorMessageCode;
      tableData.setNotificationMessage = { 'message': responseError, 'className': 'danger' };
      tableData.setNotificationShow = true
      tableData.error = true;
    }
  }
  return tableData;
};

/**
 * getSelectedRows
 * @param {*} rowsData 
 * @returns 
 */
export const getSelectedRows = (rowsData) => {
  let buffer = []
  if (rowsData !== undefined) {
    rowsData.map((x) =>
      buffer.push(x.original._id)
    )
  }
  return buffer
}