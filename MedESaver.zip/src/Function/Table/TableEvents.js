/**
 * rowOnclick
 * @param {*} rowData 
 * @param {*} url 
 * @param {*} history 
 */
export const rowOnclick = (rowData , url, history) => {    
    sessionStorage.setItem("row_id",rowData.id );
    history.push({ pathname: url, state: rowData.id });
};
/**
 * selectRow
 * @param {*} valueRef 
 * @param {*} dataRow 
 */
export const selectRow = ( valueRef ,dataRow ) => {
    valueRef.current = dataRow;
}

