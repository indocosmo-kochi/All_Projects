import { saveImgData, updateImgData } from '../../redux/action/BasicImageAction';

/**
 * saveImgAction
 * @param {*} id 
 * @param {*} formData 
 * @param {*} dispatch 
 * @param {*} store 
 * @param {*} SAVE_UPDATE_API 
 * @returns 
 */
export const saveImgAction = async (id, formData, dispatch, store, SAVE_UPDATE_API) => {
  let response = {};
  if (id === '') {
    await dispatch(saveImgData(formData, SAVE_UPDATE_API), [dispatch]);
  } else {
    await dispatch(updateImgData(id, formData, SAVE_UPDATE_API), [dispatch]);
  }
  //get state value for get API response
  const actionState = store.getState();
  const saveUpdateResponse = actionState.basicFormReducer;
  if (saveUpdateResponse.error == null) {
    response.error = false;
    if (id === '') {//add
      if (Object.keys(saveUpdateResponse.saveResponse).length > 0) {
        response.message = {
          'message': "Added Successfully", 'className': 'success'
        };
        response.saveUpdateResponse = saveUpdateResponse.saveResponse;
      }
    }
    else {//update
      if (Object.keys(saveUpdateResponse.updateResponse).length > 0) {
        response.message = {
          'message': "Updated Successfully", 'className': 'success'
        };
        response.saveUpdateResponse = saveUpdateResponse.updateResponse;
      }
    }
  } else {
    response.error = true;
    const responseError = saveUpdateResponse.error.response.data.errorMessageCode;
    response.setNotificationMessage = { 'message': responseError, 'className': 'danger' };
    response.setNotificationShow = true;

  }
  return response;
}