import React, { Fragment } from 'react';
import '../../assets/components/Pages/Footer.scss'
class AppFooter extends React.Component {
    render() {
        return (
            <Fragment>
                <div className="app-footer">
                    <div className="app-footer__inner">
                        <div className="app-footer footer-copyright-center">
                            <ul className="nav">
                                <li className="nav-item" >
                                    <div className=" nav footer-fontsize-copyright"  >
                                        Copyright &copy; 2025
                                        <a target="_parent" href="https://www.indocosmo.com/jp/" className="link-unadorned"> MedESaver
                                        </a> ,
                                        <a target="_parent" href="https://www.indocosmo.com/jp/" className="link-unadorned"> Indocosmo Systems Pvt Ltd
                                        </a> Inc. All rights reserved.
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </Fragment>
        )
    }
}

export default AppFooter;