import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import cx from 'classnames';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import PerfectScrollbar from 'react-perfect-scrollbar';
import HeaderLogo from '../AppLogo';
/** Font Icon */
import '../../assets/components/icons/fontawesome/css/fontawesome.css';
import '../../assets/components/icons/fontawesome/css/regular.css';
import '../../assets/components/icons/fontawesome/css/brands.css';
import '../../assets/components/icons/fontawesome/css/solid.css';

import MetisMenu from 'react-metismenu';


import {
    setEnableMobileMenu
} from '../../reducers/ThemeOptions';

/**
 * AppSidebar
 */
class AppSidebar extends Component {

    state = {};

    toggleMobileSidebar = () => {
        let { enableMobileMenu, setEnableMobileMenu } = this.props;
        setEnableMobileMenu(!enableMobileMenu);
    }

    render() {
        let {
            backgroundColor,
            backgroundImage,
            enableBackgroundImage,
            enableSidebarShadow,
            backgroundImageOpacity
        } = this.props;

        const waitForLocalStorage = (key, cb, timer) => {
            if (!sessionStorage.getItem(key)) {
                return (timer = setTimeout(waitForLocalStorage.bind(null, key, cb), 100))
            }
            clearTimeout(timer)
            if (typeof cb !== 'function') {
                return sessionStorage.getItem(key)
            }
            return cb(sessionStorage.getItem(key))
        }
        let sidebar_bg_color = backgroundColor;
        let sidebar_bg_img = backgroundImage;   

        return (
            <Fragment>
                <div className="sidebar-mobile-overlay" onClick={this.toggleMobileSidebar} />
                <ReactCSSTransitionGroup
                    component="div"
                    className={cx("app-sidebar", sidebar_bg_color, { 'sidebar-shadow': enableSidebarShadow })}
                    transitionName="SidebarAnimation"
                    transitionAppear={true}
                    transitionAppearTimeout={1500}
                    transitionEnter={false}
                    transitionLeave={false}>
                    {<HeaderLogo />}
                    <PerfectScrollbar>
                        <div className="app-sidebar__inner">                           
                            <MetisMenu content={[{
                                icon: 'fa-solid fa-book',
                                label: 'Inventory', 
                                to: '#/Pharmacy/Inventory/table'
                            },{
                                icon: 'fa fa-briefcase-medical',
                                label: 'Order Requests', 
                                to: '#/Pharmacy/Order/table'
                            },{
                                icon: 'fa-regular fa-calendar-check',
                                label: 'Reports', 
                                to: '#/Pharmacy/Reports'
                            }]} 
                            classNameLinkActive='active-sidebar-link'  classNameLinkHasActiveChild='active-sidebar-link' activeLinkFromLocation className="vertical-nav-menu" iconNamePrefix="" />
                        </div>
                    </PerfectScrollbar>
                    <div
                                    className={cx("app-sidebar-bg", backgroundImageOpacity)}
                                    style={{
                                        backgroundImage: enableBackgroundImage ? 'url(' + sidebar_bg_img + ')' : null
                                    }}>
                                </div>
                </ReactCSSTransitionGroup>
            </Fragment>
        )
    }
}

const mapStateToProps = state => ({
    enableBackgroundImage: state.ThemeOptions.enableBackgroundImage,
    enableSidebarShadow: state.ThemeOptions.enableSidebarShadow,
    enableMobileMenu: state.ThemeOptions.enableMobileMenu,
    backgroundColor: state.ThemeOptions.backgroundColor,
    custombackgroundColor: state.ThemeOptions.custombackgroundColor,
    backgroundImage: state.ThemeOptions.backgroundImage,
    custombackgroundImage: state.ThemeOptions.custombackgroundImage,
    backgroundImageOpacity: state.ThemeOptions.backgroundImageOpacity,
});

const mapDispatchToProps = dispatch => ({

    setEnableMobileMenu: enable => dispatch(setEnableMobileMenu(enable)),

});

export default connect(mapStateToProps, mapDispatchToProps)(AppSidebar);