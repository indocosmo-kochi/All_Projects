import React from 'react';

function Footer(){
    return (            <div className="col-md-12 login-product-section ">
    <div className="bg-section customers-email">
      <div className="info-section customers-email">
        <img src={"../images/logo_main.png"}  alt="edESaver" className="customer-email-icon" />
        <h2>
        MedESaver
        </h2>
      </div>
      <hr className='login-page-hr'></hr>
      <div className="product-section customers-email">
        <div className="text-block"><h2 className="product-name text-center">

        </h2><p className="text-center">
        Lorem Ipsum is simply dummy text of the printing and typesetting industry.
          </p></div>
      </div>
    </div>
  </div>);
}
export default Footer;