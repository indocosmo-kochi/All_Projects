import { Route, Switch, Redirect } from 'react-router-dom';
import React, { Suspense, lazy, Fragment } from 'react';
import { Spinner } from 'reactstrap';
import {
    ToastContainer,
} from 'react-toastify';
import '../../assets/components/Pages/Login.scss'
import ErrorPage from '../../Pages/ErrorPages/erro404'
const Pharmacy = lazy(() => import('../../Pages/Pharmacy'));

/**
 * AppMain
 * @returns 
 */
const AppMain = () => {

    return (
        <Fragment>
            <Suspense fallback={
                <div className="loader-container">
                    <div className="loader-container-inner">
                        <div className="suspense-spinner"> <Spinner style={{ width: '3rem', height: '3rem', color: '#0066ff' }} /> </div>
                    </div>
                </div>
            }>
                <Switch>
                    <Route path="/Pharmacy" component={Pharmacy} />
                    <Route exact path="/" render={() => (
                        <Switch>
                            <Redirect to={`/Pharmacy/Login`} />
                        </Switch>
                    )} />
                    <Route component={ErrorPage} />
                </Switch>
            </Suspense>

            <ToastContainer />
        </Fragment>
    )
};
export default AppMain;