import React, {Component} from 'react';
import {connect} from 'react-redux';
//import cx from 'classnames';
import '../../assets/components/Pages/Main.scss'

//import TitleComponent2 from './PageTitleExamples/Variation2'

class PageTitle extends Component {

    render() {
        let {
            //enablePageTitleIcon,
            //enablePageTitleSubheading,

            heading,
            //icon,
            //subheading
        } = this.props;

        return (

            <div className="app-page-title app-page-title-mt-pd">
                <div className="page-title-wrapper">
                    <div className="page-title-heading">                       
                        <div>
                            {heading}  
                        </div>
                    </div>                 
                </div>
            </div>
        );
    }
}

const mapStateToProps = state => ({
    enablePageTitleIcon: state.ThemeOptions.enablePageTitleIcon,
    enablePageTitleSubheading: state.ThemeOptions.enablePageTitleSubheading,
});

const mapDispatchToProps = dispatch => ({});

export default connect(mapStateToProps, mapDispatchToProps)(PageTitle);