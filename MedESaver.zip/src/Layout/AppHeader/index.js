import React, { Fragment } from 'react';
import cx from 'classnames';
import { connect } from 'react-redux';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import HeaderLogo from '../AppLogo';
import {
    DropdownToggle,
    DropdownMenu,
    UncontrolledButtonDropdown,
    DropdownItem
} from "reactstrap";
import { faAngleDown } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

class Header extends React.Component {

    logout = () => {
        delete sessionStorage.pharamcyId;
        window.location.href = "#/Pharmacy/Login";
    };

    render() {
        let {
            headerBackgroundColor,
            enableHeaderShadow
        } = this.props;
        return (
            <Fragment>
                <ReactCSSTransitionGroup
                    component="div"
                    className={cx("app-header", headerBackgroundColor, { 'header-shadow': enableHeaderShadow })}
                    transitionName="HeaderAnimation"
                    transitionAppear={true}
                    transitionAppearTimeout={1500}
                    transitionEnter={false}
                    transitionLeave={false}>
                    <HeaderLogo />
                    {
                        <div className={cx(
                            "app-header__content",
                            { 'header-mobile-open': true },
                        )}>
                            <div className="app-header-left">
                            </div>
                            <div className="app-header-right">
                                <Fragment>
                                    <div className="header-btn-lg pr-0">
                                        <div className="widget-content p-0">
                                            <div className="widget-content-wrapper">
                                                <div className="widget-content-left">
                                                    {window.sessionStorage.getItem('pharamcyName')}
                                                    <UncontrolledButtonDropdown>
                                                        <DropdownToggle color="link" className="p-0">
                                                            <img
                                                                width={42}
                                                                className="rounded-circle"
                                                                src={"/images/avatars/001.png"}
                                                                alt=""
                                                            />
                                                            <FontAwesomeIcon style={{ color: 'black' }}
                                                                className="ml-2 opacity-8"
                                                                icon={faAngleDown}
                                                            />
                                                        </DropdownToggle>
                                                        <DropdownMenu className="rm-pointers dropdown-menu-lg" right>
                                                            <DropdownItem onClick={this.logout}>
                                                                <span aria-label="us"  ></span> Logout
                                                            </DropdownItem>
                                                        </DropdownMenu>
                                                    </UncontrolledButtonDropdown>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </Fragment>
                            </div>
                        </div>
                    }
                </ReactCSSTransitionGroup>
            </Fragment>
        );
    }
}

const mapStateToProps = state => ({
    enableHeaderShadow: state.ThemeOptions.enableHeaderShadow,
    closedSmallerSidebar: state.ThemeOptions.closedSmallerSidebar,
    headerBackgroundColor: state.ThemeOptions.headerBackgroundColor,
    enableMobileMenuSmall: state.ThemeOptions.enableMobileMenuSmall,
});

const mapDispatchToProps = dispatch => ({});
export default connect(mapStateToProps, mapDispatchToProps)(Header);