﻿using System;
using System.Collections.Generic;
using System.IO;

using Teigha.Geometry;
using Teigha.DatabaseServices;

namespace CWorksCXF.Util
{
    public class CustomHatchUtil
    {
        public List<string> CreatePatFilesForCustomHatch(Database db, string drawingFileName)
        {
            List<string> patfiles = new List<string>();

            try
            {
                db.ReadDwgFile(drawingFileName, FileShare.Read, false, "");
            }
            catch (Exception ex)
            {
                string msg = "Unable to read drawing file." + ex.Message;
                patfiles.Add(msg);
                return patfiles;
            }

            Transaction tr = db.TransactionManager.StartTransaction();
            using (tr)
            {
                BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                BlockTableRecord btr = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForRead);

                List<string> processedHatchPatterns = new List<string>();

                foreach (ObjectId objId in btr)
                {
                    Entity ent = (Entity)tr.GetObject(objId, OpenMode.ForRead);

                    if (ent != null)
                    {
                        Hatch hatch = ent as Hatch;

                        if(hatch != null)
                        {
                            HatchPatternType patternType = hatch.PatternType;

                            if (patternType != HatchPatternType.CustomDefined)
                            {
                                continue;
                            }

                            if (!processedHatchPatterns.Contains(hatch.PatternName))
                            {
                                string path = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
                                patfiles.Add(CreatePatternFile(hatch, path));
                                processedHatchPatterns.Add(hatch.PatternName);                                    
                            } 
                        }
                    }
                }
            }

            return patfiles; 
        }
        public static string CreatePatternFile(Hatch hatch, string patternFilePath)
        { 
            HatchPatternInfo hatchPatInfo = new HatchPatternInfo(hatch.PatternName);

            int numberOfPatternDefinitions = hatch.NumberOfPatternDefinitions;

            for (int i = 0; i < numberOfPatternDefinitions; i++)
            {
                PatternDefinationLine pattDefLine = new PatternDefinationLine();

                PatternDefinition patternDef = hatch.GetPatternDefinitionAt(i);

                double angleInRadian = patternDef.Angle;
                pattDefLine.angleInDegree = (180.0 / Math.PI) * angleInRadian;

                pattDefLine.baseX = patternDef.BaseX;
                pattDefLine.baseY = patternDef.BaseY;

                Line line = new Line();
                line.StartPoint = new Point3d(0, 0, 0);
                line.EndPoint = new Point3d(patternDef.OffsetX, patternDef.OffsetY, 0);

                line.TransformBy(Matrix3d.Rotation(-1 * angleInRadian,
                                                   Vector3d.ZAxis,
                                                    new Point3d(0, 0, 0)));

                pattDefLine.offsetX = line.EndPoint.X;
                pattDefLine.offsetY = line.EndPoint.Y;

                DoubleCollection dashes = patternDef.GetDashes();

                int dashCount = dashes.Count;

                for (int j = 0; j < dashCount; j++)
                {
                    pattDefLine.dashes.Add(dashes[j]);
                }

                hatchPatInfo.patternDefinations.Add(pattDefLine);
            }

            string status = hatchPatInfo.patternName;
            string message = "";
            if (true == hatchPatInfo.Create(ref patternFilePath, ref message))
            {
                status += "||1||";
                status += patternFilePath;
            }
            else
            {
                status += "||0||";
                status += message;
            }

            return status;
        }
    }
}
