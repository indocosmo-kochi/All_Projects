﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CWorksCXF.Util
{
    public class HatchPatternInfo
    {
        public string patternName;
        private string description = "Receated custom hatch pattern file";

        public List<PatternDefinationLine> patternDefinations = new List<PatternDefinationLine>();

        public HatchPatternInfo(string patternName)
        {
            this.patternName = patternName;
        }

        public bool Create(ref string filePath, ref string message)
        {
            try
            {
                string patfileloLocation = filePath + Path.DirectorySeparatorChar + "PAT";
                if (!Directory.Exists(patfileloLocation)) Directory.CreateDirectory(patfileloLocation);
                filePath = patfileloLocation + Path.DirectorySeparatorChar + patternName + ".PAT";

                if(File.Exists(filePath))
                {
                    message = "Pattern file " + filePath + " alraedy exist";
                    return true; // Not an error condiction
                }

                FileStream f = new FileStream(filePath, FileMode.Create);
                StreamWriter s = new StreamWriter(f);

                string firstLine = "*" + patternName + ", " + description;
                s.WriteLine(firstLine);

                foreach (PatternDefinationLine pattDefLine in patternDefinations)
                {
                    StringBuilder sb = new StringBuilder();

                    sb.Append(pattDefLine.angleInDegree.ToString());

                    sb.Append(", ");
                    sb.Append(pattDefLine.baseX.ToString());

                    sb.Append(", ");
                    sb.Append(pattDefLine.baseY.ToString());

                    sb.Append(", ");
                    sb.Append(pattDefLine.offsetX.ToString());
                    sb.Append(", ");
                    sb.Append(pattDefLine.offsetY.ToString());

                    foreach (double dash in pattDefLine.dashes)
                    {
                        sb.Append(", ");
                        sb.Append(dash.ToString());
                    }

                    s.WriteLine(sb.ToString());

                    sb.Clear();
                }

                string blankLine = ""; //very very important
                s.WriteLine(blankLine);

                s.Close();
                f.Close();

                return true;
            }
            catch (System.Exception ex)
            {
                message = "Could not generate pat file - " + ex.Message;
                return false;
            }
        }
    }
}
