﻿using System;
using System.Collections.Generic;

namespace CWorksCXF.Util
{
    public class PatternDefinationLine
    {
        public double angleInDegree;
        public double baseX;
        public double baseY;
        public double offsetX;
        public double offsetY;

        public List<Double> dashes = new List<double>();
    }
}
