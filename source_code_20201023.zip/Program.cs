﻿using CWorksCXF.Common;
using System;


namespace CWorksCXF
{
    static class Program
    {

        static void Main(string[] args)
        {
            Logger.LogType = Logger.LogTypes.File;

            if ( (args == null) || (args.Length < 2) )
            {
                Logger.RecordMessage("ERROR: Parameters missing.", Logs.Log.MessageType.Error);
                Console.WriteLine("ERROR: Parameters missing.");
                string appName = System.Diagnostics.Process.GetCurrentProcess().ProcessName;
                Console.WriteLine("USAGE : " + appName + " {input_file} {output_file} [PAPERSIZE {:paper_size}] [ROTATE {:angle}] [FONT {:font_name}]] [VERSION {:version_no}] [<PARAM_1> {:value_1}] [<PARAM_2> {:value_2}] [<PARAM_3> {:value_3}]");
                Console.WriteLine("version_no: vEX2,vGX3,vR11,vR12,vGX5,vR13,vR14,v2000,v2000i,v2002,v2004,v2005,v2006,v2007,v2008,v2009,v2010,v2011,v2012,v2013,v2014,v2015,v2016,v2017,v2018,v2019,v2020,v2021");
                Console.WriteLine("Default version no: v2012");
            }
            else
            {
                ProcessParam processParams = new ProcessParam();
                processParams.InputFileName = args[0];
                processParams.OutputFileName = args[1];
                processParams.AutoCADVersionName = Common.CONST.DEFAULT_VERSION;
                for (int i = 2; i < args.Length; i+=2)
                {
                    processParams.PaperSize = (args[i].ToUpper() == "PAPERSIZE") ? args[i + 1].ToUpper().Substring(1) : processParams.PaperSize;
                    processParams.RotateAngle = (args[i].ToUpper() == "ROTATE") ? args[i + 1].ToUpper().Substring(1) : processParams.RotateAngle;
                    processParams.FontName = (args[i].ToUpper() == "FONT") ? args[i + 1].ToUpper().Substring(1) : processParams.FontName;
                    processParams.AutoCADVersionName =(args[i].ToUpper() == "VERSION") ? args[i + 1].ToUpper() : Common.CONST.DEFAULT_VERSION;
                }

                if ( processParams.AutoCADVersionName.StartsWith("***INVALID_VERSION") )
                {
                    Logger.RecordMessage("ERROR: INVALID_VERSION", Logs.Log.MessageType.Error);
                    Logger.RecordMessage(processParams.ToString(), Logs.Log.MessageType.Error);

                    Console.WriteLine("ERROR: INVALID_VERSION");
                    string appName = System.Diagnostics.Process.GetCurrentProcess().ProcessName;
                    Console.WriteLine("USAGE : " + appName + " {input_file} {output_file} [PAPERSIZE {:paper_size}] [ROTATE {:angle}] [FONT {:font_name}]] [VERSION {:version_no}] [<PARAM_1> {:value_1}] [<PARAM_2> {:value_2}] [<PARAM_3> {:value_3}]");
                    Console.WriteLine("<version_no>: vEX2,vGX3,vR11,vR12,vGX5,vR13,vR14,v2000,v2000i,v2002,v2004,v2005,v2006,v2007,v2008,v2009,v2010,v2011,v2012,v2013,v2014,v2015,v2016,v2017,v2018,v2019,v2020,v2021");
                    Console.WriteLine("Default version no: v2012");
                }
                else
                {

                    Logger.RecordMessage(processParams.ToString(), Logs.Log.MessageType.Informational);

                    MainController mainController = new MainController();
                    mainController.processFile(processParams);
                }

            }

        }
    }
}
