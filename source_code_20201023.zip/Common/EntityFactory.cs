﻿using CWorksCXF.CXF.Reader;
using CWorksCXF.CXF.Writer;
using CWorksCXF.DWG.Reader;
using CWorksCXF.DWG.Writer;

namespace CWorksCXF.Common
{
    abstract class EntityFactory
    {
        public abstract IDwgEntityReader getDwgEntityReader(string typeName);
        public abstract ICXFEntityWriter getCXFEntityWriter(string typeName);

        public abstract ICXFEntityReader getCXFEntityReader(string typeName);
        public abstract IDwgEntityWriter getDwgEntityWriter(string typeName);
    }

    class EntityConcreteFactory : EntityFactory
    {
        public override IDwgEntityReader getDwgEntityReader(string typeName)
        {
            switch (typeName)
            {
                case "AlignedDimension": return new DwgAlignedDimensionReader();
                case "Arc": return new DwgArcReader();
                case "AttributeDefinition": return new DwgAttributeDefinitionReader();
                case "BlockTableRecord": return new DwgBlockReader();
                case "LayoutBlockTableRecord": return new DwgLayoutBlockReader();
                case "BlockReference": return new DwgBlockReferenceReader();
                case "Circle": return new DwgCircleReader();
                case "DBPoint": return new DwgDBPointReader();
                case "DBText": return new DwgDBTextReader();
                case "DimStyleTableRecord": return new DwgDimStyleReader();
                case "Ellipse": return new DwgEllipseReader();
                case "Face": return new DwgFaceReader();
                case "Hatch": return new DwgHatchReader();
                case "LayerTableRecord": return new DwgLayerReader();
                case "Leader": return new DwgLeaderReader();
                case "Line": return new DwgLineReader();
                case "Layout": return new DwgLayoutReader();
                case "MText": return new DwgMTextReader();
                case "OrdinateDimension": return new DwgOrdinateDimensionReader();
                case "Polyline": return new DwgPolylineReader();
                case "PlotSettings": return new DwgPlotSettingsReader();
                case "RotatedDimension": return new DwgRotatedDimensionReader();
                case "Spline": return new DwgSplineReader();
                case "TextStyleTableRecord": return new DwgTextStyleReader();
                case "ViewportTableRecord": return new DwgModelViewportReader();
                case "Viewport": return new DwgViewportReader();
                case "LinetypeTableRecord": return new DwgLineTypeReader();
                case "MLeaderStyle": return new DWGMLeaderStyleReader();
                case "MLeader": return new DwgMLeaderReader();

                default:
                    {
                        Logger.RecordMessage(string.Format("DwgEntityReader for Entity type {0} not created.", typeName), Logs.Log.MessageType.Informational);
                        return null;
                    }
            }

        }

        public override ICXFEntityWriter getCXFEntityWriter(string typeName)
        {
            switch (typeName)
            {
                case "AlignedDimension": return new CXFAlignedDimensionWriter();
                case "Arc": return new CXFArcWriter();
                case "AttributeDefinition": return new CXFAttributeDefinitionWriter();
                case "BlockTableRecord": return new CXFBlockWriter();
                case "LayoutBlockTableRecord": return new CXFLayoutBlockWriter();
                case "BlockReference": return new CXFBlockReferenceWriter();
                case "Circle": return new CXFCircleWriter();
                case "DBPoint": return new CXFDBPointWriter();
                case "DBText": return new CXFDBTextWriter();
                case "DimStyleTableRecord": return new CXFDimStyleWriter();
                case "Ellipse": return new CXFEllipseWriter();
                case "Face": return new CXFFaceWriter();
                case "Hatch": return new CXFHatchWriter();
                case "LayerTableRecord": return new CXFLayerWriter();
                case "Leader": return new CXFLeaderWriter();
                case "Line": return new CXFLineWriter();
                case "Layout": return new CXFLayoutWriter();
                case "MText": return new CXFMTextWriter();
                case "OrdinateDimension": return new CXFOrdinateDimensionWriter();
                case "Polyline": return new CXFPolylineWriter();
                case "PlotSettings": return new CXFPlotSettingsWriter();
                case "RotatedDimension": return new CXFRotatedDimensionWriter();
                case "Spline": return new CXFSplineWriter();
                case "TextStyleTableRecord": return new CXFTextStyleWriter();
                case "ViewportTableRecord": return new CXFModelViewportWriter();
                case "Viewport": return new CXFViewportWriter();
                case "LinetypeTableRecord": return new CXFLineTypeWriter();
                case "MLeaderStyle": return new CXFMLeaderStyleWriter();
                case "MLeader": return new CXFMLeaderWriter();

                default:
                    {
                        Logger.RecordMessage(string.Format("CXFEntityWriter for Entity type {0} not created.", typeName), Logs.Log.MessageType.Informational);
                        return null;
                    }
            }
        }

        public override ICXFEntityReader getCXFEntityReader(string typeName)
        {
            switch (typeName)
            {

                case "AlignedDimension": return new CXFAlignedDimensionReader();
                case "Arc": return new CXFArcReader();
                case "AttributeDefinition": return new CXFAttributeDefinitionReader();
                case "Block": return new CXFBlockReader();
                case "LayoutBlock": return new CXFLayoutBlockReader();
                case "BlockReference": return new CXFBlockReferenceReader();
                case "Circle": return new CXFCircleReader();
                case "DBPoint": return new CXFDBPointReader();
                case "DBText": return new CXFDBTextReader();
                case "DimStyle": return new CXFDimStyleReader();
                case "Ellipse": return new CXFEllipseReader();
                case "Hatch": return new CXFHatchReader();
                case "Layer": return new CXFLayerReader();
                case "Leader": return new CXFLeaderReader();
                case "Line": return new CXFLineReader();
                case "Layout": return new CXFLayoutReader();
                case "MText": return new CXFMTextReader();
                case "OrdinateDimension": return new CXFOrdinateDimensionReader();
                case "Polyline": return new CXFPolyLineReader();
                case "PlotSettings": return new CXFPlotSettingsReader();
                case "RotatedDimension": return new CXFRotatedDimensionReader();
                case "Spline": return new CXFSplineReader();
                case "TextStyle": return new CXFTextStyleReader();
                case "ModelViewport": return new CXFModelViewportReader();
                case "Viewport": return new CXFViewportReader();
                case "LineType": return new CXFLineTypeReader();
                case "MLeaderStyle": return new CXFMLeaderStyleReader();
                case "MLeader": return new CXFMLeaderReader();

                default:
                    {
                        Logger.RecordMessage(string.Format("CXFEntityReader for Entity type {0} not created.", typeName), Logs.Log.MessageType.Informational);
                        return null;
                    }
            }
        }

        public override IDwgEntityWriter getDwgEntityWriter(string typeName)
        {
            switch (typeName)
            {
                case "AlignedDimension": return new DwgAlignedDimensionWriter();
                case "Arc": return new DwgArcWriter();
                case "AttributeDefinition": return new DwgAttributeDefinitionWriter();
                case "Block": return new DwgBlockWriter();
                case "LayoutBlock": return new DwgLayoutBlockWriter();
                case "BlockReference": return new DwgBlockReferenceWriter();
                case "Circle": return new DwgCircleWriter();
                case "DBPoint": return new DwgDBPointWriter();
                case "DBText": return new DwgDBTextWriter();
                case "DimStyle": return new DwgDimStyleWriter(); 
                case "Ellipse": return new DwgEllipseWriter();
                case "Hatch": return new DwgHatchWriter();
                case "Layer": return new DwgLayerWriter();
                case "Leader": return new DwgLeaderWriter();
                case "Line": return new DwgLineWriter();
                case "Layout": return new DwgLayoutWriter();
                case "MText": return new DwgMTextWriter();
                case "OrdinateDimension": return new DwgOrdinateDimensionWriter();
                case "Polyline": return new DwgPolyLineWriter();
                case "PlotSettings": return new DwgPlotSettingsWriter();
                case "RotatedDimension": return new DwgRotatedDimensionWriter();
                case "Spline": return new DwgSplineWriter();
                case "TextStyle": return new DwgTextStyleWriter();
                case "ModelViewport": return new DwgModelViewportWriter();
                case "Viewport": return new DwgViewportWriter();
                case "LineType": return new DwgLineTypeWriter();
                case "MLeaderStyle": return new DwgMLeaderStyleWriter();
                case "MLeader": return new DwgMLeaderWriter();

                default:
                    {
                        Logger.RecordMessage(string.Format("DwgEntityWriter for Entity type {0} not created.", typeName), Logs.Log.MessageType.Informational);
                        return null;
                    }
            }


        }


    }
}
