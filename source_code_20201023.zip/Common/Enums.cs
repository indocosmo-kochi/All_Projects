﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CWorksCXF.Common
{
    public static class Enums
    {

        public enum VersionNo
        {
            VEX2 = 10,
            VGX3 = 13,
            VR11 = 16,
            VR12 = 16,
            VGX5 = 16,
            VR13 = 19,
            VR14 = 21,
            V2000 = 23,
            V2000I = 23,
            V2002 = 23,
            V2004 = 25,
            V2005 = 25,
            V2006 = 25,
            V2007 = 27,
            V2008 = 27,
            V2009 = 27,
            V2010 = 29,
            V2011 = 29,
            V2012 = 29,
            V2013 = 31,
            V2014 = 31,
            V2015 = 31,
            V2016 = 31,
            V2017 = 31,
            V2018 = 33,
            V2019 = 33,
            V2020 = 33,
            V2021 = 33
        }



        public enum MeasurementValue
        {
            English = 0,
            Metric = 1
        }


        public enum CurveType
        {
            EllipticalArc2d = 1,
            CircularArc2d = 2,
            LineSegment2d = 3,
            NurbCurve2d = 4
        }


        /// //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// Enum conversion sub routines
        /// //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// integer/enum String value to enum convertion 
        public static T ConvertStringToEnumValue<T>(string str) where T : struct, IConvertible
        {
            T val = ((T[])Enum.GetValues(typeof(T)))[0];

            if (!typeof(T).IsEnum)
            {
                Logger.RecordMessage(typeof(T).Name + " - is not an Enumeration type.", Logs.Log.MessageType.Exception);
            }
            try
            {
                val = (T)Enum.Parse(typeof(T), str);
            }
            catch (Exception)
            {
                Logger.RecordMessage(str + " - is not a valid value for the type : " + typeof(T).Name, Logs.Log.MessageType.Exception);
            }
            return val;
        }


        public static T ConvertEnumValueToString<T>(int intValue) where T : struct, IConvertible
        {
            if (!typeof(T).IsEnum)
            {
                throw new Exception("T must be an Enumeration type.");
            }
            T val = ((T[])Enum.GetValues(typeof(T)))[0];

            foreach (T enumValue in (T[])Enum.GetValues(typeof(T)))
            {
                if (Convert.ToInt32(enumValue).Equals(intValue))
                {
                    val = enumValue;
                    break;
                }
            }
            return val;
        }

    }
}
