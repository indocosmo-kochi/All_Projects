﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CWorksCXF.Common
{
    public class CXFException: Exception
    {
        public string Property { get; set; }
        public CXFException(string message):base(message)
        {
        }
      
        public CXFException(string source, Exception exception):base(exception.Message)
        {
            if (exception.Source.Contains("mscorlib"))
            {
                Source = source;
            }
            else
            {
                Source = exception.TargetSite.ReflectedType.Name;
                Property = exception.TargetSite.Name;
            }
        }
    }
}
