﻿using CWorksCXF.Common;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace CWorksCXF
{

    public enum CONVERSIONTYPE
    {
        DWG_to_CXF,
        DXF_to_CXF,
        CXF_to_DWG,
        CXF_to_DXF
    };

    public class MainController
    {
        CONVERSIONTYPE conversionType;

        public bool processFile(ProcessParam processParam)
        {
            bool result=false;
            if (isValidConvertionType(processParam))
            {
                Logger.RecordMessage(conversionType.ToString(), Logs.Log.MessageType.Informational);
                // Ensure the output folder exist
                if (IsOutputFolderExists(processParam.OutputFileName))
                {
                    switch (conversionType)
                    {
                        case CONVERSIONTYPE.DWG_to_CXF:
                        case CONVERSIONTYPE.DXF_to_CXF:
                            {
                                DwgToCXFController dwgToCXFController = new DwgToCXFController();
                                result = dwgToCXFController.convert_DWG_to_CXF(processParam);
                                if (result)
                                {
                                    Logger.RecordMessage("CXF file created succesfully.", Logs.Log.MessageType.Informational);
                                    Console.WriteLine("CXF file created succesfully.");
                                }
                                break;
                            }
                        case CONVERSIONTYPE.CXF_to_DWG:
                            {
                                CXFToDwgController CXFToDwgController = new CXFToDwgController();
                                result = CXFToDwgController.convert_CXF_to_DWG(processParam);
                                if (result)
                                {
                                    Logger.RecordMessage("DWG file created succesfully.", Logs.Log.MessageType.Informational);
                                    Console.WriteLine("DWG file created succesfully.");
                                }
                                break;
                            }

                        case CONVERSIONTYPE.CXF_to_DXF:
                            Console.WriteLine("Processing the Conversion from CXF to DXF...");
                            CXFToDwgController cxfToDxfController = new CXFToDwgController();
                            result = cxfToDxfController.convert_CXF_to_DWG(processParam);
                            if (result)
                            {
                                Logger.RecordMessage("DXF file created succesfully.", Logs.Log.MessageType.Informational);
                                Console.WriteLine("DXF file created succesfully.");
                            }
                            break;
                    }
                    result = true;
                }
            }

            return result;

        }       

        private bool IsOutputFolderExists(string outputFileName)
        {
            bool result = false;
            try
            {               
                string outputPath = Path.GetDirectoryName(outputFileName);
                if (outputPath.Length == 0)
                {
                    Logger.RecordMessage("Invalid Output file path", Logs.Log.MessageType.Error);
                    Console.WriteLine("Invalid Output file path");
                }
                else
                {
                    Directory.CreateDirectory(outputPath);
                    result = true;
                }
            }
            catch (System.Exception)
            {
                Logger.RecordMessage("Invalid Output file path", Logs.Log.MessageType.Error);
                Console.WriteLine("Invalid Output file path");
            }
            return result;
        }
       
        private bool isValidConvertionType(ProcessParam processParam)
        {
            bool isValid = false;
            if (!File.Exists(processParam.InputFileName))
            {
                Logger.RecordMessage("Input file not found", Logs.Log.MessageType.Error);
                Console.WriteLine("Input file not found");
            }
            else
            {

                List<string> fileExtension = new List<string> { ".DWG", ".DXF", ".CXF" };

                string inputFileType = Path.GetExtension(processParam.InputFileName).ToUpper();
                string outputFileType = Path.GetExtension(processParam.OutputFileName).ToUpper();

                if ((inputFileType.Length == 0) || (!fileExtension.Contains(inputFileType)))
                {
                    Logger.RecordMessage("Invalid Input filetype", Logs.Log.MessageType.Error);
                    Console.WriteLine("Invalid Input filetype");
                }
                else if ((outputFileType.Length == 0) || (!fileExtension.Contains(outputFileType)))
                {
                    Logger.RecordMessage("Invalid Output filetype", Logs.Log.MessageType.Error);
                    Console.WriteLine("Invalid Output filetype");
                }
                else if (inputFileType == outputFileType)
                {
                    Logger.RecordMessage("Input file type and output file types are same.", Logs.Log.MessageType.Error);
                    Console.WriteLine("Input file type and output file types are same.");
                }
                else
                {
                    conversionType = (inputFileType == ".DWG") ? CONVERSIONTYPE.DWG_to_CXF :
                                                (inputFileType == ".DXF") ? CONVERSIONTYPE.DXF_to_CXF :
                                                     (outputFileType == ".DWG") ? CONVERSIONTYPE.CXF_to_DWG : CONVERSIONTYPE.CXF_to_DXF;

                    if ((conversionType == CONVERSIONTYPE.DWG_to_CXF) || (conversionType == CONVERSIONTYPE.DXF_to_CXF))
                    {
                        if (outputFileType != ".CXF")
                        {
                            Logger.RecordMessage(inputFileType + " to " + outputFileType + " Conversion not supported", Logs.Log.MessageType.Error);
                            Console.WriteLine(inputFileType + " to " + outputFileType + " Conversion not supported");
                            Console.WriteLine("DWG => CXF  or DXF => CXF only supported. ");
                            return false;
                        }
                    }
                    else if ((conversionType == CONVERSIONTYPE.CXF_to_DWG) || (conversionType == CONVERSIONTYPE.CXF_to_DXF))
                    {
                        if (inputFileType != ".CXF")
                        {
                            Logger.RecordMessage(inputFileType + " to " + outputFileType + " Conversion not supported", Logs.Log.MessageType.Error);
                            Console.WriteLine(inputFileType + " to " + outputFileType + " Conversion not supported");
                            Console.WriteLine("CXF => DWG  or CXF => DXF only supported. ");
                            return false;
                        }
                    }

                    isValid = true;
                }
            }
            return isValid;
        }
    }
}
