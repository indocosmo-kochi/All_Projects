﻿using System.IO;
using Teigha.DatabaseServices;
using Teigha.Runtime;
using CWorksCXF.CXF.Writer;
using CWorksCXF.DWG.Reader;
using CWorksCXF.Common;
using CWorksCXF.Entities;
using CWorksCXF.Util;
using System.Collections.Generic;
using Teigha.DatabaseServices.Filters;

namespace CWorksCXF
{
    public class DwgToCXFController
    {

        readonly EntityConcreteFactory factory = new EntityConcreteFactory();
        readonly Dictionary<string, CwcLayer> layerList = new Dictionary<string, CwcLayer>();
        readonly Dictionary<string, string> blockList = new Dictionary<string, string>();
        CwcColor defaultObjectColor; 
        CwcBlockReference currentBlock;
        public bool convert_DWG_to_CXF(ProcessParam processParam)
        {
            bool result = false;

            Services.odActivate(ActivationData.userInfo, ActivationData.userSignature);
            using (Services svcs = new Services())
            {
                using (Database db = new Database(false, false))
                {
                    List<string> patfiles = CustomHatchPatCreation(db, processParam.InputFileName);

                }
                using (Database db = new Database(false, false))
                {
                    StreamWriter outfile = getCXFFileHandle(processParam);
                    try
                    {
                        db.ReadDwgFile(processParam.InputFileName, FileOpenMode.OpenForReadAndAllShare, false, null);

                        readDBSettings(db, outfile);
                        readModelViewportSettings(db, outfile);
                        //                        readDwgLayerProperties(db, outfile);
                        readDwgStyleProperties(db, outfile);
                        readDwgMleaderStyleProperties(db, outfile);
                        readDwgLayerProperties(db, outfile); //Moved down after Style by Suraj 27 aug 2020
                        readDwgBlockDefinition(db, outfile);
                        readBlockContent(db, outfile);
                        
                        readModelBlockRecords(db, outfile);
                        readLayoutSettings(db, outfile);
                        readPlotSettings(db, outfile);
                        outfile.Flush();
                        result = true;
                    }
                    catch (CXFException ex)
                    {
                        Logger.RecordMessage(ex, Logs.Log.MessageType.Error);
                    }
                    catch (System.Exception ex)
                    {
                        Logger.RecordMessage(ex , Logs.Log.MessageType.Error);
                    }
                    finally
                    {
                        if (outfile != null)
                            outfile.Close();
                    }


                }
            }
            return result;
        }

        private StreamWriter getCXFFileHandle(ProcessParam processParam)
        {
            FileStream fs = new FileStream(Path.ChangeExtension(processParam.OutputFileName, ".cxf"), FileMode.Create, FileAccess.Write);
            StreamWriter outfile = new StreamWriter(fs);
            return outfile;
        }

        private void readModelBlockRecords(Database database, StreamWriter outfile)
        {
            TransactionManager tm = database.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable bt = (BlockTable)tm.GetObject(database.BlockTableId, OpenMode.ForRead))
                {
                    using (BlockTableRecord btr = (BlockTableRecord)tm.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForRead))
                    {

                        BlockTableRecordEnumerator iterator = btr.GetEnumerator();

                        ObjectId dbObject_Id;
                        DBObject dbObject;
                        string typeName;
                        while (iterator.MoveNext())
                        {
                            dbObject_Id = iterator.Current;
                            //if(dbObject_Id.ToString() == "104037768")
                            //{
                            //    int i = 0;
                            //}
                            using (dbObject = tm.GetObject(dbObject_Id, OpenMode.ForRead))
                            {
                                typeName = dbObject.GetType().Name;

                                if (typeName.ToUpper() == "HATCH")
                                    continue;

                                if (typeName == "BlockReference")
                                {
                                    ReadNWriteBlockRef(tm, tr, dbObject as BlockReference, typeName, outfile);
                                }
                                else
                                {
                                    Logger.RecordMessage(string.Format("Processing Entity {0} (Id:{1})", typeName, dbObject_Id.ToString()), Logs.Log.MessageType.Informational);

                                    IDwgEntityReader dwgEntity = factory.getDwgEntityReader(typeName);

                                    ICXFEntityWriter CXFEntity = factory.getCXFEntityWriter(typeName);
                                    if (dwgEntity != null)
                                    {
                                        ((DwgEnityReader)dwgEntity).Layers = layerList;

                                        ((DwgEnityReader)dwgEntity).DefaultColor = defaultObjectColor;

                                        ((DwgEnityReader)dwgEntity).CurrentBlock = currentBlock;

                                        CXFEntity.WriteEnityDetails(dwgEntity.ReadEntityDetails(dbObject), outfile);
                                    }
                                    Logger.RecordMessage(string.Format("Processed Successfully {0} (Id:{1})", typeName, dbObject_Id.ToString()), Logs.Log.MessageType.Informational);
                                }
                            }
                        }
                        iterator.Reset();
                        while (iterator.MoveNext())
                        {
                            ObjectId id = iterator.Current;
                            using (dbObject = tm.GetObject(id, OpenMode.ForRead))
                            {
                                typeName = dbObject.GetType().Name;
                                if (typeName.ToUpper() == "HATCH")
                                    readAndWriteEntity(dbObject, typeName, "", outfile);
                            }
                        }
                    }
                }
                tr.Abort();
            }
        }

        private void ReadNWriteBlockRef(TransactionManager tm, Transaction tr, 
                                        BlockReference dbObject, string typeName, StreamWriter outfile)
        {

            IDwgEntityReader dwgEntity = factory.getDwgEntityReader(typeName);

            ICXFEntityWriter CXFEntity = factory.getCXFEntityWriter(typeName);
            if (dwgEntity != null)
            {
                ((DwgEnityReader)dwgEntity).Layers = layerList;

                ((DwgEnityReader)dwgEntity).DefaultColor = defaultObjectColor;

                ((DwgEnityReader)dwgEntity).CurrentBlock = currentBlock;

                #region ReadBlockRef
                using (BlockTableRecord bDef = (BlockTableRecord)dbObject.BlockTableRecord.GetObject(OpenMode.ForRead))
                {
                    (dwgEntity as DwgBlockReferenceReader).acTrans = tr;
                    (dwgEntity as DwgBlockReferenceReader).btrBlock = bDef;
                    currentBlock = (CwcBlockReference)dwgEntity.ReadEntityDetails(dbObject);

                    Logger.RecordMessage(string.Format("Processing Entity {0} (Id:{1}) in Block (Id:{2})", typeName, currentBlock.Id, currentBlock.BlockDefId), Logs.Log.MessageType.Informational);

                    CXFEntity.WriteEnityDetails(currentBlock, outfile);


                    BlockTableRecordEnumerator iterator_block = bDef.GetEnumerator();

                    DBObject dbObject_block;

                    //if the block name list doesn't contain blockreference's block name.
                    if (!blockList.ContainsKey(dbObject.Name))
                    {
                        blockList.Add(dbObject.Name, bDef.Id.ToString());
                        while (iterator_block.MoveNext())
                        {
                            ObjectId id = iterator_block.Current;
                            using (dbObject_block = tm.GetObject(id, OpenMode.ForRead))
                            {
                                typeName = dbObject_block.GetType().Name;
                                if (typeName == "BlockReference")
                                {
                                    ReadNWriteBlockRef(tm, tr, dbObject_block as BlockReference, typeName, outfile);
                                }
                                else if (typeName.ToUpper() != "HATCH")
                                {
                                    readAndWriteEntity(dbObject_block, typeName, currentBlock.BlockDefId, outfile);
                                }
                            }
                        }
                        iterator_block.Reset();
                        while (iterator_block.MoveNext())
                        {
                            ObjectId id = iterator_block.Current;
                            using (dbObject_block = tm.GetObject(id, OpenMode.ForRead))
                            {
                                typeName = dbObject_block.GetType().Name;
                                if (typeName.ToUpper() == "HATCH")
                                    readAndWriteEntity(dbObject_block, typeName, currentBlock.BlockDefId, outfile);
                            }
                        }
                    }
                }
                #endregion
            }
        }

        private void readDwgBlockDefinition(Database database, StreamWriter outfile)
        {

            TransactionManager tm = database.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable bt = (BlockTable)tm.GetObject(database.BlockTableId, OpenMode.ForRead))
                {
                    foreach (ObjectId objId in bt)
                    {
                        BlockTableRecord btr;
                        using (btr = (BlockTableRecord)tm.GetObject(objId, OpenMode.ForRead))
                        {

                            if (!btr.IsLayout)
                            {
                                //if (btr.HasAttributeDefinitions)
                               	// To include the Arrow head blocks of MLeader eg. _Open30
                                if (btr.Name.StartsWith("*") == false)
                                {
                                    string typeName = btr.GetType().Name;
                                    Logger.RecordMessage(string.Format("Processing Block Definition {0} (Id:{1})", typeName, objId.ToString()), Logs.Log.MessageType.Informational);
                                    IDwgEntityReader dwgEntity = factory.getDwgEntityReader(typeName);

                                    ICXFEntityWriter CXFEntity = factory.getCXFEntityWriter(typeName);
                                    if (dwgEntity != null)
                                    {
                                        ((DwgEnityReader)dwgEntity).Layers = layerList;

                                        ((DwgEnityReader)dwgEntity).DefaultColor = defaultObjectColor;

                                        (dwgEntity as DwgBlockReader).acTrans = tr;

                                        CwcBlock block = (CwcBlock)dwgEntity.ReadEntityDetails(btr);

                                        CXFEntity.WriteEnityDetails(block, outfile);
                                        Logger.RecordMessage(string.Format("Successfully Processed Block Definition {0} (Id:{1})", btr.Name, btr.Id.ToString()), Logs.Log.MessageType.Informational);

                                        if (btr.Name != string.Empty && !blockList.ContainsKey(btr.Name))
                                        {
                                            blockList.Add(btr.Name, btr.Id.ToString());
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
                 
        }

        private void readBlockContent(Database database, StreamWriter outfile)
        {
            TransactionManager tm = database.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable bt = (BlockTable)tm.GetObject(database.BlockTableId, OpenMode.ForRead))
                {
                    foreach (ObjectId objId in bt)
                    {
                        BlockTableRecord btr;
                        using (btr = (BlockTableRecord)tm.GetObject(objId, OpenMode.ForRead))
                        {

                            if (!btr.IsLayout)
                            {
                                //if (btr.HasAttributeDefinitions)
                                //{
                                if (!btr.Name.StartsWith("*"))
                                {
                                    foreach (var recordId in btr)
                                    {
                                        using (var record = recordId.GetObject(OpenMode.ForRead))
                                        {
                                            string typeName = record.GetType().Name;

                                            if (record is Hatch)
                                                continue;

                                            Logger.RecordMessage(string.Format("Processing readblock Entity {0} (Id:{1})", typeName, recordId.ToString()), Logs.Log.MessageType.Informational);

                                            IDwgEntityReader dwgEntity = factory.getDwgEntityReader(typeName);

                                            ICXFEntityWriter CXFEntity = factory.getCXFEntityWriter(typeName);
                                            if (dwgEntity != null)
                                            {
                                                ((DwgEnityReader)dwgEntity).Layers = layerList;

                                                ((DwgEnityReader)dwgEntity).DefaultColor = defaultObjectColor;

                                                ((DwgEnityReader)dwgEntity).CurrentBlock = currentBlock;

                                                if (record is BlockReference)
                                                {
                                                    (dwgEntity as DwgBlockReferenceReader).acTrans = tr;
                                                    (dwgEntity as DwgBlockReferenceReader).btrBlock = btr;
                                                }

                                                CXFEntity.WriteEnityDetails(dwgEntity.ReadEntityDetails(record), outfile);
                                            }

                                            Logger.RecordMessage(string.Format("Processed Successfully {0} (Id:{1})", typeName, recordId.ToString()), Logs.Log.MessageType.Informational);
                                        }
                                    }
                                    foreach (var recordId in btr)
                                    {
                                        using (var dbObject = tm.GetObject(recordId, OpenMode.ForRead))
                                        {
                                            if (dbObject is Hatch)
                                                readAndWriteEntity(dbObject, dbObject.GetType().Name, "", outfile);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private void readAndWriteEntity(DBObject dbObject, string typeName, string blockId, StreamWriter outfile)
        {
            if (blockId.Length == 0)
            {
                Logger.RecordMessage(string.Format("Processing Entity {0} (Id:{1})", typeName, dbObject.Id.ToString()), Logs.Log.MessageType.Informational);
            }
            else
            {
                Logger.RecordMessage(string.Format("Processing Entity {0} (Id:{1}) in Block (Id:{2})", typeName, dbObject.Id.ToString(), blockId), Logs.Log.MessageType.Informational);
            }

            IDwgEntityReader dwgEntity_Block = factory.getDwgEntityReader(typeName);

            ICXFEntityWriter CXFEntity_Block = factory.getCXFEntityWriter(typeName);
            if (dwgEntity_Block != null)
            {
                ((DwgEnityReader)dwgEntity_Block).Layers = layerList;

                ((DwgEnityReader)dwgEntity_Block).DefaultColor = defaultObjectColor;

                //((DwgEnityReader)dwgEntity_Block).BlockReferences = blockReferences;

                ((DwgEnityReader)dwgEntity_Block).CurrentBlock = currentBlock;

                CXFEntity_Block.WriteEnityDetails(dwgEntity_Block.ReadEntityDetails(dbObject), outfile);
            }

        }



        private void readDwgLayerProperties(Database database, StreamWriter outfile)
        {
            TransactionManager tm = database.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (LayerTable lt = (LayerTable)tm.GetObject(database.LayerTableId, OpenMode.ForRead))
                {

                    SymbolTableEnumerator iterator = lt.GetEnumerator();

                    ObjectId layerObject_Id;
                    DBObject layerObject;

                    while (iterator.MoveNext())
                    {
                        layerObject_Id = iterator.Current;
                        using (layerObject = tm.GetObject(layerObject_Id, OpenMode.ForRead))
                        {
                            string typeName = layerObject.GetType().Name;
                            Logger.RecordMessage(string.Format("Processing Layer {0} (Id:{1})", layerObject.GetType().Name, layerObject_Id.ToString()), Logs.Log.MessageType.Informational);
                            IDwgEntityReader dwgEntity = factory.getDwgEntityReader(typeName);

                            ICXFEntityWriter CXFEntity = factory.getCXFEntityWriter(typeName);
                            if (dwgEntity != null)
                            {
                                (dwgEntity as DwgLayerReader).acTrans = tr;
                                CwcLayer layer = (CwcLayer)dwgEntity.ReadEntityDetails(layerObject);

                                layerList.Add(layer.Id, layer);

                                defaultObjectColor = (layer.Color.Color == "ffffffff") ? layer.Color : (layer.Color.Color == "00000000") ? layer.Color : new CwcColor(255, 255, 255);

                                CXFEntity.WriteEnityDetails(layer, outfile);
                                Logger.RecordMessage(string.Format("Layer Name= {0},Colour={1}, LineType ={2}, Lineweight={3}, Id={4}", layer.Name, layer.Color.ToString(), layer.LineTypeId, layer.LineWeight, layer.Id), Logs.Log.MessageType.Informational);
                            }

                        }
                    }
                }

                tr.Abort();
            }
        }

        private void readDwgStyleProperties(Database database, StreamWriter outfile)
        {
            TransactionManager tm = database.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (TextStyleTable tst = (TextStyleTable)tm.GetObject(database.TextStyleTableId, OpenMode.ForRead))
                {
                    SymbolTableEnumerator tst_iterator = tst.GetEnumerator();

                    ObjectId textStyleObject_Id;

                    while (tst_iterator.MoveNext())
                    {
                        textStyleObject_Id = tst_iterator.Current;
                        using (TextStyleTableRecord textStyleRecord = (TextStyleTableRecord)tm.GetObject(textStyleObject_Id, OpenMode.ForRead))
                        {

                            string typeName = textStyleRecord.GetType().Name;
                            IDwgEntityReader dwgEntity = factory.getDwgEntityReader(typeName);

                            ICXFEntityWriter CXFEntity = factory.getCXFEntityWriter(typeName);
                            if (dwgEntity != null)
                            {

                                CwcTextStyle textStyle = (CwcTextStyle)dwgEntity.ReadEntityDetails(textStyleRecord);

                                // To skip empty textstyle entities coming from linetype defs
                                if ( (textStyle.Name.Length > 0) && (textStyle.FontName.Length > 0) ||
                                     (textStyle.Name.Length > 0) && (textStyle.FileName.Length > 0) )
                                {

                                    //                  textStyleList.Add(textStyle.Id, textStyle);
                                    Logger.RecordMessage(string.Format("Processing Text Style (Id:{0}) {1} ", textStyle.Id, textStyle.FontName), Logs.Log.MessageType.Informational);

                                    CXFEntity.WriteEnityDetails(textStyle, outfile);
                                }
                            }
                        }
                    
                    }
                }

                using (DimStyleTable dimst = (DimStyleTable)tm.GetObject(database.DimStyleTableId, OpenMode.ForRead))
                {

                    SymbolTableEnumerator dst_iterator = dimst.GetEnumerator();

                    ObjectId dimStyleObject_Id;

                    while (dst_iterator.MoveNext())
                    {
                        dimStyleObject_Id = dst_iterator.Current;

                        using (DimStyleTableRecord dimStyleRecord = (DimStyleTableRecord)tm.GetObject(dimStyleObject_Id, OpenMode.ForRead))
                        {

                            string typeName = dimStyleRecord.GetType().Name;
                            IDwgEntityReader dwgEntity = factory.getDwgEntityReader(typeName);

                            ICXFEntityWriter CXFEntity = factory.getCXFEntityWriter(typeName);
                            if (dwgEntity != null)
                            {
                                ((DwgEnityReader)dwgEntity).DefaultColor = defaultObjectColor;

                                CwcDimStyle dimStyle = (CwcDimStyle)dwgEntity.ReadEntityDetails(dimStyleRecord);

                                Logger.RecordMessage(string.Format("Processing DimStyle (Id:{0}) {1} ", dimStyle.Id, dimStyle.Name), Logs.Log.MessageType.Informational);

                                CXFEntity.WriteEnityDetails(dimStyle, outfile);

                            }
                        }
                    }
                }

                using (LinetypeTable ltt = (LinetypeTable)tm.GetObject(database.LinetypeTableId, OpenMode.ForRead))
                {
                    SymbolTableEnumerator ltt_iterator = ltt.GetEnumerator();

                    ObjectId lineTypeObject_Id;

                    while (ltt_iterator.MoveNext())
                    {
                        lineTypeObject_Id = ltt_iterator.Current;
                        using (LinetypeTableRecord linetypeTableRecord = (LinetypeTableRecord)tm.GetObject(lineTypeObject_Id, OpenMode.ForRead))
                        {

                            string typeName = linetypeTableRecord.GetType().Name;
                            IDwgEntityReader dwgEntity = factory.getDwgEntityReader(typeName);

                            ICXFEntityWriter CXFEntity = factory.getCXFEntityWriter(typeName);
                            if (dwgEntity != null)
                            {

                                CwcLineType lineType = (CwcLineType)dwgEntity.ReadEntityDetails(linetypeTableRecord);
                                //                  textStyleList.Add(textStyle.Id, textStyle);
                                Logger.RecordMessage(string.Format("Processing LineType(Id:{0}) {1} ", lineType.Id, lineType.Name), Logs.Log.MessageType.Informational);

                                CXFEntity.WriteEnityDetails(lineType, outfile);
                            }
                        }

                    }
                }


                tr.Abort();
            }
        }

        private void readDwgMleaderStyleProperties(Database database, StreamWriter outfile)
        {
            TransactionManager tm = database.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (DBDictionary mlStyleDictionary = (DBDictionary)tm.GetObject(database.MLeaderStyleDictionaryId, OpenMode.ForRead))
                {
                    foreach (var mlStyleId in mlStyleDictionary)
                    {
                        using (MLeaderStyle mlStyle = mlStyleId.Value.GetObject(OpenMode.ForRead) as MLeaderStyle)
                        {
                            string typeName = mlStyle.GetType().Name;
                            IDwgEntityReader dwgEntity = factory.getDwgEntityReader(typeName);

                            ICXFEntityWriter CXFEntity = factory.getCXFEntityWriter(typeName);
                            if (dwgEntity != null)
                            {

                                CwcMLeaderStyle mleaderStyle = (CwcMLeaderStyle)dwgEntity.ReadEntityDetails(mlStyle);

                                // To skip empty textstyle entities coming from linetype defs
                                if (mleaderStyle.Name.Length > 0)
                                {
                                    Logger.RecordMessage(string.Format("Processing MLeader Style (Id:{0}) {1} ", mleaderStyle.Id, mleaderStyle.Name), Logs.Log.MessageType.Informational);

                                    CXFEntity.WriteEnityDetails(mleaderStyle, outfile);
                                }
                            }
                        }
                    }
                }
            }
        }

        private void readLayoutSettings(Database database, StreamWriter outfile)
        {
            TransactionManager tm = database.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (var layoutDict = tm.GetObject(database.LayoutDictionaryId, OpenMode.ForRead) as DBDictionary)
                {
                    foreach (var layoutId in layoutDict)
                    {
                        using (var layoutEntity = layoutId.Value.GetObject(OpenMode.ForRead) as Layout)
                        {
                            string typeName = layoutEntity.GetType().Name;
                            Logger.RecordMessage(string.Format("Processing Layout {0} (Id:{1})", typeName, layoutId.Value.ToString()), Logs.Log.MessageType.Informational);
                            IDwgEntityReader dwgEntity = factory.getDwgEntityReader(typeName);

                            ICXFEntityWriter CXFEntity = factory.getCXFEntityWriter(typeName);
                            if (dwgEntity != null)
                            {
                                CwcLayout layout = (CwcLayout)dwgEntity.ReadEntityDetails(layoutEntity);

                                CXFEntity.WriteEnityDetails(layout, outfile);
                                Logger.RecordMessage(string.Format("Processing Layout details {0} (Id:{1})", layout.LayoutName, layout.Id.ToString()), Logs.Log.MessageType.Informational);
                            }

                            //read block reader for layout viewport
                            if (!layoutEntity.ModelType)
                            {
                                readLayoutBlock(tm, tr, layoutEntity, outfile);
                            }
                        }
                    }
                }
            }
        }

        private void readLayoutBlock(TransactionManager tm, Transaction tr, Layout layoutEntity, StreamWriter outfile)
        {
            using (var layoutBlockEntity = tm.GetObject(layoutEntity.BlockTableRecordId, OpenMode.ForRead) as BlockTableRecord)
            {
                string typeName = "LayoutBlockTableRecord";
                Logger.RecordMessage(string.Format("Processing Layout Block {0} (Id:{1})", typeName, layoutBlockEntity.Id.ToString()), Logs.Log.MessageType.Informational);
                IDwgEntityReader dwgEntity = factory.getDwgEntityReader(typeName);

                ICXFEntityWriter CXFEntity = factory.getCXFEntityWriter(typeName);
                if (dwgEntity != null)
                {
                    CwcLayoutBlock layoutBlock = (CwcLayoutBlock)dwgEntity.ReadEntityDetails(layoutBlockEntity);

                    CXFEntity.WriteEnityDetails(layoutBlock, outfile);
                    Logger.RecordMessage(string.Format("Processing Layout Block details {0} (Id:{1})", layoutBlock.LayoutName, layoutBlock.Id.ToString()), Logs.Log.MessageType.Informational);
                }

                //read block table record contents
                readLayoutContent(tm, tr, layoutBlockEntity, outfile);
            }
        }

        private void readLayoutContent(TransactionManager tm, Transaction tr, BlockTableRecord btr, StreamWriter outfile)
        {
            foreach(var layoutItemId in btr)
            {
                using (var layoutItem = layoutItemId.GetObject(OpenMode.ForRead))
                {
                    if(layoutItem is BlockReference)
                     {
                        ReadNWriteBlockRef(tm, tr, layoutItem as BlockReference, layoutItem.GetType().Name, outfile);
                    }
                    else
                    {
                        var typeName = layoutItem.GetType().Name;
                        Logger.RecordMessage(string.Format("Processing Layout Entity {0} (Id:{1})", typeName, layoutItem.Id.ToString()), Logs.Log.MessageType.Informational);

                        IDwgEntityReader dwgEntity = factory.getDwgEntityReader(typeName);

                        ICXFEntityWriter CXFEntity = factory.getCXFEntityWriter(typeName);
                        if (dwgEntity != null)
                        {
                            ((DwgEnityReader)dwgEntity).Layers = layerList;

                            ((DwgEnityReader)dwgEntity).DefaultColor = defaultObjectColor;

                            ((DwgEnityReader)dwgEntity).CurrentBlock = currentBlock;

                            CXFEntity.WriteEnityDetails(dwgEntity.ReadEntityDetails(layoutItem), outfile);
                        }
                    }
                }
            }
        }

        private void readPlotSettings(Database database, StreamWriter outfile)
        {
            TransactionManager tm = database.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (var plotSettingsDict = tr.GetObject(database.PlotSettingsDictionaryId, OpenMode.ForRead) as DBDictionary)
                {
                    foreach (var dictPlotItem in plotSettingsDict)
                    {
                        using (var entity = dictPlotItem.Value.GetObject(OpenMode.ForRead) as PlotSettings)
                        {
                            if (!entity.ModelType)
                            {
                                string typeName = entity.GetType().Name;
                                Logger.RecordMessage(string.Format("Processing PlotSettings {0} (Id:{1})", typeName, entity.Id.ToString()), Logs.Log.MessageType.Informational);
                                IDwgEntityReader dwgEntity = factory.getDwgEntityReader(typeName);

                                ICXFEntityWriter CXFEntity = factory.getCXFEntityWriter(typeName);
                                if (dwgEntity != null)
                                {
                                    CwcPlotSettings plotSetting = null;
                                    bool layoutExist = false;
                                    using (var layoutDict = tm.GetObject(database.LayoutDictionaryId, OpenMode.ForRead) as DBDictionary)
                                    {
                                        foreach (var layoutDictItem in layoutDict)
                                        {
                                            using (var layout = tr.GetObject(layoutDictItem.Value, OpenMode.ForRead) as Layout)
                                            {
                                                if (!layout.ModelType)
                                                {
                                                    if (layout.PlotSettingsName == entity.PlotSettingsName)
                                                    {
                                                        plotSetting = (CwcPlotSettings)dwgEntity.ReadEntityDetails(layout);
                                                        CXFEntity.WriteEnityDetails(plotSetting, outfile);
                                                        layoutExist = true;
                                                    }
                                                }
                                            }
                                        }
                                        if (!layoutExist)
                                        {
                                            plotSetting = (CwcPlotSettings)dwgEntity.ReadEntityDetails(entity);
                                            CXFEntity.WriteEnityDetails(plotSetting, outfile);
                                        }

                                        Logger.RecordMessage(string.Format("Processing PlotSettings details {0} (Id:{1})", plotSetting.Name, plotSetting.Id.ToString()), Logs.Log.MessageType.Informational);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
       
        private void readModelViewportSettings(Database database, StreamWriter outfile)
        {

            TransactionManager tm = database.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (var vpt = tm.GetObject(database.ViewportTableId, OpenMode.ForRead) as ViewportTable)
                {
                    SymbolTableEnumerator iterator = vpt.GetEnumerator();

                    ObjectId id;

                    while (iterator.MoveNext())
                    {
                        id = iterator.Current;
                        using (ViewportTableRecord vtr = tm.GetObject(id, OpenMode.ForRead) as ViewportTableRecord)
                        {

                            string typeName = vtr.GetType().Name;
                            Logger.RecordMessage(string.Format("Processing Viewport {0} (Id:{1})", typeName, id.ToString()), Logs.Log.MessageType.Informational);
                            IDwgEntityReader dwgEntity = factory.getDwgEntityReader(typeName);

                            ICXFEntityWriter CXFEntity = factory.getCXFEntityWriter(typeName);
                            if (dwgEntity != null)
                            {
                                CwcModelViewport viewport = (CwcModelViewport)dwgEntity.ReadEntityDetails(vtr);

                                CXFEntity.WriteEnityDetails(viewport, outfile);
                                Logger.RecordMessage(string.Format("Processing Viewport details {0} (Id:{1})", viewport.Name, viewport.Id.ToString()), Logs.Log.MessageType.Informational);
                            }
                        }
                    }
                }
                tr.Abort();
            }
        }
        private void readDBSettings(Database db, StreamWriter outfile)
        {
            Logger.RecordMessage("Reading Database Settings", Logs.Log.MessageType.Informational);
            DwgDBSettingsReader dwgDBSettingsReader = new DwgDBSettingsReader();

            CXFDBSettingsWriter CXFDBSettingsWriter = new CXFDBSettingsWriter();
            CwcDBSettings dbSettings = (CwcDBSettings)dwgDBSettingsReader.ReadDBSettings(db);

            CXFDBSettingsWriter.WriteDBSettings(dbSettings, outfile);

            Logger.RecordMessage("Writing Database Settings", Logs.Log.MessageType.Informational);
        }


        private List<string> CustomHatchPatCreation(Database db, string drawingFileName)
        {

            try
            {
                List<string> patfiles;
                CustomHatchUtil custHatchUtil = new CustomHatchUtil();
                patfiles = custHatchUtil.CreatePatFilesForCustomHatch(db, drawingFileName);
                Logger.RecordMessage(patfiles.ToString(), Logs.Log.MessageType.Informational);
            }
            catch (System.Exception ex)
            {
                Logger.RecordMessage(ex.Message, Logs.Log.MessageType.Error);
            }
            return new List<string>();
        }

    }
}
