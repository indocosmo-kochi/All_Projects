﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFEllipseReader : CXFEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcEllipse entity = new CwcEllipse();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            entity.Visible = ConvertCXFValue2Bool(entityRecord, "Visible", false, true);

            CwcPoint3D point3d;
            if (ParseCXFPoint3d(entityRecord, "Center", true, out point3d))
                entity.Center = point3d;

            CwcVector3D vector3d;
            if (ParseCXFVector3d(entityRecord, "UnitNormal", true, out vector3d))
                entity.UnitNormal = vector3d;

            if (ParseCXFVector3d(entityRecord, "MajorAxis", true, out vector3d))
                entity.MajorAxis = vector3d;

            if (ReadPropertyValue(entityRecord, "RadiusRatio", false, out value))
                entity.RadiusRatio = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "StartAngle", false, out value))
                entity.StartAngle = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "EndAngle", false, out value))
                entity.EndAngle = ConvertCXFValue2Double(value);

            entity.Color = ParseCXFColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            if (ReadPropertyValue(entityRecord, "Linetype", false, out value))
                entity.Linetype = value;

            if (ReadPropertyValue(entityRecord, "LinetypeScale", false, out value))
                entity.LinetypeScale = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                entity.LineWeight = ConvertCXFLineWeightToDwg(value);

            return entity;
        }

    }
}

