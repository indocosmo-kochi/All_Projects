﻿using System;
using System.Collections.Generic;
using CWorksCXF.Entities;
using System.Text.RegularExpressions;
using CWorksCXF.Common;
using Teigha.DatabaseServices;
using Teigha.Colors;

namespace CWorksCXF.CXF.Reader
{
    public abstract class CXFEntityReader:ICXFEntityReader  
    {
        public string EntityTypeName { get; set; }
        public abstract CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord);

        protected bool ReadPropertyValue(Dictionary<string, string> entityRecord, string entityProperty, bool isRequired, out string value)
        {
            string errorMsg = "ERROR: Missing property VALUE '" + entityProperty + "' for Entity [" + EntityTypeName + "], CXF->DWG processing Aborted!!!.";
            return ReadPropertyValue(entityRecord, entityProperty, isRequired, out value, errorMsg);
        }

        protected bool ReadPropertyValue(Dictionary<string, string> entityRecord, string entityProperty, bool isRequired, out string value, string errorMsg)
        {
            if (entityRecord.ContainsKey(entityProperty))
            {
                value = entityRecord[entityProperty].Trim();
                if (isRequired && value.Length == 0)
                {
                    Logger.RecordMessage(errorMsg, Logs.Log.MessageType.Exception);
                    return false;
                }
                return true;
            }
            else
            {
                value = string.Empty;
                if (isRequired)
                {
                    Logger.RecordMessage(errorMsg, Logs.Log.MessageType.Exception);
                }
                return false;
            }
        }

        private byte?[] ConvertColorCsvStringToByte(string csvString)
        {
            string[] strValues = Regex.Match(csvString, @"\(([^)]*)\)").Groups[1].Value.Split(',');
            byte?[] byteValues = { null, null, null };
            if (strValues[0] != "-1")
            {
                byteValues[0] = ConvertCXFValue2Byte(strValues[0]);

                byteValues[1] = ConvertCXFValue2Byte(strValues[1]);

                byteValues[2] = ConvertCXFValue2Byte(strValues[2]);

            }

            return byteValues;
        }

        private Double[] ConvertPoint3dCsvStringToDouble(string csvString)
        {
            string[] strValues = Regex.Match(csvString, @"\(([^)]*)\)").Groups[1].Value.Split(',');
            Double[] doubleValues = { 0, 0, 0 };
            Double.TryParse(strValues[0], out doubleValues[0]);
            Double.TryParse(strValues[1], out doubleValues[1]);
            Double.TryParse(strValues[2], out doubleValues[2]);
            return doubleValues;
        }

        private double[] ConvertPoint2dCsvStringToDouble(string csvString)
        {
            string[] strValues = Regex.Match(csvString, @"\(([^)]*)\)").Groups[1].Value.Split(',');
            double[] doubleValues = { 0, 0};
            double.TryParse(strValues[0], out doubleValues[0]);
            double.TryParse(strValues[1], out doubleValues[1]);

            return doubleValues;
        }

        protected CwcColor ParseCXFColor(Dictionary<string, string> entityRecord, string colorProperty,
                                            string colorMethodProperty, string colorIndexProperty)
        {
            const short DEFAUTLT_COLOR_INDEX = 9;
            const byte DEFAUTLT_COLOR_RGB_VALUE = 255;

            // initialise with default value for color as ByLayer
            short colorIndex = DEFAUTLT_COLOR_INDEX;
            byte?[] colorValues = { DEFAUTLT_COLOR_RGB_VALUE, DEFAUTLT_COLOR_RGB_VALUE, DEFAUTLT_COLOR_RGB_VALUE };
            ColorMethod colorMethod = ColorMethod.None;

            // if value specified in the entity property, it will be overridden
            if (entityRecord.ContainsKey(colorProperty))
            {
                colorValues = ConvertColorCsvStringToByte(entityRecord[colorProperty]);
            }


            if (entityRecord.ContainsKey(colorMethodProperty))
            {
                int value;
                int.TryParse(entityRecord[colorMethodProperty], out value);
                colorMethod = ConvertCXFColorMethodToDwg(entityRecord[colorMethodProperty]);
            }

            if (entityRecord.ContainsKey(colorIndexProperty))
            {
                short.TryParse(entityRecord[colorIndexProperty], out colorIndex);
            }
            CwcColor cwcColor = new CwcColor(colorValues[0], colorValues[1], colorValues[2]);
            cwcColor.ColorMethod = colorMethod;
            cwcColor.ColorIndex = colorIndex;

      
            return cwcColor;
        }

        protected bool ParseCXFPoint3d(Dictionary<string, string> entityRecord, string entityProperty, bool isRequired, out CwcPoint3D point3d)
        {
            if (!entityRecord.ContainsKey(entityProperty))
            {
                point3d = new CwcPoint3D(0, 0, 0);
                if (isRequired)
                {
                    Logger.RecordMessage("ERROR: Missing property '" + entityProperty + "' for Entity [" + EntityTypeName + "], CXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
                }
                return false;
            }
            else
            {
                double[] CXFPoint3dValues = ConvertPoint3dCsvStringToDouble(entityRecord[entityProperty]);

                point3d = new CwcPoint3D(CXFPoint3dValues[0], CXFPoint3dValues[1], CXFPoint3dValues[2]);
                return true;
            }

        }

        protected bool ParseCXFScale3d(Dictionary<string, string> entityRecord, string entityProperty, bool isRequired, out CwcScale3D point3d)
        {
            if (!entityRecord.ContainsKey(entityProperty))
            {
                point3d = new CwcScale3D(0, 0, 0);
                if (isRequired)
                {
                    Logger.RecordMessage("ERROR: Missing property '" + entityProperty + "' for Entity [" + EntityTypeName + "], CXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
                }
                return false;
            }
            else
            {
                double[] CXFPoint3dValues = ConvertPoint3dCsvStringToDouble(entityRecord[entityProperty]);

                point3d = new CwcScale3D(CXFPoint3dValues[0], CXFPoint3dValues[1], CXFPoint3dValues[2]);
                return true;
            }

        }

        protected bool ParseCXFPoint2d(Dictionary<string, string> entityRecord, string entityProperty, bool isRequired, out CwcPoint2D point2d)
        {
            if (!entityRecord.ContainsKey(entityProperty))
            {
                point2d = new CwcPoint2D(0, 0);
                if (isRequired)
                {
                    Logger.RecordMessage("ERROR: Missing property '" + entityProperty + "' for Entity [" + EntityTypeName + "], CXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
                }
                return false;
            }
            else
            {
                double[] CXFPoint2dValues = ConvertPoint2dCsvStringToDouble(entityRecord[entityProperty]);

                point2d = new CwcPoint2D(CXFPoint2dValues[0], CXFPoint2dValues[1]);
                return true;
            }

        }

        protected bool ParseCXFVector2d(Dictionary<string, string> entityRecord, string entityProperty, bool isRequired, out CwcVector2D vector2d)
        {
            if (!entityRecord.ContainsKey(entityProperty))
            {
                vector2d = new CwcVector2D(0, 0);
                if (isRequired)
                {
                    Logger.RecordMessage("ERROR: Missing property '" + entityProperty + "' for Entity [" + EntityTypeName + "], CXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
                }
                return false;
            }
            else
            {
                double[] CXFVector2dValues = ConvertPoint2dCsvStringToDouble(entityRecord[entityProperty]);

                vector2d = new CwcVector2D(CXFVector2dValues[0], CXFVector2dValues[1]);
                return true;
            }

        }

        protected bool ParseCXFVector3d(Dictionary<string, string> entityRecord, string entityProperty, bool isRequired, out CwcVector3D vector3d)
        {
            if (!entityRecord.ContainsKey(entityProperty))
            {
                vector3d = new CwcVector3D(0, 0, 0);
                if (isRequired)
                {
                    Logger.RecordMessage("ERROR: Missing property '" + entityProperty + "' for Entity [" + EntityTypeName + "], CXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
                }
                return false;
            }
            else
            {
                double[] CXFVector3dValues = ConvertPoint3dCsvStringToDouble(entityRecord[entityProperty]);

                vector3d = new CwcVector3D(CXFVector3dValues[0], CXFVector3dValues[1], CXFVector3dValues[2]);
                return true;
            }

        }

        protected bool ConvertCXFValue2Bool(Dictionary<string, string> entityRecord, string entityProperty, bool isRequired, bool defaultValue)
        {
            if (entityRecord.ContainsKey(entityProperty))
            {
                return (entityRecord[entityProperty].Trim() == "1") ? true : false;
            }
            else
            {
                if (isRequired)
                {
                    Logger.RecordMessage("ERROR: Missing property '" + entityProperty + "' for Entity [" + EntityTypeName + "], CXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
                }
                return defaultValue;
            }
        }

        protected double ConvertCXFValue2Double(string value)
        {
            double dValue;

            if (!double.TryParse(value, out dValue))
            {
                Logger.RecordMessage("ERROR: String to Double Conversion, '" + value + "' cannot be converted. CXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
            }

            return dValue;
        }

        protected byte ConvertCXFValue2Byte(string value)
        {
            byte byteValue;

            if (!byte.TryParse(value, out byteValue))
            {
                Logger.RecordMessage("ERROR: String to Byte Conversion, '" + value + "' cannot be converted. CXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
            }

            return byteValue;
        }

        protected float ConvertCXFValue2float(string value)
        {
            float fValue;

            if (!float.TryParse(value, out fValue))
            {
                Logger.RecordMessage("ERROR: String to Float Conversion, '" + value + "' cannot be converted. CXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
            }

            return fValue;
        }

        protected int ConvertCXFValue2Integer(string value)
        {
            int intValue;

            if (!int.TryParse(value, out intValue))
            {
                Logger.RecordMessage("ERROR: String to Integer Conversion, '" + value + "' cannot be converted. CXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
            }

            return intValue;
        }
        protected short ConvertCXFValue2Short(string value)
        {
            short shortValue;

            if (!short.TryParse(value, out shortValue))
            {
                Logger.RecordMessage("ERROR: String to Short Conversion, '" + value + "' cannot be converted. CXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
            }

            return shortValue;
        }
        

        protected LineSpacingStyle ConvertCXFMTextLineSpacingStyleToDwg(string CXFLineSpacingStyle)
        {
            return Enums.ConvertStringToEnumValue<LineSpacingStyle>(CXFLineSpacingStyle);
        }

        protected FlowDirection ConvertCXFMTextFlowDirectionToDwg(string CXFFlowDirection)
        {
            return Enums.ConvertStringToEnumValue<FlowDirection>(CXFFlowDirection);
        }

        protected ColumnType ConvertCXFMTextColumnTypeToDwg(string CXFColumnType)
        {
            return Enums.ConvertStringToEnumValue<ColumnType>(CXFColumnType);
        }

        protected AttachmentPoint ConvertCXFMTextAttachmentToDwg(string CXFAttachment)
        {
            return Enums.ConvertStringToEnumValue<AttachmentPoint>(CXFAttachment);
        }

        protected TextVerticalMode ConvertCXFVerticalModeToDwg(string CXFVerticalMode)
        {
            return Enums.ConvertStringToEnumValue<TextVerticalMode>(CXFVerticalMode);
        }

        protected AttachmentPoint ConvertCXFTextJustifyToDwg(string CXFTextJustify)
        {
            return Enums.ConvertStringToEnumValue<AttachmentPoint>(CXFTextJustify);
        }

        protected TextHorizontalMode ConvertCXFHorizontalModeToDwg(string CXFHorizontalMode)
        {
            return Enums.ConvertStringToEnumValue<TextHorizontalMode>(CXFHorizontalMode);
        }

        
        protected AnnotationType ConvertCXFAnnotationTypeToDwg(string CXFAnnotationType)
        {
            return Enums.ConvertStringToEnumValue<AnnotationType>(CXFAnnotationType);
        }

        protected LineWeight ConvertCXFLineWeightToDwg(string CXFLineWeight)
        {
            return Enums.ConvertStringToEnumValue<LineWeight>(CXFLineWeight);
        }

        protected AnnotativeStates ConvertCXFAnnotativeStatesToDwg(string CXFAnnotativeStates)
        {
            return Enums.ConvertStringToEnumValue<AnnotativeStates>(CXFAnnotativeStates);
        }

        protected ColorMethod ConvertCXFColorMethodToDwg(string CXFColorMethod)
        {
            return Enums.ConvertStringToEnumValue<ColorMethod>(CXFColorMethod);
        }

        protected UnitsValue ConvertCXFBlockUnitToDwg(string CXFBlockUnit)
        {
            return Enums.ConvertStringToEnumValue<UnitsValue>(CXFBlockUnit);
        }

        protected TextAlignmentType ConvertCXFTextAlignmentTypeToDwg(string CXFTextAlignmentType)
        {
            return Enums.ConvertStringToEnumValue<TextAlignmentType>(CXFTextAlignmentType);
        }

        protected void ReadDimensionValues(CwcDimension entity, Dictionary<string, string> entityRecord)
        {
            string value;

            if (ReadPropertyValue(entityRecord, "Dimadec", false, out value))
                entity.Dimadec = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimaltd", false, out value))
                entity.Dimaltd = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimalttd", false, out value))
                entity.Dimalttd = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimalttz", false, out value))
                entity.Dimalttz = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimaltu", false, out value))
                entity.Dimaltu = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimaltz", false, out value))
                entity.Dimaltz = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimaltf", false, out value))
                entity.Dimaltf = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimaltrnd", false, out value))
                entity.Dimaltrnd = ConvertCXFValue2Double(value);

            entity.Dimalt = ConvertCXFValue2Bool(entityRecord, "Dimalt", false, false);

            if (ReadPropertyValue(entityRecord, "Dimapost", false, out value))
                entity.Dimapost = value;

            if (ReadPropertyValue(entityRecord, "Dimasz", false, out value))
                entity.Dimasz = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimarcsym", false, out value))
                entity.Dimarcsym = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimatfit", false, out value))
                entity.Dimatfit = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimaunit", false, out value))
                entity.Dimaunit = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimazin", false, out value))
                entity.Dimazin = ConvertCXFValue2Integer(value);

            entity.Dimsah = ConvertCXFValue2Bool(entityRecord, "Dimsah", false, false);

            if (ReadPropertyValue(entityRecord, "Dimblk1s", false, out value))
                entity.Dimblk1s = value;

            if (ReadPropertyValue(entityRecord, "Dimblk2s", false, out value))
                entity.Dimblk2s = value;

            if (ReadPropertyValue(entityRecord, "Dimblks", false, out value))
                entity.Dimblks = value;

            if (ReadPropertyValue(entityRecord, "Dimcen", false, out value))
                entity.Dimcen = ConvertCXFValue2Double(value);

            entity.Dimclrd = ParseCXFColor(entityRecord, "Dimclrd", "Dimclrd_ColorMethod", "Dimclrd_ColorIndex");

            entity.Dimclre = ParseCXFColor(entityRecord, "Dimclre", "Dimclre_ColorMethod", "Dimclre_ColorIndex");

            entity.Dimclrt = ParseCXFColor(entityRecord, "Dimclrt", "Dimclrt_ColorMethod", "Dimclrt_ColorIndex");

            if (ReadPropertyValue(entityRecord, "Dimdec", false, out value))
                entity.Dimdec = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimfrac", false, out value))
                entity.Dimfrac = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimdle", false, out value))
                entity.Dimdle = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimdli", false, out value))
                entity.Dimdli = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimexe", false, out value))
                entity.Dimexe = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimexo", false, out value))
                entity.Dimexo = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimfxlen", false, out value))
                entity.Dimfxlen = ConvertCXFValue2Double(value);

            entity.DimfxlenOn = ConvertCXFValue2Bool(entityRecord, "DimfxlenOn", false, false);

            if (ReadPropertyValue(entityRecord, "Dimgap", false, out value))
                entity.Dimgap = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimjogang", false, out value))
                entity.Dimjogang = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimjust", false, out value))
                entity.Dimjust = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimdsep", false, out value))
            {
                if (value.Trim().Length > 0)
                {
                    entity.Dimdsep = value.Trim()[0];
                }
            }

            if (ReadPropertyValue(entityRecord, "Dimldrblks", false, out value))
                entity.Dimldrblks = value;

            if (ReadPropertyValue(entityRecord, "Dimlfac", false, out value))
                entity.Dimlfac = ConvertCXFValue2Double(value);

            entity.Dimlim = ConvertCXFValue2Bool(entityRecord, "Dimlim", false, false);

            if (ReadPropertyValue(entityRecord, "Dimltex1", false, out value))
                entity.Dimltex1 = value;

            if (ReadPropertyValue(entityRecord, "Dimltex2", false, out value))
                entity.Dimltex2 = value;

            if (ReadPropertyValue(entityRecord, "Dimltype", false, out value))
                entity.Dimltype = value;

            if (ReadPropertyValue(entityRecord, "Dimpost", false, out value))
                entity.Dimpost = value;

            if (ReadPropertyValue(entityRecord, "Dimrnd", false, out value))
                entity.Dimrnd = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimscale", false, out value))
                entity.Dimscale = ConvertCXFValue2Double(value);

            entity.Dimsd1 = ConvertCXFValue2Bool(entityRecord, "Dimsd1", false, false);

            entity.Dimsd2 = ConvertCXFValue2Bool(entityRecord, "Dimsd2", false, false);

            entity.Dimse1 = ConvertCXFValue2Bool(entityRecord, "Dimse1", false, false);

            entity.Dimse2 = ConvertCXFValue2Bool(entityRecord, "Dimse2", false, false);

            entity.Dimsoxd = ConvertCXFValue2Bool(entityRecord, "Dimsoxd", false, false);

            if (ReadPropertyValue(entityRecord, "Dimtad", false, out value))
                entity.Dimtad = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimtdec", false, out value))
                entity.Dimtdec = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimtfill", false, out value))
                entity.Dimtfill = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimtfac", false, out value))
                entity.Dimtfac = ConvertCXFValue2Double(value);

            entity.Dimtfillclr = ParseCXFColor(entityRecord, "Dimtfillclr", "Dimtfillclr_ColorMethod", "Dimtfillclr_ColorIndex");

            entity.Dimtih = ConvertCXFValue2Bool(entityRecord, "Dimtih", false, false);

            entity.Dimtix = ConvertCXFValue2Bool(entityRecord, "Dimtix", false, false);

            if (ReadPropertyValue(entityRecord, "Dimtm", false, out value))
                entity.Dimtm = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtmove", false, out value))
                entity.Dimtmove = ConvertCXFValue2Integer(value);

            entity.Dimtofl = ConvertCXFValue2Bool(entityRecord, "Dimtofl", false, false);

            entity.Dimtoh = ConvertCXFValue2Bool(entityRecord, "Dimtoh", false, false);

            entity.Dimtol = ConvertCXFValue2Bool(entityRecord, "Dimtol", false, false);

            if (ReadPropertyValue(entityRecord, "Dimtolj", false, out value))
                entity.Dimtolj = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimtp", false, out value))
                entity.Dimtp = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtsz", false, out value))
                entity.Dimtsz = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtvp", false, out value))
                entity.Dimtvp = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtxt", false, out value))
                entity.Dimtxt = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtzin", false, out value))
                entity.Dimtzin = ConvertCXFValue2Integer(value);

            entity.Dimupt = ConvertCXFValue2Bool(entityRecord, "Dimupt", false, false);

            if (ReadPropertyValue(entityRecord, "Dimzin", false, out value))
                entity.Dimzin = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimlwd", false, out value))
                entity.Dimlwd = ConvertCXFLineWeightToDwg(value);

            if (ReadPropertyValue(entityRecord, "Dimlwe", false, out value))
                entity.Dimlwe = ConvertCXFLineWeightToDwg(value);

        }

    }

}
