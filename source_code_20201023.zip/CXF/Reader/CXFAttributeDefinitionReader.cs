﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFAttributeDefinitionReader : CXFEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcAttributeDefinition entity = new CwcAttributeDefinition();

            CwcPoint3D point3d;
            string value;

            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;
            if (ParseCXFPoint3d(entityRecord, "Position", true, out point3d))
                entity.Position = point3d;

            if (ParseCXFPoint3d(entityRecord, "AlignmentPoint", true, out point3d))
                entity.AlignmentPoint = point3d;

            if (ReadPropertyValue(entityRecord, "Tag", true, out value))
                entity.Tag = value;

            if (ReadPropertyValue(entityRecord, "TextString", false, out value))
                entity.TextString = value;

            if (ReadPropertyValue(entityRecord, "FieldLength", true, out value))
                entity.FieldLength = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Height", true, out value))
                entity.Height = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Oblique", true, out value))
                entity.Oblique = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Rotation", true, out value))
                entity.Rotation = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "WidthFactor", true, out value))
                entity.WidthFactor = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Annotative", true, out value))
                entity.Annotative = ConvertCXFAnnotativeStatesToDwg(value);

            if (ReadPropertyValue(entityRecord, "Justify", true, out value))
                entity.Justify = ConvertCXFTextJustifyToDwg(value);

            entity.IsMirroredInX = ConvertCXFValue2Bool(entityRecord, "IsMirroredInX", true, false);
            entity.IsMirroredInY = ConvertCXFValue2Bool(entityRecord, "IsMirroredInY", true, false);
            entity.Constant = ConvertCXFValue2Bool(entityRecord, "Constant", true, false);
            entity.IsMTextAttributeDefinition = ConvertCXFValue2Bool(entityRecord, "IsMTextAttributeDefinition", true, false);
            entity.Invisible = ConvertCXFValue2Bool(entityRecord, "Invisible", false, false);
            entity.LockPositionInBlock = ConvertCXFValue2Bool(entityRecord, "LockPositionInBlock", false, false);

            if (!entity.Constant)
            {
                if (ReadPropertyValue(entityRecord, "Prompt", false, out value))
                    entity.Prompt = value;
                entity.Verifiable = ConvertCXFValue2Bool(entityRecord, "Verifiable", false, false);
                entity.Preset = ConvertCXFValue2Bool(entityRecord, "Preset", false, false);
            }
            if (entity.IsMTextAttributeDefinition)
            {
                if (ReadPropertyValue(entityRecord, "MTextWidth", true, out value))
                    entity.MTextWidth = ConvertCXFValue2Double(value);

                if (ReadPropertyValue(entityRecord, "MTextContents", true, out value))
                    entity.MTextContents = value;

            }
            entity.Color = ParseCXFColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            if (ReadPropertyValue(entityRecord, "TextStyleId", false, out value))
                entity.TextStyleId = value;

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            return entity;
        }

    }
}
