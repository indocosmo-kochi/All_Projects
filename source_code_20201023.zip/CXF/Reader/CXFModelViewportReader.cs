﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFModelViewportReader : CXFEntityReader
    {
        //public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        //{
        //    CwcViewport cwcViewport = new CwcViewport();

        //    string value;
        //    if (ReadPropertyValue(entityRecord, "Id", true, out value))
        //        cwcViewport.Id = value;

        //    CwcPoint3D point3d;
        //    if (ParseCXFPoint3d(entityRecord, "CenterPoint", true, out point3d))
        //        cwcViewport.CenterPoint = point3d;

        //    cwcViewport.Color = ParseCXFColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

        //    cwcViewport.GridEnabled = ConvertCXFValue2Bool(entityRecord, "GridEnabled", false, true);

           
        //    if (ReadPropertyValue(entityRecord, "Height", false, out value))
        //        cwcViewport.Height = ConvertCXFValue2Double(value);

        //    if (ReadPropertyValue(entityRecord, "Width", false, out value))
        //        cwcViewport.Width = ConvertCXFValue2Double(value);

        //    if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
        //        cwcViewport.LayerId = value;

        //    if (ReadPropertyValue(entityRecord, "LinetypeId", false, out value))
        //        cwcViewport.LinetypeId = value;

        //    if (ReadPropertyValue(entityRecord, "LinetypeScale", false, out value))
        //        cwcViewport.LinetypeScale = ConvertCXFValue2Double(value);

        //    if (ReadPropertyValue(entityRecord, "PlotStyleName", false, out value))
        //        cwcViewport.PlotStyleName = value;

        //    if (ReadPropertyValue(entityRecord, "Transparency", false, out value))
        //        cwcViewport.Transparency = value;

        //    cwcViewport.On = ConvertCXFValue2Bool(entityRecord, "On", false, true);
        //    cwcViewport.DisplayLocked = ConvertCXFValue2Bool(entityRecord, "DisplayLocked", false, true);
        //    cwcViewport.BackClipOn = ConvertCXFValue2Bool(entityRecord, "BackClipOn", false, false);
        //    cwcViewport.FrontClipOn = ConvertCXFValue2Bool(entityRecord, "FrontClipOn", false, false);

        //    if (ReadPropertyValue(entityRecord, "AnnotationScale", false, out value))
        //        cwcViewport.AnnotationScale = ConvertCXFValue2Double(value);

        //    if (ReadPropertyValue(entityRecord, "StandardScale", false, out value))
        //        cwcViewport.StandardScale = ConvertCXFValue2Integer(value);

        //    if (ReadPropertyValue(entityRecord, "CustomScale", false, out value))
        //        cwcViewport.CustomScale = ConvertCXFValue2Double(value);

        //    if (ReadPropertyValue(entityRecord, "CustomScale", false, out value))
        //        cwcViewport.CustomScale = ConvertCXFValue2Double(value);

        //    cwcViewport.UcsPerViewport = ConvertCXFValue2Bool(entityRecord, "UcsPerViewport", false, false);

        //    if (ReadPropertyValue(entityRecord, "VisualStyleId", false, out value))
        //        cwcViewport.VisualStyleId = value;

        //    if (ReadPropertyValue(entityRecord, "ShadePlot", false, out value))
        //        cwcViewport.ShadePlot = ConvertCXFValue2Integer(value);


        //    return cwcViewport;
            
        //}

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcModelViewport cwcViewport = new CwcModelViewport();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                cwcViewport.Id = value;

            if (ReadPropertyValue(entityRecord, "Name", true, out value))
                cwcViewport.Name = value;

            if (ReadPropertyValue(entityRecord, "CircleSides", false, out value))
                cwcViewport.CircleSides = ConvertCXFValue2Short(value);

            cwcViewport.IconAtOrigin = ConvertCXFValue2Bool(entityRecord, "IconAtOrigin", false, false);
            cwcViewport.GridEnabled = ConvertCXFValue2Bool(entityRecord, "GridEnabled", false, true);

            CwcPoint2D point2d;
            if (ParseCXFPoint2d(entityRecord, "CenterPoint", true, out point2d))
                cwcViewport.CenterPoint = point2d;

            if (ReadPropertyValue(entityRecord, "Height", false, out value))
                cwcViewport.Height = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Width", false, out value))
                cwcViewport.Width = ConvertCXFValue2Double(value);

            return cwcViewport;

        }

    }
}
