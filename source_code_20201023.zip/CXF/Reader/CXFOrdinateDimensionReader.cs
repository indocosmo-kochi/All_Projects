﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFOrdinateDimensionReader : CXFEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcOrdinateDimension entity = new CwcOrdinateDimension();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", false, out value))
                entity.Id = value;

            entity.Visible = ConvertCXFValue2Bool(entityRecord, "Visible", false, true);

            entity.UsingXAxis = ConvertCXFValue2Bool(entityRecord, "UsingXAxis", true, false);

            CwcPoint3D point3d;
            if (ParseCXFPoint3d(entityRecord, "DefiningPoint", true, out point3d))
                entity.DefiningPoint = point3d;

            if (ParseCXFPoint3d(entityRecord, "LeaderEndPoint", true, out point3d))
                entity.LeaderEndPoint = point3d;

            if (ReadPropertyValue(entityRecord, "DimStyleId", false, out value))
                entity.DimStyleId = value;

            //if (ReadPropertyValue(entityRecord, "DimensionStyleName", false, out value))
            //    entity.DimensionStyleName = value;

            entity.Color = ParseCXFColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            if (ReadPropertyValue(entityRecord, "TextStyleId", true, out value))
                entity.TextStyleId = value;

            if (ParseCXFPoint3d(entityRecord, "TextPosition", true, out point3d))
                entity.TextPosition = point3d;

            if (ReadPropertyValue(entityRecord, "TextRotation", false, out value))
                entity.TextRotation = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            if (ReadPropertyValue(entityRecord, "Linetype", false, out value))
                entity.Linetype = value;

            if (ReadPropertyValue(entityRecord, "LinetypeScale", false, out value))
                entity.LinetypeScale = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                entity.LineWeight = ConvertCXFLineWeightToDwg(value);

            return entity;
        }

    }
}
