﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFArcReader : CXFEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcArc entity = new CwcArc();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            entity.Visible = ConvertCXFValue2Bool(entityRecord, "Visible", false, true);

            CwcPoint3D point3d;
            if (ParseCXFPoint3d(entityRecord, "Center", true, out point3d))
                entity.Center = point3d;

            if (ReadPropertyValue(entityRecord, "Radius", false, out value))
                entity.Radius = ConvertCXFValue2Double(value);

            if (ParseCXFPoint3d(entityRecord, "StartPoint", true, out point3d))
                entity.StartPoint = point3d;

            if (ParseCXFPoint3d(entityRecord, "EndPoint", true, out point3d))
                entity.EndPoint = point3d;

            if (ReadPropertyValue(entityRecord, "StartAngle", false, out value))
                entity.StartAngle = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "EndAngle", false, out value))
                entity.EndAngle = ConvertCXFValue2Double(value);

            CwcVector3D normal;
            if (ParseCXFVector3d(entityRecord, "Normal", true, out normal))
                entity.Normal = normal;

            entity.Color = ParseCXFColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            if (ReadPropertyValue(entityRecord, "Linetype", false, out value))
                entity.Linetype = value;

            if (ReadPropertyValue(entityRecord, "LinetypeScale", false, out value))
                entity.LinetypeScale = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                entity.LineWeight = ConvertCXFLineWeightToDwg(value);

            return entity;
        }

    }
}
