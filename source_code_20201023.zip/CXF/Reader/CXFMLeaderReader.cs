﻿using System.Collections.Generic;
using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.CXF.Reader
{
    public class CXFMLeaderReader : CXFEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcPoint3D point3d;
            CwcScale3D scale3d;
            string value;
            int leaderCount = 0;

            if (ReadPropertyValue(entityRecord, "LeaderCount", true, out value))
                leaderCount = ConvertCXFValue2Integer(value);
            CwcMLeader entity = new CwcMLeader(leaderCount);

            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            entity.Visible = ConvertCXFValue2Bool(entityRecord, "Visible", false, true);

            if (ReadPropertyValue(entityRecord, "AnnotationName", false, out value))
                entity.AnnotationName = value;
            //arrow header points
            for (int i=0; i< entity.LeaderCount; i++)
            {
                if (ParseCXFPoint3d(entityRecord, string.Format("HeaderPoint({0})", i), true, out point3d))
                    entity.HeaderPoints[i] = point3d;
            }
            //arrow tail points
            if (ParseCXFPoint3d(entityRecord, "NockPoint", true, out point3d))
                entity.NockPoint = point3d;

            //leader properties
            if (ReadPropertyValue(entityRecord, "ArrowSize", true, out value))
                entity.ArrowSize = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "ArrowSymbol", true, out value))
                entity.ArrowSymbol = value;

            if (ReadPropertyValue(entityRecord, "LeaderLineType", true, out value))
                entity.LeaderLineType = ConvertCXFValue2Integer(value);

            entity.LeaderLineColor = ParseCXFColor(entityRecord, "LeaderLineColor", "LeaderLineColorMethod", "LeaderLineColorIndex");

            if (ReadPropertyValue(entityRecord, "LeaderLineTypeId", true, out value))
                entity.LeaderLineTypeId = value;

            if (ReadPropertyValue(entityRecord, "LeaderLineWeight", true, out value))
                entity.LeaderLineWeight = ConvertCXFValue2Integer(value);
             
            entity.EnableLanding = ConvertCXFValue2Bool(entityRecord, "EnableLanding", false, false);
            
            if (ReadPropertyValue(entityRecord, "LandingGap", true, out value))
                entity.LandingGap = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Annotative", true, out value))
                entity.Annotative = ConvertCXFValue2Integer(value);


            if (ReadPropertyValue(entityRecord, "Scale", true, out value))
                entity.Scale = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "ContentType", true, out value))
                entity.ContentType = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "LandingDistance", true, out value))
                entity.LandingDistance = ConvertCXFValue2Double(value);

            if (ParseCXFPoint3d(entityRecord, "ContentLocation", true, out point3d))
                entity.ContentLocation = point3d;

            if (ReadPropertyValue(entityRecord, "MLeaderStyleId", true, out value))
                entity.MLeaderStyleId = value;

            if ((ContentType)entity.ContentType == ContentType.MTextContent)
            {
                if (ReadPropertyValue(entityRecord, "Contents", false, out value))
                    entity.Contents = value;

                if (ReadPropertyValue(entityRecord, "TextHeight", true, out value))
                    entity.TextHeight = ConvertCXFValue2Double(value);

                if (ReadPropertyValue(entityRecord, "DefaultContents", false, out value))
                    entity.DefaultContents = value;

                entity.TextRightJustify = ConvertCXFValue2Bool(entityRecord, "TextRightJustify", false, true);

                if (ReadPropertyValue(entityRecord, "TextLength", false, out value))
                    entity.TextLength = ConvertCXFValue2Double(value);

                if (ReadPropertyValue(entityRecord, "TextStyleId", true, out value))
                    entity.TextStyleId = value;

                if (ReadPropertyValue(entityRecord, "TextAngleType", false, out value))
                    entity.TextAngleType = ConvertCXFValue2Integer(value);

                entity.TextColor = ParseCXFColor(entityRecord, "TextColor", "TextColorMethod", "TextColorIndex");

                if (ReadPropertyValue(entityRecord, "TextHeight", true, out value))
                    entity.TextHeight = ConvertCXFValue2Double(value);

                entity.EnableFrameText = ConvertCXFValue2Bool(entityRecord, "EnableFrameText", false, false);

                if (ReadPropertyValue(entityRecord, "TextAttachmentDirection", true, out value))
                    entity.TextAttachmentDirection = ConvertCXFValue2Integer(value);

                if (ReadPropertyValue(entityRecord, "TextAttachmentType", true, out value))
                    entity.TextAttachmentType = ConvertCXFValue2Integer(value);

                if (ReadPropertyValue(entityRecord, "TextJustification", true, out value))
                    entity.TextJustification = ConvertCXFValue2Integer(value);
            }

            if ((ContentType)entity.ContentType == ContentType.BlockContent)
            {
                if (ReadPropertyValue(entityRecord, "SourceBlockId", false, out value))
                    entity.SourceBlockId = value;

                if (ReadPropertyValue(entityRecord, "LeaderStyleBlockId", false, out value))
                    entity.LeaderStyleBlockId = value;

                if (ReadPropertyValue(entityRecord, "BlockConnectionType", false, out value))
                    entity.BlockConnectionType = ConvertCXFValue2Integer(value);

                if (ParseCXFScale3d(entityRecord, "BlockScale", false, out scale3d))
                    entity.BlockScale = scale3d;

                if (ReadPropertyValue(entityRecord, "BlockAttributesCount", true, out value))
                    entity.BlockAttributesCount = ConvertCXFValue2Integer(value);


                entity.BlockAttributes = new List<KeyValuePair<string, string>>();
                for (int i = 0; i < entity.BlockAttributesCount; i++)
                {
                    if (ReadPropertyValue(entityRecord, string.Format("BlockAttributes({0})", i), false, out value))
                    {
                        var pair = value.Split(',');
                        if (pair.Length == 2)
                            entity.BlockAttributes.Add(new KeyValuePair<string, string>(pair[0].Trim(), pair[1].Trim()));
                    }
                }
            }

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            if (ReadPropertyValue(entityRecord, "TextAlignmentType", false, out value))
                entity.TextAlignmentType = ConvertCXFTextAlignmentTypeToDwg(value);

            return entity;
        }
    }
}
