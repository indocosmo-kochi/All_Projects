﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFLayoutBlockReader : CXFEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcLayoutBlock entity = new CwcLayoutBlock();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            if (ReadPropertyValue(entityRecord, "Name", true, out value))
                entity.Name = value;

            if (ReadPropertyValue(entityRecord, "LayoutName", true, out value))
                entity.LayoutName = value;

            return entity;
        }

    }
}
