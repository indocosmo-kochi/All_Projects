﻿using System.Collections.Generic;
using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.CXF.Reader
{
    public class CXFMLeaderStyleReader : CXFEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            string value;
            CwcScale3D scale;

            CwcMLeaderStyle entity = new CwcMLeaderStyle();

            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            if (ReadPropertyValue(entityRecord, "Name", true, out value))
                entity.Name = value;


            //leader properties
            if (ReadPropertyValue(entityRecord, "ArrowSize", true, out value))
                entity.ArrowSize = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "ArrowSymbol", true, out value))
                entity.ArrowSymbol = value;

            if (ReadPropertyValue(entityRecord, "LandingDistance", true, out value))
                entity.LandingDistance = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LeaderLineType", true, out value))
                entity.LeaderLineType = ConvertCXFValue2Integer(value);

            entity.LeaderLineColor = ParseCXFColor(entityRecord, "LeaderLineColor", "LeaderLineColorMethod", "LeaderLineColorIndex");

            if (ReadPropertyValue(entityRecord, "LeaderLineTypeId", true, out value))
                entity.LeaderLineTypeId = value;

            if (ReadPropertyValue(entityRecord, "LeaderLineWeight", true, out value))
                entity.LeaderLineWeight = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "BreakSize", true, out value))
                entity.BreakSize = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "MaxLeaderSegmentsPoints", true, out value))
                entity.MaxLeaderSegmentsPoints = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "FirstSegmentAngleConstraint", true, out value))
                entity.FirstSegmentAngleConstraint = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "SecondSegmentAngleConstraint", true, out value))
                entity.SecondSegmentAngleConstraint = ConvertCXFValue2Integer(value);

            entity.EnableLanding = ConvertCXFValue2Bool(entityRecord, "EnableLanding", false, false);

            if (ReadPropertyValue(entityRecord, "LandingGap", true, out value))
                entity.LandingGap = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Annotative", true, out value))
                entity.Annotative = ConvertCXFValue2Integer(value);

            entity.EnableBlockScale = ConvertCXFValue2Bool(entityRecord, "EnableBlockScale", false, false);

            if (ReadPropertyValue(entityRecord, "Scale", true, out value))
                entity.Scale = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "ContentType", true, out value))
                entity.ContentType = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "TextHeight", true, out value))
                entity.TextHeight = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "DefaultContents", false, out value))
                entity.DefaultContents = value;

            if (ReadPropertyValue(entityRecord, "TextStyleId", true, out value))
                entity.TextStyleId = value;

            if (ReadPropertyValue(entityRecord, "TextAngleType", false, out value))
                entity.TextAngleType = ConvertCXFValue2Integer(value);

            entity.TextColor = ParseCXFColor(entityRecord, "TextColor", "TextColorMethod", "TextColorIndex");

            if (ReadPropertyValue(entityRecord, "TextHeight", true, out value))
                entity.TextHeight = ConvertCXFValue2Double(value);

            entity.EnableFrameText = ConvertCXFValue2Bool(entityRecord, "EnableFrameText", false, false);

            if (ReadPropertyValue(entityRecord, "TextAttachmentDirection", true, out value))
                entity.TextAttachmentDirection = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "TextAttachmentType", true, out value))
                entity.TextAttachmentType = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "LeaderStyleBlockId", false, out value))
                entity.LeaderStyleBlockId = value;

            if (ReadPropertyValue(entityRecord, "BlockConnectionType", false, out value))
                entity.BlockConnectionType = ConvertCXFValue2Integer(value);

            if (ParseCXFScale3d(entityRecord, "BlockScale", false, out scale))
                entity.BlockScale = scale;

            //if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
            //    entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            return entity;
        }

    }
}
