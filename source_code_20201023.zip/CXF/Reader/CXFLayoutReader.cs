﻿using System;
using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFLayoutReader : CXFEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            string value;
            int viewportCount = 0;

            if (ReadPropertyValue(entityRecord, "ViewportCount", true, out value))
                viewportCount = ConvertCXFValue2Integer(value);

            CwcLayout cwcLayout = new CwcLayout(viewportCount);

            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                cwcLayout.Id = value;

            if (ReadPropertyValue(entityRecord, "LayoutName", true, out value))
                cwcLayout.LayoutName = value;

            if (ReadPropertyValue(entityRecord, "PlotSettingsName", false, out value))
                cwcLayout.PlotSettingsName = value;

            if (ReadPropertyValue(entityRecord, "TabOrder", true, out value))
                cwcLayout.TabOrder = ConvertCXFValue2Integer(value);

            cwcLayout.ModelType = ConvertCXFValue2Bool(entityRecord, "ModelType", false, false);

            return cwcLayout;
        }

    }
}
