﻿using System.Collections.Generic;
using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.CXF.Reader
{
    public class CXFLeaderReader : CXFEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {            
            int numberOfVertices = 0;
            string value;
            if (ReadPropertyValue(entityRecord, "NumVertices", true, out value))
                numberOfVertices = ConvertCXFValue2Integer(value);
            
            CwcLeader entity = new CwcLeader(numberOfVertices);

            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            entity.Visible = ConvertCXFValue2Bool(entityRecord, "Visible", false, true);

            CwcPoint3D point3d;
            for (int i = 0; i < numberOfVertices; i++)
            {
                if (ParseCXFPoint3d(entityRecord, string.Format("Vertex({0})", i), true, out point3d))
                    entity.Vertices[i] = point3d;
            }
            entity.HasArrowHead = ConvertCXFValue2Bool(entityRecord, "HasArrowHead", true, false);
            entity.IsSplined = ConvertCXFValue2Bool(entityRecord, "IsSplined", true, false);   
                     
            if (ReadPropertyValue(entityRecord, "TextStyleId", false, out value))
                entity.TextStyleId = value;

            entity.Dimclrd = ParseCXFColor(entityRecord, "Dimclrd", "Dimclrd_ColorMethod", "Dimclrd_ColorIndex");

            if (ReadPropertyValue(entityRecord, "Dimasz", true, out value))
                entity.Dimasz = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimgap", true, out value))
                entity.Dimgap = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimscale", true, out value))
                entity.Dimscale = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtxt", true, out value))
                entity.Dimtxt = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtad", true, out value))
                entity.Dimtad = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimblks", false, out value))
                entity.Dimblks = value;

            if (ReadPropertyValue(entityRecord, "AnnoType", true, out value))
                entity.AnnoType = ConvertCXFAnnotationTypeToDwg(value);

            if (ReadPropertyValue(entityRecord, "Dimlwd", false, out value))
                entity.Dimlwd = ConvertCXFLineWeightToDwg(value);

            if (ReadPropertyValue(entityRecord, "Dimldrblk", false, out value))
                entity.Dimldrblk = value;

            if (ReadPropertyValue(entityRecord, "DimensionStyle", true, out value))
                entity.DimensionStyle = value;

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            if (ReadPropertyValue(entityRecord, "Linetype", false, out value))
                entity.Linetype = value;

            if (ReadPropertyValue(entityRecord, "LinetypeScale", false, out value))
                entity.LinetypeScale = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                entity.LineWeight = ConvertCXFLineWeightToDwg(value);

            if (entity.AnnoType == AnnotationType.MText)
            {
                if (ReadPropertyValue(entityRecord, "Annotation", false, out value))
                    entity.Annotation = value;
            }

            return entity;
        }

    }
}
