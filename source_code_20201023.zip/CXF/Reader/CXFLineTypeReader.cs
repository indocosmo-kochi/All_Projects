﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFLineTypeReader : CXFEntityReader
    {
        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {

            string value;
            int numDashes = 0;
            if (ReadPropertyValue(entityRecord, "NumDashes", true, out value))
                numDashes = ConvertCXFValue2Integer(value);
            CwcLineType entity = new CwcLineType(numDashes);

            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            if (ReadPropertyValue(entityRecord, "Name", true, out value))
                entity.Name = value;

            if (ReadPropertyValue(entityRecord, "Comments", true, out value))
                entity.Comments = value;

            
            if (ReadPropertyValue(entityRecord, "PatternLength", true, out value))
                entity.PatternLength = ConvertCXFValue2Double(value);

            entity.IsScaledToFit = ConvertCXFValue2Bool(entityRecord, "IsScaledToFit", true, false);

            for (int i = 0; i < numDashes; i++)
            {
                CwcLTDetails ltDetails = new CwcLTDetails();

                if (ReadPropertyValue(entityRecord, string.Format("DashLengthAt({0})", i), true, out value))
                    ltDetails.DashLengthAt = ConvertCXFValue2Double(value);



                if (ReadPropertyValue(entityRecord, string.Format("ShapeNumberAt({0})", i), true, out value))
                    ltDetails.ShapeNumberAt = ConvertCXFValue2Integer(value);

                if (ltDetails.ShapeNumberAt != 0)
                {

                    if (ReadPropertyValue(entityRecord, string.Format("ShapeStyleAt({0})", i), false, out value))
                        ltDetails.ShapeStyleAt = value;

                    ltDetails.IsShapeFileExists = ConvertCXFValue2Bool(entityRecord, string.Format("IsShapeFileExists({0})", i), true, false);
                    if (ltDetails.IsShapeFileExists)
                    {
                        if (ReadPropertyValue(entityRecord, string.Format("ShapeStyleFileName({0})", i), false, out value))
                            ltDetails.ShapeStyleFileName = value;
                    }
                    if (ReadPropertyValue(entityRecord, string.Format("ShapeScaleAt({0})", i), false, out value))
                        ltDetails.ShapeScaleAt = ConvertCXFValue2Double(value);

                    if (ReadPropertyValue(entityRecord, string.Format("ShapeRotationAt({0})", i), false, out value))
                        ltDetails.ShapeRotationAt = ConvertCXFValue2Double(value);

                    CwcVector2D vector2d;
                    if (ParseCXFVector2d(entityRecord, string.Format("ShapeOffsetAt({0})", i), false, out vector2d))
                        ltDetails.ShapeOffsetAt = vector2d;
                }

                entity.LTDetails[i] = ltDetails;


            }

            return entity;

        }
    }
}
