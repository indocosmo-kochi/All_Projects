﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFRotatedDimensionReader : CXFEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcRotatedDimension entity = new CwcRotatedDimension();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            entity.Visible = ConvertCXFValue2Bool(entityRecord, "Visible", false, true);

            ReadDimensionValues(entity, entityRecord);

            CwcPoint3D point3d;
            if (ParseCXFPoint3d(entityRecord, "XLine1Point", true, out point3d))
                entity.XLine1Point = point3d;

            if (ParseCXFPoint3d(entityRecord, "XLine2Point", true, out point3d))
                entity.XLine2Point = point3d;

            if (ParseCXFPoint3d(entityRecord, "DimLinePoint", true, out point3d))
                entity.DimLinePoint = point3d;

            if (ReadPropertyValue(entityRecord, "Rotation", false, out value))
                entity.Rotation = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "DimStyleId", false, out value))
                entity.DimStyleId = value;

            entity.Color = ParseCXFColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            if (ReadPropertyValue(entityRecord, "TextStyleId", true, out value))
                entity.TextStyleId = value;

            if (ParseCXFPoint3d(entityRecord, "TextPosition", true, out point3d))
                entity.TextPosition = point3d;

            if (ReadPropertyValue(entityRecord, "TextRotation", false, out value))
                entity.TextRotation = ConvertCXFValue2Double(value);
            
            if (ReadPropertyValue(entityRecord, "DimBlockId", false, out value))
                entity.DimBlockId = value;
            
            if (ReadPropertyValue(entityRecord, "DimensionText", false, out value))
                entity.DimensionText = value;

            entity.DynamicDimension = ConvertCXFValue2Bool(entityRecord, "DynamicDimension", false, false);

            if (ReadPropertyValue(entityRecord, "Elevation", false, out value))
                entity.Elevation = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "HorizontalRotation", false, out value))
                entity.HorizontalRotation = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "AlternatePrefix", false, out value))
                entity.AlternatePrefix = value;

            if (ReadPropertyValue(entityRecord, "AlternateSuffix", false, out value))
                entity.AlternateSuffix = value;

            if (ReadPropertyValue(entityRecord, "Prefix", false, out value))
                entity.Prefix = value;

            if (ReadPropertyValue(entityRecord, "Suffix", false, out value))
                entity.Suffix = value;

            entity.AltSuppressLeadingZeros = ConvertCXFValue2Bool(entityRecord, "AltSuppressLeadingZeros", false, false);
            entity.AltSuppressTrailingZeros = ConvertCXFValue2Bool(entityRecord, "AltSuppressTrailingZeros", false, false);
            entity.AltSuppressZeroFeet = ConvertCXFValue2Bool(entityRecord, "AltSuppressZeroFeet", false, false);
            entity.AltSuppressZeroInches = ConvertCXFValue2Bool(entityRecord, "AltSuppressZeroInches", false, false);
            entity.AltToleranceSuppressLeadingZeros = ConvertCXFValue2Bool(entityRecord, "AltToleranceSuppressLeadingZeros", false, false);
            entity.AltToleranceSuppressTrailingZeros = ConvertCXFValue2Bool(entityRecord, "AltToleranceSuppressTrailingZeros", false, false);
            entity.AltToleranceSuppressZeroFeet = ConvertCXFValue2Bool(entityRecord, "AltToleranceSuppressZeroFeet", false, false);
            entity.AltToleranceSuppressZeroInches = ConvertCXFValue2Bool(entityRecord, "AltToleranceSuppressZeroInches", false, false);

            entity.SuppressAngularLeadingZeros = ConvertCXFValue2Bool(entityRecord, "SuppressAngularLeadingZeros", false, false);
            entity.SuppressAngularTrailingZeros = ConvertCXFValue2Bool(entityRecord, "SuppressAngularTrailingZeros", false, false);
            entity.SuppressLeadingZeros = ConvertCXFValue2Bool(entityRecord, "SuppressLeadingZeros", false, false);
            entity.SuppressTrailingZeros = ConvertCXFValue2Bool(entityRecord, "SuppressTrailingZeros", false, false);
            entity.SuppressZeroFeet = ConvertCXFValue2Bool(entityRecord, "SuppressZeroFeet", false, false);
            entity.SuppressZeroInches = ConvertCXFValue2Bool(entityRecord, "SuppressZeroInches", false, false);

            entity.ToleranceSuppressLeadingZeros = ConvertCXFValue2Bool(entityRecord, "ToleranceSuppressLeadingZeros", false, false);
            entity.ToleranceSuppressTrailingZeros = ConvertCXFValue2Bool(entityRecord, "ToleranceSuppressTrailingZeros", false, false);
            entity.ToleranceSuppressZeroFeet = ConvertCXFValue2Bool(entityRecord, "ToleranceSuppressZeroFeet", false, false);
            entity.ToleranceSuppressZeroInches = ConvertCXFValue2Bool(entityRecord, "ToleranceSuppressZeroInches", false, false);
            entity.UsingDefaultTextPosition = ConvertCXFValue2Bool(entityRecord, "UsingDefaultTextPosition", false, false);

            if (ReadPropertyValue(entityRecord, "TextLineSpacingFactor", false, out value))
                entity.TextLineSpacingFactor = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "TextAttachment", true, out value))
                entity.TextAttachment = ConvertCXFTextJustifyToDwg(value);

            if (ReadPropertyValue(entityRecord, "TextLineSpacingStyle", false, out value))
                entity.TextLineSpacingStyle = ConvertCXFMTextLineSpacingStyleToDwg(value);

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            if (ReadPropertyValue(entityRecord, "Linetype", false, out value))
                entity.Linetype = value;

            if (ReadPropertyValue(entityRecord, "LinetypeScale", false, out value))
                entity.LinetypeScale = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                entity.LineWeight = ConvertCXFLineWeightToDwg(value);

            return entity;
        }

    }
}
