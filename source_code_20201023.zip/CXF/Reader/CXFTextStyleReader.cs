﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFTextStyleReader : CXFEntityReader
    {
        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcTextStyle cwcTextStyle = new CwcTextStyle();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                cwcTextStyle.Id = value;

            if (ReadPropertyValue(entityRecord, "Name", true, out value))
                cwcTextStyle.Name = value;

            if (ReadPropertyValue(entityRecord, "FontName", false, out value))
                cwcTextStyle.FontName = value;

            string customErrMsg = "ERROR: Missing Font '" + cwcTextStyle.FontName + "' Empty  'FileName' for Entity [TEXTSTYLE], CXF->DWG processing Aborted!!!.";
            if (ReadPropertyValue(entityRecord, "FileName", false, out value, customErrMsg))
                cwcTextStyle.FileName = value;

            if (ReadPropertyValue(entityRecord, "TextSize", false, out value))
                cwcTextStyle.TextSize = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "ObliquingAngle", false, out value))
                cwcTextStyle.ObliquingAngle = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "FlagBits", false, out value))
                cwcTextStyle.FlagBits = ConvertCXFValue2Byte(value);

            cwcTextStyle.IsVertical = ConvertCXFValue2Bool(entityRecord, "IsVertical", false, false);

            cwcTextStyle.IsItallic = ConvertCXFValue2Bool(entityRecord, "IsItallic", false, false);

            cwcTextStyle.IsBold = ConvertCXFValue2Bool(entityRecord, "IsBold", false, false);

            if (ReadPropertyValue(entityRecord, "Characters", false, out value))
                cwcTextStyle.Characters = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "PitchAndFamily", false, out value))
                cwcTextStyle.PitchAndFamily = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Annotative", false, out value))
                cwcTextStyle.Annotative = ConvertCXFAnnotativeStatesToDwg(value);

            if (ReadPropertyValue(entityRecord, "BigFontFileName", false, out value))
                cwcTextStyle.BigFontFileName = value;

            if (ReadPropertyValue(entityRecord, "PriorSize", false, out value))
                cwcTextStyle.PriorSize = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "XScale", false, out value))
                cwcTextStyle.XScale = ConvertCXFValue2Double(value);

            return cwcTextStyle;

        }
    }
}
