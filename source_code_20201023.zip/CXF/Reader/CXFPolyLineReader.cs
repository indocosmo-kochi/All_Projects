﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFPolyLineReader : CXFEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            string value;
            int numberOfVertices = 0;
            if (ReadPropertyValue(entityRecord, "NumberOfVertices", true, out value))
                numberOfVertices = ConvertCXFValue2Integer(value);

            CwcPolyline entity = new CwcPolyline(numberOfVertices);

            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            entity.Visible = ConvertCXFValue2Bool(entityRecord, "Visible", false, true);

            CwcPoint3D point3d;
            for (int i = 0; i < numberOfVertices; i++)
            {
                if (ParseCXFPoint3d(entityRecord, string.Format("Vertex({0})", i), true, out point3d))
                    entity.Vertices[i] = point3d;
                if (ReadPropertyValue(entityRecord, string.Format("Bulge({0})", i), true, out value))
                    entity.Bulge[i] = ConvertCXFValue2Double(value);
                if (ReadPropertyValue(entityRecord, string.Format("StartWidth({0})", i), true, out value))
                    entity.StartWidth[i] = ConvertCXFValue2Double(value);
                if (ReadPropertyValue(entityRecord, string.Format("EndWidth({0})", i), true, out value))
                    entity.EndWidth[i] = ConvertCXFValue2Double(value);
            }

            entity.IsClosed = ConvertCXFValue2Bool(entityRecord, "IsClosed", true, true);

            entity.Color = ParseCXFColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            if (ReadPropertyValue(entityRecord, "Linetype", false, out value))
                entity.Linetype = value;

            if (ReadPropertyValue(entityRecord, "LinetypeScale", false, out value))
                entity.LinetypeScale = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                entity.LineWeight = ConvertCXFLineWeightToDwg(value);

            return entity;
        }

    }
}

