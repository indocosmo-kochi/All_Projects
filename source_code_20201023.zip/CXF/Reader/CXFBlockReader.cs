﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFBlockReader : CXFEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcBlock entity = new CwcBlock();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            if (ReadPropertyValue(entityRecord, "Name", true, out value))
                entity.Name = value;

            return entity;
        }

    }
}
