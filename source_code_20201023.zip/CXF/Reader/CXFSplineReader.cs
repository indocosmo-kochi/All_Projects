﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFSplineReader : CXFEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            string value;

            bool hasFitData = ConvertCXFValue2Bool(entityRecord, "HasFitData", true, true);

            int numberOfFitPoints = 0;
            int numberOfControlPoints = 0;
            int numberOfKnots = 0;
            int numberOfWeights = 0;
            CwcSpline entity;
            CwcPoint3D point3d;

            if (hasFitData)
            {

                bool fitTangentsExist = ConvertCXFValue2Bool(entityRecord, "FitTangentsExist", true, true);

                if (ReadPropertyValue(entityRecord, "NumFitPoints", true, out value))
                    numberOfFitPoints = ConvertCXFValue2Integer(value);

                entity = new CwcSpline(hasFitData, numberOfFitPoints);

                entity.FitTangentsExist = fitTangentsExist;

                for (int i = 0; i < numberOfFitPoints; i++)
                {
                    if (ParseCXFPoint3d(entityRecord, string.Format("FitPoints({0})", i), true, out point3d))
                        entity.FitPoints[i] = point3d;
                }

                CwcVector3D vector3d;

                if (fitTangentsExist)
                {
                    if (ParseCXFVector3d(entityRecord, "StartFitTangent", true, out vector3d))
                        entity.StartFitTangent = vector3d;

                    if (ParseCXFVector3d(entityRecord, "EndFitTangent", true, out vector3d))
                        entity.EndFitTangent = vector3d;
                }

                if (ReadPropertyValue(entityRecord, "FitTolerance", false, out value))
                    entity.FitTolerance = ConvertCXFValue2Double(value);

                if (ReadPropertyValue(entityRecord, "Order", false, out value))
                    entity.Order = ConvertCXFValue2Integer(value);

            }
            else
            {
                if (ReadPropertyValue(entityRecord, "NumControlPoints", true, out value))
                    numberOfControlPoints = ConvertCXFValue2Integer(value);

                if (ReadPropertyValue(entityRecord, "NumKnots", true, out value))
                    numberOfKnots = ConvertCXFValue2Integer(value);

                if (ReadPropertyValue(entityRecord, "NumWeights", true, out value))
                    numberOfWeights = ConvertCXFValue2Integer(value);

                entity = new CwcSpline(hasFitData, numberOfControlPoints, numberOfKnots, numberOfWeights);

                for (int cp = 0; cp < numberOfControlPoints; cp++)
                {
                    if (ParseCXFPoint3d(entityRecord, string.Format("ControlPoints({0})", cp), true, out point3d))
                        entity.ControlPoints[cp] = point3d;
                }

                for (int knt = 0; knt < numberOfKnots; knt++)
                {
                    if (ReadPropertyValue(entityRecord, string.Format("Knots({0})", knt), true, out value))
                        entity.NurbsData.Knots[knt] = ConvertCXFValue2Double(value);
                }

                for (int wt = 0; wt < numberOfWeights; wt++)
                {
                    if (ReadPropertyValue(entityRecord, string.Format("Weights({0})", wt), true, out value))
                        entity.NurbsData.Weights[wt] = ConvertCXFValue2Double(value);
                }

                entity.NurbsData.Closed = ConvertCXFValue2Bool(entityRecord, "Closed", false, false);

                if (ReadPropertyValue(entityRecord, "Degree", false, out value))
                    entity.NurbsData.Degree = ConvertCXFValue2Integer(value);

                if (ReadPropertyValue(entityRecord, "ControlPointTolerance", false, out value))
                    entity.NurbsData.ControlPointTolerance = ConvertCXFValue2Double(value);

                if (ReadPropertyValue(entityRecord, "KnotTolerance", false, out value))
                    entity.NurbsData.KnotTolerance = ConvertCXFValue2Double(value);

                entity.NurbsData.Periodic = ConvertCXFValue2Bool(entityRecord, "Periodic", false, false);
                entity.NurbsData.Rational = ConvertCXFValue2Bool(entityRecord, "Rational", false, false);

            }

            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            entity.Visible = ConvertCXFValue2Bool(entityRecord, "Visible", false, true);

            entity.Color = ParseCXFColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            if (ReadPropertyValue(entityRecord, "Linetype", false, out value))
                entity.Linetype = value;

            if (ReadPropertyValue(entityRecord, "LinetypeScale", false, out value))
                entity.LinetypeScale = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                entity.LineWeight = ConvertCXFLineWeightToDwg(value);

            return entity;
        }

    }
}
