﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFViewportReader : CXFEntityReader
    {
        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            string value;
            CwcPoint3D point3D;
            CwcPoint2D point2D;
            CwcVector2D vector2D;
            CwcVector3D vector3D;

            CwcViewport viewport = new CwcViewport();

            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                viewport.Id = value;

            viewport.Visible = ConvertCXFValue2Bool(entityRecord, "Visible", false, true);

            if (ReadPropertyValue(entityRecord, "AnnotationName", true, out value))
                viewport.AnnotationName = value;

            viewport.BackClipOn = ConvertCXFValue2Bool(entityRecord, "BackClipOn", false, true);

            if (ParseCXFPoint3d(entityRecord, "CenterPoint", true, out point3D))
                viewport.CenterPoint = point3D;

            if (ParseCXFPoint3d(entityRecord, "ViewTarget", true, out point3D))
                viewport.ViewTarget = point3D;

            viewport.Color = ParseCXFColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            if (ReadPropertyValue(entityRecord, "CustomScale", true, out value))
                viewport.CustomScale = ConvertCXFValue2Double(value);

            viewport.DisplayLocked = ConvertCXFValue2Bool(entityRecord, "DisplayLocked", false, true);

            viewport.FrontClipOn = ConvertCXFValue2Bool(entityRecord, "FrontClipOn", false, true);

            viewport.GridEnabled = ConvertCXFValue2Bool(entityRecord, "GridEnabled", false, true);

            if (ParseCXFVector2d(entityRecord, "GridIncrement", true, out vector2D))
                viewport.GridIncrement = vector2D;

            if (ReadPropertyValue(entityRecord, "Height", true, out value))
                viewport.Height = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Width", true, out value))
                viewport.Width = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "TwistAngle", true, out value))
                viewport.TwistAngle = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "ViewHeight", true, out value))
                viewport.ViewHeight = ConvertCXFValue2Double(value);

            if (ParseCXFPoint2d(entityRecord, "ViewCenter", true, out point2D))
                viewport.ViewCenter = point2D;

            if (ParseCXFVector3d(entityRecord, "ViewDirection", true, out vector3D))
                viewport.ViewDirection = vector3D;

            if (ReadPropertyValue(entityRecord, "LayerId", true, out value))
                viewport.LayerId = value;

            if (ReadPropertyValue(entityRecord, "LinetypeId", true, out value))
                viewport.LinetypeId = value;

            if (ReadPropertyValue(entityRecord, "LinetypeScale", true, out value))
                viewport.LinetypeScale = ConvertCXFValue2Double(value);

            viewport.On = ConvertCXFValue2Bool(entityRecord, "On", false, true);

            if (ReadPropertyValue(entityRecord, "PlotStyleName", true, out value))
                viewport.PlotStyleName = value;

            if (ReadPropertyValue(entityRecord, "ShadePlot", true, out value))
                viewport.ShadePlot = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "StandardScale", true, out value))
                viewport.StandardScale = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Transparency", true, out value))
                viewport.Transparency = value;

            viewport.UcsIconAtOrigin = ConvertCXFValue2Bool(entityRecord, "UcsIconAtOrigin", false, true);
            viewport.UcsPerViewport = ConvertCXFValue2Bool(entityRecord, "UcsPerViewport", false, true);

            if (ReadPropertyValue(entityRecord, "VisualStyleId", true, out value))
                viewport.VisualStyleId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", true, out value))
                viewport.BlockId = value;

            if (ReadPropertyValue(entityRecord, "BlockName", true, out value))
                viewport.BlockName = value;


            return viewport;

        }

    }
}
