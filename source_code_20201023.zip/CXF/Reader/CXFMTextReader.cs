﻿using System;
using System.Collections.Generic;
using Teigha.DatabaseServices;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFMTextReader : CXFEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {

            string value;
            int colCount = 0;
            ColumnType colType = ColumnType.NoColumns;
            if (ReadPropertyValue(entityRecord, "ColumnCount", false, out value))
                colCount = ConvertCXFValue2Integer(value);

            bool colAutoHeight = ConvertCXFValue2Bool(entityRecord, "ColumnAutoHeight", true, false);

            if (ReadPropertyValue(entityRecord, "ColumnType", true, out value))
                colType = ConvertCXFMTextColumnTypeToDwg(value);

            CwcMText entity = new CwcMText(colType, colAutoHeight, colCount);

            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            entity.Visible = ConvertCXFValue2Bool(entityRecord, "Visible", false, true);

            if (ReadPropertyValue(entityRecord, "TextString", false, out value))
                entity.TextString = value;

            CwcPoint3D point3d;
            if (ParseCXFPoint3d(entityRecord, "Location", true, out point3d))
                entity.Location = point3d;

            if (ReadPropertyValue(entityRecord, "Height", false, out value))
                entity.Height = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Width", false, out value))
                entity.Width = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "TextHeight", false, out value))
                entity.TextHeight = ConvertCXFValue2Double(value);

            CwcVector3D vector3d;
            if (ParseCXFVector3d(entityRecord, "Normal", true, out vector3d))
                entity.Normal = vector3d;

            if (ReadPropertyValue(entityRecord, "Attachment", false, out value))
                entity.Attachment = ConvertCXFMTextAttachmentToDwg(value);

            if (ParseCXFVector3d(entityRecord, "Direction", true, out vector3d))
                entity.Direction = vector3d;

            if (ReadPropertyValue(entityRecord, "FlowDirection", false, out value))
                entity.FlowDirection = ConvertCXFMTextFlowDirectionToDwg(value);

            if (ReadPropertyValue(entityRecord, "BackgroundScaleFactor", false, out value))
                entity.BackgroundScaleFactor = ConvertCXFValue2Double(value);

            entity.ColumnFlowReversed = ConvertCXFValue2Bool(entityRecord, "ColumnFlowReversed", false, false);

            if (entity.ColumnType != ColumnType.NoColumns)
            {
                if (ReadPropertyValue(entityRecord, "ColumnGutterWidth", false, out value))
                    entity.ColumnGutterWidth = ConvertCXFValue2Double(value);

                if (ReadPropertyValue(entityRecord, "ColumnWidth", false, out value))
                    entity.ColumnWidth = ConvertCXFValue2Double(value);
            }

            if ((!entity.ColumnAutoHeight) && (entity.ColumnType == ColumnType.DynamicColumns))
            {
                for (int col = 0; col < entity.ColumnCount; col++)
                {
                    if (ReadPropertyValue(entityRecord, String.Format("ColumnHeight[{0}]", col), false, out value))
                        entity.ColumnWidth = ConvertCXFValue2Double(value);
                }
            }


            if (ReadPropertyValue(entityRecord, "LineSpaceDistance", false, out value))
                entity.LineSpaceDistance = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineSpacingFactor", false, out value))
                entity.LineSpacingFactor = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineSpacingStyle", false, out value))
                entity.LineSpacingStyle = ConvertCXFMTextLineSpacingStyleToDwg(value);

            if (ReadPropertyValue(entityRecord, "Rotation", false, out value))
                entity.Rotation = ConvertCXFValue2Double(value);


            //if (ReadPropertyValue(entityRecord, "Font", false, out value))
            //    entity.Font = value;

            entity.BackgroundFill = ConvertCXFValue2Bool(entityRecord, "BackgroundFill", true, false);
            entity.UseBackgroundColor = ConvertCXFValue2Bool(entityRecord, "UseBackgroundColor", false, false);

            if (entity.BackgroundFill)
                entity.BackgroundFillColor = ParseCXFColor(entityRecord, "BackgroundFillColor", "BackgroundFillColorMethod", "BackgroundFillColorIndex");


            if (ReadPropertyValue(entityRecord, "TextStyleId", false, out value))
                entity.TextStyleId = value;

            entity.Color = ParseCXFColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            return entity;
        }

    }
}
