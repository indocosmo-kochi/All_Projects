﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFPlotSettingsReader : CXFEntityReader
    {
        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            string value;
            CwcPoint2D point2D;

            CwcPlotSettings plotSetting = new CwcPlotSettings();

            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                plotSetting.Id = value;

            if (ReadPropertyValue(entityRecord, "Name", true, out value))
                plotSetting.Name = value;

            if (ReadPropertyValue(entityRecord, "LayoutName", false, out value))
                plotSetting.LayoutName = value;

            plotSetting.ModelType = ConvertCXFValue2Bool(entityRecord, "ModelType", false, true);

            if (ReadPropertyValue(entityRecord, "CurrentStyleSheet", true, out value))
                plotSetting.CurrentStyleSheet = value;

            if (ReadPropertyValue(entityRecord, "CustomPrintScaleDenominator", true, out value))
                plotSetting.CustomPrintScaleDenominator = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "CustomPrintScaleNumerator", true, out value))
                plotSetting.CustomPrintScaleNumerator = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "CustomScale", false, out value))
                plotSetting.CustomScale = value;

            plotSetting.FitToPaper = ConvertCXFValue2Bool(entityRecord, "FitToPaper", false, true);

            plotSetting.PlotAsRaster = ConvertCXFValue2Bool(entityRecord, "PlotAsRaster", false, false);

            if (ReadPropertyValue(entityRecord, "MediaName", true, out value))
                plotSetting.MediaName = value;

            if (ParseCXFPoint2d(entityRecord, "PaperSize", true, out point2D))
                plotSetting.PaperSize = point2D;

            plotSetting.PlotCentered = ConvertCXFValue2Bool(entityRecord, "PlotCentered", false, true);
            plotSetting.PlotHidden = ConvertCXFValue2Bool(entityRecord, "PlotHidden", false, false);

            if (ParseCXFPoint2d(entityRecord, "PlotOrigin", true, out point2D))
                plotSetting.PlotOrigin = point2D;

            if (ParseCXFPoint2d(entityRecord, "PlotPaperMarginsMaxPoint", true, out point2D))
                plotSetting.PlotPaperMarginsMaxPoint = point2D;

            if (ParseCXFPoint2d(entityRecord, "PlotPaperMarginsMinPoint", true, out point2D))
                plotSetting.PlotPaperMarginsMinPoint = point2D;

            if (ReadPropertyValue(entityRecord, "PlotPaperUnits", true, out value))
                plotSetting.PlotPaperUnits = ConvertCXFValue2Integer(value);

            plotSetting.PlotPlotStyles = ConvertCXFValue2Bool(entityRecord, "PlotPlotStyles", false, true);

            if (ReadPropertyValue(entityRecord, "PlotRotation", true, out value))
                plotSetting.PlotRotation = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "PlotterName", true, out value))
                plotSetting.PlotterName = value;

            plotSetting.PlotTransparency = ConvertCXFValue2Bool(entityRecord, "PlotTransparency", false, false);

            if (ReadPropertyValue(entityRecord, "PlotType", true, out value))
                plotSetting.PlotType = ConvertCXFValue2Integer(value);

            plotSetting.PlotViewportBorders = ConvertCXFValue2Bool(entityRecord, "PlotViewportBorders", false, false);
            plotSetting.PrintLineweights = ConvertCXFValue2Bool(entityRecord, "PrintLineweights", false, false);
            plotSetting.PlotWireframe = ConvertCXFValue2Bool(entityRecord, "PlotWireframe", false, false);
            plotSetting.ShowPlotStyles = ConvertCXFValue2Bool(entityRecord, "ShowPlotStyles", false, false);
            plotSetting.ScaleLineweights = ConvertCXFValue2Bool(entityRecord, "ScaleLineweights", false, false);
            plotSetting.PlotPaperspaceLast = ConvertCXFValue2Bool(entityRecord, "PlotPaperspaceLast", false, false);

            if (ReadPropertyValue(entityRecord, "StdScaleType", true, out value))
                plotSetting.StdScaleType = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "StdScale", true, out value))
                plotSetting.StdScale = ConvertCXFValue2Double(value);

            plotSetting.UseStandardScale = ConvertCXFValue2Bool(entityRecord, "UseStandardScale", false, false);

            return plotSetting;

        }

    }
}
