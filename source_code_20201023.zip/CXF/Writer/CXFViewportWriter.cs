﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{
    public class CXFViewportWriter : CXFEntityWriter
    {
        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcViewport);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                   .AppendLine(String.Format("Id={0}", entity.Id))
                   .AppendLine(String.Format("Visible={0}", entity.Visible.ToString(1)))
                   .AppendLine(String.Format("AnnotationName={0}", entity.AnnotationName))
                   .AppendLine(String.Format("BackClipOn={0}", entity.BackClipOn))
                   .AppendLine(String.Format("CenterPoint={0}", entity.CenterPoint.ToString()))
                   .AppendLine(String.Format("Color={0}", entity.Color.ToString()))
                   .AppendLine(String.Format("CustomScale={0}", entity.CustomScale))
                   .AppendLine(String.Format("DisplayLocked={0}", entity.DisplayLocked.ToString(1)))
                   .AppendLine(String.Format("FrontClipOn={0}", entity.FrontClipOn.ToString(1)))
                   .AppendLine(String.Format("GridEnabled={0}", entity.GridEnabled.ToString(1)))
                   .AppendLine(String.Format("GridIncrement={0}", entity.GridIncrement.ToString()))
                   .AppendLine(String.Format("ViewCenter={0}", entity.ViewCenter.ToString()))
                   .AppendLine(String.Format("ViewTarget={0}", entity.ViewTarget.ToString()))
                   .AppendLine(String.Format("ViewDirection={0}", entity.ViewDirection.ToString()))
                   .AppendLine(String.Format("ViewHeight={0}", entity.ViewHeight))
                   .AppendLine(String.Format("Height={0}", entity.Height))
                   .AppendLine(String.Format("Width={0}", entity.Width))
                   .AppendLine(String.Format("TwistAngle={0}", entity.TwistAngle))
                   .AppendLine(String.Format("LayerId={0}", entity.LayerId))
                   .AppendLine(String.Format("LinetypeId={0}", entity.LinetypeId))
                   .AppendLine(String.Format("LinetypeScale={0}", entity.LinetypeScale))
                   .AppendLine(String.Format("On={0}", entity.On.ToString(1)))
                   .AppendLine(String.Format("PlotStyleName={0}", entity.PlotStyleName))
                   .AppendLine(String.Format("ShadePlot={0}", entity.ShadePlot))
                   .AppendLine(String.Format("StandardScale={0}", entity.StandardScale))
                   .AppendLine(String.Format("Transparency={0}", entity.Transparency))
                   .AppendLine(String.Format("UcsIconAtOrigin={0}", entity.UcsIconAtOrigin.ToString(1)))
                   .AppendLine(String.Format("UcsPerViewport={0}", entity.UcsPerViewport.ToString(1)))
                   .AppendLine(String.Format("VisualStyleId={0}", entity.VisualStyleId))
                   .AppendLine(String.Format("BlockId={0}", entity.BlockId))
                   .AppendLine(String.Format("BlockName={0}", entity.BlockName));

            return strBuilder.ToString();
        }
    }
}
