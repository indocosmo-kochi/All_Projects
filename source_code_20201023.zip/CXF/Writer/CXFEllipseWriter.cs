﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{
    public class CXFEllipseWriter : CXFEntityWriter
    {
        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcEllipse);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("Visible={0}", entity.Visible.ToString(1)))
                    .AppendLine(String.Format("Center={0}", entity.Center.ToString()))

                    .AppendLine(String.Format("UnitNormal={0}", entity.UnitNormal.ToString()))

                    .AppendLine(String.Format("MajorAxis={0}", entity.MajorAxis.ToString()))
                    .AppendLine(String.Format("RadiusRatio={0}", entity.RadiusRatio.ToString()))

                    .AppendLine(String.Format("Color={0}", entity.Color.ToString()))
                    .AppendLine(String.Format("ColorMethod={0}", entity.Color.ColorMethod.ToString("D")))
                    .AppendLine(String.Format("ColorIndex={0}", entity.Color.ColorIndex.ToString()))
                    .AppendLine(String.Format("StartAngle={0}", entity.StartAngle.ToString()))
                    .AppendLine(String.Format("EndAngle={0}", entity.EndAngle.ToString()))
                    .AppendLine(String.Format("Linetype={0}", entity.Linetype))
                    .AppendLine(String.Format("LinetypeScale={0}", entity.LinetypeScale))
                    .AppendLine(String.Format("LayerId={0}", entity.LayerId))
                    .AppendLine(String.Format("LineWeight={0} ", entity.LineWeight.ToString("D")))
                    ;
            if (entity.BlockName.Trim().ToUpper() != CONST.MODEL_SPACE)
                strBuilder.AppendLine(String.Format("BlockId={0}", entity.BlockId));
            return strBuilder.ToString();
        }
    }
}
