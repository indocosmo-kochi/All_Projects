﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{
    public class CXFAttributeDefinitionWriter : CXFEntityWriter
    {
        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcAttributeDefinition);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("Tag={0}", entity.Tag));
            if (!entity.Constant)
            {
                strBuilder.AppendLine(String.Format("Prompt={0}", entity.Prompt))
                            .AppendLine(String.Format("Verifiable={0}", entity.Verifiable.ToString(1)))
                            .AppendLine(String.Format("Preset={0}", entity.Preset.ToString(1)))
                    ;
            }
            if (entity.IsMTextAttributeDefinition)
            {
                strBuilder.AppendLine(String.Format("MTextWidth={0}", entity.MTextWidth.ToString()));
                strBuilder.AppendLine(String.Format("MTextContents={0}",entity.MTextContents));
            }

            strBuilder.AppendLine(String.Format("TextString={0}", entity.TextString))
                .AppendLine(String.Format("Position={0}", entity.Position.ToString()))
                .AppendLine(String.Format("AlignmentPoint={0}", entity.AlignmentPoint.ToString()))
                .AppendLine(String.Format("Oblique={0}", entity.Oblique.ToString()))
                .AppendLine(String.Format("Rotation={0}", entity.Rotation.ToString()))
                .AppendLine(String.Format("WidthFactor={0}", entity.WidthFactor.ToString()))
                .AppendLine(String.Format("Height={0}", entity.Height.ToString()))
                .AppendLine(String.Format("Justify={0}", entity.Justify.ToString("D")))
                .AppendLine(String.Format("Constant={0}", entity.Constant.ToString(1)))
                .AppendLine(String.Format("Invisible={0}", entity.Invisible.ToString(1)))
                .AppendLine(String.Format("IsMTextAttributeDefinition={0}", entity.IsMTextAttributeDefinition.ToString(1)))
                .AppendLine(String.Format("LockPositionInBlock={0}", entity.LockPositionInBlock.ToString(1)))
                .AppendLine(String.Format("Annotative={0}", entity.Annotative.ToString("D")))
                .AppendLine(String.Format("IsMirroredInX={0}", entity.IsMirroredInX.ToString(1)))
                .AppendLine(String.Format("IsMirroredInY={0}", entity.IsMirroredInY.ToString(1)))
                .AppendLine(String.Format("FieldLength={0}", entity.FieldLength.ToString()))
                .AppendLine(String.Format("Color={0}", entity.Color.ToString()))
                .AppendLine(String.Format("ColorMethod={0}", entity.Color.ColorMethod.ToString("D")))
                .AppendLine(String.Format("ColorIndex={0}", entity.Color.ColorIndex.ToString()))
                .AppendLine(String.Format("TextStyleId={0}", entity.TextStyleId))
                .AppendLine(String.Format("LayerId={0}", entity.LayerId))
                ;
            if (entity.BlockName.Trim().ToUpper() != CONST.MODEL_SPACE)
                strBuilder.AppendLine(String.Format("BlockId={0}", entity.BlockId));

            return strBuilder.ToString();
        }
    }
}
