﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{
    public class CXFOrdinateDimensionWriter : CXFEntityWriter
    {
        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcOrdinateDimension);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("Visible={0}", entity.Visible.ToString(1)))
                    .AppendLine(String.Format("DefiningPoint={0}", entity.DefiningPoint.ToString()))
                    .AppendLine(String.Format("LeaderEndPoint={0}", entity.LeaderEndPoint.ToString()))
                    .AppendLine(String.Format("Origin={0}", entity.Origin.ToString()))

                    .AppendLine(String.Format("UsingXAxis={0}", entity.UsingXAxis.ToString()))
                    //.AppendLine(String.Format("DimensionStyleName={0} ", entity.DimensionStyleName))
                    .AppendLine(String.Format("DimStyleId={0} ", entity.DimStyleId.ToString()))

                    .AppendLine(String.Format("Color={0}", entity.Color.ToString()))
                    .AppendLine(String.Format("ColorMethod={0}", entity.Color.ColorMethod.ToString("D")))
                    .AppendLine(String.Format("ColorIndex={0}", entity.Color.ColorIndex.ToString()))
                    .AppendLine(String.Format("TextStyleId={0}", entity.TextStyleId))
                    .AppendLine(String.Format("TextPosition={0}", entity.TextPosition.ToString()))
                    .AppendLine(String.Format("TextRotation={0}", entity.TextRotation.ToString()))
                    .AppendLine(String.Format("Linetype={0}", entity.Linetype))
                    .AppendLine(String.Format("LinetypeScale={0}", entity.LinetypeScale))

                    .AppendLine(String.Format("LineWeight={0} ", entity.LineWeight.ToString("D")))
                    .AppendLine(String.Format("LayerId={0}", entity.LayerId))
                    ;
            if (entity.BlockName.Trim().ToUpper() != CONST.MODEL_SPACE)
                strBuilder.AppendLine(String.Format("BlockId={0}", entity.BlockId));
            return strBuilder.ToString();
        }
    }
}
