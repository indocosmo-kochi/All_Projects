﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{
    public class CXFLineWriter : CXFEntityWriter
    {
  
        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcLine);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("Visible={0}", entity.Visible.ToString(1)))
                    .AppendLine(String.Format("StartPoint={0}", entity.StartPoint.ToString()))
                    .AppendLine(String.Format("EndPoint={0}", entity.EndPoint.ToString()))
                    .AppendLine(String.Format("Color={0}", entity.Color.ToString()))
                    .AppendLine(String.Format("ColorMethod={0}", entity.Color.ColorMethod.ToString("D")))
                    .AppendLine(String.Format("ColorIndex={0}", entity.Color.ColorIndex.ToString()))
                    .AppendLine(String.Format("Linetype={0}", entity.Linetype))
                    .AppendLine(String.Format("LinetypeScale={0}", entity.LinetypeScale))
                    .AppendLine(String.Format("LineWeight={0}", entity.LineWeight.ToString("D")))

                    .AppendLine(String.Format("LayerId={0}", entity.LayerId))
                    ;
            if (entity.BlockName.Trim().ToUpper() != CONST.MODEL_SPACE)
                strBuilder.AppendLine(String.Format("BlockId={0}", entity.BlockId));

            return strBuilder.ToString();
        }

    }
}
