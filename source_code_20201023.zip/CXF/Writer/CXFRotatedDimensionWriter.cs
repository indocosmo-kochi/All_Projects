﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{
    public class CXFRotatedDimensionWriter : CXFEntityWriter
    {
        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcRotatedDimension);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("Visible={0}", entity.Visible.ToString(1)))
                    .AppendLine(String.Format("Rotation={0}", entity.Rotation.ToString()))
                    .AppendLine(String.Format("XLine1Point={0} ", entity.XLine1Point.ToString()))
                    .AppendLine(String.Format("XLine2Point={0} ", entity.XLine2Point.ToString()))
                    .AppendLine(String.Format("DimLinePoint={0} ", entity.DimLinePoint.ToString()))
                    .Append(WriteDimensionValues(entity))
                    .AppendLine(String.Format("DimStyleId={0} ", entity.DimStyleId.ToString()))                    
                    .AppendLine(String.Format("Color={0}", entity.Color.ToString()))
                    .AppendLine(String.Format("ColorMethod={0}", entity.Color.ColorMethod.ToString("D")))
                    .AppendLine(String.Format("ColorIndex={0}", entity.Color.ColorIndex.ToString()))
                    .AppendLine(String.Format("TextStyleId={0}", entity.TextStyleId))
                    .AppendLine(String.Format("TextPosition={0}", entity.TextPosition.ToString()))
                    .AppendLine(String.Format("TextRotation={0}", entity.TextRotation.ToString()))

                    .AppendLine(String.Format("DimBlockId={0}", entity.DimBlockId))
                    .AppendLine(String.Format("DimensionText={0}", entity.DimensionText))
                    .AppendLine(String.Format("DynamicDimension={0}", entity.DynamicDimension))
                    .AppendLine(String.Format("Elevation={0}", entity.Elevation.ToString()))
                    .AppendLine(String.Format("HorizontalRotation={0}", entity.HorizontalRotation.ToString()))
                    .AppendLine(String.Format("AlternatePrefix={0}", entity.AlternatePrefix))
                    .AppendLine(String.Format("AlternateSuffix={0}", entity.AlternateSuffix))
                    .AppendLine(String.Format("AltSuppressLeadingZeros={0}", entity.AltSuppressLeadingZeros.ToString(1)))
                    .AppendLine(String.Format("AltSuppressTrailingZeros={0}", entity.AltSuppressTrailingZeros.ToString(1)))
                    .AppendLine(String.Format("AltSuppressZeroFeet={0}", entity.AltSuppressZeroFeet.ToString(1)))
                    .AppendLine(String.Format("AltSuppressZeroInches={0}", entity.AltSuppressZeroInches.ToString(1)))
                    .AppendLine(String.Format("AltToleranceSuppressLeadingZeros={0}", entity.AltToleranceSuppressLeadingZeros.ToString(1)))
                    .AppendLine(String.Format("AltToleranceSuppressTrailingZeros={0}", entity.AltToleranceSuppressTrailingZeros.ToString(1)))
                    .AppendLine(String.Format("AltToleranceSuppressZeroFeet={0}", entity.AltToleranceSuppressZeroFeet.ToString(1)))
                    .AppendLine(String.Format("AltToleranceSuppressZeroInches={0}", entity.AltToleranceSuppressZeroInches.ToString(1)))
                    .AppendLine(String.Format("Prefix={0}", entity.Prefix))
                    .AppendLine(String.Format("Suffix={0}", entity.Suffix))
                    .AppendLine(String.Format("SuppressAngularLeadingZeros={0}", entity.SuppressAngularLeadingZeros.ToString(1)))
                    .AppendLine(String.Format("SuppressAngularTrailingZeros={0}", entity.SuppressAngularTrailingZeros.ToString(1)))
                    .AppendLine(String.Format("SuppressLeadingZeros={0}", entity.SuppressLeadingZeros.ToString(1)))
                    .AppendLine(String.Format("SuppressTrailingZeros={0}", entity.SuppressTrailingZeros.ToString(1)))
                    .AppendLine(String.Format("SuppressZeroFeet={0}", entity.SuppressZeroFeet.ToString(1)))
                    .AppendLine(String.Format("SuppressZeroInches={0}", entity.SuppressZeroInches.ToString(1)))
                    .AppendLine(String.Format("TextAttachment={0}", entity.TextAttachment.ToString("D")))
                    .AppendLine(String.Format("TextLineSpacingFactor={0}", entity.TextLineSpacingFactor.ToString()))
                    .AppendLine(String.Format("TextLineSpacingStyle={0}", entity.TextLineSpacingStyle.ToString("D")))
                    .AppendLine(String.Format("ToleranceSuppressLeadingZeros={0}", entity.ToleranceSuppressLeadingZeros.ToString(1)))
                    .AppendLine(String.Format("ToleranceSuppressTrailingZeros={0}", entity.ToleranceSuppressTrailingZeros.ToString(1)))
                    .AppendLine(String.Format("ToleranceSuppressZeroFeet={0}", entity.ToleranceSuppressZeroFeet.ToString(1)))
                    .AppendLine(String.Format("ToleranceSuppressZeroInches={0}", entity.ToleranceSuppressZeroInches.ToString(1)))
                    .AppendLine(String.Format("UsingDefaultTextPosition={0}", entity.UsingDefaultTextPosition.ToString(1)))
                    .AppendLine(String.Format("Linetype={0} ", entity.Linetype))
                    .AppendLine(String.Format("LinetypeScale={0}", entity.LinetypeScale))
                    .AppendLine(String.Format("LayerId={0}", entity.LayerId))
                    .AppendLine(String.Format("LineWeight={0} ", entity.LineWeight.ToString("D")))
                    ;
            if (entity.BlockName.Trim().ToUpper() != CONST.MODEL_SPACE)
                strBuilder.AppendLine(String.Format("BlockId={0}", entity.BlockId));
            return strBuilder.ToString();
        }
    }
}
