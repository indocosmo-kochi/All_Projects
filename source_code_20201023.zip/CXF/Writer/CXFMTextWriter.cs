﻿using System;
using System.Text;
using Teigha.DatabaseServices;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{

    public class CXFMTextWriter : CXFEntityWriter
    {
        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcMText);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("Visible={0}", entity.Visible.ToString(1)))
                    .AppendLine(String.Format("TextString={0}", entity.TextString))
                    .AppendLine(String.Format("Location={0}", entity.Location.ToString()))
                    .AppendLine(String.Format("Height={0}", entity.Height.ToString()))
                    .AppendLine(String.Format("Width={0}", entity.Width.ToString()))
                    .AppendLine(String.Format("TextHeight={0}", entity.TextHeight.ToString()))
                    .AppendLine(String.Format("Color={0}", entity.Color.ToString()))
                    .AppendLine(String.Format("ColorMethod={0}", entity.Color.ColorMethod.ToString("D")))
                    .AppendLine(String.Format("ColorIndex={0}", entity.Color.ColorIndex.ToString()))
                    .AppendLine(String.Format("TextStyleId={0}", entity.TextStyleId))

                    .AppendLine(String.Format("ColumnType={0}", entity.ColumnType.ToString("D")))
                    .AppendLine(String.Format("ColumnAutoHeight={0}", entity.ColumnAutoHeight.ToString(1)))
                    .AppendLine(String.Format("ColumnCount={0}", entity.ColumnCount.ToString()))

                    .AppendLine(String.Format("Attachment={0}", entity.Attachment.ToString("D")))
                    .AppendLine(String.Format("BackgroundFill={0}", entity.BackgroundFill.ToString(1)))
                   
                    .AppendLine(String.Format("BackgroundScaleFactor={0}", entity.BackgroundScaleFactor.ToString()))
                    .AppendLine(String.Format("Direction={0}", entity.Direction.ToString()))
                    .AppendLine(String.Format("FlowDirection={0}", entity.FlowDirection.ToString("D")))
                    .AppendLine(String.Format("LineSpaceDistance={0}", entity.LineSpaceDistance.ToString()))

                    .AppendLine(String.Format("LineSpacingFactor={0}", entity.LineSpacingFactor.ToString()))
                    .AppendLine(String.Format("LineSpacingStyle={0}", entity.LineSpacingStyle.ToString("D")))
                    .AppendLine(String.Format("Normal={0}", entity.Normal.ToString()))
                    .AppendLine(String.Format("Rotation={0}", entity.Rotation.ToString()))
                    .AppendLine(String.Format("UseBackgroundColor={0}", entity.UseBackgroundColor.ToString(1)))
                    .AppendLine(String.Format("LayerId={0}", entity.LayerId))
                    ;
            if (entity.BackgroundFill)
            {
                strBuilder.AppendLine(String.Format("BackgroundFillColor={0}", entity.BackgroundFillColor.ToString()))
                    .AppendLine(String.Format("BackgroundFillColorMethod={0}", entity.BackgroundFillColor.ColorMethod.ToString("D")))
                    .AppendLine(String.Format("BackgroundFillColorIndex={0}", entity.BackgroundFillColor.ColorIndex.ToString()));
            }

            if ( (entity.ColumnType == ColumnType.StaticColumns) || 
                 (entity.ColumnType == ColumnType.DynamicColumns) )
            {
                strBuilder
                    .AppendLine(String.Format("ColumnFlowReversed={0}", entity.ColumnFlowReversed.ToString(1)))
                    .AppendLine(String.Format("ColumnGutterWidth={0}", entity.ColumnGutterWidth.ToString()))
                    .AppendLine(String.Format("ColumnWidth={0}", entity.ColumnWidth.ToString()));

                if ((!entity.ColumnAutoHeight) && (entity.ColumnType == ColumnType.DynamicColumns))
                {
                    for (int col = 0; col < entity.ColumnCount; col++)
                        strBuilder
                            .AppendLine(String.Format("ColumnHeight[{0}]={1}", col, entity.ColumnHeight[col].ToString()));

                }
            }

            if (entity.BlockName.Trim().ToUpper() != CONST.MODEL_SPACE)
                strBuilder.AppendLine(String.Format("BlockId={0}", entity.BlockId));

            return strBuilder.ToString();
        }
    }
}
