﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;
using Teigha.DatabaseServices;
using System.Collections.Generic;

namespace CWorksCXF.CXF.Writer
{
    public class CXFMLeaderStyleWriter : CXFEntityWriter
    {

        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcMLeaderStyle);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("Name={0}", entity.Name))
                     //leader style properties
                     .AppendLine(string.Format("ArrowSize={0}", entity.ArrowSize.ToString()))
                     .AppendLine(string.Format("ArrowSymbol={0}", entity.ArrowSymbol.ToString()))
                     .AppendLine(string.Format("LeaderLineType={0}", entity.LeaderLineType.ToString()))
                     .AppendLine(string.Format("LeaderLineColorMethod={0}", entity.LeaderLineColor.ColorMethod.ToString()))
                     .AppendLine(string.Format("LeaderLineColorIndex={0}", entity.LeaderLineColor.ColorIndex.ToString()))
                     .AppendLine(string.Format("LeaderLineColor={0}", entity.LeaderLineColor.ToString()))
                     .AppendLine(string.Format("LeaderLineTypeId={0}", entity.LeaderLineTypeId))
                     .AppendLine(string.Format("LeaderLineWeight={0}", entity.LeaderLineWeight.ToString()))
                     .AppendLine(string.Format("BreakSize={0}", entity.BreakSize.ToString()))
                     .AppendLine(string.Format("MaxLeaderSegmentsPoints={0}", entity.MaxLeaderSegmentsPoints.ToString()))
                     .AppendLine(string.Format("FirstSegmentAngleConstraint={0}", entity.FirstSegmentAngleConstraint.ToString()))
                     .AppendLine(string.Format("SecondSegmentAngleConstraint={0}", entity.SecondSegmentAngleConstraint.ToString()))
                     .AppendLine(string.Format("EnableLanding={0}", entity.EnableLanding ? "1" : "0"))
                     .AppendLine(string.Format("LandingGap={0}", entity.LandingGap.ToString()))
                     .AppendLine(string.Format("Annotative={0}", entity.Annotative.ToString()))
                     .AppendLine(string.Format("EnableBlockScale={0}", entity.EnableBlockScale ? "1" : "0"))
                     .AppendLine(string.Format("Scale={0}", entity.Scale.ToString()))
                     .AppendLine(string.Format("ContentType={0}", entity.ContentType))
                    .AppendLine(string.Format("LandingDistance={0}", entity.LandingDistance))
                    .AppendLine(string.Format("TextStyleId={0}", entity.TextStyleId))
                    .AppendLine(string.Format("TextAngleType={0}", entity.TextAngleType))
                    .AppendLine(string.Format("TextColorMethod={0}", entity.TextColor.ColorMethod))
                    .AppendLine(string.Format("TextColorIndex={0}", entity.TextColor.ColorIndex))
                    .AppendLine(string.Format("TextColor={0}", entity.TextColor.ToString()))
                    .AppendLine(string.Format("TextHeight={0}", entity.TextHeight))
                    .AppendLine(string.Format("EnableFrameText={0}", entity.EnableFrameText ? "1" : "0"))
                    .AppendLine(string.Format("TextAttachmentDirection={0}", entity.TextAttachmentDirection))
                    .AppendLine(string.Format("TextAttachmentType={0}", entity.TextAttachmentType))
                    .AppendLine(string.Format("BlockConnectionType={0}", entity.BlockConnectionType))
                    .AppendLine(string.Format("LeaderStyleBlockId={0}", entity.LeaderStyleBlockId))
                    .AppendLine(string.Format("BlockScale={0}", entity.BlockScale == null ? string.Empty : entity.BlockScale.ToString()))
                    .AppendLine(String.Format("BlockId={0}", entity.BlockId));

            return strBuilder.ToString();
        }
    }
}
