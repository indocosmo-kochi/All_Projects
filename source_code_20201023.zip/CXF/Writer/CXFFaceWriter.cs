﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{
    public class CXFFaceWriter : CXFEntityWriter
    {

        public override string getEntityDetails(CwcDbObject item)
        {
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine("FACE:")
                    .AppendLine(String.Format("Id={0}", (item as CwcFace).Id))
                    .AppendLine(String.Format("Visible={0}", (item as CwcFace).Visible.ToString(1)))
                    .AppendLine(String.Format("Vertex1.X={0}", (item as CwcFace).Vertex1.X.ToString()))
                    .AppendLine(String.Format("Vertex1.Y={0}", (item as CwcFace).Vertex1.Y.ToString()))
                    .AppendLine(String.Format("Vertex1.Z={0}", (item as CwcFace).Vertex1.Z.ToString()))
                    .AppendLine(String.Format("Vertex2.X={0}", (item as CwcFace).Vertex2.X.ToString()))
                    .AppendLine(String.Format("Vertex2.Y={0}", (item as CwcFace).Vertex2.Y.ToString()))
                    .AppendLine(String.Format("Vertex2.Z={0}", (item as CwcFace).Vertex2.Z.ToString()))
                    .AppendLine(String.Format("Vertex3.X={0}", (item as CwcFace).Vertex3.X.ToString()))
                    .AppendLine(String.Format("Vertex3.Y={0}", (item as CwcFace).Vertex3.Y.ToString()))
                    .AppendLine(String.Format("Vertex3.Z={0}", (item as CwcFace).Vertex3.Z.ToString()))
                    .AppendLine(String.Format("Vertex4.X={0}", (item as CwcFace).Vertex4.X.ToString()))
                    .AppendLine(String.Format("Vertex4.Y={0}", (item as CwcFace).Vertex4.Y.ToString()))
                    .AppendLine(String.Format("Vertex4.Z={0}", (item as CwcFace).Vertex4.Z.ToString()))
                    .AppendLine(String.Format("IsEdgeVisibleAtVertex1={0}", (item as CwcFace).IsEdgeVisibleAtVertex1.ToString()))
                    .AppendLine(String.Format("IsEdgeVisibleAtVertex2={0}", (item as CwcFace).IsEdgeVisibleAtVertex2.ToString()))
                    .AppendLine(String.Format("IsEdgeVisibleAtVertex3={0}", (item as CwcFace).IsEdgeVisibleAtVertex3.ToString()))
                    .AppendLine(String.Format("IsEdgeVisibleAtVertex4={0}", (item as CwcFace).IsEdgeVisibleAtVertex4.ToString()))
                    .AppendLine(String.Format("IsVisble={0}", (item as CwcFace).IsVisible.ToString()))
                    .AppendLine(String.Format("Material={0}", (item as CwcFace).Material))
//                    .AppendLine(String.Format("CXF_Color={0}", (item as CwcFace).Color.ToString()))
                    .AppendLine(String.Format("[ColorMethod={0}]", (item as CwcFace).Color.ColorMethod))
                    .AppendLine(String.Format("Linetype={0}", (item as CwcFace).Linetype))

   //                 .AppendLine(String.Format("LayerName={0}", (item as CwcFace).LayerName))
                    .AppendLine(String.Format("BlockName={0}", (item as CwcFace).BlockName))
                    .AppendLine(String.Format("[LayerId={0}]", (item as CwcFace).LayerId))
                    .AppendLine(String.Format("[BlockId={0}]", (item as CwcFace).BlockId))
                    .AppendLine(String.Format("LineWeight={0}", (item as CwcFace).LineWeight))
                    ;
            return strBuilder.ToString();
        }

    }
}

