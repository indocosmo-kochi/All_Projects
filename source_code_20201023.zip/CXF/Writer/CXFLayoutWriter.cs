﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{
    public class CXFLayoutWriter : CXFEntityWriter
    {
        public override string getEntityDetails(CwcDbObject item)
        {
            CwcLayout entity = item as CwcLayout;

            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                 .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("LayoutName={0}", entity.LayoutName))
                    .AppendLine(String.Format("ModelType={0}", entity.ModelType.ToString(1)))
                    .AppendLine(String.Format("PlotSettingsName={0}", entity.PlotSettingsName))
                    .AppendLine(String.Format("TabOrder={0}", entity.TabOrder))
                    .AppendLine(String.Format("ViewportCount={0}", entity.ViewportCount));

            return strBuilder.ToString();
        }
    }
}
