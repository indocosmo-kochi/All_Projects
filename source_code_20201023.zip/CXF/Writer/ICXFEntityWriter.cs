﻿using CWorksCXF.Entities;
using System.IO;

namespace CWorksCXF.CXF.Writer
{
    public interface ICXFEntityWriter
    {
        void WriteEnityDetails(CwcDbObject item, StreamWriter outfile);
    }
}
