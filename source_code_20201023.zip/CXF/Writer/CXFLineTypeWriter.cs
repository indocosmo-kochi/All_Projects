﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{
    public class CXFLineTypeWriter : CXFEntityWriter
    {
        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcLineType);
            StringBuilder strBuilder = new StringBuilder();

            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("Name={0}", entity.Name))
                    .AppendLine(String.Format("Comments={0}", String.IsNullOrEmpty(entity.Comments) ? entity.Name : entity.Comments))
                    .AppendLine(String.Format("NumDashes={0}", entity.NumDashes.ToString()))
                    .AppendLine(String.Format("PatternLength={0}", entity.PatternLength.ToString()))
                    .AppendLine(String.Format("IsScaledToFit={0}", entity.IsScaledToFit.ToString(1)));                    
            ;
            for (int i = 0; i < entity.NumDashes; i++)
            {

                strBuilder.AppendLine(String.Format("DashLengthAt({0})={1}", i, entity.LTDetails[i].DashLengthAt))
                    .AppendLine(String.Format("ShapeNumberAt({0})={1}", i, entity.LTDetails[i].ShapeNumberAt));
                if (entity.LTDetails[i].ShapeNumberAt != 0)
                {
                    strBuilder.AppendLine(String.Format("ShapeStyleAt({0})={1}", i, entity.LTDetails[i].ShapeStyleAt));
                    strBuilder.AppendLine(String.Format("IsShapeFileExists({0})={1} ", i, entity.LTDetails[i].IsShapeFileExists.ToString(1)));
                    if (entity.LTDetails[i].IsShapeFileExists)
                        strBuilder.AppendLine(String.Format("ShapeStyleFileName({0})={1}", i, entity.LTDetails[i].ShapeStyleFileName));
                    strBuilder.AppendLine(String.Format("ShapeScaleAt({0})={1}", i, entity.LTDetails[i].ShapeScaleAt.ToString()));
                    strBuilder.AppendLine(String.Format("ShapeRotationAt({0})={1}", i, entity.LTDetails[i].ShapeRotationAt.ToString()));

                    strBuilder.AppendLine(String.Format("ShapeOffsetAt({0})={1}", i, entity.LTDetails[i].ShapeOffsetAt.ToString()));

                }

            }
            return strBuilder.ToString();
        }
    }
}
