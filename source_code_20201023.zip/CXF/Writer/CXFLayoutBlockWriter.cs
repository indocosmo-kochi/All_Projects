﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{
    public class CXFLayoutBlockWriter : CXFEntityWriter
    {
        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcLayoutBlock);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id.ToString()))
                    .AppendLine(String.Format("Name={0}", entity.Name))
                    .AppendLine(String.Format("LayoutName={0}", entity.LayoutName));

            return strBuilder.ToString();
        }
    }
}
