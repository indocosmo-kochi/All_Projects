﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{
    public class CXFModelViewportWriter : CXFEntityWriter
    {
        //public override string getEntityDetails(CwcDbObject item)
        //{
        //    var entity = (item as CwcViewport);
        //    StringBuilder strBuilder = new StringBuilder();
        //    strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
        //            .AppendLine(String.Format("Id={0}", entity.Id))
        //            .AppendLine(String.Format("CenterPoint={0}", entity.CenterPoint.ToString()))
        //            .AppendLine(String.Format("Color={0}", entity.Color.ToString()))
        //            .AppendLine(String.Format("ColorMethod={0}", entity.Color.ColorMethod.ToString()))
        //            .AppendLine(String.Format("ColorIndex={0}", entity.Color.ColorIndex.ToString()))
        //            .AppendLine(String.Format("GridEnabled={0}", entity.GridEnabled.ToString(1)))
        //            .AppendLine(String.Format("Height={0}", entity.Height.ToString()))
        //            .AppendLine(String.Format("Width={0}", entity.Width.ToString()))
        //            .AppendLine(String.Format("LayerId={0}", entity.LayerId))
        //            .AppendLine(String.Format("LinetypeId={0}", entity.LinetypeId))
        //            .AppendLine(String.Format("LinetypeScale={0}", entity.LinetypeScale))
        //            .AppendLine(String.Format("PlotStyleName={0}", entity.PlotStyleName))
        //            .AppendLine(String.Format("Transparency={0}", entity.Transparency))
        //            .AppendLine(String.Format("On={0}", entity.On))
        //            .AppendLine(String.Format("DisplayLocked={0}", entity.DisplayLocked))
        //            .AppendLine(String.Format("BackClipOn={0}", entity.BackClipOn))
        //            .AppendLine(String.Format("FrontClipOn={0}", entity.FrontClipOn))
        //            .AppendLine(String.Format("AnnotationScale={0}", entity.AnnotationScale))
        //            .AppendLine(String.Format("StandardScale={0}", entity.StandardScale))
        //            .AppendLine(String.Format("CustomScale={0}", entity.CustomScale))
        //            .AppendLine(String.Format("UcsPerViewport={0}", entity.UcsPerViewport))
        //            .AppendLine(String.Format("VisualStyleId={0}", entity.VisualStyleId))
        //            .AppendLine(String.Format("ShadePlot={0}", entity.ShadePlot))
        //    ;

        //    return strBuilder.ToString();
        //}

        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcModelViewport);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("Name={0}", entity.Name))
                    .AppendLine(String.Format("IconAtOrigin={0}", entity.IconAtOrigin.ToString(1)))
                    .AppendLine(String.Format("CircleSides={0}", entity.CircleSides.ToString()))
                    .AppendLine(String.Format("GridEnabled={0}", entity.GridEnabled.ToString(1)))
                    .AppendLine(String.Format("CenterPoint={0}", entity.CenterPoint.ToString()))
                    .AppendLine(String.Format("Height={0}", entity.Height.ToString()))
                    .AppendLine(String.Format("Width={0}", entity.Width.ToString()))
            ;
            return strBuilder.ToString();
        }
    }
}
