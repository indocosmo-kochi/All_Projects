﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{
    public class CXFPlotSettingsWriter : CXFEntityWriter
    {
        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcPlotSettings);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                   .AppendLine(String.Format("Id={0}", entity.Id))
                   .AppendLine(String.Format("Name={0}", entity.Name))
                   .AppendLine(String.Format("LayoutName={0}", entity.LayoutName))
                   .AppendLine(String.Format("ModelType={0}", entity.ModelType.ToString(1)))
                   .AppendLine(String.Format("CurrentStyleSheet={0}", entity.CurrentStyleSheet))
                   .AppendLine(String.Format("CustomPrintScaleDenominator={0}", entity.CustomPrintScaleDenominator))
                   .AppendLine(String.Format("CustomPrintScaleNumerator={0}", entity.CustomPrintScaleNumerator))
                   .AppendLine(String.Format("CustomScale={0}", entity.CustomScale))
                   .AppendLine(String.Format("FitToPaper={0}", entity.FitToPaper.ToString(1)))
                   .AppendLine(String.Format("MediaName={0}", entity.MediaName))
                   .AppendLine(String.Format("PaperSize={0}", entity.PaperSize.ToString()))
                   .AppendLine(String.Format("PlotAsRaster={0}", entity.PlotAsRaster.ToString(1)))
                   .AppendLine(String.Format("PlotCentered={0}", entity.PlotCentered.ToString(1)))
                   .AppendLine(String.Format("PlotHidden={0}", entity.PlotHidden.ToString(1)))
                   .AppendLine(String.Format("PlotOrigin={0}", entity.PlotOrigin.ToString()))
                   .AppendLine(String.Format("PlotPaperMarginsMaxPoint={0}", entity.PlotPaperMarginsMaxPoint.ToString()))
                   .AppendLine(String.Format("PlotPaperMarginsMinPoint={0}", entity.PlotPaperMarginsMinPoint.ToString()))
                   .AppendLine(String.Format("PlotPaperUnits={0}", entity.PlotPaperUnits))
                   .AppendLine(String.Format("PlotPlotStyles={0}", entity.PlotPlotStyles.ToString(1)))
                   .AppendLine(String.Format("PlotPaperspaceLast={0}", entity.PlotPaperspaceLast.ToString(1)))
                   .AppendLine(String.Format("PlotRotation={0}", entity.PlotRotation))
                   .AppendLine(String.Format("PlotterName={0}", entity.PlotterName))
                   .AppendLine(String.Format("PlotTransparency={0}", entity.PlotTransparency.ToString(1)))
                   .AppendLine(String.Format("PlotType={0}", entity.PlotType))
                   .AppendLine(String.Format("PlotViewportBorders={0}", entity.PlotViewportBorders.ToString(1)))
                   .AppendLine(String.Format("PlotWireframe={0}", entity.PlotWireframe.ToString(1)))
                   .AppendLine(String.Format("PrintLineweights={0}", entity.PrintLineweights.ToString(1)))
                   .AppendLine(String.Format("ShowPlotStyles={0}", entity.ShowPlotStyles.ToString(1)))
                   .AppendLine(String.Format("ScaleLineweights={0}", entity.ScaleLineweights.ToString(1)))
                   .AppendLine(String.Format("StdScale={0}", entity.StdScale))
                   .AppendLine(String.Format("StdScaleType={0}", entity.StdScaleType))
                   .AppendLine(String.Format("UseStandardScale={0}", entity.UseStandardScale.ToString(1)));

            return strBuilder.ToString();
        }
    }
}
