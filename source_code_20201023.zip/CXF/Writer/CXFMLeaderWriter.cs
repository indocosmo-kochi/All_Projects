﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;
using Teigha.DatabaseServices;
using System.Collections.Generic;

namespace CWorksCXF.CXF.Writer
{
    public class CXFMLeaderWriter : CXFEntityWriter
    {

        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcMLeader);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("Visible={0}", entity.Visible.ToString(1)))
                    .AppendLine(String.Format("LayerId={0}", entity.LayerId))
                    .AppendLine(String.Format("LeaderCount={0}", entity.LeaderCount.ToString()))
                    .AppendLine(String.Format("AnnotationName={0}", entity.AnnotationName));
            //add arrow header points
            for (int i = 0; i < entity.LeaderCount; i++)
            {
                strBuilder.AppendLine(String.Format("HeaderPoint({0})={1}", i, entity.HeaderPoints[i].ToString()));
            }
            strBuilder.AppendLine(string.Format("NockPoint={0}", entity.NockPoint.ToString()))
                     .AppendLine(string.Format("ArrowSize={0}", entity.ArrowSize.ToString()))
                     .AppendLine(string.Format("ArrowSymbol={0}", entity.ArrowSymbol.ToString()))
                     .AppendLine(string.Format("LeaderLineType={0}", entity.LeaderLineType.ToString()))
                     .AppendLine(string.Format("LeaderLineColorMethod={0}", entity.LeaderLineColor.ColorMethod.ToString()))
                     .AppendLine(string.Format("LeaderLineColorIndex={0}", entity.LeaderLineColor.ColorIndex.ToString()))
                     .AppendLine(string.Format("LeaderLineColor={0}", entity.LeaderLineColor))
                     .AppendLine(string.Format("LeaderLineTypeId={0}", entity.LeaderLineTypeId))
                     .AppendLine(string.Format("LeaderLineWeight={0}", entity.LeaderLineWeight.ToString()))
                     .AppendLine(string.Format("EnableLanding={0}", entity.EnableLanding ? "1" : "0"))
                     .AppendLine(string.Format("LandingGap={0}", entity.LandingGap.ToString()))
                     .AppendLine(string.Format("Annotative={0}", entity.Annotative.ToString()))
                     .AppendLine(string.Format("Scale={0}", entity.Scale.ToString()))
                     .AppendLine(string.Format("LandingDistance={0}", entity.LandingDistance.ToString()))
                     .AppendLine(string.Format("ContentType={0}", entity.ContentType))
                     .AppendLine(string.Format("ContentLocation={0}", entity.ContentLocation.ToString()))
                     .AppendLine(string.Format("MLeaderStyleId={0}", entity.MLeaderStyleId))
                     .AppendLine(string.Format("TextAlignmentType={0}", entity.TextAlignmentType));

            if ((ContentType)entity.ContentType == ContentType.MTextContent)
            {
                strBuilder.AppendLine(string.Format("TextStyleId={0}", entity.TextStyleId))
                        .AppendLine(string.Format("Contents={0}", entity.Contents))
                        .AppendLine(string.Format("TextRightJustify={0}", entity.TextRightJustify ? "1" : "0"))
                        .AppendLine(string.Format("TextLength={0}", entity.TextLength.ToString()))
                        .AppendLine(string.Format("TextAngleType={0}", entity.TextAngleType))
                        .AppendLine(string.Format("TextColorMethod={0}", entity.TextColor.ColorMethod.ToString()))
                        .AppendLine(string.Format("TextColorIndex={0}", entity.TextColor.ColorIndex.ToString()))
                        .AppendLine(string.Format("TextColor={0}", entity.TextColor.ToString()))
                        .AppendLine(string.Format("TextHeight={0}", entity.TextHeight))
                        .AppendLine(string.Format("EnableFrameText={0}", entity.EnableFrameText ? "1" : "0"))
                        .AppendLine(string.Format("TextAttachmentDirection={0}", entity.TextAttachmentDirection))
                        .AppendLine(string.Format("TextAttachmentType={0}", entity.TextAttachmentType))
                        .AppendLine(string.Format("TextJustification={0}", entity.TextJustification.ToString()));
            }
            if ((ContentType)entity.ContentType == ContentType.BlockContent)
            {
                strBuilder.AppendLine(string.Format("SourceBlockId={0}", entity.SourceBlockId))
                    .AppendLine(string.Format("BlockConnectionType={0}", entity.BlockConnectionType))
                    .AppendLine(string.Format("BlockScale={0}", entity.BlockScale?.ToString()))
                    .AppendLine(string.Format("BlockAttributesCount={0}", entity.BlockAttributes.Count.ToString()));
            }
            int j = 0;
            foreach (var blockRef in entity.BlockAttributes)
            {
                strBuilder.AppendLine(string.Format("BlockAttributes({0})={1},{2}", j++, blockRef.Key, blockRef.Value));
            }

            if (entity.BlockName.Trim().ToUpper() != CONST.MODEL_SPACE)
                strBuilder.AppendLine(String.Format("BlockId={0}", entity.BlockId));
            
            return strBuilder.ToString();
        }
    }
}
