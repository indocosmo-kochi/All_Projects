﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{
    public class CXFPolylineWriter : CXFEntityWriter
    {

        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcPolyline);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("Visible={0}", entity.Visible.ToString(1)))
                    .AppendLine(String.Format("NumberOfVertices={0}", entity.NumberOfVertices))
                    ;

            for (int i = 0; i < entity.NumberOfVertices; i++)
            {
                strBuilder.AppendLine(String.Format("Vertex({0})={1}", i, entity.Vertices[i].ToString()))
                    .AppendLine(String.Format("Bulge({0})={1}", i, entity.Bulge[i].ToString()))
                    .AppendLine(String.Format("StartWidth({0})={1}", i, entity.StartWidth[i].ToString()))
                    .AppendLine(String.Format("EndWidth({0})={1}", i, entity.EndWidth[i].ToString()))
                    ;
            }

             strBuilder
                    .AppendLine(String.Format("IsClosed={0}", entity.IsClosed.ToString(1)))

                    .AppendLine(String.Format("Color={0}", entity.Color.ToString()))
                    .AppendLine(String.Format("ColorMethod={0}", entity.Color.ColorMethod.ToString("D")))
                    .AppendLine(String.Format("ColorIndex={0}", entity.Color.ColorIndex.ToString()))
                    .AppendLine(String.Format("Linetype={0}", entity.Linetype))
                    .AppendLine(String.Format("LinetypeScale={0}", entity.LinetypeScale))
                    .AppendLine(String.Format("LayerId={0}", entity.LayerId))
                    .AppendLine(String.Format("LineWeight={0}", entity.LineWeight.ToString("D")))
                    ;
            if (entity.BlockName.Trim().ToUpper() != CONST.MODEL_SPACE)
                strBuilder.AppendLine(String.Format("BlockId={0}", entity.BlockId));
            return strBuilder.ToString();
        }

    }
}
