﻿using CWorksCXF.Common;
using CWorksCXF.CXF.Reader;
using CWorksCXF.DWG.Writer;
using CWorksCXF.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using Teigha.DatabaseServices;
using Teigha.Runtime;
//using System.Linq;  // used in DictToFile - For Debug


namespace CWorksCXF
{
    class CXFToDwgController
    {

        readonly EntityConcreteFactory factory = new EntityConcreteFactory();
        readonly Dictionary<string, ObjectId> objectIdMapperList = new Dictionary<string, ObjectId>();
        public bool convert_CXF_to_DWG(ProcessParam processParam)
        {
            bool result = false;    
            Services.odActivate(ActivationData.userInfo, ActivationData.userSignature);
            using (Services svcs = new Services())
            {
                Environment.SetEnvironmentVariable("DDPLOTSTYLEPATHS", processParam.PlotStyleConfigPath);
                HostApplicationServices.Current = new HostAppServ();
                SystemObjects.DynamicLinker.LoadApp("PlotSettingsValidator", false, false);
                using (Database db = new Database(true, true))
                {

                    try
                    {
                        using (StreamReader streamRdr = File.OpenText(processParam.InputFileName))
                        {
                            string txtline = String.Empty;
                            string entityTypeName = String.Empty;
                            Dictionary<string, string> CXFEntityRecord = new Dictionary<string, string>();

                            while ((txtline = streamRdr.ReadLine()) != null)
                            {
                                // check if this is NOT an empty line
                                if (txtline.Trim().Length > 0)
                                {
                                    // check if this is a valid cfx entity title
                                    if ((txtline.Trim()[0] == '[') && (txtline.Trim()[txtline.Trim().Length - 1] == ']'))
                                    {
                                        entityTypeName = Resource.GetCXFEntityTypeName(txtline.Trim());
                                        if (entityTypeName.Length > 0)
                                        {
                                            //add the entity typename into list
                                            CXFEntityRecord.Clear();
                                        }
                                    }
                                    // read each line and add into list until a blank row (end of title rec) found
                                    else
                                    {
                                        string[] keyValue = new string[2];
                                        int posOfEqual = txtline.IndexOf("=");
                                        keyValue[0] = txtline.Substring(0, posOfEqual);
                                        int posOfValue = posOfEqual + 1;
                                        keyValue[1] = txtline.Substring(posOfValue, txtline.Length - posOfValue);
                                        CXFEntityRecord.Add(keyValue[0], keyValue[1]);
                                    }
                                }
                                else // if the "txtline" is BLANK Line after entity ppty values
                                {

                                    WriteDwgEntity(db, CXFEntityRecord, entityTypeName);
                                    entityTypeName = "";
                                }
                            }
                            // to process the last entry if there is no blank line after 
                            WriteDwgEntity(db, CXFEntityRecord, entityTypeName);
                        }
                        MoveHatchtoBack(db);

                        string extension = Path.GetExtension(processParam.OutputFileName);
                        if (extension.ToUpper() == ".DXF")
                        {
                            string drawingFilename = Path.GetFileNameWithoutExtension(processParam.OutputFileName);
                            string path = Path.GetDirectoryName(processParam.OutputFileName);
                            return converttoDXF(db, path + Path.DirectorySeparatorChar + drawingFilename);
                        }
                        else
                        {
                            db.SaveAs(processParam.OutputFileName, ((DwgVersion)processParam.AutoCADVersionNo));
                        }
                        result = true;
                    }
                    catch (CXFException ex)
                    {
                        Logger.RecordMessage(ex, Logs.Log.MessageType.Error);
                    }
                    catch (System.Exception ex)
                    {
                        Logger.RecordMessage(ex, Logs.Log.MessageType.Error);
                    }
                }
            }
            return result;
        }

        private bool converttoDXF(Database db, string fileName)
        {
            try
            {
                string destinationFile = fileName + ".dwg";
                db.SaveAs(destinationFile, DwgVersion.AC1024);
                db.ReadDwgFile(destinationFile, FileOpenMode.OpenForReadAndAllShare, true, "");
                TransactionManager tm = db.TransactionManager;
                using (Transaction ta = tm.StartTransaction())
                {
                    using (BlockTable bt = (BlockTable)ta.GetObject(db.BlockTableId, OpenMode.ForRead))
                    {
                        using (BlockTableRecord ms = (BlockTableRecord)ta.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite)) // or OpenMode.ForRead if we don't modify it
                        {
                            foreach (ObjectId id in ms)
                            {
                                Logger.RecordMessage("Convert to DXF - " + id.ToString(), Logs.Log.MessageType.Error);
                            }
                        }
                    }
                    ta.Commit();
                }
                db.DxfOut(fileName + ".dxf", 16, true);
                File.Delete(destinationFile);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private bool IsValidDBEntity(Database db,
                                    Dictionary<string, string> CXFEntityRecord, string entityTypeName)
        {
            if (entityTypeName.Length > 0)
            {
                if (entityTypeName.ToUpper() != "DBSETTINGS")
                {
                    return true;
                }
                CXFDBSettingsReader CXFDBSettingsReader = new CXFDBSettingsReader();
                DwgDBSettingsWriter dwgDBSettingsWriter = new DwgDBSettingsWriter();
                CwcDBSettings cwcDBSettings = CXFDBSettingsReader.ReadAndParseDBSettings(CXFEntityRecord);
                dwgDBSettingsWriter.SetDBSettings(db, cwcDBSettings);
                return false;
            }
            return false;
        }

        private void WriteDwgEntity(Database db,  
                                    Dictionary<string, string> CXFEntityRecord, string entityTypeName)
        {
            if (IsValidDBEntity(db, CXFEntityRecord, entityTypeName))
            {

                // send this list into the CXFReader of the type of entity we read
                // create the entity type, call the DWGWriter to create the entity in DWG file

                IDwgEntityWriter dwgEntity = factory.getDwgEntityWriter(entityTypeName);

                ICXFEntityReader CXFEntity = factory.getCXFEntityReader(entityTypeName);

                if (CXFEntity != null)
                {

                    ((CXFEntityReader)CXFEntity).EntityTypeName = entityTypeName;

                    CwcDbObject cwcDbObject = CXFEntity.ReadAndParse(CXFEntityRecord);

                    Logger.RecordMessage(string.Format("Processing Entity {0} (Id:{1})", entityTypeName, cwcDbObject.Id.ToString()), Logs.Log.MessageType.Informational);

                    ((DwgEntityWriter)dwgEntity).ObjectIdMapperList = objectIdMapperList;

                    ObjectId dwgObjectId = dwgEntity.CreateDwgEntity(db, cwcDbObject);
                    
                    if (!objectIdMapperList.ContainsKey(cwcDbObject.Id))
                        objectIdMapperList.Add(cwcDbObject.Id, dwgObjectId);

                    Logger.RecordMessage(string.Format("Processed Successfully {0} (Id:{1})", entityTypeName, dwgObjectId.ToString()), Logs.Log.MessageType.Informational);
                }
            }
        }



        private void MoveHatchtoBack(Database database)
        {

            TransactionManager tm = database.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable bt = (BlockTable)tm.GetObject(database.BlockTableId, OpenMode.ForRead))
                {
                    using (BlockTableRecord btr = (BlockTableRecord)tm.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForRead))
                    {

                        using (DrawOrderTable drawOrder = (DrawOrderTable)tm.GetObject(btr.DrawOrderTableId, OpenMode.ForRead))
                        {

                            ObjectIdCollection hatchids = new ObjectIdCollection();
                            BlockTableRecordEnumerator iterator = btr.GetEnumerator();

                            ObjectId dbObject_Id;
                            DBObject dbObject;
                            string typeName;
                            while (iterator.MoveNext())
                            {
                                dbObject_Id = (ObjectId)iterator.Current;
                                using (dbObject = tm.GetObject(dbObject_Id, OpenMode.ForRead))
                                {

                                    typeName = dbObject.GetType().Name;

                                    if (typeName.ToUpper() == "HATCH")
                                    {
                                        hatchids.Add(dbObject_Id);
                                    }
                                    else if (typeName == "BlockReference")
                                    {

                                        using (BlockTableRecord bDef = (BlockTableRecord)(((BlockReference)dbObject).BlockTableRecord.GetObject(OpenMode.ForRead)))
                                        {

                                            using (DrawOrderTable blkdrawOrder = (DrawOrderTable)tm.GetObject(bDef.DrawOrderTableId, OpenMode.ForRead))
                                            {

                                                ObjectIdCollection blkhatchids = new ObjectIdCollection();

                                                BlockTableRecordEnumerator iterator_block = bDef.GetEnumerator();

                                                DBObject dbObject_block;

                                                while (iterator_block.MoveNext())
                                                {
                                                    ObjectId id = (ObjectId)iterator_block.Current;
                                                    using (dbObject_block = tm.GetObject(id, OpenMode.ForRead))
                                                    {
                                                        typeName = dbObject_block.GetType().Name;
                                                        if (typeName.ToUpper() == "HATCH")
                                                        {
                                                            blkhatchids.Add(id);
                                                        }
                                                    }
                                                }
                                                if (blkhatchids.Count > 0)
                                                {
                                                    blkdrawOrder.UpgradeOpen();
                                                    blkdrawOrder.MoveToBottom(blkhatchids);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if (hatchids.Count > 0)
                            {
                                drawOrder.UpgradeOpen();
                                drawOrder.MoveToBottom(hatchids);
                            }
                        }
                    }
                }

                tr.Commit();
            }
        }


    }

    //For Debug - objectIdMapperList
    //public static class DictToFile
    //{
    //    public static string ToString(this System.Collections.Generic.Dictionary<string, ObjectId> source, string keyValueSeparator = "=", string sequenceSeparator = "|")
    //    {
    //        return source == null ? "" : string.Join(sequenceSeparator, source.Keys.Zip(source.Values, (k, v) => k + keyValueSeparator + v));
    //    }

    //}
    public class HostAppServ : HostApplicationServices
    {
        public override string FindFile(string fileName, Database database, FindFileHint hint)
        {
            if (hint == FindFileHint.PatternFile)
            {
                string _application = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) +
                    Path.DirectorySeparatorChar + "PAT";
                if (File.Exists(_application + Path.DirectorySeparatorChar + fileName))
                    return _application + Path.DirectorySeparatorChar + fileName;
                
                return FindFileEx(fileName, database, hint);

            }
            return FindFileEx(fileName, database, hint);
        }
    }


}