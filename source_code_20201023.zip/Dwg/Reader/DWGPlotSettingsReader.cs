﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgPlotSettingsReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            CwcPlotSettings plotSetting = new CwcPlotSettings();
            var entity = dbObject as PlotSettings;
            plotSetting.Id = entity.Id.ToString();
            plotSetting.ModelType = entity.ModelType;
            plotSetting.Name = entity.PlotSettingsName;
            plotSetting.LayoutName = string.Empty;
            if (dbObject is Layout)
            {
                plotSetting.LayoutName = (dbObject as Layout).LayoutName;
            }
            plotSetting.MediaName = entity.CanonicalMediaName;
            plotSetting.PlotterName = entity.PlotConfigurationName;
            plotSetting.CurrentStyleSheet = entity.CurrentStyleSheet;
            plotSetting.CustomPrintScaleDenominator = entity.CustomPrintScale.Denominator;
            plotSetting.CustomPrintScaleNumerator = entity.CustomPrintScale.Numerator;
            plotSetting.PlotCentered = entity.PlotCentered;
            plotSetting.PlotAsRaster = entity.PlotAsRaster;
            plotSetting.PlotOrigin = entity.PlotOrigin;
            plotSetting.PlotPaperMarginsMaxPoint = entity.PlotPaperMargins.MaxPoint;
            plotSetting.PlotPaperMarginsMinPoint = entity.PlotPaperMargins.MinPoint;
            plotSetting.PaperSize = entity.PlotPaperSize;
            plotSetting.PlotPaperUnits = (int)entity.PlotPaperUnits;
            plotSetting.PlotRotation = (int)entity.PlotRotation;
            plotSetting.PlotType = (int)entity.PlotType;
            plotSetting.ScaleLineweights = entity.ScaleLineweights;
            plotSetting.StdScale = entity.StdScale;
            plotSetting.StdScaleType = (int)entity.StdScaleType;
            plotSetting.ShowPlotStyles = entity.ShowPlotStyles;
            plotSetting.UseStandardScale = entity.UseStandardScale;
            plotSetting.PlotPlotStyles = entity.PlotPlotStyles;
            plotSetting.PlotTransparency = entity.PlotTransparency;
            plotSetting.PrintLineweights = entity.PrintLineweights;
            plotSetting.PlotHidden = entity.PlotHidden;
            plotSetting.PlotWireframe = entity.PlotWireframe;
            plotSetting.PlotViewportBorders = entity.PlotViewportBorders;
            plotSetting.PlotPaperspaceLast = entity.DrawViewportsFirst; 

            return plotSetting;
        }
    }


}

