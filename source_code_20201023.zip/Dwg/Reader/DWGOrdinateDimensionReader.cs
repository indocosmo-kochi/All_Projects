﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgOrdinateDimensionReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            CwcOrdinateDimension dimension = new CwcOrdinateDimension();
            var entity = (dbObject as OrdinateDimension);

            dimension.LayerId = entity.LayerId.ToString();
            dimension.Visible = entity.Visible;
            dimension.LinetypeId = entity.LinetypeId.ToString();

            dimension.UsingXAxis = entity.UsingXAxis;
            dimension.DefiningPoint = entity.DefiningPoint;
            dimension.LeaderEndPoint = entity.LeaderEndPoint;
            dimension.DimStyleId = entity.DimensionStyle.ToString();
            //dimension.DimensionStyleName = entity.DimensionStyleName;

            dimension.Origin = entity.Origin;

            dimension.TextStyleId = entity.TextStyleId.ToString();
            dimension.TextPosition = entity.TextPosition;
            dimension.TextRotation = entity.TextRotation;

            dimension.Linetype = entity.Linetype;
            dimension.LinetypeScale = entity.LinetypeScale;

            dimension.LineWeight = entity.LineWeight;
            dimension.BlockId = entity.BlockId.ToString();
            dimension.BlockName = entity.BlockName;

            dimension.Color = GetDwgEntityColor(entity.Color, entity.LayerId.ToString());

            return dimension;
        }
    }
}
