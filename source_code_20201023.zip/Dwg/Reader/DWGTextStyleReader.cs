﻿using CWorksCXF.Entities;
using System.Collections;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgTextStyleReader : IDwgEntityReader
    {
        public CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            CwcTextStyle textStyle = new CwcTextStyle();
            TextStyleTableRecord textStyleRecord = (dbObject as TextStyleTableRecord);
            //textStyleRecord.IsShapeFile
            textStyle.Id = textStyleRecord.Id.ToString();
            textStyle.Name = textStyleRecord.Name;
            textStyle.FileName = textStyleRecord.FileName;
            textStyle.FontName = textStyleRecord.Font.TypeFace;
            textStyle.IsBold = textStyleRecord.Font.Bold;
            textStyle.IsItallic = textStyleRecord.Font.Italic;
            textStyle.Characters = textStyleRecord.Font.CharacterSet;
            textStyle.PitchAndFamily = textStyleRecord.Font.PitchAndFamily;
            textStyle.TextSize = textStyleRecord.TextSize;
            textStyle.ObliquingAngle = textStyleRecord.ObliquingAngle;
            textStyle.FlagBits = textStyleRecord.FlagBits;                        
            textStyle.IsVertical = textStyleRecord.IsVertical;

            textStyle.Annotative = textStyleRecord.Annotative;
            textStyle.BigFontFileName = textStyleRecord.BigFontFileName;
            textStyle.PriorSize = textStyleRecord.PriorSize;
            textStyle.XScale = textStyleRecord.XScale;
            // WOrking on Text Reverse property correction C reverse Suraj Aug 2020
            byte _byte = textStyleRecord.FlagBits;
            var bits = new BitArray(_byte);
            System.Text.StringBuilder str = new System.Text.StringBuilder();
            for (int i = 0; i < bits.Length; i++)
                str.Append(string.Format("Value of {0} is {1} ",i,bits[i]));
            textStyle.Bitvalue = str.ToString();

            return textStyle;
        }
    }


}
