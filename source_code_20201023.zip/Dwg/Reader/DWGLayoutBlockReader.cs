﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgLayoutBlockReader : DwgEnityReader, IDwgEntityReader
    {
        public Transaction acTrans { get; set; }

        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            var entity = (dbObject as BlockTableRecord);

            CwcLayoutBlock block = new CwcLayoutBlock();
            block.Id = entity.Id.ToString();
            block.Name = entity.Name;
            if (entity.IsLayout)
            {
                using (var layout = entity.LayoutId.GetObject(OpenMode.ForRead) as Layout)
                {
                    block.LayoutName = layout.LayoutName;
                }
            }

            return block;
        }
    }
}

