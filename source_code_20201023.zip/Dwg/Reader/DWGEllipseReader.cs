﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgEllipseReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            CwcEllipse ellipse = new CwcEllipse();
            var entity = (dbObject as Ellipse);
            ellipse.Id = entity.Id.ToString();
            ellipse.LayerId = entity.LayerId.ToString();
            ellipse.Visible = entity.Visible;
      //      ellipse.LayerName = Layers[ellipse.LayerId].Name;
            ellipse.Center = entity.Center;
            ellipse.MajorRadius = entity.MajorRadius;
            ellipse.MinorRadius = entity.MinorRadius;

            ellipse.UnitNormal = entity.Normal;
            ellipse.MajorAxis = entity.MajorAxis;
            ellipse.MinorAxis = entity.MajorAxis;
            ellipse.RadiusRatio = entity.RadiusRatio;
            ellipse.StartAngle = entity.StartAngle;
            ellipse.EndAngle = entity.EndAngle;

            ellipse.Linetype = entity.Linetype;
            ellipse.LinetypeScale = entity.LinetypeScale;

            ellipse.LineWeight = entity.LineWeight;
            ellipse.BlockId = entity.BlockId.ToString();
            ellipse.BlockName = entity.BlockName;

            ellipse.Color = GetDwgEntityColor(entity.Color, entity.LayerId.ToString());

            ellipse.LinetypeId = entity.LinetypeId.ToString();

            return ellipse;
        }
    }
}
