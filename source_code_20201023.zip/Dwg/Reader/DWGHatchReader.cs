﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{

    public class DwgHatchReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {

            var entity = (dbObject as Hatch);
            CwcHatch hatch = new CwcHatch(entity.NumberOfLoops);
            hatch.Id = entity.Id.ToString();
            hatch.LayerId = entity.LayerId.ToString();
            hatch.Visible = entity.Visible;
            //       hatch.LayerName = Layers[hatch.LayerId].Name;

            hatch.HatchObjectType = entity.HatchObjectType;
            hatch.IsGradient = entity.IsGradient;
            hatch.IsHatch = entity.IsHatch;
            hatch.IsSolidFill = entity.IsSolidFill;
            hatch.Origin = entity.Origin;

            hatch.Annotative = entity.Annotative;
            hatch.Associative = entity.Associative;

            if (entity.IsGradient)
            {
                hatch.GradientName = entity.GradientName;
                hatch.GradientType = entity.GradientType;
                hatch.GradientAngle = entity.GradientAngle;
                hatch.GradientOneColorMode = entity.GradientOneColorMode;
                hatch.GradientShift = entity.GradientShift;

                GradientColor[] gclrs = entity.GetGradientColors();
                hatch.GradientColor[0] = gclrs[0];
                hatch.GradientColor[1] = gclrs[1];
            }

            //hatch.AssociatedObjectId = new System.Collections.Generic.List<string>();

            //var objectIds = entity.GetAssociatedObjectIds();
            //foreach (var oId in objectIds)
            //    hatch.AssociatedObjectId.Add(oId.ToString());

            if (entity.IsHatch)
            {
                hatch.PatternName = entity.PatternName.ToString();
                hatch.PatternType = entity.PatternType;
                hatch.PatternAngle = entity.PatternAngle;
                hatch.PatternScale = entity.PatternScale;
                hatch.PatternSpace = entity.PatternSpace;
                hatch.HatchStyle = entity.HatchStyle;
                hatch.Color = entity.Color;
                hatch.BackgroundColor = entity.BackgroundColor;
            }

            hatch.NumberOfLoops = entity.NumberOfLoops;
            for (int i = 0; i < hatch.NumberOfLoops; i++)
            {
                if (entity.Associative)
                {
                    ObjectIdCollection ids = entity.GetAssociatedObjectIdsAt(i);
                    hatch.Loops[i] = new CwcHatchLoop(ids);
                }
                else
                {
                    HatchLoop dwgHatchLoop = entity.GetLoopAt(i);
                    hatch.Loops[i] = dwgHatchLoop;
                    if (!hatch.Loops[i].IsPolyline)
                    {
                        GetCurvesFromHatchLoop(dwgHatchLoop, hatch.Loops[i]);
                    }
                }
                hatch.Loops[i].LoopType = entity.LoopTypeAt(i);
            }

            hatch.Linetype = entity.Linetype;
            hatch.LinetypeScale = entity.LinetypeScale;

            hatch.LineWeight = entity.LineWeight;
            hatch.BlockId = entity.BlockId.ToString();
            hatch.BlockName = entity.BlockName;
            return hatch;
        }


        private void GetCurvesFromHatchLoop(HatchLoop dwgHatchLoop, CwcHatchLoop cwcHatchLoop)
        {
            for (int j = 0; j < cwcHatchLoop.NumberOfCurves; j++)
            {
                Common.Enums.CurveType curvetype = Common.Enums.ConvertStringToEnumValue<Common.Enums.CurveType>(dwgHatchLoop.Curves[j].GetType().Name);

                switch (curvetype)
                {
                    case Common.Enums.CurveType.LineSegment2d:
                        CwcLineSegment2D linesegment = new CwcLineSegment2D(curvetype);
                        Teigha.Geometry.LineSegment2d dwgLineSegment2d = dwgHatchLoop.Curves[j] as Teigha.Geometry.LineSegment2d;
                        linesegment.StartPoint = dwgLineSegment2d.StartPoint;
                        linesegment.EndPoint = dwgLineSegment2d.EndPoint;
                        cwcHatchLoop.Curve2DCollection[j] = linesegment;
                        break;
                    case Common.Enums.CurveType.CircularArc2d:
                        CwcCircularArc2D circularArc = new CwcCircularArc2D(curvetype);
                        Teigha.Geometry.CircularArc2d dwgCircularArc2d = dwgHatchLoop.Curves[j] as Teigha.Geometry.CircularArc2d;
                        circularArc.Center = dwgCircularArc2d.Center;
                        circularArc.Radius = dwgCircularArc2d.Radius;
                        circularArc.StartAngle = dwgCircularArc2d.StartAngle;
                        circularArc.EndAngle = dwgCircularArc2d.EndAngle;
                        circularArc.ReferenceVector = dwgCircularArc2d.ReferenceVector;
                        circularArc.IsClockWise = dwgCircularArc2d.IsClockWise;
                        cwcHatchLoop.Curve2DCollection[j] = circularArc;
                        break;
                    case Common.Enums.CurveType.EllipticalArc2d:
                        CwcEllipticalArc2D ellipticalArc = new CwcEllipticalArc2D(curvetype);
                        Teigha.Geometry.EllipticalArc2d dwgEllipticalArc2d = dwgHatchLoop.Curves[j] as Teigha.Geometry.EllipticalArc2d;
                        ellipticalArc.Center = dwgEllipticalArc2d.Center;
                        ellipticalArc.MajorRadius = dwgEllipticalArc2d.MajorRadius;
                        ellipticalArc.MinorRadius = dwgEllipticalArc2d.MinorRadius;
                        ellipticalArc.MajorAxis = dwgEllipticalArc2d.MajorAxis;
                        ellipticalArc.MinorAxis = dwgEllipticalArc2d.MinorAxis;
                        ellipticalArc.StartAngle = dwgEllipticalArc2d.StartAngle;
                        ellipticalArc.EndAngle = dwgEllipticalArc2d.EndAngle;
                        cwcHatchLoop.Curve2DCollection[j] = ellipticalArc;
                        break;
                    case Common.Enums.CurveType.NurbCurve2d:
                        Teigha.Geometry.NurbCurve2d dwgNurbCurve2d = dwgHatchLoop.Curves[j] as Teigha.Geometry.NurbCurve2d;

                        CwcNurbCurve2D nurbCurve2d = null;

                        if (dwgNurbCurve2d.HasFitData)
                        {
                            nurbCurve2d = new CwcNurbCurve2D(dwgNurbCurve2d.NumFitPoints, curvetype);

                            nurbCurve2d.HasFitData = dwgNurbCurve2d.HasFitData;

                            nurbCurve2d.FitKnotParameterization = dwgNurbCurve2d.FitKnotParameterization;
                            nurbCurve2d.Fit_TangentsExist = dwgNurbCurve2d.FitData.TangentsExist;

                            if (dwgNurbCurve2d.FitData.TangentsExist)
                            {
                                nurbCurve2d.Fit_StartTangent = dwgNurbCurve2d.FitData.StartTangent;
                                nurbCurve2d.Fit_EndTangent = dwgNurbCurve2d.FitData.EndTangent;
                            }
                            nurbCurve2d.FitTolerance_EqualPoint = dwgNurbCurve2d.FitTolerance.EqualPoint;
                            nurbCurve2d.FitTolerance_EqualVector = dwgNurbCurve2d.FitTolerance.EqualVector;
                            nurbCurve2d.Degree = dwgNurbCurve2d.Degree;
                            nurbCurve2d.NumFitPoints = dwgNurbCurve2d.NumFitPoints;

                            for (int i = 0; i < dwgNurbCurve2d.NumFitPoints; i++)
                            {
                                nurbCurve2d.FitPoints[i] = dwgNurbCurve2d.GetFitPointAt(i);
                            }
                        }
                        else
                        {
                            nurbCurve2d = new CwcNurbCurve2D(dwgNurbCurve2d.NumControlPoints, dwgNurbCurve2d.NumKnots, dwgNurbCurve2d.NumWeights, curvetype);
                            nurbCurve2d.HasFitData = dwgNurbCurve2d.HasFitData;
                            nurbCurve2d.Degree = dwgNurbCurve2d.DefinitionData.Degree;
                            nurbCurve2d.Periodic = dwgNurbCurve2d.DefinitionData.Periodic;
                            
                            nurbCurve2d.NumControlPoints = dwgNurbCurve2d.NumControlPoints;
                            for (int i = 0; i < dwgNurbCurve2d.NumControlPoints; i++)
                            {
                                nurbCurve2d.ControlPoints[i] = dwgNurbCurve2d.GetControlPointAt(i);
                            }

                            nurbCurve2d.NumKnots = dwgNurbCurve2d.NumKnots;
                            for (int i = 0; i < dwgNurbCurve2d.NumKnots; i++)
                            {
                                nurbCurve2d.Knots[i] = dwgNurbCurve2d.DefinitionData.Knots[i];
                            }

                            nurbCurve2d.NumWeights = dwgNurbCurve2d.NumWeights;
                            for (int i = 0; i < dwgNurbCurve2d.NumWeights; i++)
                            {
                                nurbCurve2d.Weights[i] = dwgNurbCurve2d.GetWeightAt(i);
                            }
                        }

                        cwcHatchLoop.Curve2DCollection[j] = nurbCurve2d;
                        break;
                }
            }
        }
    }


}

