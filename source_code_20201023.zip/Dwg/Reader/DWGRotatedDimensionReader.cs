﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgRotatedDimensionReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {

            var entity = (dbObject as RotatedDimension);

            CwcRotatedDimension dimension = new CwcRotatedDimension(entity as Dimension);

            dimension.Id = entity.Id.ToString();
            dimension.Visible = entity.Visible;
            dimension.LayerId = entity.LayerId.ToString();
            dimension.LinetypeId = entity.LinetypeId.ToString();

            dimension.Rotation = entity.Rotation;
            dimension.DimLinePoint = entity.DimLinePoint;
            dimension.XLine1Point = entity.XLine1Point;
            dimension.XLine2Point = entity.XLine2Point;

            dimension.DimStyleId = entity.DimensionStyle.ToString();
            dimension.Dimclrd = GetDwgEntityColor(entity.Dimclrd, entity.LayerId.ToString()); 
            dimension.Dimclre = GetDwgEntityColor(entity.Dimclre, entity.LayerId.ToString()); 
            dimension.Dimclrt = GetDwgEntityColor(entity.Dimclrt, entity.LayerId.ToString()); 
            dimension.Dimtfillclr = GetDwgEntityColor(entity.Dimtfillclr, entity.LayerId.ToString());            

            dimension.TextStyleId = entity.TextStyleId.ToString();
            dimension.TextPosition = entity.TextPosition;
            dimension.TextRotation = entity.TextRotation;

            dimension.DimBlockId = entity.DimBlockId.ToString();
            dimension.Dimapost = entity.Dimapost;
            dimension.DimensionText = entity.DimensionText;

            dimension.DynamicDimension = entity.DynamicDimension;
            dimension.Elevation = entity.Elevation;
            dimension.HorizontalRotation = entity.HorizontalRotation;
            dimension.AlternatePrefix = entity.AlternatePrefix;
            dimension.AlternateSuffix = entity.AlternateSuffix;
            dimension.AltSuppressLeadingZeros = entity.AltSuppressLeadingZeros;
            dimension.AltSuppressTrailingZeros = entity.AltSuppressTrailingZeros;
            dimension.AltSuppressZeroFeet = entity.AltSuppressZeroFeet;
            dimension.AltSuppressZeroInches = entity.AltSuppressZeroInches;
            dimension.AltToleranceSuppressLeadingZeros = entity.AltToleranceSuppressLeadingZeros;
            dimension.AltToleranceSuppressTrailingZeros = entity.AltToleranceSuppressTrailingZeros;
            dimension.AltToleranceSuppressZeroFeet = entity.AltToleranceSuppressZeroFeet;
            dimension.AltToleranceSuppressZeroInches = entity.AltToleranceSuppressZeroInches;
            dimension.Prefix = entity.Prefix;
            dimension.Suffix = entity.Suffix;
            dimension.SuppressAngularLeadingZeros = entity.SuppressAngularLeadingZeros;
            dimension.SuppressAngularTrailingZeros = entity.SuppressAngularTrailingZeros;
            dimension.SuppressLeadingZeros = entity.SuppressLeadingZeros;
            dimension.SuppressTrailingZeros = entity.SuppressTrailingZeros;
            dimension.SuppressZeroFeet = entity.SuppressZeroFeet;
            dimension.SuppressZeroInches = entity.SuppressZeroInches;
            dimension.TextAttachment = entity.TextAttachment;
            dimension.TextLineSpacingFactor = entity.TextLineSpacingFactor;
            dimension.TextLineSpacingStyle = entity.TextLineSpacingStyle;
            dimension.ToleranceSuppressLeadingZeros = entity.ToleranceSuppressLeadingZeros;
            dimension.ToleranceSuppressTrailingZeros = entity.ToleranceSuppressTrailingZeros;
            dimension.ToleranceSuppressZeroFeet = entity.ToleranceSuppressZeroFeet;
            dimension.ToleranceSuppressZeroInches = entity.ToleranceSuppressZeroInches;
            dimension.UsingDefaultTextPosition = entity.UsingDefaultTextPosition;

            dimension.Linetype = entity.Linetype;
            dimension.LinetypeScale = entity.LinetypeScale;

            dimension.LineWeight = entity.LineWeight;

            dimension.BlockId = entity.BlockId.ToString();
            dimension.BlockName = entity.BlockName;
            dimension.Color = GetDwgEntityColor(entity.Color, entity.LayerId.ToString());

            return dimension;
        }
    }
}
