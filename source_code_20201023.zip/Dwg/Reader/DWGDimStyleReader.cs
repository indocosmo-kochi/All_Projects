﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgDimStyleReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            CwcDimStyle dimStyle = null;

            DimStyleTableRecord dimStyleRecord = (dbObject as DimStyleTableRecord);
            dimStyle = dimStyleRecord;
            dimStyle.Dimclrd = dimStyleRecord.Dimclrd;  
            dimStyle.Dimclre = dimStyleRecord.Dimclre; 
            dimStyle.Dimclrt = dimStyleRecord.Dimclrt;
            dimStyle.Dimtfillclr = dimStyleRecord.Dimtfillclr;

            return dimStyle;
        }




    }


}

