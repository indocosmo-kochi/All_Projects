﻿using CWorksCXF.Entities;
using System.Text;
using Teigha.DatabaseServices;



namespace CWorksCXF.DWG.Reader
{
    public class DwgDBTextReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            CwcDBText text = new CwcDBText();
            var entity = (dbObject as DBText);
            text.LayerId = entity.LayerId.ToString();
            text.Visible = entity.Visible;

            text.TextString = entity.TextString;

            text.Position = entity.Position;
            text.Id = entity.Id.ToString();

            text.Height = entity.Height;
            text.HorizontalMode = entity.HorizontalMode;
            text.VerticalMode = entity.VerticalMode;
            text.Justify = entity.Justify;
            text.Normal = entity.Normal;
            text.Oblique = entity.Oblique;
            text.Rotation = entity.Rotation;
            text.Thickness = entity.Thickness;
            text.IsDefaultAlignment = entity.IsDefaultAlignment;
            text.AlignmentPoint = entity.AlignmentPoint;
            text.IsMirroredInX = entity.IsMirroredInX;
            text.IsMirroredInY = entity.IsMirroredInY;

            text.WidthFactor = entity.WidthFactor;

            text.TextStyleId = entity.TextStyleId.ToString();

            text.BlockId = entity.BlockId.ToString();
            text.BlockName = entity.BlockName;

            text.Color = GetDwgEntityColor(entity.Color, entity.LayerId.ToString());


            return text;
        }
    }
}
