﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgAttributeDefinitionReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            var entity = (dbObject as AttributeDefinition);
            CwcAttributeDefinition attrDef = new CwcAttributeDefinition(entity);
            attrDef.Id = entity.Id.ToString();
            attrDef.Visible = entity.Visible;
            attrDef.BlockId = entity.BlockId.ToString();
            attrDef.BlockName = entity.BlockName;
            attrDef.Color = GetDwgEntityColor(entity.Color, entity.LayerId.ToString());

            return attrDef;
        }
    }
}
