﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgModelViewportReader : DwgEnityReader, IDwgEntityReader
    {
        //public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        //{
        //    CwcViewport viewport = new CwcViewport();
        //    Viewport entity = (dbObject as Viewport);
        //    viewport.Id = entity.Id.ToString();
        //    viewport.Color = entity.Color;
        //    viewport.LayerId = entity.LayerId.ToString();
        //    viewport.LinetypeId = entity.LinetypeId.ToString();
        //    viewport.LinetypeScale = entity.LinetypeScale;
        //    viewport.PlotStyleName = entity.PlotStyleName;
        //    viewport.Transparency = entity.Transparency.ToString();
        //    viewport.CenterPoint = entity.CenterPoint;
        //    viewport.Height = entity.Height;
        //    viewport.Width = entity.Width;
        //    viewport.On = entity.On;
        //    viewport.DisplayLocked = entity.Locked;
        //    viewport.GridEnabled = entity.GridOn;
        //    viewport.BackClipOn = entity.BackClipOn;
        //    viewport.FrontClipOn = entity.FrontClipOn;
        //    viewport.AnnotationScale = entity.AnnotationScale.Scale;
        //    viewport.StandardScale = (int)entity.StandardScale;
        //    viewport.CustomScale = entity.CustomScale;
        //    viewport.UcsPerViewport = entity.UcsPerViewport;
        //    viewport.VisualStyleId = entity.VisualStyleId.ToString();
        //    viewport.ShadePlot = (int)entity.ShadePlot;

        //    return viewport;
        //}

        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            CwcModelViewport viewport = new CwcModelViewport();
            ViewportTableRecord entity = (dbObject as ViewportTableRecord);
            viewport.Id = entity.Id.ToString();
            viewport.Name = entity.Name;
            viewport.CircleSides = entity.CircleSides;
            viewport.GridEnabled = entity.GridEnabled;
            viewport.CenterPoint = entity.CenterPoint;
            viewport.Height = entity.Height;
            viewport.Width = entity.Width;
            viewport.IconAtOrigin = entity.IconAtOrigin;

            return viewport;
        }
    }


}

