﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DWGMLeaderStyleReader: DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            var entity = dbObject as MLeaderStyle;
            CwcMLeaderStyle mlStyle = new CwcMLeaderStyle();
            mlStyle.Id = entity.Id.ToString();
            mlStyle.Name = entity.Name;
            mlStyle.ArrowSize = entity.ArrowSize;
            mlStyle.ArrowSymbol = entity.ArrowSymbolId.ToString();
            mlStyle.LeaderLineType = (int)entity.LeaderLineType;
            mlStyle.LeaderLineColor = entity.LeaderLineColor;
            mlStyle.LeaderLineTypeId = entity.LeaderLineTypeId.ToString();
            mlStyle.LeaderLineWeight = (int)entity.LeaderLineWeight;
            mlStyle.BreakSize = entity.BreakSize;
            mlStyle.MaxLeaderSegmentsPoints = entity.MaxLeaderSegmentsPoints;
            mlStyle.FirstSegmentAngleConstraint = (int)entity.FirstSegmentAngleConstraint;
            mlStyle.SecondSegmentAngleConstraint = (int)entity.SecondSegmentAngleConstraint;
            mlStyle.EnableLanding = entity.EnableLanding;
            mlStyle.LandingGap = entity.LandingGap;
            mlStyle.LandingDistance = entity.DoglegLength;
            mlStyle.Annotative = (int)entity.Annotative;
            mlStyle.EnableBlockScale = entity.EnableBlockScale;
            mlStyle.Scale = entity.Scale;
            mlStyle.ContentType = (int)entity.ContentType;
            mlStyle.DefaultContents = entity.DefaultMText.Contents;
            mlStyle.TextStyleId = entity.TextStyleId.ToString();
            mlStyle.TextAngleType = (int)entity.TextAngleType;
            mlStyle.TextColor = entity.TextColor;
            mlStyle.TextHeight = entity.TextHeight;
            mlStyle.TextAlignAlwaysLeft = entity.TextAlignAlwaysLeft;
            mlStyle.EnableFrameText = entity.EnableFrameText;
            mlStyle.TextAttachmentDirection = (int)entity.TextAttachmentDirection;
            mlStyle.TextAttachmentType = (int)entity.TextAttachmentType;
            mlStyle.BlockConnectionType = (int)entity.BlockConnectionType;
            mlStyle.LeaderStyleBlockId = entity.BlockId.ToString();
            mlStyle.BlockScale = entity.BlockScale;

            //mlStyle.BlockName = entity.blockName;
            mlStyle.BlockId = entity.BlockId.ToString();

            return mlStyle;
        }
    }
}
