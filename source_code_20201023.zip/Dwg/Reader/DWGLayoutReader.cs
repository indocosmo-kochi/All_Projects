﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgLayoutReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            Layout entity = (dbObject as Layout);
            int viewportCount = entity.GetViewports().Count;
            CwcLayout layout = new CwcLayout(viewportCount);
            layout.Id = entity.Id.ToString();
            layout.LayoutName = entity.LayoutName;
            layout.ModelType = entity.ModelType;
            layout.TabOrder = entity.TabOrder;
            layout.PlotSettingsName = entity.PlotSettingsName;

            return layout;
        }
    }


}

