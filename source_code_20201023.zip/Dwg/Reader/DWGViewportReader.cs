﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgViewportReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            CwcViewport viewport = new CwcViewport();
            Viewport entity = (dbObject as Viewport);
           
            viewport.AnnotationName = entity.AnnotationScale.Name;
            viewport.BackClipOn = entity.BackClipOn;
            viewport.CenterPoint = entity.CenterPoint;
            viewport.Color = entity.Color;
            viewport.ViewCenter = entity.ViewCenter;
            viewport.ViewHeight = entity.ViewHeight;
            viewport.CustomScale = entity.CustomScale;
            viewport.DisplayLocked = entity.Locked;
            viewport.FrontClipOn = entity.FrontClipOn;
            viewport.GridEnabled = entity.GridOn;
            viewport.GridIncrement = entity.GridIncrement;
            viewport.Height = entity.Height;
            viewport.Width = entity.Width;
            viewport.Id = entity.Id.ToString();
            viewport.Visible = entity.Visible;
            viewport.LayerId = entity.LayerId.ToString();
            viewport.LinetypeId = entity.LinetypeId.ToString();
            viewport.LinetypeScale = entity.LinetypeScale;
            viewport.On = entity.On;
            viewport.PlotStyleName = entity.PlotStyleName;
            viewport.ShadePlot = (int)entity.ShadePlot;
            viewport.StandardScale = (int)entity.StandardScale;
            viewport.Transparency = entity.Transparency.Alpha.ToString();
            viewport.UcsPerViewport = entity.UcsPerViewport;
            viewport.VisualStyleId = entity.VisualStyleId.ToString();
            viewport.TwistAngle = entity.TwistAngle;
            viewport.ViewTarget = entity.ViewTarget;
            viewport.ViewDirection = entity.ViewDirection;
            viewport.UcsIconAtOrigin = entity.UcsIconAtOrigin;

            viewport.BlockId = entity.BlockId.ToString();
            viewport.BlockName = entity.BlockName;

            return viewport;
        }
    }


}

