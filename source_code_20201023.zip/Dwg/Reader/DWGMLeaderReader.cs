﻿using CWorksCXF.Entities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgMLeaderReader: DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            var entity = dbObject as MLeader;
            ArrayList lineIndexes = entity.GetLeaderLineIndexes(0);
            CwcMLeader mLeader = new CwcMLeader(lineIndexes.Count);
            mLeader.Id = entity.Id.ToString();
            mLeader.Visible = entity.Visible;
            mLeader.LayerId = entity.LayerId.ToString();            
            //Arrow header points
            for (int i = 0; i < mLeader.LeaderCount; i++)
            {
                mLeader.HeaderPoints[i] = entity.GetFirstVertex((int)lineIndexes[i]);
            }
            //arrow tail point
            mLeader.NockPoint = entity.GetLastVertex(0);
            mLeader.ContentType = (int)entity.ContentType;
            mLeader.ArrowSize = entity.ArrowSize;
            mLeader.ArrowSymbol = entity.ArrowSymbolId.ToString();
            mLeader.LeaderLineType = (int)entity.LeaderLineType;
            mLeader.LeaderLineColor = GetDwgEntityColor(entity.LeaderLineColor, entity.LayerId.ToString());
            mLeader.LeaderLineTypeId = entity.LeaderLineTypeId.ToString();
            mLeader.LeaderLineWeight = (int)entity.LeaderLineWeight;
            mLeader.EnableLanding = entity.EnableLanding;
            mLeader.LandingGap = entity.LandingGap;
            mLeader.Annotative = (int)entity.Annotative;
            mLeader.Scale = entity.LinetypeScale;
            mLeader.LandingDistance = entity.DoglegLength;
            mLeader.MLeaderStyleId = entity.MLeaderStyle.ToString();

            if (entity.ContentType == ContentType.MTextContent)
            {
                mLeader.Contents = entity.MText.Contents;
                mLeader.TextHeight = entity.MText.TextHeight;
                mLeader.TextLength = entity.MText.ActualWidth;
                mLeader.TextStyleId = entity.TextStyleId.ToString();
                mLeader.TextAngleType = (int)entity.TextAngleType;
                mLeader.TextColor = GetDwgEntityColor(entity.TextColor, entity.LayerId.ToString());
                mLeader.EnableFrameText = entity.EnableFrameText;
                mLeader.TextAttachmentDirection = (int)entity.TextAttachmentDirection;
                mLeader.TextAttachmentType = (int)entity.TextAttachmentType;
                mLeader.TextJustification = (int)entity.MText.Attachment;
                mLeader.ContentLocation = entity.MText.Location;
            }
            else if (entity.ContentType == ContentType.BlockContent)
            {
                using (BlockTableRecord tr = entity.BlockContentId.GetObject(OpenMode.ForRead) as BlockTableRecord)
                {
                    foreach (ObjectId attrId in tr)
                    {
                        DBObject attrDef = attrId.GetObject(OpenMode.ForRead);
                        if (attrDef is AttributeDefinition)
                        {
                            AttributeReference blockValues = entity.GetBlockAttribute(attrId);
                            mLeader.BlockAttributes.Add(new KeyValuePair<string, string>(blockValues.Tag, blockValues.TextString));
                        }
                    }
                }
                mLeader.ContentLocation = entity.BlockPosition;
                mLeader.BlockConnectionType = (int)entity.BlockConnectionType;
                mLeader.BlockScale = entity.BlockScale;
            }
            mLeader.SourceBlockId = entity.BlockContentId.ToString();

            //annotation section
            if (entity.EnableAnnotationScale)
            {
                ObjectContextCollection contextCollection = entity.Database.ObjectContextManager.GetContextCollection("ACDB_ANNOTATIONSCALES");
                foreach (var context in contextCollection)
                {
                    if (context is AnnotationScale && entity.HasContext(context))
                    {
                        mLeader.AnnotationName = ((AnnotationScale)context).Name;
                        break;
                    }
                }
            }
            mLeader.BlockName = entity.BlockName;
            mLeader.BlockId = entity.BlockId.ToString();
            mLeader.TextAlignmentType = entity.TextAlignmentType;            

            return mLeader;
        }        
    }
}
