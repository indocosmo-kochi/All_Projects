﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{

    public class DwgLineTypeReader : IDwgEntityReader
    {
        public CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            var entity = (dbObject as LinetypeTableRecord);
            CwcLineType linetype = new CwcLineType(entity.NumDashes);
            linetype.Id = entity.Id.ToString();
            linetype.Name = entity.Name;
            linetype.Comments = entity.Comments;
            linetype.NumDashes = entity.NumDashes;
            linetype.PatternLength = entity.PatternLength;
            linetype.IsScaledToFit = entity.IsScaledToFit;
            //CwcLTDetails ltdetails = null;
            for (int i = 0; i < linetype.NumDashes; i++)
            {
                linetype.LTDetails[i] = new CwcLTDetails();
                linetype.LTDetails[i].DashLengthAt = entity.DashLengthAt(i);
                linetype.LTDetails[i].ShapeNumberAt = entity.ShapeNumberAt(i);
                linetype.LTDetails[i].ShapeStyleAt = entity.ShapeStyleAt(i).ToString();

                if (linetype.LTDetails[i].ShapeNumberAt != 0)
                {
                    using (TextStyleTableRecord pTextStyle = (TextStyleTableRecord)(entity.ShapeStyleAt(i) == ObjectId.Null ? null : entity.ShapeStyleAt(i).GetObject(OpenMode.ForRead)))
                    {
                        
                        linetype.LTDetails[i].IsShapeFileExists = pTextStyle.IsShapeFile;
                        if (pTextStyle.IsShapeFile)
                            linetype.LTDetails[i].ShapeStyleFileName = pTextStyle.FileName;
                    }
                    linetype.LTDetails[i].ShapeScaleAt = entity.ShapeScaleAt(i);
                    linetype.LTDetails[i].ShapeRotationAt = entity.ShapeRotationAt(i);
                    linetype.LTDetails[i].ShapeOffsetAt = entity.ShapeOffsetAt(i);
                }
            }

            return linetype;
        }
    }


}

