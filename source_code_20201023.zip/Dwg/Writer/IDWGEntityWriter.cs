﻿using CWorksCXF.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Writer
{
    interface IDwgEntityWriter
    {
        ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject);
    }
}
