﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgCircleWriter : DwgEntityWriter
    {

        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {
            ObjectId entityId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable blockTbl = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable)
                {

                    // save the current line type for database into a temp variable
                    ObjectId current_linetypeId = db.Celtype;

                    CwcCircle entityObject = cwcDbObject as CwcCircle;

                    using (Circle circle = new Circle())
                    {

                        Point3d center = new Point3d(entityObject.Center.X, entityObject.Center.Y, entityObject.Center.Z);
                        circle.Center = center;
                        circle.Radius = entityObject.Radius;
                        circle.SetDatabaseDefaults();

                        if (entityObject.LayerId.Length > 0)
                            circle.LayerId = GetDwgObjectId(entityObject.LayerId);

                        circle.Color = GetDwgColor(entityObject.Color);

                        circle.LinetypeId = GetLineTypeIdFromName(db, entityObject.Linetype);
                        circle.LinetypeScale = entityObject.LinetypeScale;
                        circle.Visible = entityObject.Visible;
                        circle.LineWeight = entityObject.LineWeight;

                        ObjectId btrId;

                        // Open the Block table record for write
                        if (entityObject.BlockId == null)
                            btrId = blockTbl[BlockTableRecord.ModelSpace];
                        else
                            btrId = GetDwgObjectId(entityObject.BlockId);

                        using (BlockTableRecord btr = tr.GetObject(btrId, OpenMode.ForWrite) as BlockTableRecord)
                        {
                            // Add the new object to the block table record and the transaction
                            entityId = btr.AppendEntity(circle);
                            tm.AddNewlyCreatedDBObject(circle, true);
                        }

                    }

                    // restore the current line type for database from the temp variable
                    db.Celtype = current_linetypeId;

                }

                tr.Commit();
            }


            return entityId;
        }
    }
}

