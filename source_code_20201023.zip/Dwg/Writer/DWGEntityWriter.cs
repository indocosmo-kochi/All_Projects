﻿using System.Collections.Generic;
using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Colors;
using CWorksCXF.Common;

namespace CWorksCXF.DWG.Writer
{
    public abstract class DwgEntityWriter : IDwgEntityWriter
    {
        public Dictionary<string, ObjectId> ObjectIdMapperList { get; set; }

        public abstract ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject);

        protected ObjectId GetDwgObjectId(string CXFObjectId)
        {
            if (ObjectIdMapperList.ContainsKey(CXFObjectId))
            {
                return ObjectIdMapperList[CXFObjectId];
            }
            return new ObjectId();
        }

        protected Color GetDwgColor(CwcColor color)
        {
            if (color.ColorMethod == ColorMethod.ByColor)
                return Color.FromRgb((byte)color.Red, (byte)color.Green, (byte)color.Blue);
            else // ColorMethod.None ByAci ByLayer Foreground
                return Color.FromColorIndex(color.ColorMethod, color.ColorIndex);
                ;
            //if (color.ColorIndex == 8)
            //    return Color.FromRgb((byte)color.Red, (byte)color.Green, (byte)color.Blue);
            //else if (color.ColorIndex == 9)
            //    return Color.FromColorIndex((ColorMethod)color.ColorMethod, 256);
            //else if (color.ColorIndex == -1)
            //    return Color.FromColorIndex((ColorMethod)color.ColorMethod, 257);
            //else
            //    return Color.FromColorIndex((ColorMethod)color.ColorMethod, (short)color.ColorIndex);
        }


        protected ObjectId GetLineTypeIdFromName(Database db, string linetype)
        {
            ObjectId linetypeId;
            using (Transaction temptrans = db.TransactionManager.StartTransaction())
            {
                using (LinetypeTable acLineTypTbl = (LinetypeTable)db.LinetypeTableId.GetObject(OpenMode.ForRead))
                {
                    if (acLineTypTbl.Has(linetype) == false)
                    {
                        try
                        {
                            db.LoadLineTypeFile(linetype, CONST.ACAD_LINETYPES_FILE);
                            // sets the new line type as the current line type for database
                            db.Celtype = acLineTypTbl[linetype];
                        }
                        catch
                        {
                            linetypeId = acLineTypTbl["CONTINUOUS"];
                        }
                    }
                    linetypeId= acLineTypTbl[linetype];
                }
                temptrans.Abort();
            }
            return linetypeId;

        }


        protected void SetDimensionPropertyValues(Dimension dimension, CwcDimension cwcDimension)
        {
            dimension.Dimadec = cwcDimension.Dimadec;
            dimension.Dimalt = cwcDimension.Dimalt;
            dimension.Dimaltd = cwcDimension.Dimaltd;
            dimension.Dimaltf = cwcDimension.Dimaltf;
            dimension.Dimaltrnd = cwcDimension.Dimaltrnd;
            dimension.Dimalttd = cwcDimension.Dimalttd;
            dimension.Dimalttz = cwcDimension.Dimalttz;
            dimension.Dimaltu = cwcDimension.Dimaltu;
            dimension.Dimaltz = cwcDimension.Dimaltz;
            dimension.Dimapost = cwcDimension.Dimapost;
            dimension.Dimarcsym = cwcDimension.Dimarcsym;
            dimension.Dimasz = cwcDimension.Dimasz;
            dimension.Dimatfit = cwcDimension.Dimatfit;
            dimension.Dimaunit = cwcDimension.Dimaunit;
            dimension.Dimazin = cwcDimension.Dimazin;
            // If Dimsah is true, the arrowheads are formed by blocks set by the Dimblk1 and Dimblk2. If false, a block from Dimblk is used
            dimension.Dimsah = cwcDimension.Dimsah;
            if (cwcDimension.Dimsah)
            {
                if (cwcDimension.Dimblk1s.Length > 0)
                    dimension.Dimblk1s = cwcDimension.Dimblk1s;
                if (cwcDimension.Dimblk2s.Length > 0)
                    dimension.Dimblk2s = cwcDimension.Dimblk2s;
            }
            else
            {
                if (cwcDimension.Dimblks.Length > 0)
                    dimension.Dimblks = cwcDimension.Dimblks;
            }
            dimension.Dimcen = cwcDimension.Dimcen;
            dimension.Dimdec = cwcDimension.Dimdec;
            dimension.Dimdle = cwcDimension.Dimdle;
            dimension.Dimdli = cwcDimension.Dimdli;
            dimension.Dimdsep = cwcDimension.Dimdsep;
            dimension.Dimexe = cwcDimension.Dimexe;
            dimension.Dimexo = cwcDimension.Dimexo;
            dimension.Dimfrac = cwcDimension.Dimfrac;
            dimension.Dimfxlen = cwcDimension.Dimfxlen;
            dimension.DimfxlenOn = cwcDimension.DimfxlenOn;
            dimension.Dimgap = cwcDimension.Dimgap;
            dimension.Dimjogang = cwcDimension.Dimjogang;
            dimension.Dimjust = cwcDimension.Dimjust;
            if (cwcDimension.Dimldrblks.Length > 0)
                if (cwcDimension.Dimldrblks != "NONE")
                    dimension.Dimldrblks = cwcDimension.Dimldrblks;
            dimension.Dimlfac = cwcDimension.Dimlfac;
            dimension.Dimlim = cwcDimension.Dimlim;
            ////// Linetype Ext 1		
            dimension.Dimltex1 = GetDwgObjectId(cwcDimension.Dimltex1);
            //////////////// Linetype Ext 2
            dimension.Dimltex2 = GetDwgObjectId(cwcDimension.Dimltex2);
            /////////////////////////// Linetype
            dimension.Dimltype = GetDwgObjectId(cwcDimension.Dimltype);
            // 1..6 values
            if ((cwcDimension.Dimlunit >= 1) && (cwcDimension.Dimlunit <= 6))
                dimension.Dimlunit = cwcDimension.Dimlunit;
            //< Added by Suresh on 24-03-2020 >
            try
            {
                ////////////////////// Lineweight
                dimension.Dimlwd = cwcDimension.Dimlwd;
            }
            catch (System.Exception ex)
            {
                dimension.Dimlwd = LineWeight.ByLineWeightDefault;
                Logger.RecordMessage(ex, Logs.Log.MessageType.Error);
            }
            try
            {
                /////////////////////// Lineweight
                dimension.Dimlwe = cwcDimension.Dimlwe;
            }
            catch (System.Exception ex)
            {
                dimension.Dimlwe = LineWeight.ByLineWeightDefault;
                Logger.RecordMessage(ex, Logs.Log.MessageType.Error);
            }
            //</ Added by Suresh on 24-03-2020 >
            dimension.Dimpost = cwcDimension.Dimpost;
            dimension.Dimrnd = cwcDimension.Dimrnd;
            dimension.Dimscale = cwcDimension.Dimscale;
            dimension.Dimsd1 = cwcDimension.Dimsd1;
            dimension.Dimsd2 = cwcDimension.Dimsd2;
            dimension.Dimse1 = cwcDimension.Dimse1;
            dimension.Dimse2 = cwcDimension.Dimse2;
            dimension.Dimsoxd = cwcDimension.Dimsoxd;
            dimension.Dimtad = cwcDimension.Dimtad;
            dimension.Dimtdec = cwcDimension.Dimtdec;
            dimension.Dimtfac = cwcDimension.Dimtfac;
            dimension.Dimtfill = cwcDimension.Dimtfill;
            dimension.Dimtih = cwcDimension.Dimtih;
            dimension.Dimtix = cwcDimension.Dimtix;
            dimension.Dimtm = cwcDimension.Dimtm;
            dimension.Dimtmove = cwcDimension.Dimtmove;
            dimension.Dimtofl = cwcDimension.Dimtofl;
            dimension.Dimtoh = cwcDimension.Dimtoh;
            dimension.Dimtol = cwcDimension.Dimtol;
            dimension.Dimtolj = cwcDimension.Dimtolj;
            dimension.Dimtp = cwcDimension.Dimtp;
            dimension.Dimtsz = cwcDimension.Dimtsz;
            dimension.Dimtvp = cwcDimension.Dimtvp;
            dimension.Dimtxt = cwcDimension.Dimtxt;
            dimension.Dimtzin = cwcDimension.Dimtzin;
            dimension.Dimupt = cwcDimension.Dimupt;
            dimension.Dimzin = cwcDimension.Dimzin;

            dimension.Dimclrd = GetDwgColor(cwcDimension.Dimclrd);
            dimension.Dimclre = GetDwgColor(cwcDimension.Dimclre);
            dimension.Dimclrt = GetDwgColor(cwcDimension.Dimclrt);
            dimension.Dimtfillclr = GetDwgColor(cwcDimension.Dimtfillclr);

        }


    }
}
