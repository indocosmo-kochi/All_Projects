﻿using System;
using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Runtime;

namespace CWorksCXF.DWG.Writer
{
    public class DwgLayoutWriter : DwgEntityWriter
    {
        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {
            ObjectId layoutId;
            CwcLayout layout = cwcDbObject as CwcLayout;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                // save the current line type for database into a temp variable
                ObjectId current_linetypeId = db.Celtype;

                using (DBDictionary layoutDict = (DBDictionary)tm.GetObject(db.LayoutDictionaryId, OpenMode.ForRead))
                {
                    layoutId = layoutDict.GetAt(layout.LayoutName);
                    if (!layoutId.IsValid)
                    {
                        foreach (var layoutItem in layoutDict)
                        {
                            using (var layoutEntity = layoutItem.Value.GetObject(OpenMode.ForWrite) as Layout)
                            {
                                if (layoutEntity.TabOrder == layout.TabOrder)
                                {
                                    using (PlotSettings plotSet = new PlotSettings(layout.ModelType))
                                    {
                                        layoutEntity.UpgradeOpen();
                                        layoutEntity.LayoutName = layout.LayoutName;
                                        layoutEntity.PlotSettingsName = layout.PlotSettingsName;
                                        layoutId = layoutEntity.Id;
                                        layoutEntity.DowngradeOpen();
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }

                //if the layout is a new one, then add it
                if (!layoutId.IsValid && LayoutManager.Current != null)
                {
                    layoutId = LayoutManager.Current.CreateLayout(layout.LayoutName);
                }

                // restore the current line type for database from a temp variable
                db.Celtype = current_linetypeId;

                tr.Commit();
            }

            return layoutId;
        }

    }
}
