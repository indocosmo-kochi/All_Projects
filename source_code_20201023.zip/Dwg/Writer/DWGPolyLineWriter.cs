﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgPolyLineWriter : DwgEntityWriter
    {

        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId entityId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {

                using (BlockTable blockTbl = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable)
                {

                    // save the current line type for database into a temp variable
                    ObjectId current_linetypeId = db.Celtype;

                    CwcPolyline entityObject = cwcDbObject as CwcPolyline;
                    using (Polyline polyline = new Polyline(entityObject.NumberOfVertices))
                    {

                        for (int i = 0; i < entityObject.NumberOfVertices; i++)
                        {
                            polyline.AddVertexAt(i, new Point2d(entityObject.Vertices[i].X, entityObject.Vertices[i].Y),
                                                    entityObject.Bulge[i], entityObject.StartWidth[i], entityObject.EndWidth[i]);
                        }

                        if (entityObject.LayerId.Length > 0)
                            polyline.LayerId = GetDwgObjectId(entityObject.LayerId);

                        polyline.Color = GetDwgColor(entityObject.Color);
                        polyline.Visible = entityObject.Visible;

                        polyline.LinetypeId = GetLineTypeIdFromName(db, entityObject.Linetype);
                        polyline.LinetypeScale = entityObject.LinetypeScale;

                        polyline.LineWeight = entityObject.LineWeight;

                        polyline.Closed = entityObject.IsClosed;

                        ObjectId btrId;

                        // Open the Block table record for write
                        if (entityObject.BlockId == null)
                            btrId = blockTbl[BlockTableRecord.ModelSpace];
                        else
                            btrId = GetDwgObjectId(entityObject.BlockId);

                        using (BlockTableRecord btr = tr.GetObject(btrId, OpenMode.ForWrite) as BlockTableRecord)
                        {
                            // Add the new object to the block table record and the transaction
                            entityId = btr.AppendEntity(polyline);
                            tm.AddNewlyCreatedDBObject(polyline, true);
                        }

                    }

                    // restore the current line type for database from the temp variable
                    db.Celtype = current_linetypeId;

                }

                tr.Commit();
            }


            return entityId;
        }
    }
}
