﻿using CWorksCXF.Common;
using CWorksCXF.Entities;
using System;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgPlotSettingsWriter : DwgEntityWriter
    {
        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            TransactionManager tm = db.TransactionManager;
            ObjectId layoutId = new ObjectId();
            HostApplicationServices.WorkingDatabase = db;

            try
            {
                using (Transaction tr = tm.StartTransaction())
                {
                    var plotSetting = cwcDbObject as CwcPlotSettings;
                    var psValidator = PlotSettingsValidator.Current;
                    var modelLayoutName = string.Empty;
                    bool isLayoutPlotSettingSet = plotSetting.LayoutName.Trim() != string.Empty;

                    using (var layoutDict = tr.GetObject(db.LayoutDictionaryId, OpenMode.ForRead) as DBDictionary)
                    {
                        if (isLayoutPlotSettingSet)
                        {
                            layoutId = (ObjectId)layoutDict[plotSetting.LayoutName];
                        }

                        foreach (var dictItem in layoutDict)
                        {
                            using (var lay = dictItem.Value.GetObject(OpenMode.ForRead) as Layout)
                            {
                                if (lay.ModelType)
                                {
                                    modelLayoutName = lay.LayoutName;
                                }
                                else if (!isLayoutPlotSettingSet)
                                {
                                    layoutId = lay.Id;
                                }
                            }
                            if (layoutId.IsValid && modelLayoutName.Length > 0)
                            {
                                break;
                            }
                        }
                    }

                    using (var layout = tr.GetObject(layoutId, OpenMode.ForWrite) as Layout)
                    {
                        using (var plotSet = new PlotSettings(layout.ModelType))
                        {
                            LayoutManager.Current.CurrentLayout = layout.LayoutName;
                            plotSet.CopyFrom(layout);
                            plotSet.PlotSettingsName = plotSetting.Name;
                            plotSet.PlotHidden = plotSetting.PlotHidden;
                            plotSet.PlotPlotStyles = plotSetting.PlotPlotStyles;
                            plotSet.ShowPlotStyles = plotSetting.ShowPlotStyles;
                            plotSet.DrawViewportsFirst = plotSetting.PlotPaperspaceLast;

                            plotSet.PlotTransparency = plotSetting.PlotTransparency;
                            plotSet.PlotViewportBorders = plotSetting.PlotViewportBorders;
                            plotSet.PrintLineweights = plotSetting.PrintLineweights;
                            plotSet.ScaleLineweights = plotSetting.ScaleLineweights;
                            //plotSet.ShowPlotStyles = true;
                            var deviceList = psValidator.GetPlotDeviceList();

                            if (deviceList.Contains(plotSetting.PlotterName))
                            {
                                psValidator.SetPlotConfigurationName(plotSet, plotSetting.PlotterName, null);
                            }
                            psValidator.RefreshLists(plotSet);
                            var styleSheets = psValidator.GetPlotStyleSheetList();
                            var pageSizeList = psValidator.GetCanonicalMediaNameList(plotSet);
                            if (pageSizeList.Contains(plotSetting.MediaName))
                            {
                                psValidator.SetCanonicalMediaName(plotSet, plotSetting.MediaName);
                                psValidator.SetPlotPaperUnits(plotSet, (PlotPaperUnit)plotSetting.PlotPaperUnits);
                            }

                            //psValidator.SetCurrentStyleSheet(plotSet, "acad.ctlb"); 
                            if (styleSheets.Contains(plotSetting.CurrentStyleSheet))
                            {
                                psValidator.SetCurrentStyleSheet(plotSet, plotSetting.CurrentStyleSheet);
                            }
                            psValidator.SetPlotCentered(plotSet, plotSetting.PlotCentered);
                            psValidator.SetPlotRotation(plotSet, (PlotRotation)plotSetting.PlotRotation);
                            psValidator.SetPlotOrigin(plotSet, new Point2d(plotSetting.PlotOrigin.X, plotSetting.PlotOrigin.Y));
                            psValidator.SetPlotType(plotSet, (PlotType)plotSetting.PlotType);
                            //entity.ShowPlotStyles = plotSetting.PlotPlotStyles;
                            psValidator.SetCustomPrintScale(plotSet, new CustomScale(plotSetting.CustomPrintScaleNumerator,
                                                                plotSetting.CustomPrintScaleDenominator));
                            psValidator.SetUseStandardScale(plotSet, plotSetting.UseStandardScale);
                            if (plotSetting.UseStandardScale)
                            {
                                psValidator.SetStdScaleType(plotSet, (StdScaleType)plotSetting.StdScaleType);
                                psValidator.SetStdScale(plotSet, plotSetting.StdScale);
                            }

                            plotSet.AddToPlotSettingsDictionary(db);
                            var upgraded = false;
                            if (!layout.IsWriteEnabled && isLayoutPlotSettingSet)
                            {
                                upgraded = true;
                                layout.UpgradeOpen();
                            }
                            if (isLayoutPlotSettingSet)
                            {
                                layout.CopyFrom(plotSet);
                            }
                            if (upgraded)
                            {
                                layout.DowngradeOpen();
                            }

                            //set current layout to Model
                            if (modelLayoutName != string.Empty)
                            {
                                LayoutManager.Current.CurrentLayout = modelLayoutName;
                            }
                        }
                    }

                    tr.Commit();
                }
            }
            catch(Exception ex)
            {
                throw new CXFException("CreateDwgEntity", ex);
            }
            return layoutId;
        }
       
    }
}
