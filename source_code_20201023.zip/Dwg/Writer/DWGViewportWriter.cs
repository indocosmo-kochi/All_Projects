﻿using CWorksCXF.Entities;
using System;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgViewportWriter : DwgEntityWriter
    {
        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId viewportId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                // save the current line type for database into a temp variable
                ObjectId current_linetypeId = db.Celtype;

                CwcViewport viewport = cwcDbObject as CwcViewport;

                var targetBlockId = GetDwgObjectId(viewport.BlockId);


                using (BlockTableRecord btr = (BlockTableRecord)tm.GetObject(targetBlockId, OpenMode.ForWrite))
                {

                    Viewport viewportEntity = new Viewport();
                    viewportEntity.SetDatabaseDefaults();

                    //viewportEntity.Annotative = AnnotativeStates.True;
                    viewportEntity.Visible = viewport.Visible;
                    viewportEntity.BackClipOn = viewport.BackClipOn;
                    viewportEntity.CenterPoint = new Point3d(viewport.CenterPoint.X, viewport.CenterPoint.Y, viewport.CenterPoint.Z);
                    viewportEntity.Color = GetDwgColor(viewport.Color);
                    viewportEntity.CustomScale = viewport.CustomScale;
                    viewportEntity.Locked = viewport.DisplayLocked;
                    viewportEntity.FrontClipOn = viewport.FrontClipOn;
                    viewportEntity.GridOn = viewport.GridEnabled;
                    viewportEntity.GridIncrement = new Vector2d(viewport.GridIncrement.X, viewport.GridIncrement.Y);
                    viewportEntity.Height = viewport.Height;
                    viewportEntity.Width = viewport.Width;
                    viewportEntity.TwistAngle = viewport.TwistAngle;
                    viewportEntity.ViewCenter = new Point2d(viewport.ViewCenter.X, viewport.ViewCenter.Y);
                    viewportEntity.ViewHeight = viewport.ViewHeight;
                    viewportEntity.LayerId = GetDwgObjectId(viewport.LayerId);
                    viewportEntity.LinetypeId = GetDwgObjectId(viewport.LinetypeId);
                    viewportEntity.LinetypeScale = viewport.LinetypeScale;
                    viewportEntity.On = viewport.On;
                    //viewportEntity.ViewDirection
                    viewportEntity.ViewTarget = new Point3d(viewport.ViewTarget.X,
                                                            viewport.ViewTarget.Y, viewport.ViewTarget.Z);
                    viewportEntity.ViewDirection = new Vector3d(viewport.ViewDirection.X,
                                                            viewport.ViewDirection.Y, viewport.ViewDirection.Z);
                    //viewportEntity.PlotStyleName = viewport.PlotStyleName;
                    viewportEntity.ShadePlot = (ShadePlotType)viewport.ShadePlot;
                    if ((StandardScaleType)viewport.StandardScale != StandardScaleType.CustomScale)
                    {
                        viewportEntity.StandardScale = (StandardScaleType)viewport.StandardScale;
                    }
                    viewportEntity.Transparency = new Teigha.Colors.Transparency(Convert.ToByte(viewport.Transparency));
                    viewportEntity.UcsIconAtOrigin = viewport.UcsIconAtOrigin;
                    viewportEntity.UcsPerViewport = viewport.UcsPerViewport;
                    viewportEntity.VisualStyleId = GetDwgObjectId(viewport.VisualStyleId);

                    viewportId = btr.AppendEntity(viewportEntity);
                    tm.AddNewlyCreatedDBObject(viewportEntity, true);

                    //set annotation scale
                    var annotations = db.ObjectContextManager.GetContextCollection("ACDB_ANNOTATIONSCALES");
                    if (annotations.HasContext(viewport.AnnotationName))
                    {
                        viewportEntity.AnnotationScale = annotations.GetContext(viewport.AnnotationName) as AnnotationScale;
                    }

                }

                // restore the current line type for database from a temp variable
                db.Celtype = current_linetypeId;
                tr.Commit();
            }
            return viewportId;
        }
       
    }
}
