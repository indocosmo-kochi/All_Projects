﻿using CWorksCXF.Common;
using CWorksCXF.Entities;
using System.Linq;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgMLeaderStyleWriter : DwgEntityWriter
    {
        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {
            ObjectId entityId;
            TransactionManager tm = db.TransactionManager;

            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable blockTbl = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable)
                {
                    // save the current line type for database into a temp variable
                    ObjectId current_linetypeId = db.Celtype;

                    var entityObject = cwcDbObject as CwcMLeaderStyle;
                    //set mleader styles
                    using (DBDictionary mlStyles = tr.GetObject(db.MLeaderStyleDictionaryId, OpenMode.ForRead) as DBDictionary)
                    {
                        //if the mleader style exists use the existing one
                        if (mlStyles.Contains(entityObject.Name))
                        {
                            entityId = mlStyles.GetAt(entityObject.Name);

                            using (MLeaderStyle mlStyle = (MLeaderStyle)tm.GetObject(entityId, OpenMode.ForWrite))
                            {
                                mlStyle.UpgradeOpen();

                                SetLeaderStyle(mlStyle, entityObject);
                            }
                        }
                        else
                        {
                            using (MLeaderStyle mlStyle = new MLeaderStyle())
                            {
                                mlStyle.SetFromStyle();
                                SetLeaderStyle(mlStyle, entityObject);
                                // Add the new object to the block table record and the transaction
                                mlStyle.PostMLeaderStyleToDb(db, entityObject.Name);
                                tm.AddNewlyCreatedDBObject(mlStyle, true);
                                entityId = mlStyle.ObjectId;
                            }
                        }
                    }
                    // restore the current line type for database from the temp variable
                    db.Celtype = current_linetypeId;
                }

                tr.Commit();
            }

            return entityId;
        }
        /// <summary>
        /// Set properties that are read from the cxf file to the Mleader object
        /// </summary>
        /// <param name="mlStyle">Mleader style to set</param>
        /// <param name="entityObject">Source Mleader style</param>
        private void SetLeaderStyle(MLeaderStyle mlStyle, CwcMLeaderStyle entityObject)
        {
            mlStyle.ArrowSize = entityObject.ArrowSize;
            mlStyle.ArrowSymbolId = GetDwgObjectId(entityObject.ArrowSymbol);
            mlStyle.LeaderLineType = (LeaderType)entityObject.LeaderLineType;
            mlStyle.LeaderLineColor = GetDwgColor(entityObject.LeaderLineColor);
            mlStyle.LeaderLineTypeId = GetDwgObjectId(entityObject.LeaderLineTypeId);
            mlStyle.LeaderLineWeight = (LineWeight)entityObject.LeaderLineWeight;
            mlStyle.BreakSize = entityObject.BreakSize;
            mlStyle.MaxLeaderSegmentsPoints = entityObject.MaxLeaderSegmentsPoints;
            mlStyle.FirstSegmentAngleConstraint = (AngleConstraint)entityObject.FirstSegmentAngleConstraint;
            mlStyle.SecondSegmentAngleConstraint = (AngleConstraint)entityObject.SecondSegmentAngleConstraint;
            mlStyle.EnableLanding = entityObject.EnableLanding;
            mlStyle.LandingGap = entityObject.LandingGap;
            mlStyle.Annotative = (AnnotativeStates)entityObject.Annotative;
            mlStyle.EnableBlockScale = entityObject.EnableBlockScale;
            mlStyle.Scale = entityObject.Scale;
            mlStyle.ContentType = (ContentType)entityObject.ContentType;
            mlStyle.DoglegLength = entityObject.LandingDistance;
            //if (style.DefaultMText != null)
            //{
            //    style.DefaultMText.Contents = entityObject.DefaultContents;
            //}
            mlStyle.TextStyleId = GetDwgObjectId(entityObject.TextStyleId);
            mlStyle.TextAngleType = (TextAngleType)entityObject.TextAngleType;
            mlStyle.TextColor = GetDwgColor(entityObject.TextColor);
            mlStyle.TextHeight = entityObject.TextHeight;
            mlStyle.TextAlignAlwaysLeft = entityObject.TextAlignAlwaysLeft;
            mlStyle.EnableFrameText = entityObject.EnableFrameText;
            mlStyle.TextAttachmentDirection = (TextAttachmentDirection)entityObject.TextAttachmentDirection;
            if (entityObject.TextAttachmentType == 9)
            {
                mlStyle.SetTextAttachmentType(TextAttachmentType.AttachmentMiddleOfTop, LeaderDirectionType.RightLeader);
                mlStyle.SetTextAttachmentType(TextAttachmentType.AttachmentMiddleOfTop, LeaderDirectionType.LeftLeader);
            }
            else
            {
                mlStyle.TextAttachmentType = (TextAttachmentType)entityObject.TextAttachmentType;
            }
            //mlStyle.SetTextAttachmentType(TextAttachmentType.AttachmentMiddleOfTop, LeaderDirectionType.LeftLeader);
            //mlStyle.TextAttachmentType = (TextAttachmentType)entityObject.TextAttachmentType;
            if ((ContentType)entityObject.ContentType == ContentType.BlockContent)
            {
                mlStyle.BlockId = GetDwgObjectId(entityObject.LeaderStyleBlockId);
                mlStyle.BlockConnectionType = (BlockConnectionType)entityObject.BlockConnectionType;
                mlStyle.BlockScale = new Scale3d(entityObject.BlockScale.X, entityObject.BlockScale.Y, entityObject.BlockScale.Z);
            }
        }
    }
}
