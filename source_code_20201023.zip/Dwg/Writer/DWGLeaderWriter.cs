﻿using CWorksCXF.Common;
using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgLeaderWriter : DwgEntityWriter
    {
        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {
            ObjectId entityId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {

                using (BlockTable blockTbl = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable)
                {
                    // save the current line type for database into a temp variable
                    ObjectId current_linetypeId = db.Celtype;

                    CwcLeader entityObject = cwcDbObject as CwcLeader;
                    using (Leader leader = new Leader())
                    {
                        leader.SetDatabaseDefaults();
                        for (int i = 0; i < entityObject.NumVertices; i++)
                        {
                            leader.AppendVertex(new Point3d(entityObject.Vertices[i].X, entityObject.Vertices[i].Y, entityObject.Vertices[i].Z));
                        }

                        if (entityObject.TextStyleId.Length > 0)
                        {
                            leader.TextStyleId = GetDwgObjectId(entityObject.TextStyleId);
                        }

                        if (entityObject.LayerId.Length > 0)
                            leader.LayerId = GetDwgObjectId(entityObject.LayerId);

                        if (entityObject.Dimclrd != null)
                            leader.Dimclrd = GetDwgColor(entityObject.Dimclrd);

                        leader.LinetypeId = GetLineTypeIdFromName(db, entityObject.Linetype);
                        leader.Visible = entityObject.Visible;
                        leader.LinetypeScale = entityObject.LinetypeScale;
                        leader.LineWeight = (LineWeight)entityObject.LineWeight;
                        leader.HasArrowHead = entityObject.HasArrowHead;
                        leader.IsSplined = entityObject.IsSplined;
                        leader.Dimlwd = entityObject.Dimlwd;
                        leader.Dimldrblk = GetDwgObjectId(entityObject.Dimldrblk);
                        leader.Dimasz = entityObject.Dimasz;
                        leader.Dimgap = entityObject.Dimgap;
                        leader.Dimscale = entityObject.Dimscale;
                        leader.Dimtxt = entityObject.Dimtxt;
                        leader.Dimtad = entityObject.Dimtad;

                        if (entityObject.DimensionStyle.Length > 0)
                            leader.DimensionStyle = GetDwgObjectId(entityObject.DimensionStyle);

                        //< Added by Suresh on 24-03-2020 >
                        try
                        {
                            if (entityObject.Dimblks.Length > 0)
                            {
                                ObjectId id;
                                using (DimStyleTableRecord dimStyle = (DimStyleTableRecord)leader.DimensionStyle.GetObject(OpenMode.ForWrite, true, true))
                                {
                                    ObjectId savedId = dimStyle.Dimblk1;
                                    dimStyle.Dimblk1s = entityObject.Dimblks;
                                    id = dimStyle.Dimblk1;
                                    dimStyle.Dimblk1 = savedId;
                                }
                                leader.Dimldrblk = id;
                            }
                        }
                        catch (System.Exception ex)
                        {
                            //const string arrowName = "";
                            //ObjectId arrId = GetArrowObjectId(db,arrowName);
                            //leader.Dimldrblk = arrId;
                            Logger.RecordMessage(ex, Logs.Log.MessageType.Error);
                        }
                        //</ Added by Suresh on 24-03-2020 >



                        if ((entityObject.AnnoType == AnnotationType.MText) && (entityObject.Annotation.Length > 0))
                            leader.Annotation = GetDwgObjectId(entityObject.Annotation);

                        ObjectId btrId;

                        // Open the Block table record for write
                        if (entityObject.BlockId == null)
                            btrId = blockTbl[BlockTableRecord.ModelSpace];
                        else
                            btrId = GetDwgObjectId(entityObject.BlockId);

                        using (BlockTableRecord btr = tr.GetObject(btrId, OpenMode.ForWrite) as BlockTableRecord)
                        {
                            // Add the new object to the block table record and the transaction
                            entityId = btr.AppendEntity(leader);
                            tm.AddNewlyCreatedDBObject(leader, true);
                        }
                    }

                    // restore the current line type for database from the temp variable
                    db.Celtype = current_linetypeId;

                }

                tr.Commit();
            }

            return entityId;
        }
    }
}
