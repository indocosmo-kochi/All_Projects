﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgMLeaderWriter : DwgEntityWriter
    {
        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {
            ObjectId entityId;
            TransactionManager tm = db.TransactionManager;

            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable blockTbl = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable)
                {
                    // save the current line type for database into a temp variable
                    ObjectId current_linetypeId = db.Celtype;

                    var entityObject = cwcDbObject as CwcMLeader;
                    
                    using (MLeader leader = new MLeader())
                    {
                        if (entityObject.LayerId?.Length > 0)
                            leader.LayerId = GetDwgObjectId(entityObject.LayerId);

                        leader.SetDatabaseDefaults();
                        leader.ContentType = (ContentType)entityObject.ContentType;
                        leader.ArrowSize = entityObject.ArrowSize;
                        leader.ArrowSymbolId = GetDwgObjectId(entityObject.ArrowSymbol);
                        leader.LeaderLineType = (LeaderType)entityObject.LeaderLineType;
                        leader.LeaderLineColor = GetDwgColor(entityObject.LeaderLineColor);
                        leader.LeaderLineTypeId = GetDwgObjectId(entityObject.LeaderLineTypeId);
                        leader.LeaderLineWeight = (LineWeight)entityObject.LeaderLineWeight;
                        leader.EnableLanding = entityObject.EnableLanding;
                        leader.LandingGap = entityObject.LandingGap;
                        leader.LinetypeScale = entityObject.Scale;
                        leader.Annotative = (AnnotativeStates)entityObject.Annotative;
                        leader.EnableAnnotationScale = leader.Annotative == AnnotativeStates.True ? true : false;
                        leader.EnableFrameText = entityObject.EnableFrameText;
                        leader.MLeaderStyle = GetDwgObjectId(entityObject.MLeaderStyleId);
                        leader.DoglegLength = entityObject.LandingDistance;

                        //read annotative property
                        if (leader.EnableAnnotationScale)
                        {
                            ObjectContextCollection contextCollection = db.ObjectContextManager.GetContextCollection("ACDB_ANNOTATIONSCALES");
                            foreach (var context in contextCollection)
                            {
                                //remove default context
                                if (context is AnnotationScale
                                    && leader.HasContext(context))
                                    leader.RemoveContext(context);
                                //add context
                                if (context is AnnotationScale
                                    && !leader.HasContext(context)
                                    && ((AnnotationScale)context).Name == entityObject.AnnotationName)
                                {
                                    leader.AddContext(context);
                                }
                            }
                        }
                        //content type
                        if ((ContentType)entityObject.ContentType == ContentType.MTextContent)
                        {
                            using (MText text = new MText())
                            {
                                text.SetDatabaseDefaults();
                                text.Attachment = (AttachmentPoint)entityObject.TextJustification;
                                text.Contents = entityObject.Contents;
                                text.TextHeight = entityObject.TextHeight;
                                text.Location = new Point3d(entityObject.ContentLocation.X,
                                                                entityObject.ContentLocation.Y,
                                                                entityObject.ContentLocation.Z);
                                leader.MText = text;
                                leader.TextStyleId = GetDwgObjectId(entityObject.TextStyleId);
                                leader.TextAngleType = (TextAngleType)entityObject.TextAngleType;
                                leader.TextColor = GetDwgColor(entityObject.TextColor);
                                leader.TextHeight = entityObject.TextHeight;
                                leader.EnableFrameText = entityObject.EnableFrameText;
                                leader.TextAttachmentDirection = (TextAttachmentDirection)entityObject.TextAttachmentDirection;
                                if (entityObject.TextAttachmentType == 9)
                                {
                                    leader.SetTextAttachmentType(TextAttachmentType.AttachmentMiddleOfTop, LeaderDirectionType.RightLeader);
                                    leader.SetTextAttachmentType(TextAttachmentType.AttachmentMiddleOfTop, LeaderDirectionType.LeftLeader);
                                }
                                else
                                {
                                    leader.TextAttachmentType = (TextAttachmentType)entityObject.TextAttachmentType;
                                }
                            }
                        }
                        if ((ContentType)entityObject.ContentType == ContentType.BlockContent)
                        {
                            leader.BlockContentId = GetDwgObjectId(entityObject.SourceBlockId);
                            leader.BlockScale = new Scale3d(entityObject.BlockScale.X, entityObject.BlockScale.Y, entityObject.BlockScale.Z);
                            leader.BlockConnectionType = (BlockConnectionType)entityObject.BlockConnectionType;
                            leader.BlockPosition = new Point3d(entityObject.ContentLocation.X,
                                                                entityObject.ContentLocation.Y,
                                                                entityObject.ContentLocation.Z);

                            using (BlockTableRecord blkRecord = leader.BlockContentId.GetObject(OpenMode.ForWrite) as BlockTableRecord)
                            {
                                //Matrix3d transfo = Matrix3d.Displacement(leader.BlockPosition.GetAsVector());
                                foreach (ObjectId blkEntityId in blkRecord)
                                {
                                    var obj = blkEntityId.GetObject(OpenMode.ForWrite);
                                    AttributeDefinition attrDef = blkEntityId.GetObject(OpenMode.ForWrite) as AttributeDefinition;
                                   
                                    if (attrDef != null)
                                    {
                                        var entityBlockRef = entityObject.BlockAttributes.Find(item => item.Key == attrDef.Tag);
                                        AttributeReference attrRef = new AttributeReference();
                                        attrRef.SetDatabaseDefaults(); 
                                        //attrRef.SetAttributeFromBlock(attrDef, transfo);
                                        //attrRef.Position = attrDef.Position.TransformBy(transfo);

                                        attrRef.Tag = entityBlockRef.Key;
                                        attrRef.TextString = entityBlockRef.Value;
                                        leader.SetBlockAttribute(blkEntityId, attrRef);
                                        tr.AddNewlyCreatedDBObject(attrRef, true);
                                    }
                                }
                            }
                        }

                        for (int i = 0; i < entityObject.LeaderCount; i++)
                        {
                            int idx = leader.AddLeaderLine(new Point3d(entityObject.NockPoint.X,
                                                                    entityObject.NockPoint.Y,
                                                                    entityObject.NockPoint.Z));
                            leader.AddFirstVertex(idx, new Point3d(entityObject.HeaderPoints[i].X, 
                                                            entityObject.HeaderPoints[i].Y, 
                                                            entityObject.HeaderPoints[i].Z));
                        }

                        ObjectId btrId;

                        // Open the Block table record for write
                        if (entityObject.BlockId == null)
                            btrId = blockTbl[BlockTableRecord.ModelSpace];
                        else
                            btrId = GetDwgObjectId(entityObject.BlockId);

                        using (BlockTableRecord btr = tr.GetObject(btrId, OpenMode.ForWrite) as BlockTableRecord)
                        {
                            // Add the new object to the block table record and the transaction
                            entityId = btr.AppendEntity(leader);
                            tm.AddNewlyCreatedDBObject(leader, true);
                        }
                        
                    }
                    // restore the current line type for database from the temp variable
                    db.Celtype = current_linetypeId;
                }

                tr.Commit();
            }

            return entityId;
        }
    }
}
