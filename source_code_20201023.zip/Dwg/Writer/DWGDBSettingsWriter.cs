﻿using CWorksCXF.Entities;
using System;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Writer
{
    public class DwgDBSettingsWriter 
    {

        public void SetDBSettings(Database db, CwcDBSettings dbSettings)
        {
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                db.Pdmode = dbSettings.Pdmode;
                db.Pdsize = dbSettings.Pdsize;
                db.Ltscale = dbSettings.Ltscale;
                db.Measurement = (MeasurementValue)dbSettings.Measurement;

                //dbSettings UnitsValue.Millimeters;
                db.Insunits = (UnitsValue)dbSettings.Unit; 
                // LightingUnits.LightingUnitsInternational
                db.LightingUnits = (Byte)dbSettings.LightingUnit;

                tr.Commit();
            }

        }
    }
}
