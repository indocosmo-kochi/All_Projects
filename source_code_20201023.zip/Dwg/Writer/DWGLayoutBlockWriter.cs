﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgLayoutBlockWriter : DwgEntityWriter
    {

        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId btrId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (DBDictionary blockTbl = tr.GetObject(db.LayoutDictionaryId, OpenMode.ForRead) as DBDictionary)
                {
                    CwcLayoutBlock entityObject = cwcDbObject as CwcLayoutBlock;

                    using (var layout = tr.GetObject(blockTbl.GetAt(entityObject.LayoutName), OpenMode.ForRead) as Layout)
                    {
                        //get layout block table record id
                        btrId = layout.BlockTableRecordId;
                    }
                }
                tr.Commit();
            }


            return btrId;
        }
    }
}
