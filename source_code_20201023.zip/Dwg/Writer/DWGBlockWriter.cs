﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgBlockWriter : DwgEntityWriter
    {

        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId btrId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable blockTbl = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable)
                {

                    //// save the current line type for database into a temp variable
                    //ObjectId current_linetypeId = db.Celtype;

                    CwcBlock entityObject = cwcDbObject as CwcBlock;

                    btrId = blockTbl[entityObject.Name];
                    if (btrId.IsNull)
                    {
                        using (BlockTableRecord btr = new BlockTableRecord())
                        {
                            btr.Name = entityObject.Name;
                            blockTbl.UpgradeOpen();
                            btrId = blockTbl.Add(btr);

                            tm.AddNewlyCreatedDBObject(btr, true);
                        }
                    }

                    //// restore the current line type for database from the temp variable
                    //db.Celtype = current_linetypeId;
                }
                tr.Commit();
            }


            return btrId;
        }
    }
}
