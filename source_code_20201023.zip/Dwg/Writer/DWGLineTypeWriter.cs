﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgLineTypeWriter : DwgEntityWriter
    {
       
        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId linetypeId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {

                var setLineTypeAttributes = new System.Action<CwcLineType, LinetypeTableRecord>((src, dest) => {
                    dest.Name = src.Name;
                    dest.Comments = src.Comments;
                    dest.NumDashes = src.NumDashes;
                    dest.PatternLength = src.PatternLength;
                    dest.IsScaledToFit = src.IsScaledToFit;
                    for (int i = 0; i < src.NumDashes; i++)
                    {
                        dest.SetDashLengthAt(i, src.LTDetails[i].DashLengthAt);
                        dest.SetShapeNumberAt(i, src.LTDetails[i].ShapeNumberAt);

                        if (src.LTDetails[i].ShapeNumberAt != 0)
                        {

                            using (TextStyleTable tst = (TextStyleTable)tr.GetObject(db.TextStyleTableId, OpenMode.ForRead))
                            {
                                ObjectId textstyleId = ObjectId.Null;
                                textstyleId = tst[src.LTDetails[i].ShapeStyleFileName];
                                if (textstyleId == ObjectId.Null)
                                {
                                    using (TextStyleTableRecord tstr = new TextStyleTableRecord())
                                    {
                                        tstr.Name = src.LTDetails[i].ShapeStyleFileName;
                                        tstr.FileName = src.LTDetails[i].ShapeStyleFileName;
                                        tst.UpgradeOpen();
                                        textstyleId = tst.Add(tstr);
                                        tm.AddNewlyCreatedDBObject(tstr, true);
                                    }
                                }
                                dest.SetShapeStyleAt(i, textstyleId);
                            }


                            if (src.LTDetails[i].ShapeScaleAt != 0.0)
                            {
                                dest.SetShapeScaleAt(i, src.LTDetails[i].ShapeScaleAt);
                            }
                            if (src.LTDetails[i].ShapeRotationAt != 0)
                            {
                                dest.SetShapeRotationAt(i, src.LTDetails[i].ShapeRotationAt);
                            }
                            if ((src.LTDetails[i].ShapeOffsetAt.X != 0) || (src.LTDetails[i].ShapeOffsetAt.Y != 0))
                            {
                                Vector2d shapeOffset = new Vector2d(src.LTDetails[i].ShapeOffsetAt.X, src.LTDetails[i].ShapeOffsetAt.Y);
                                dest.SetShapeOffsetAt(i, shapeOffset);
                            }
                        }

                    }
                });

                using (LinetypeTable ltt = (LinetypeTable)tm.GetObject(db.LinetypeTableId, OpenMode.ForRead))
                {

                    CwcLineType linetype = cwcDbObject as CwcLineType;

                    if (ltt.Has(linetype.Name))
                    {
                        linetypeId = ltt[linetype.Name];
                        using (LinetypeTableRecord lttr = (LinetypeTableRecord)tm.GetObject(linetypeId, OpenMode.ForWrite))
                        {
                            ltt.UpgradeOpen();
                            setLineTypeAttributes(linetype, lttr);
                        }
                    }
                    else
                    {
                        using (LinetypeTableRecord lttr = new LinetypeTableRecord())
                        {
                            setLineTypeAttributes(linetype, lttr);
                            ltt.UpgradeOpen();
                            linetypeId = ltt.Add(lttr);
                            tm.AddNewlyCreatedDBObject(lttr, true);
                        }
                    }
                }
                tr.Commit();
            }
            return linetypeId;
        }
    }
}

