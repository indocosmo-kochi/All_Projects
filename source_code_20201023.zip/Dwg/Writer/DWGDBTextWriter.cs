﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgDBTextWriter : DwgEntityWriter
    {

        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId entityId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable blockTbl = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable)
                {

                    CwcDBText entityObject = cwcDbObject as CwcDBText;

                    using (DBText dbtext = new DBText())
                    {

                        dbtext.TextString = entityObject.TextString;

                        Point3d position = new Point3d(entityObject.Position.X, entityObject.Position.Y, entityObject.Position.Z);
                        dbtext.Position = position;

                        dbtext.SetDatabaseDefaults();
                        dbtext.Visible = entityObject.Visible;
                        dbtext.Height = entityObject.Height;
                        //if (!entityObject.IsDefaultAlignment)
                            dbtext.AlignmentPoint = new Point3d(entityObject.AlignmentPoint.X, entityObject.AlignmentPoint.Y, entityObject.AlignmentPoint.Z);
                        dbtext.HorizontalMode = entityObject.HorizontalMode;
                        dbtext.VerticalMode = entityObject.VerticalMode;

                        dbtext.Justify = entityObject.Justify;
                        dbtext.Normal = new Vector3d(entityObject.Normal.X, entityObject.Normal.Y, entityObject.Normal.Z);
                        dbtext.Oblique = entityObject.Oblique;
                        dbtext.Rotation = entityObject.Rotation;
                        dbtext.Thickness = entityObject.Thickness;

                        dbtext.IsMirroredInX = entityObject.IsMirroredInX;
                        dbtext.IsMirroredInY = entityObject.IsMirroredInY;

                        dbtext.WidthFactor = entityObject.WidthFactor;

                        if (entityObject.TextStyleId.Length > 0)
                            dbtext.TextStyleId = GetDwgObjectId(entityObject.TextStyleId);

                        if (entityObject.LayerId.Length > 0)
                            dbtext.LayerId = GetDwgObjectId(entityObject.LayerId);

                        dbtext.Color = GetDwgColor(entityObject.Color);


                        ObjectId btrId;

                        // Open the Block table record for write
                        if (entityObject.BlockId == null)
                            btrId = blockTbl[BlockTableRecord.ModelSpace];
                        else
                            btrId = GetDwgObjectId(entityObject.BlockId);

                        using (BlockTableRecord btr = tr.GetObject(btrId, OpenMode.ForWrite) as BlockTableRecord)
                        {
                            // Add the new object to the block table record and the transaction
                            entityId = btr.AppendEntity(dbtext);
                            tm.AddNewlyCreatedDBObject(dbtext, true);
                        }

                    }
                }

                tr.Commit();
            }


            return entityId;
        }
    }
}
