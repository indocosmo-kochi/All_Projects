﻿using CWorksCXF.Common;
using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgLayerWriter : DwgEntityWriter
    {
        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId layerId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (LayerTable lt = (LayerTable)tm.GetObject(db.LayerTableId, OpenMode.ForRead))
                {

                    // save the current line type for database into a temp variable
                    ObjectId current_linetypeId = db.Celtype;

                    CwcLayer layer = cwcDbObject as CwcLayer;

                    if (lt.Has(layer.Name))
                    {
                        layerId = lt[layer.Name];
                        using (LayerTableRecord ltr = (LayerTableRecord)tm.GetObject(layerId, OpenMode.ForWrite))
                        {
                            lt.UpgradeOpen();
                            ltr.Color = GetDwgColor(layer.Color);
                            ltr.IsLocked = layer.IsLocked;
                            ltr.IsHidden = layer.IsHidden;
                            ltr.IsPlottable = layer.IsPlottable;
                            ltr.IsOff = layer.IsOff;

                            ltr.LinetypeObjectId = GetLineTypeIdFromName(db, layer.LineType);
                            ltr.LineWeight = (LineWeight)layer.LineWeight;

                        }


                    }
                    else
                    {
 
                        using (LayerTableRecord ltr = new LayerTableRecord())
                        {
                            ltr.Name = layer.Name;
                            ltr.Color = GetDwgColor(layer.Color);
                            ltr.IsLocked = layer.IsLocked;
                            ltr.IsHidden = layer.IsHidden;
                            ltr.IsPlottable = layer.IsPlottable;
                            ltr.IsOff = layer.IsOff;

                            if (layer.LineType != null)
                            {
                                ltr.LinetypeObjectId = GetLineTypeIdFromName(db, layer.LineType);
                            }

                            ltr.LineWeight = (LineWeight)layer.LineWeight;

                            lt.UpgradeOpen();
                            layerId = lt.Add(ltr);
                            tm.AddNewlyCreatedDBObject(ltr, true);

                        }
                    }

                    // restore the current line type for database from a temp variable
                    db.Celtype = current_linetypeId;
                }
                tr.Commit();
            }
            return layerId;
        }
    }
}
