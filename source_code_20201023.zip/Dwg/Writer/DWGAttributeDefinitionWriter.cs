﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgAttributeDefinitionWriter : DwgEntityWriter
    {

        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId entityId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable blockTbl = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable)
                {

                    //// save the current line type for database into a temp variable
                    //ObjectId current_linetypeId = db.Celtype;

                    var entityObject = cwcDbObject as CwcAttributeDefinition;
                    ObjectId btrId;
                    // Open the Block table record for write
                    if (entityObject.BlockId == null)
                        btrId = blockTbl[BlockTableRecord.ModelSpace];
                    else
                        btrId = GetDwgObjectId(entityObject.BlockId);

                    using (BlockTableRecord btr = tr.GetObject(btrId, OpenMode.ForWrite) as BlockTableRecord)
                    {
                        using (AttributeDefinition attrDef = new AttributeDefinition())
                        {
                            attrDef.Position = new Point3d(entityObject.Position.X,
                                                            entityObject.Position.Y,
                                                            entityObject.Position.Z);
                            attrDef.AlignmentPoint = new Point3d(entityObject.AlignmentPoint.X,
                                                            entityObject.AlignmentPoint.Y,
                                                            entityObject.AlignmentPoint.Z);
                            attrDef.Tag = entityObject.Tag;
                            attrDef.TextString = entityObject.TextString;
                            attrDef.Constant = entityObject.Constant;
                            if (!entityObject.Constant)
                            {
                                attrDef.Prompt = entityObject.Prompt;
                                attrDef.Preset = entityObject.Preset;
                                attrDef.Verifiable = entityObject.Verifiable;
                            }
                            attrDef.Color = GetDwgColor(entityObject.Color);
                            attrDef.Invisible = entityObject.Invisible;
                            attrDef.LockPositionInBlock = entityObject.LockPositionInBlock;
                            attrDef.Oblique = entityObject.Oblique;
                            attrDef.Rotation = entityObject.Rotation;
                            attrDef.WidthFactor = entityObject.WidthFactor;
                            attrDef.Height = entityObject.Height;
                            attrDef.FieldLength = entityObject.FieldLength;
                            attrDef.Justify = entityObject.Justify;
                            attrDef.Annotative = entityObject.Annotative;
                            attrDef.IsMirroredInX = entityObject.IsMirroredInX;
                            attrDef.IsMirroredInY = entityObject.IsMirroredInY;

                            if (entityObject.IsMTextAttributeDefinition)
                            {
                                MText mtext = new MText();
                                mtext.Width = entityObject.MTextWidth;
                                mtext.Contents = entityObject.MTextContents;
                                btr.AppendEntity(mtext);
                                attrDef.MTextAttributeDefinition = mtext;
                                attrDef.IsMTextAttributeDefinition = entityObject.IsMTextAttributeDefinition;
                            }

                            if (entityObject.TextStyleId.Length > 0)
                                attrDef.TextStyleId = GetDwgObjectId(entityObject.TextStyleId);

                            if (entityObject.LayerId.Length > 0)
                                attrDef.LayerId = GetDwgObjectId(entityObject.LayerId);


                            // Add the new object to the block table record and the transaction
                            entityId = btr.AppendEntity(attrDef);
                            tm.AddNewlyCreatedDBObject(attrDef, true);
                        }


                    }
                }
                tr.Commit();
            }

            return entityId;
        }
    }
}
