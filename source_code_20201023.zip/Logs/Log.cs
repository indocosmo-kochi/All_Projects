﻿using CWorksCXF.Common;
using System;

namespace CWorksCXF.Logs
{
    /// <remarks>  /// Abstract class to dictate the format for the logs that our   /// logger will use.  /// </remarks>  
    public abstract class Log
    {
        /// <value>Available message severities</value>   
        public enum MessageType
        {     /// <value>Informational message</value>     
            Informational = 1,     /// <value>Failure audit message</value>     
            Failure = 2,     /// <value>Warning message</value>     
            Warning = 3,     /// <value>Error message</value>     
            Error = 4,
            Exception = 5
        }

        public abstract void RecordMessage(CXFException Message, MessageType Severity);

        public abstract void RecordMessage(Exception Message, MessageType Severity);

        public abstract void RecordMessage(string Message, MessageType Severity);
    }
}
