﻿using CWorksCXF.Common;
using System;
using System.IO;
using System.Text;

namespace CWorksCXF.Logs
{
    public class FileLog : Log
    {   // Internal log file name value   
        public string FileName { get; set; }

        // Internal log file location value   
        private string _FileLocation = "";

        //current process name
        private string _source;
        private string _target;
        private string _stackTrace;

       
        public string FileLocation
        {
            get { return this._FileLocation; }
            set
            {
                this._FileLocation = value;  
                // Verify a '\' exists on the end of the location       
                if (this._FileLocation.LastIndexOf("\\") != (this._FileLocation.Length - 1))
                {
                    this._FileLocation += "\\";
                }
            }
        }

        private bool isFileCreate = false;

        public FileLog()
        {
            DirectoryInfo parentDir = Directory.GetParent(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location));
            this.FileLocation = parentDir.FullName + "\\logs\\"; 
            this.FileName = "CWORKSCXF.LOG";
            isFileCreate = true;
        }

        public override void RecordMessage(Exception exception, Log.MessageType severity)
        {
            _source = exception.TargetSite.ReflectedType.Name;
            _target = exception.TargetSite.Name;
            _stackTrace = exception.StackTrace;
            this.RecordMessage(exception.Message, severity);
        }

        public override void RecordMessage(CXFException exception, Log.MessageType severity)
        {
            _source = exception.Source;
            _target = exception.Property;
            _stackTrace = exception.StackTrace;
            this.RecordMessage(exception.Message, severity);
        }


        public override void RecordMessage(string Message, Log.MessageType Severity)
        {
            FileStream fileStream = null;
            StreamWriter writer = null;
            StringBuilder message = new StringBuilder();
            try
            {
                if (isFileCreate)
                {
                    fileStream = new FileStream(this._FileLocation + this.FileName, FileMode.Create, FileAccess.Write);
                    isFileCreate = false;
                }
                else
                {
                    fileStream = new FileStream(this._FileLocation + this.FileName, FileMode.OpenOrCreate, FileAccess.Write);
                }
                writer = new StreamWriter(fileStream);        
                // Set the file pointer to the end of the file      
                writer.BaseStream.Seek(0, SeekOrigin.End);
                // Create the message        
                message.Append(System.DateTime.Now.ToString()).Append(",");
                if (Severity == MessageType.Error)
                {
                    message.Append(" Error at ").Append(_target).Append(", ").Append(_source);
                }
                message.Append(" ").Append(Message);
                // Force the write to the underlying file      
                writer.WriteLine(message.ToString());
                writer.Flush();
            }
            finally
            {
                if (writer != null)
                    writer.Close();
            }
        }
    }

}
