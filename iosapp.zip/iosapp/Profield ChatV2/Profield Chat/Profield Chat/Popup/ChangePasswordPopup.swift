//
//  ChangePasswordPopup.swift
//  Profield Chat
//
//  Created by Apple on 18/01/19.
//  Copyright © 2019 indocosmo. All rights reserved.
//

import UIKit

class ChangePasswordPopup: UIViewController {
    @IBOutlet weak var txtCurrentPassword: UITextField!
    @IBOutlet weak var txtConfirmPassword: UITextField!
    @IBOutlet weak var txtNewPassword: UITextField!
    @IBOutlet weak var viewBg: UIView!
    
    //MARK:- viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        screenSetup()
    }
    func screenSetup()
    {
        viewBg.layer.cornerRadius = 5
        txtNewPassword.setBottomBorder()
        txtConfirmPassword.setBottomBorder()
        txtCurrentPassword.setBottomBorder()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func SubmitACtion(_ sender: Any) {
        if txtCurrentPassword.text == ""
        {
            AppHelper.showAlertMessage(vc: self, title: "", message:"Please enter your current password")
        }
        else  if txtNewPassword.text == ""
        {
            AppHelper.showAlertMessage(vc: self, title: "", message:"Please enter your new password")
        }
        else  if txtConfirmPassword.text == ""
        {
            AppHelper.showAlertMessage(vc: self, title: "", message:"Please enter confirm password")
        }
        else  if txtNewPassword.text != txtConfirmPassword.text
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "New Password and confirm password do not match.")
        }
        else if(txtConfirmPassword.text?.count)! < 6
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "minimum password length is 6 characters.")
        }
            
        else
        {
            AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
            let accessToken = UserDefaults.standard.value(forKey: "accessToken")
            let tokenType = UserDefaults.standard.value(forKey: "tokenType")
            let  userId = UserDefaults.standard.value(forKey: "userId") as! String
            let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
            let par = ["Authorization": headerrr]
            let apiUrl = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.changePassword)
            var customAllowedSet =  NSCharacterSet(charactersIn:"=\"#%/<>&?@\\^`{|}").inverted
            let newPassword = txtNewPassword.text!.addingPercentEncoding(withAllowedCharacters:customAllowedSet)
            let oldPassword = txtCurrentPassword.text!.addingPercentEncoding(withAllowedCharacters: customAllowedSet)
            let url = String(format: "%@?userId=%@&currentPass=%@&newPassword=%@", apiUrl,userId,oldPassword!,newPassword!)
            APiClass.apiCallGetWithHeader(mainUrl: url, postParameters: par) { (responseArray) in
                AppHelper.HidePrograss(vc: self.view)
                let responseDict = responseArray[0]
                if (responseDict.object(forKey: "error") != nil)
                {
                    let message = responseDict["error"]
                    AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
                }
                else
                {
                    let arrayAllResponse = responseDict["value"] as! NSArray
                    let arrayResponse = arrayAllResponse[0] as! [String:Any]
                    let msg = arrayResponse["status"] as! String
                    if msg == "success"
                    {
                        let actionSheetController: UIAlertController = UIAlertController(title: "Password changed successfully", message: "", preferredStyle: .alert)
                        let cancelAction: UIAlertAction = UIAlertAction(title: "OK", style: .cancel) { action -> Void in
                            self.dismiss(animated: true, completion:{
                            } )
                        }
                        actionSheetController.addAction(cancelAction)
                        self.present(actionSheetController, animated: true, completion: nil)
                    }
                    else
                    {
                        if msg == "currentPasswordWorng."
                        {
                            AppHelper.showAlertMessage(vc: self, title: "", message:"Current Password is wrong.")
                        }
                        else
                        {
                            AppHelper.showAlertMessage(vc: self, title: "", message:msg)
                        }
                    }
                    
                }
            }
        }
    }
    @IBAction func dismiss(_ sender: Any) {
        self.dismiss(animated: true, completion:{
        } )
    }
}
