//
//  ViewMorePopup.swift
//  Profield Chat
//
//  Created by Apple on 03/09/19.
//  Copyright © 2019 indocosmo. All rights reserved.
//

import UIKit
import SDWebImage
class ViewMorePopup: UIViewController,UITableViewDataSource,UITableViewDelegate {
    @IBOutlet weak var bgVuew: UIView!
    var arrayList = [[String:Any]]()
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblCategory: UILabel!
    @IBOutlet weak var lblshortTilte: UILabel!
    @IBOutlet weak var tbl: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        bgVuew.layer.cornerRadius = 4
        UserDefaults.standard.set("yes", forKey: "viewMoreScreen")
        getmoreproductdetails()
        lblTitle.text = self.stringReplace(stingValue:UserDefaults.standard.value(forKey: "productName") as! String )
        lblCategory.text = self.stringReplace(stingValue:UserDefaults.standard.value(forKey: "Category") as! String)
        lblshortTilte.text = self.stringReplace(stingValue:UserDefaults.standard.value(forKey: "productTitle") as! String)
        var link = UserDefaults.standard.value(forKey: "productImageUrl") as! String
        let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
        link = link.replacingOccurrences(of: "/", with: "-")
        var imgUrl = String(format: "%@/api/attachmentsByPath/%@", apiUrl,link)
        imgUrl = imgUrl.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        img.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
    }
    override func viewWillAppear(_ animated: Bool) {
        let nc = NotificationCenter.default
        nc.addObserver(self, selector: #selector(notificationObserver), name: Notification.Name("viewMoreSocketPush"), object: nil)
    }
    override func viewWillDisappear(_ animated: Bool) {
        UserDefaults.standard.set("no", forKey: "viewMoreScreen")
        let nc = NotificationCenter.default
        nc.removeObserver("viewMoreSocketPush")
    }
    @objc func notificationObserver()
    {
        lblTitle.text = self.stringReplace(stingValue:UserDefaults.standard.value(forKey: "productName") as! String )
        lblCategory.text = self.stringReplace(stingValue:UserDefaults.standard.value(forKey: "Category") as! String)
        lblshortTilte.text = self.stringReplace(stingValue:UserDefaults.standard.value(forKey: "productTitle") as! String)
        var link = UserDefaults.standard.value(forKey: "productImageUrl") as! String
        getmoreproductdetails()
    }
    func getmoreproductdetails(){
        //load chat list
        AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
        let proId =  UserDefaults.standard.value(forKey: "productid") as! String
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let par = ["Authorization": headerrr]
        let url = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.getmoreproductdetails)
        let parameter = ["productId":proId]
        APiClass.apiCallGetWithHeaderAndBodyGana(mainUrl: url, postParameters: parameter) { (responseArray) in
            let responseDict = responseArray[0]
            if (responseDict.object(forKey: "error") != nil)
            {
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["error"]
                AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
            }
            else
            {
                AppHelper.HidePrograss(vc: self.view)
                let res = responseDict["value"] as! [[String:Any]]
                let message = res[0]["status"] as! String
                if message == "success"
                {
                    self.arrayList = [[String:Any]]()
                    self.arrayList = res[0]["moreproductDetailsList"] as! [[String : Any]]
                    self.tbl.reloadData()
                }
                else
                {
                    AppHelper.HidePrograss(vc: self.view)
                    AppHelper.showAlertMessage(vc: self, title: "", message: message)
                }
            }
        }
        
    }
    @IBAction func dismiss(_ sender: Any) {
        self.dismiss(animated: true, completion:{
        } )
    }
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let identifier = "viewMoreCell"
        var cell: viewMoreTableCell! = tableView.dequeueReusableCell(withIdentifier: identifier) as? viewMoreTableCell
        if cell == nil {
            tableView.register(UINib(nibName: "viewMoreTableCell", bundle: nil), forCellReuseIdentifier: identifier)
            cell = tableView.dequeueReusableCell(withIdentifier: identifier) as? viewMoreTableCell
        }
        let lblTitleCell : UILabel = cell.viewWithTag(1) as! UILabel
        let lblDes : UILabel = cell.viewWithTag(3) as! UILabel
        let imgDp : UIImageView = cell.viewWithTag(2) as! UIImageView
        
        lblTitleCell.text = self.stringReplace(stingValue:arrayList[indexPath.row]["attribute"] as! String)
        lblDes.text = self.stringReplace(stingValue:arrayList[indexPath.row]["description"] as! String)
        var  imgLink = self.stringReplace(stingValue:arrayList[indexPath.row]["imageUrl"] as! String)
        let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
        imgLink = imgLink.replacingOccurrences(of: "/", with: "-")
        var imgUrl = String(format: "%@/api/attachmentsByPath/%@", apiUrl,imgLink)
        imgUrl = imgUrl.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        imgDp.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
        return cell
    }
    func stringReplace(stingValue : String) -> String {
        var orginalString = stingValue
        orginalString = orginalString.replacingOccurrences(of: "<div></div>", with: "\n")
        orginalString = orginalString.replacingOccurrences(of: "<div>", with: "\n")
        orginalString = orginalString.replacingOccurrences(of: "</div>", with: "")
        orginalString = orginalString.replacingOccurrences(of: "<br>", with: "")
        orginalString = orginalString.replacingOccurrences(of: "&nbsp;", with: " ")
        orginalString = orginalString.replacingOccurrences(of: "&lt;", with: "<")
        orginalString = orginalString.replacingOccurrences(of: "&gt;", with: ">")
        orginalString = orginalString.replacingOccurrences(of: "amp;", with: "")
        orginalString = orginalString.replacingOccurrences(of: "&amp;", with: "")
        orginalString = orginalString.replacingOccurrences(of: "<b>", with: "")
        orginalString = orginalString.replacingOccurrences(of: "</b>", with: "")
        return orginalString
    }
}
