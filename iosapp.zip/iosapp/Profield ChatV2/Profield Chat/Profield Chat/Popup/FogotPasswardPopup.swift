//
//  FogotPasswardPopup.swift
//  Profield Chat
//
//  Created by Apple on 22/11/18.
//  Copyright © 2018 indocosmo. All rights reserved.
//

import UIKit
import Alamofire
class FogotPasswardPopup: UIViewController,UINavigationControllerDelegate {
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPopupView: UIView!
    @IBOutlet weak var txtnewPassword: UITextField!
    @IBOutlet weak var btnCloseSecond: UIButton!
    @IBOutlet weak var txtOtp: UITextField!
    @IBOutlet weak var btnFirstClose: UIButton!
    @IBOutlet weak var txtConfirmPassword: UITextField!
    @IBOutlet weak var passwordView: UIView!
    @IBOutlet weak var txtUserName: UITextField!
    //MARK:- viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        passwordView.isHidden = true
        btnCloseSecond.isHidden = true
        screenSetup()
    }
    func screenSetup()
    {
        txtPopupView.layer.cornerRadius = 5
        passwordView.layer.cornerRadius = 5
        txtOtp.setBottomBorder()
        txtnewPassword.setBottomBorder()
        txtConfirmPassword.setBottomBorder()
        txtUserName.setBottomBorder()
        txtEmail.setBottomBorder()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func SubmitFirst(_ sender: Any) {
        if txtUserName.text==""
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Enter your user name")
        }
        else  if txtEmail.text==""
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Enter your email")
        }
        else  if !AppHelper.isValidEmail(testStr: txtEmail.text!)
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Enter a valid email")
        }
        else
        {
            AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
            let par = ["emailId": txtEmail.text!,"userName":txtUserName.text!]
            let apiUrl = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.forgotPassword)
            APiClass.apiCallRestUrlEncode(mainUrl: apiUrl, postParameters: par) { (responseArray) in
                let responseDict = responseArray[0]
                if (responseDict.object(forKey: "error") != nil)
                {
                    AppHelper.HidePrograss(vc: self.view)
                    let message = responseDict["error"]
                    AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
                }
                else
                {
                    if responseDict["status"] as! String == "send"
                    {
                        AppHelper.HidePrograss(vc: self.view)
                        AppHelper.showAlertMessage(vc: self, title: "", message: "We have emailed you the OTP for resetting your password. You should receive the email shortly!")
                        self.passwordView.isHidden = false
                        self.btnCloseSecond.isHidden = false
                        self.txtPopupView.isHidden = true
                        self.btnFirstClose.isHidden = true
                        self.lblUserName.text = String(format: "User Name : %@", self.txtUserName.text!)
                    }
                    else
                    {
                        AppHelper.HidePrograss(vc: self.view)
                        if responseDict["status"] as! String == "not-found"
                        {
                            AppHelper.showAlertMessage(vc: self, title: "", message: "No user found")
                        }
                        else
                        {
                            AppHelper.showAlertMessage(vc: self, title: "", message: responseDict["message"] as! String)
                        }
                    }
                }
            }
        }
    }
    @IBAction func SubmitSecond(_ sender: Any) {
        if txtOtp.text == ""
        {
            AppHelper.showAlertMessage(vc: self, title: "", message:"Please enter OTP")
        }
        else if txtnewPassword.text == ""
        {
            AppHelper.showAlertMessage(vc: self, title: "", message:"Please enter new password")
        }
        else if txtConfirmPassword.text == ""
        {
            AppHelper.showAlertMessage(vc: self, title: "", message:"Please enter confirm password")
        }
        else if txtConfirmPassword.text != txtnewPassword.text
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "New Password and confirm password do not match.")
        }
        else if(txtConfirmPassword.text?.count)! < 6
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "minimum password length is 6 characters.")
        }
            
        else
        {
            AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
            let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
            let strUrll =  String(format:"%@/api/auth/savePassword?tocken=%@&password=%@&emailId=%@",apiUrl, txtOtp.text!,txtnewPassword.text!,txtEmail.text!)
            print(strUrll)
            let par = ["tesr":"tocken"]
            APiClass.apiCallRestUrlEncode(mainUrl: strUrll, postParameters: par) { (responseArray) in
                let responseDict = responseArray[0]
                if (responseDict.object(forKey: "error") != nil)
                {
                    AppHelper.HidePrograss(vc: self.view)
                    let message = responseDict["error"]
                    AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
                }
                else
                {
                    if responseDict["status"] as! String == "send"
                    {
                        AppHelper.HidePrograss(vc: self.view)
                        AppHelper.showAlertMessage(vc: self, title: "", message: "")
                        self.passwordView.isHidden = false
                        self.btnCloseSecond.isHidden = false
                        self.txtPopupView.isHidden = true
                        self.btnFirstClose.isHidden = true
                    }
                    else
                    {
                        if responseDict["status"] as! String == "sucess"
                        {
                            AppHelper.HidePrograss(vc: self.view)
                            let actionSheetController: UIAlertController = UIAlertController(title: "Successfully changed your password. Please login your account", message: "", preferredStyle: .alert)
                            let cancelAction: UIAlertAction = UIAlertAction(title: "OK", style: .cancel) { action -> Void in
                                self.dismiss(animated: true, completion:{
                                } )
                            }
                            actionSheetController.addAction(cancelAction)
                            self.present(actionSheetController, animated: true, completion: nil)
                        }
                        else
                        {
                            AppHelper.HidePrograss(vc: self.view)
                            AppHelper.showAlertMessage(vc: self, title: "", message: responseDict["status"] as! String)
                        }
                    }
                }
            }
        }
    }
    @IBAction func dismiss(_ sender: Any) {
        self.dismiss(animated: true, completion:{
        } )
    }
}
