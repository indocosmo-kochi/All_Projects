//
//  CustomerFeedbackPopup.swift
//  Profield Chat
//
//  Created by Apple on 30/08/19.
//  Copyright © 2019 indocosmo. All rights reserved.
//

import UIKit
import MGStarRatingView
class CustomerFeedbackPopup: UIViewController,UITextViewDelegate {
    @IBOutlet weak var starRating: StarRatingView!
    @IBOutlet weak var viewBg: UIView!
    @IBOutlet weak var txtTextView: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        viewBg.layer.cornerRadius = 5
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        txtTextView.layer.cornerRadius = 4
        txtTextView.layer.borderWidth = 1
        txtTextView.layer.borderColor = UIColor.gray.cgColor
        txtTextView.delegate = self
    }
    @IBAction func submit(_ sender: Any) {
        AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
        let ownerId = UserDefaults.standard.value(forKey: "ownerId")
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let par = ["Authorization": headerrr]
        let url = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.customerFeedback)
        let proId =  UserDefaults.standard.value(forKey: "productid") as! String
        let userId = UserDefaults.standard.value(forKey: "userId") as! String
        
        
        var dateFormatter : DateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy/MM/dd HH:mm:ss"
        var date = Date()
        let feedback_date = dateFormatter.string(from: date)
        dateFormatter.dateFormat = "yyyy/MM/dd"
        let createdOn = dateFormatter.string(from: date)
        var feedbackComments = self.stringToHtmlEncdeing(stringValue: txtTextView.text)
        if feedbackComments == "Any suggestion for us to improve our service?"
        {
            feedbackComments = ""
        }
        
        
        let parameter = ["customerId": userId,"productId": proId,"productOwnerId":ownerId,"feedBackRating":starRating.current,"FeedBackComments":feedbackComments,"feedback_date":feedback_date,"createdOn":createdOn] as [String : Any]
        APiClass.apiCallRESTProduct(mainUrl: url, postParameters: parameter,HeaderParameters:par) { (responseArray) in
            let responseDict = responseArray[0]
            if (responseDict.object(forKey: "error") != nil)
            {
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["error"]
                AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
            }
            else
            {
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["status"] as! String
                if message == "success"
                {
                    self.dismiss((Any).self)
                }
                else
                {
                    AppHelper.HidePrograss(vc: self.view)
                    AppHelper.showAlertMessage(vc: self, title: "", message: message)
                }
            }
        }
    }
    func stringToHtmlEncdeing(stringValue :String) ->String
    {
        var msgText = ""
        let arrayofstring = stringValue.characters.map { (Character) -> Character in
            return Character
        }
        var flagString = 0
        for i in 0..<arrayofstring .count
        {
            let str = String(arrayofstring[i])
            if str == "\n"
            {
                if flagString == 0
                {
                    flagString = 1
                    msgText = String(format: "%@%@", msgText,"</>")
                    
                }
                else if flagString == 1
                {
                    flagString = 2
                    
                    msgText = String(format: "%@%@", msgText,str)
                }
                else
                {
                    flagString = 2
                    msgText = String(format: "%@%@", msgText,str)
                }
            }
            else
            {
                flagString = 0
                msgText = String(format: "%@%@", msgText,str)
            }
        }
        msgText = msgText.replacingOccurrences(of: "<", with: "&lt;")
        msgText = msgText.replacingOccurrences(of: ">", with: "&gt;")
        msgText = msgText.replacingOccurrences(of: "&lt;/&gt;", with: "<div></div>")
        msgText = msgText.replacingOccurrences(of: "\n", with: "<div><br></div>")
        return msgText
    }
    @IBAction func dismiss(_ sender: Any) {
        self.dismiss(animated: true, completion:{
        } )
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.text == "Any suggestion for us to improve our service?"
        {
            textView.text = ""
        }
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text == ""
        {
            textView.text = "Any suggestion for us to improve our service?"
        }
    }
}
