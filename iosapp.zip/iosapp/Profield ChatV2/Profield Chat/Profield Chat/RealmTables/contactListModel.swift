//
//  contactListModel.swift
//  Profield Chat
//
//  Created by Apple on 28/08/19.
//  Copyright © 2019 indocosmo. All rights reserved.
//

import Foundation
import RealmSwift
class contactListModel: Object, Decodable  {
    @objc  var id:String?
    @objc  var employeeId:String?
    @objc  var contactListId:String?
    @objc dynamic var lastMessageTime=Date()
    @objc  var customerName:String?
    @objc  var userName:String?
    @objc  var productName:String?
    @objc dynamic var customerIsOnline = 0
    @objc  var ownerAttachemntId:String?
    @objc  var offLineMessage = 0
    @objc   var productId:String?
    @objc  var isDeleted:String?
    @objc  var createdBy:String?
    @objc   var customerId:String?
    @objc  var LId:String?
    @objc  var categoryName:String?
    @objc  var productImageUrl:String?
    @objc  var productTitle:String?
}
