//
//  AppHelper.swift
//  AlimonySwift
//
//  Created by Apple on 21/11/18.
//  Copyright © 2018 indocosmo. All rights reserved.
//

import UIKit

public class AppHelper
{
    // MARK: email validation
    static func isValidEmail(testStr:String) -> Bool
    {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    // MARK: show default alert with action
    static func showAppErrorWithOKAction(vc: UIViewController, title:String, message:String, handler: ((UIAlertAction) -> Void)?) -> Void
    {
        let alertView = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertView.addAction(UIAlertAction(title: "OK", style: .default, handler: handler))
        vc.present(alertView, animated: true, completion: nil)
    }
    // MARK: show default alert
    static func showAlertMessage(vc: UIViewController, title:String, message:String) -> Void
    {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert);
        vc.present(alert, animated: true, completion: nil)
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0, execute: {
            self.dismiss(alert:alert)
        })
    }
    // MARK:dismiss alert
    static func dismiss(alert:UIAlertController)
    {
        alert.dismiss(animated: true, completion: nil)
    }
    //MARK:UTCtoLocal
   static func UTCToLocalTime(date:String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "H:mm:ss"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        
        let dt = dateFormatter.date(from: date)
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = "h:mm a"
        
        return dateFormatter.string(from: dt!)
    }
    static func UTCToLocalDate(date:String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        
        let dt = dateFormatter.date(from: date)
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        return dateFormatter.string(from: dt!)
    }
    // MARK: change image size
    static func imageScaledToSize(image:UIImage, newSize:CGSize) -> UIImage
    {
        UIGraphicsBeginImageContextWithOptions(newSize, false, 0.0)
        image.draw(in: CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage!
    }
    // MARK:Show Activity indicator
    static func showPrograss(vc: UIView, title:String, message:String) -> Void
    {
        let spinnerActivity = MBProgressHUD.showAdded(to: vc, animated: true);
        spinnerActivity.label.text = title
        spinnerActivity.detailsLabel.text = message
        spinnerActivity.isUserInteractionEnabled = true;
    }
    // MARK: Show Activity indicator with user intraction enabled
    static func showPrograssIntraction(vc: UIView, title:String, message:String) -> Void
    {
        let spinnerActivity = MBProgressHUD.showAdded(to: vc, animated: true);
        spinnerActivity.label.text = title
        spinnerActivity.detailsLabel.text = message
        spinnerActivity.isUserInteractionEnabled = false;
    }
    // MARK: Hide activity indicator
    static func HidePrograss(vc: UIView) -> Void
    {   DispatchQueue.main.asyncAfter(deadline: .now(), execute: {
        MBProgressHUD.hide(for: vc, animated: true)
    })
    }
}
