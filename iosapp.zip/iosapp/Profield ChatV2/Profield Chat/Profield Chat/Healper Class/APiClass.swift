//
//  APiClass.swift
//  Profield Chat
//
//  Created by Apple on 28/11/18.
//  Copyright © 2018 indocosmo. All rights reserved.
//
//This call for API

import Foundation
import Alamofire

public class APiClass
{
    static func apiCallREST(mainUrl : String, postParameters:Dictionary<String,String>!, callback:@escaping (Array<AnyObject>) -> Void)
    {
        Alamofire.request(mainUrl, method: .post, parameters: postParameters, encoding: JSONEncoding.default, headers: nil).responseJSON {
            response in
            switch response.result {
            case .success:
                let strError = response.result.error
                if (strError != nil)
                {
                    let errorDict = ["error" : strError]
                    let callbackArray = [errorDict]
                    callback(callbackArray as Array<AnyObject>)
                }
                else
                {
                    let responseee = [response.result.value]
                    callback(responseee as Array<AnyObject>)
                }
                break
            case .failure(let error):
                let errorDict = ["error" : error.localizedDescription]
                let callbackArray = [errorDict]
                callback(callbackArray as Array<AnyObject>)
            }
        }
    }
    static func apiCallRESTProduct(mainUrl : String, postParameters:Dictionary<String,Any>!,HeaderParameters:Dictionary<String,String>!, callback:@escaping (Array<AnyObject>) -> Void)
    {
        Alamofire.request(mainUrl, method: .post, parameters: postParameters, encoding: JSONEncoding.default, headers: HeaderParameters).responseJSON {
            response in
            switch response.result {
            case .success:
                let strError = response.result.error
                if (strError != nil)
                {
                    let errorDict = ["error" : strError]
                    let callbackArray = [errorDict]
                    callback(callbackArray as Array<AnyObject>)
                }
                else
                {
                    let responseee = [response.result.value]
                    callback(responseee as Array<AnyObject>)
                }
                break
            case .failure(let error):
                let errorDict = ["error" : error.localizedDescription]
                let callbackArray = [errorDict]
                callback(callbackArray as Array<AnyObject>)
            }
        }
    }
    static func apiCallRestUrlEncode(mainUrl : String, postParameters:Dictionary<String,String>!, callback:@escaping (Array<AnyObject>) -> Void)
    {
        Alamofire.request(mainUrl, method: .post, parameters: postParameters, encoding: URLEncoding.default, headers: nil).responseJSON {
            response in
            switch response.result {
            case .success:
                let strrr = response.result.error
                if (strrr != nil)
                {
                    let test = ["error" : strrr]
                    let arr = [test]
                    callback(arr as Array<AnyObject>)
                }
                else
                {
                    let responseee = [response.result.value]
                    callback(responseee as Array<AnyObject>)
                }
                break
            case .failure(let error):
                let test = ["error" : error.localizedDescription]
                let arr = [test]
                callback(arr as Array<AnyObject>)
            }
        }
    }
    static func apiCallPostWithHeader(mainUrl : String, postParameters:Dictionary<String,String>!, callback:@escaping (Array<AnyObject>) -> Void)
    {
        Alamofire.request(mainUrl, method: .post, parameters: nil, encoding: JSONEncoding.default, headers: postParameters).responseJSON {
            response in
            switch response.result {
            case .success:
                let strrr = response.result.error
                if (strrr != nil)
                {
                    let test = ["error" : strrr]
                    let arr = [test]
                    callback(arr as Array<AnyObject>)
                }
                else
                {
                    if response.result.value is Array<Any>
                    {
                        let responseee = ["value" : [response.result.value]]
                        let arr = [responseee]
                        callback(arr as Array<AnyObject>)
                    }
                    else
                    {
                        let dict = response.result.value as! [String:Any]
                        print(dict)
                        if dict.index(forKey: "status") != nil {
                            if dict["status"] as! Int == 401
                            {
                                let test = ["error" : "Unauthorized"]
                                let arr = [test]
                                callback(arr as Array<AnyObject>)
                            }
                            else
                            {
                                let responseee = ["value" : [response.result.value]]
                                let arr = [responseee]
                                callback(arr as Array<AnyObject>)
                            }
                        }
                        else
                        {
                            let responseee = ["value" : [response.result.value]]
                            let arr = [responseee]
                            callback(arr as Array<AnyObject>)
                        }
                    }
                    
                }
                break
            case .failure(let error):
                let test = ["error" : error.localizedDescription]
                let arr = [test]
                callback(arr as Array<AnyObject>)
            }
        }
        
    }
    static func apiCallPostValueWithHeaderDeletMessage(mainUrl : String, postParameters:Dictionary<String,Any>!,headerParams:Dictionary<String,String>!, callback:@escaping (Array<AnyObject>) -> Void)
    {
        Alamofire.request(mainUrl, method: .post, parameters: postParameters, encoding: URLEncoding.default, headers: headerParams).responseJSON {
            response in
            switch response.result {
            case .success:
                let strrr = response.result.error
                if (strrr != nil)
                {
                    let test = ["error" : strrr]
                    let arr = [test]
                    callback(arr as Array<AnyObject>)
                }
                else
                {
                    let responseee = ["value" : [response.result.value]]
                    let arr = [responseee]
                    callback(arr as Array<AnyObject>)
                }
                break
            case .failure(let error):
                let test = ["error" : error.localizedDescription]
                let arr = [test]
                callback(arr as Array<AnyObject>)
            }
        }
    }
    static func apiCallPostValueWithHeader(mainUrl : String, postParameters:Dictionary<String,String>!,headerParams:Dictionary<String,String>!, callback:@escaping (Array<AnyObject>) -> Void)
    {
        Alamofire.request(mainUrl, method: .post, parameters: postParameters, encoding: URLEncoding.default, headers: headerParams).responseJSON {
            response in
            switch response.result {
            case .success:
                let strrr = response.result.error
                if (strrr != nil)
                {
                    let test = ["error" : strrr]
                    let arr = [test]
                    callback(arr as Array<AnyObject>)
                }
                else
                {
                    let responseee = ["value" : [response.result.value]]
                    let arr = [responseee]
                    callback(arr as Array<AnyObject>)
                }
                break
            case .failure(let error):
                let test = ["error" : error.localizedDescription]
                let arr = [test]
                callback(arr as Array<AnyObject>)
            }
        }
    }
    static func apiCallPostValueWithHeaderFormData(mainUrl : String, postParameters:Dictionary<String,String>!,headerParams:Dictionary<String,String>!, callback:@escaping (Array<AnyObject>) -> Void)
    {
        Alamofire.request(mainUrl, method: .post, parameters: postParameters, encoding: URLEncoding.default, headers: headerParams).responseJSON {
            response in
            switch response.result {
            case .success:
                let strrr = response.result.error
                if (strrr != nil)
                {
                    let test = ["error" : strrr]
                    let arr = [test]
                    callback(arr as Array<AnyObject>)
                }
                else
                {
                    let responseee = ["value" : [response.result.value]]
                    let arr = [responseee]
                    callback(arr as Array<AnyObject>)
                }
                break
            case .failure(let error):
                let test = ["error" : error.localizedDescription]
                let arr = [test]
                callback(arr as Array<AnyObject>)
            }
        }
    }
    static func apiCallGetWithHeader(mainUrl : String, postParameters:Dictionary<String,String>!, callback:@escaping (Array<AnyObject>) -> Void)
    {
        Alamofire.request(mainUrl, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: postParameters).responseJSON {
            response in
            switch response.result {
            case .success:
                let strrr = response.result.error
                if (strrr != nil)
                {
                    let test = ["error" : strrr]
                    let arr = [test]
                    callback(arr as Array<AnyObject>)
                }
                else
                {
                    if response.result.value is Array<Any>
                    {
                        let responseee = ["value" : [response.result.value]]
                        let arr = [responseee]
                        callback(arr as Array<AnyObject>)
                    }
                    else
                    {
                        let dict = response.result.value as! [String:Any]
                        if dict.index(forKey: "status") != nil {
                            if dict["status"] as? Int == 401
                            {
                                let test = ["error" : "Unauthorized"]
                                let arr = [test]
                                callback(arr as Array<AnyObject>)
                            }
                            else
                            {
                                let responseee = ["value" : [response.result.value]]
                                let arr = [responseee]
                                callback(arr as Array<AnyObject>)
                            }
                        }
                        else
                        {
                            let responseee = ["value" : [response.result.value]]
                            let arr = [responseee]
                            callback(arr as Array<AnyObject>)
                        }
                    }
                }
                break
            case .failure(let error):
                let test = ["error" : error.localizedDescription]
                let arr = [test]
                callback(arr as Array<AnyObject>)
            }
        }
        
    }
    static func apiCallGetWithHeaderAndBody(mainUrl : String, postParameters:Dictionary<String,String>!, callback:@escaping (Array<AnyObject>) -> Void)
    {
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let par = ["Authorization": headerrr]
        Alamofire.request(mainUrl, method: .post, parameters: postParameters, encoding: URLEncoding.default, headers:par ).responseJSON {
            response in
            switch response.result {
            case .success:
                print(response)
                let strrr = response.result.error
                if (strrr != nil)
                {
                    let test = ["error" : strrr]
                    let arr = [test]
                    callback(arr as Array<AnyObject>)
                }
                else
                {
                    let responseee = ["value" : [response.result.value]]
                    let arr = [responseee]
                    callback(arr as Array<AnyObject>)
                }
                break
            case .failure(let error):
                let test = ["error" : error.localizedDescription]
                let arr = [test]
                callback(arr as Array<AnyObject>)
            }
        }
        
    }
    static func apiCallGetWithHeaderAndBodyGana(mainUrl : String, postParameters:Dictionary<String,String>!, callback:@escaping (Array<AnyObject>) -> Void)
    {
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let par = ["Authorization": headerrr]
        Alamofire.request(mainUrl, method: .get, parameters: postParameters, encoding: URLEncoding.default, headers:par ).responseJSON {
            response in
            switch response.result {
            case .success:
                let strrr = response.result.error
                if (strrr != nil)
                {
                    let test = ["error" : strrr]
                    let arr = [test]
                    callback(arr as Array<AnyObject>)
                }
                else
                {
                    let responseee = ["value" : [response.result.value]]
                    let arr = [responseee]
                    callback(arr as Array<AnyObject>)
                }
                break
            case .failure(let error):
                let test = ["error" : error.localizedDescription]
                let arr = [test]
                callback(arr as Array<AnyObject>)
            }
        }
    }
    
    static func ApiCallImageUpload(mainUrl : String, postParameters:Dictionary<String,String>!, mimeType:String, uploadParameterName:String, fileName:String, uploadFileData:Data!, callback:@escaping (Array<AnyObject>) -> Void)
    {
        Alamofire.upload(multipartFormData: { multipartFormData in
            multipartFormData.append(uploadFileData, withName: uploadParameterName,fileName: fileName, mimeType: mimeType)
            for (key, value) in postParameters
            {
                multipartFormData.append(value.data(using: String.Encoding.utf8)!, withName: key)
            } //Optional for extra parameters
        }, to: mainUrl)
        {
            (result) in
            switch result
            {
            case .success(let upload, _, _):
                upload.uploadProgress(closure: { (progress) in
                    print("Upload Progress: \(progress.fractionCompleted)")
                })
                upload.responseJSON { response in
                    
                    let strrr = response.result.error
                    if (strrr != nil)
                    {
                        let test = ["error" : strrr]
                        let arr = [test]
                        callback(arr as Array<AnyObject>)
                    }
                    else
                    {
                        let responseee = [response.result.value]
                        callback(responseee as Array<AnyObject>)
                    }
                }
            case .failure(let error):
                let test = ["error" : error.localizedDescription]
                let arr = [test]
                callback(arr as Array<AnyObject>)
            }
        }
    }
    static func ApiCallImageUploadWithHeade(mainUrl : String,HeaderParameters:Dictionary<String,String>!, postParameters:Dictionary<String,String>!, mimeType:String, uploadParameterName:String, fileName:String, uploadFileData:Data!, callback:@escaping (Array<AnyObject>) -> Void)
    {
        Alamofire.upload(multipartFormData: { multipartFormData in
            //Parameter for Upload files
            multipartFormData.append(uploadFileData, withName: uploadParameterName,fileName: fileName , mimeType: mimeType)
            for (key, value) in postParameters
            {
                multipartFormData.append(value.data(using: String.Encoding.utf8)!, withName: key)
            }
            
        }, usingThreshold:UInt64.init(),
           to: mainUrl, //URL Here
            method: .post,
            headers: HeaderParameters, //pass header dictionary here
            encodingCompletion: { (result) in
                switch result {
                case .success(let upload, _, _):
                    print("the status code is :")
                    upload.uploadProgress(closure: { (progress) in
                        print(progress)
                    })
                    upload.responseJSON { response in
                        let strrr = response.result.error
                        if (strrr != nil)
                        {
                            let test = ["error" : strrr?.localizedDescription]
                            let arr = [test]
                            callback(arr as Array<AnyObject>)
                        }
                        else
                        {
                            let responseee = [response.result.value]
                            callback(responseee as Array<AnyObject>)
                        }
                    }
                    break
                case .failure(let encodingError):
                    print("the error is  : \(encodingError.localizedDescription)")
                    let test = ["error" : encodingError.localizedDescription]
                    let arr = [test]
                    callback(arr as Array<AnyObject>)
                    break
                }
        })
    }
}
