//
//  ScrollView.swift
//  Profield Chat
//
//  Created by USER on 2019/07/15.
//  Copyright © 2019 indocosmo. All rights reserved.
//

import Foundation
import UIKit

class ScrollViewClass {
    let ArrayOfViews: [UIView]
    let width: Int
    let scrollView = UIScrollView()
    init(ArrayOfViews: [UIView], width: Int) {
        self.ArrayOfViews = ArrayOfViews
        self.width = width
    }
    
    func build() -> UIScrollView {
        
        scrollView.isScrollEnabled =  true
        scrollView.frame.size.width = UIScreen.main.bounds.width
        scrollView.frame.size.height = UIScreen.main.bounds.height
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.isPagingEnabled = true
        scrollView.contentSize = CGSize(width: /*4000*/ self.width, height: 80)
        scrollView.showsHorizontalScrollIndicator = true
        scrollView.isDirectionalLockEnabled = true
       
        
        for (index, views) in ArrayOfViews.enumerated() {
            scrollView.addSubview(views)
          
        }
        
        return scrollView
    }
    
}
