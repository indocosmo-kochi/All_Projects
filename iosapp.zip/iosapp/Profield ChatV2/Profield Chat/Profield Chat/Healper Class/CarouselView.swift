//
//  CarouselView.swift
//  Profield Chat
//
//  Created by Apple on 05/08/19.
//  Copyright © 2019 indocosmo. All rights reserved.
//

import UIKit
import SDWebImage
class CarouselView: UITableViewCell,iCarouselDelegate,iCarouselDataSource {
    @IBOutlet var carouselView: iCarousel!
    var gameImages = [1,2,3,4,5,6,7,8,9,10]
    var attributesList = [String:Any]()
    var currentIndex : Int!
    override func awakeFromNib() {
        super.awakeFromNib()
        carouselView.type = .invertedCylinder
        //  carouselView.type = .cylinder
        carouselView.delegate=self
        carouselView.dataSource=self
        carouselView.bounces = false
        carouselView.isPagingEnabled = true
        
        
        
      
        
        // Initialization code
    }
    
    func numberOfItems(in carousel: iCarousel) -> Int {
        
        if attributesList.isEmpty
        {
            return 0
        }
        else
        {
            let attributes = attributesList["attributes"] as! [[String:Any]]
            var indexCount = attributes.count+1
            if indexCount == 2
            {
                indexCount = 4
            }
            return indexCount
        }
        
    }
    
    func carousel(_ carousel: iCarousel, viewForItemAt index: Int, reusing view: UIView?) -> UIView {
        var attributes = attributesList["attributes"] as! [[String:Any]]
        var indexCount = attributes.count
        var currentIndex = index
        if indexCount == 1
        {
            
            if currentIndex == 2
            {
                currentIndex = 0
            }
            if currentIndex == 3
            {
                currentIndex = 1
            }
        }
        
        
        let customView = UINib.init(nibName: "CardScrollView", bundle: nil).instantiate(withOwner: self)[0] as! UIView
        let cellWidth = UIScreen.main.bounds.size.width - 40
        customView.frame =  CGRect(x: 0, y: 0, width: cellWidth, height: 320)
        let lblTopTitle : UILabel = customView.viewWithTag(1) as! UILabel
        let img : UIImageView = customView.viewWithTag(2) as! UIImageView
        let lblCategory : UILabel = customView.viewWithTag(3) as! UILabel
        let lblDescription : UILabel = customView.viewWithTag(4) as! UILabel
        let lblCount : UILabel = customView.viewWithTag(10) as! UILabel
        lblCount.layer.cornerRadius = 17.5
        lblCount.clipsToBounds = true
//        if indexCount == 1
//        {
//            var currentpage = index+1
//            if currentpage == 3
//            {
//                currentpage = 1
//            }
//            if currentpage == 4
//            {
//                currentpage = 2
//            }
//              lblCount.text=String(format: "%d/%d",currentpage, 2)
//        }
//        else
//        {
            lblCount.text=String(format: "%d/%d",currentIndex+1, attributes.count+1)
            
     //   }
      
        customView.layer.cornerRadius = 5.0
        customView.layer.masksToBounds = false
        customView.layer.shadowColor = UIColor.black.withAlphaComponent(0.2).cgColor
        if currentIndex == 0
        {
            print(attributesList)
            
            var productName = attributesList["productName"] as! String
            var productTitle = attributesList["productTitle"] as! String
            var categoryName = attributesList["categoryName"] as! String
            
            
            productName = self.stringReplace(stingValue: productName)
            productTitle = self.stringReplace(stingValue: productTitle)
            categoryName = self.stringReplace(stingValue: categoryName)
            
            lblTopTitle.text = productName
            lblCategory.text = productTitle
           
            
            lblDescription.text = String(format: "Category : %@", categoryName )
            let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
            if  var imageUrl = attributesList["productImageUrl"] as? String
            {
                imageUrl = imageUrl.replacingOccurrences(of: "/", with: "-")
                imageUrl = String(format: "%@/api/attachmentsByPath/%@", apiUrl,imageUrl)
                
                //sdImageView set header values
                let accessToken = UserDefaults.standard.value(forKey: "accessToken")
                let tokenType = UserDefaults.standard.value(forKey: "tokenType")
                let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
 SDWebImageDownloader.shared.setValue(headerrr, forHTTPHeaderField:"Authorization")
                img.sd_imageIndicator = SDWebImageActivityIndicator.gray
              
                imageUrl = imageUrl.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
                img.sd_setImage(with: URL(string:  imageUrl), placeholderImage: UIImage(named: "chat_logo.png"))
            }
            else
            {
                img.image = UIImage(named: "chat_logo.png")
            }
        }
        else
        {
             attributes = attributesList["attributes"] as! [[String:Any]]

            
            var productName = attributesList["productName"] as? String
            if attributes.count >= currentIndex-1
            {
                
            
            var attribute = attributes[currentIndex-1]["attribute"] as? String
            var description = attributes[currentIndex-1]["description"] as? String
            
            productName = self.stringReplace(stingValue: productName!)
            attribute = self.stringReplace(stingValue: attribute!)
            description = self.stringReplace(stingValue: description!)
            
            
            
            lblTopTitle.text = productName
            lblCategory.text = attribute
            lblDescription.text =  description
            
            
            let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
            if  var imageUrl =  attributes[currentIndex-1]["imageUrl"] as? String{
                imageUrl = imageUrl.replacingOccurrences(of: "/", with: "-")
                imageUrl = String(format: "%@/api/attachmentsByPath/%@", apiUrl,imageUrl)
                //sdImageView set header values
                let accessToken = UserDefaults.standard.value(forKey: "accessToken")
                let tokenType = UserDefaults.standard.value(forKey: "tokenType")
                let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
             SDWebImageDownloader.shared.setValue(headerrr, forHTTPHeaderField:"Authorization")
                img.sd_imageIndicator = SDWebImageActivityIndicator.gray
                imageUrl = imageUrl.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
                print(imageUrl)
                img.sd_setImage(with: URL(string:  imageUrl), placeholderImage: UIImage(named: "chat_logo.png"))
            }
            else
            {
                img.image = UIImage(named: "chat_logo.png")
            }
            }
        }
        
        return customView
    
    }
    
    func carousel(_ carousel: iCarousel, valueFor option: iCarouselOption, withDefault value: CGFloat) -> CGFloat {
        if option == iCarouselOption.spacing{
            return value * 1.1
        }
        return value
        
    }
    func stringReplace(stingValue : String) -> String {
        
        var orginalString = stingValue
        orginalString = orginalString.replacingOccurrences(of: "<div></div>", with: "\n")
        orginalString = orginalString.replacingOccurrences(of: "<div>", with: "\n")
        orginalString = orginalString.replacingOccurrences(of: "</div>", with: "")
        orginalString = orginalString.replacingOccurrences(of: "<br>", with: "")
        orginalString = orginalString.replacingOccurrences(of: "&nbsp;", with: " ")
        orginalString = orginalString.replacingOccurrences(of: "&lt;", with: "<")
        orginalString = orginalString.replacingOccurrences(of: "&gt;", with: ">")
        orginalString = orginalString.replacingOccurrences(of: "amp;", with: "")
          orginalString = orginalString.replacingOccurrences(of: "&amp;", with: "")
          orginalString = orginalString.replacingOccurrences(of: "<b>", with: "")
        orginalString = orginalString.replacingOccurrences(of: "</b>", with: "")

        
        return orginalString
        
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    func getIndexPath() -> IndexPath? {
        guard let superView = self.superview as? UITableView else {
            print("superview is not a UITableView - getIndexPath")
            return nil
        }
        let  indexPath = superView.indexPath(for: self)
        return indexPath
    }
}
