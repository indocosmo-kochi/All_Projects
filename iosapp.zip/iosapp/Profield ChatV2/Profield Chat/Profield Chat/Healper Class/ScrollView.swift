//
//  ScrollView.swift
//  Profield Chat
//
//  Created by USER on 2019/07/15.
//  Copyright © 2019 indocosmo. All rights reserved.
//

import Foundation
import UIKit

class ScrollViewClass {
    let ArrayOfViews: [UIView]
    let scrollView = UIScrollView()
    
    init(ArrayOfViews: [UIView]) {
        self.ArrayOfViews = ArrayOfViews
    }
    
    func build() -> UIScrollView {
        scrollView.isScrollEnabled =  true
        scrollView.frame.size.width = UIScreen.main.bounds.width
        scrollView.frame.size.height = UIScreen.main.bounds.height
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.isPagingEnabled = true
        scrollView.contentSize = CGSize(width: 2000, height: 500)
        scrollView.showsHorizontalScrollIndicator = true
        let stackView:UIStackView = UIStackView()
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.alignment = .fill
        stackView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        
        for (index, views) in ArrayOfViews.enumerated() {
            stackView.addArrangedSubview(views)
            print(index)
        }
        scrollView.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor, constant: 0).isActive = true
        stackView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor, constant: 0).isActive = true
        stackView.topAnchor.constraint(equalTo: scrollView.topAnchor, constant: 0).isActive = true
        stackView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor, constant: 0).isActive = true
        return scrollView
    }
}
