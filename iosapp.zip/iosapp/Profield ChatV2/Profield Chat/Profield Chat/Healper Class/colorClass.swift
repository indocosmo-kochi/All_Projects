//
//  colorClass.swift
//  Profield Chat
//
//  Created by Apple on 29/11/18.
//  Copyright © 2018 indocosmo. All rights reserved.
//

import UIKit
import Foundation
extension UIColor
{
    func lightBlueColor() -> UIColor {
        return ColorChanger().color(from: "1991B7")
    }
    func offlineColr() -> UIColor {
        return ColorChanger().color(from: "808080")
    }
}

