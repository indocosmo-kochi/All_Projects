//
//  DefineClass.swift
//  Profield Chat
//
//  Created by Apple on 28/11/18.
//  Copyright © 2018 indocosmo. All rights reserved.
//

import Foundation
struct DefineClass
{
    static let SocketUrl = "/socket"
    
    static let Register = "/api/auth/signupv2"
    
    static let activateAccount = "/api/auth/confirmActivateAccount"
    
    static let OtpActivateAccount = "/api/auth/activateAccount"
    
    static let DefaultAddress = ""
    
    static let RegisterProfileImage = "/api/auth/uploadProfilePic"
    
    static let LoginApi = "/api/auth/signinv2"
    
    static let allUser = "/api/test/users"
    
    static let forgotPassword = "/api/auth/forgotPasswordv2"
    
    static let savePassword = "/api/auth/savePassword"
    
    static let inviteUser = "/api/inviteUser"
    
    static let getAllFirendRequest = "/api/getAllFirendRequest"
    
    static let exitFromGroup = "/api/exitFromGroup"
    
    static let getContactList = "/api/ownerContactList"
    
    static let approvefriendReq = "/api/approvefriendReq"
    
    static let sendFrndRequest = "/api/sendFrndRequest"
    
    static let rejectFriendReq = "/api/rejectFriendReq"
    
    static let changePassword = "/api/changePassword"
    
    static let messageList = "/api/getMessageAll"
    
    static let saveGroup = "/api/saveGroup"
    
    static let deleteMessage = "/api/deleteMessage"
    
    static let deleteAllMessages = "/api/deleteAllMessages"
    
    static let updateGroupImage = "/api/updateGroupImage"
    
    static let uploadAttachment = "/api/uploadAttachment"
    
    static let updateProfileImage = "/api/updateProfilePic"
    
    static let updateGroup = "/api/updateGroup"
    
    static let addGroupMembers = "/api/addGroupMembers"
    
    static let DeleteGroup = "/api/deleteGroup"
    
    static let DeleteGroupMember = "/api/deleteGroupMember"
    
    static let setMemberRole = "/api/setMemberRole"
    
    static let deRegisterUser = "/api/deRegisterUser"
    
    static let loadUserDetails = "/api/loadUserDetails"
    
    static let searchUserDetails = "/api/searchUserDetails"
    
    static let updateProfile = "/api/updateProfile"
    
    static let productList = "/api/productList"
    
    static let recentProductList = "/api/recentProductList"
    
    static let chatWithOwner = "/api/chatWithOwner"
    
    static let customerFeedback = "/api/customerFeedback"
    
    static let getmoreproductdetails = "/api/getMoreProductDetails"
    
}

