//
//  ChatViewController.swift
//  Profield Chat
//
//  Created by Apple on 29/11/18.
//  Copyright © 2018 indocosmo. All rights reserved.
//

import UIKit
import IQKeyboardManager
import MobileCoreServices
import AVFoundation
import Alamofire
import RealmSwift
import ISEmojiView
import Starscream
import AVKit
import FSCalendar
import SDWebImage
class ChatViewController:
UIViewController,UITableViewDelegate,UITableViewDataSource,UITextViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIDocumentMenuDelegate,UIDocumentPickerDelegate,AVAudioRecorderDelegate,EmojiViewDelegate,WebSocketDelegate,FSCalendarDelegate,FSCalendarDataSource,FSCalendarDelegateAppearance {
    
    @IBOutlet weak var bgCalander: UIView!
    @IBOutlet weak var textViewHeight: NSLayoutConstraint!
    @IBOutlet weak var btnCancel: UIButton!
    @IBOutlet weak var btnMenu: UIButton!
    @IBOutlet weak var btnDelete: UIButton!
    @IBOutlet weak var stackVieww: UIStackView!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var btnAudio: UIButton!
    @IBOutlet weak var userDp: UIImageView!
    @IBOutlet weak var itemDp: UIImageView!
    @IBOutlet weak var lbltitleName: UILabel!
    @IBOutlet weak var txtmsg: UITextView!
    @IBOutlet weak var txtView: UIView!
    @IBOutlet weak var viewTexttttt: UIView!
    @IBOutlet weak var tblBtn: NSLayoutConstraint!
    @IBOutlet weak var bgMenuView: UIView!
    @IBOutlet weak var menuChat: UIView!
    @IBOutlet weak var menuMembers: UIView!
    @IBOutlet weak var menuAdmin: UIView!
    @IBOutlet weak var menuOwner: UIView!
    @IBOutlet weak var icnCalendar: UIButton!
    @IBOutlet weak var tbl: UITableView!
    @IBOutlet weak var recordView: UIView!
    @IBOutlet weak var itemView: UIView!
    @IBOutlet weak var navigationView: UIView!
    @IBOutlet weak var calendar: FSCalendar!
    @IBOutlet weak var lblItemTitle: UILabel!
    @IBOutlet weak var btnCancelAction: UIButton!
    @IBOutlet weak var btnEmoji: UIButton!
    @IBOutlet weak var btnDocument: UIButton!
    @IBOutlet weak var btnNewMessage: UIButton!
    @IBOutlet weak var btnSend: UIButton!
    @IBOutlet weak var AttaxchmentView: UIView!
    @IBOutlet weak var btnAttachmentCancel: UIButton!
    @IBOutlet weak var lblAttachemntName: UILabel!
    @IBOutlet weak var replyView: UIView!
    @IBOutlet weak var btnReplClose: UIButton!
    @IBOutlet weak var lblReplyName: UILabel!
    @IBOutlet weak var lblReplyMessage: UILabel!
    @IBOutlet weak var replayHeight: NSLayoutConstraint!
    @IBOutlet weak var replyViewY: NSLayoutConstraint!
    @IBOutlet weak var imgReplyImage: UIImageView!
    var timer = Timer()
    var replySelectedid : String!
    var replySelectedUSerUd : String!
    var tapGestureTable: UITapGestureRecognizer!
    var emojiView = EmojiView()
    var recordingView = SKRecordView()
    let dateFormatter = DateFormatter()
    let locale = NSLocale.current
    var datePicker : UIDatePicker!
    let toolBar = UIToolbar()
    var chosenImage = UIImage()
    let picker = UIImagePickerController()
    var imageFlag = 0
    var emojiFlag = 0
    var deleteFlag = 0
    var selectAllFlag = 0
    var dataPDF:Data!
    var pdfpath:String!
    var recordingSession: AVAudioSession!
    var audioRecorder: AVAudioRecorder!
    var arraySelectedArray = [Int]()
    var arrayMessage = [[String:String]]()
    var arrayDate = [String]()
    var bottomType: BottomType!
    var emojis: [EmojiCategory]?
    var socket: WebSocket!
    var senderName : String!
    var userAttachemntId : String!
    var groupFlag : String!
    var groupDescription : String!
    var userId : String!
    var senderId : String!
    var productName : String!
    var menuFlag : Int!
    var MyRole : Int!
    var caseCount = 300
    var socketArray = [WebSocket]()
    var reciverId : String!
    var Role : String!
    var productname : String!
    var productImage : String!
    var ChatUserName : String!
    var flagEditingOver9Line : Int!
    var mimetypeUploading : String!
    var uploadingData : Data!
    var flagScrollToBottom : Int!
    var textviewNewHeight : CGFloat!
    var textviewOrginslY : CGFloat!
    var textviewNewY : CGFloat!
    var replyFlag = 0;
    var replyAttachemntID : String!
    var replyIsAttachment : Int!
    var replyAttachemntExtension : String!
    var arrayMessagedup = [[String:String]]()
    var flagInitailTime : Int!
    
    @IBOutlet weak var lblChatUserName: UILabel!
    var datesWithChatArray = [String]()
    var contactId : String!
    var productId : String!
    var customerId : String!
    var ownerID : String!
    var online : Int!
    
    fileprivate let gregorian: Calendar = Calendar(identifier: .gregorian)
    fileprivate lazy var dateFormatter1: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
    fileprivate lazy var dateFormatter2: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
    
    //Check internet Connection
    struct Connectivity
    {
        static let sharedInstance = NetworkReachabilityManager()!
        static var isConnectedToInternet:Bool {
            return self.sharedInstance.isReachable
        }
    }
    //touch event in main view
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    //MARK:- ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        //IQKeyboard disable
        IQKeyboardManager.shared().disabledToolbarClasses.add(ChatViewController.self)
        IQKeyboardManager.shared().disabledDistanceHandlingClasses.add(ChatViewController.self)
        replyAttachemntExtension=""
        deleteFlag = 0
        icnCalendar.isHidden = false
        UserDefaults.standard.set("Chat", forKey: "socketMain")
        //socket connection check
        if socket.isConnected
        {
            //print("Socket is connecteddddddd")
        }
        else
        {
            socketCoennection()
        }
        userId = UserDefaults.standard.value(forKey: "userId") as! String
        
        flagInitailTime = 1
        let nc = NotificationCenter.default
        nc.addObserver(self, selector: #selector(updateSocket), name: Notification.Name("updateSocketChat"), object: nil)
        
        //top image
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        SDWebImageDownloader.shared.setValue(headerrr, forHTTPHeaderField:"Authorization")
        let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
        let imgUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,userAttachemntId)
        userDp.sd_imageIndicator = SDWebImageActivityIndicator.gray
        userDp.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
        
        
        var link = UserDefaults.standard.value(forKey: "productImageUrl") as! String
        link = link.replacingOccurrences(of: "/", with: "-")
        var imgUrlPro = String(format: "%@/api/attachmentsByPath/%@", apiUrl,link)
        imgUrlPro = imgUrlPro.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        itemDp.sd_setImage(with: URL(string:  imgUrlPro), placeholderImage: UIImage(named: "chat_logo.png"))
        lblItemTitle.text = UserDefaults.standard.value(forKey: "productName") as! String
        
        
        lblChatUserName.text = ChatUserName
        
        
        socket.delegate = self
        lbltitleName.text = senderName
        menuFlag = 0
        
        
        if groupFlag == "yes"
        {
            
        }
        else
        {
            menuMembers.isHidden = true
            menuOwner.isHidden = false
            menuAdmin.isHidden = true
        }
        
        //config screen
        screenSetup()
        
        //load chats from api
        flagScrollToBottom = 1
        getMsgList()
        
        tbl.reloadData()
        
        //        if arrayMessage.count != 0
        //        {
        //            //scroll to table bottom
        //            tbl.scrollToBottom()
        //        }
    }
    func screenSetup()
    {
        //        itemView.layer.borderColor = UIColor.gray.cgColor
        //        itemView.layer.borderWidth = 3
        
        self.txtmsg.text = "Send a message"
        self.txtmsg.textColor = UIColor.lightGray
        
        if online == 0
        {
            navigationView.backgroundColor = ColorChanger().color(from: "808080")
            self.view.backgroundColor = ColorChanger().color(from: "808080")
            
        }
        textviewOrginslY=txtmsg.frame.origin.y
        userDp.layer.cornerRadius = userDp.frame.size.width/2
        itemDp.layer.cornerRadius = userDp.frame.size.width/2
        viewTexttttt.layer.cornerRadius = 4
        viewTexttttt.layer.borderColor = ColorChanger().color(from: "516073").cgColor
        viewTexttttt.layer.borderWidth = 1
        txtmsg.delegate=self
        txtmsg.layer.cornerRadius = 4
        txtmsg.layer.borderColor = ColorChanger().color(from: "bababa").cgColor
        txtmsg.layer.borderWidth = 1
        AttaxchmentView.layer.cornerRadius=4
        let ViewForDoneButtonOnKeyboard = UIToolbar()
        ViewForDoneButtonOnKeyboard.sizeToFit()
        self.bgCalander.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        menuMembers.layer.borderColor = UIColor.gray.cgColor
        menuMembers.layer.borderWidth = 1
        menuMembers.layer.cornerRadius = 4
        
        menuAdmin.layer.borderColor = UIColor.gray.cgColor
        menuAdmin.layer.borderWidth = 1
        menuAdmin.layer.cornerRadius = 4
        
        menuOwner.layer.borderColor = UIColor.gray.cgColor
        menuOwner.layer.borderWidth = 1
        menuOwner.layer.cornerRadius = 4
        
        //Place recording button and record animation
        recordingView = SKRecordView(frame: CGRect (x:0, y:UIScreen.main.bounds.height - 50 , width: UIScreen.main.bounds.width, height: 40))
        recordingView.delegate = self
        recordingView.recordingImages = [UIImage(named: "rec-1.png")!,UIImage(named: "rec-2.png")!,UIImage(named: "rec-3.png")!,UIImage(named: "rec-4.png")!,UIImage(named: "rec-5.png")!,UIImage(named: "rec-6.png")!]
        recordingView.normalImage = UIImage(named: "icnMike.png")!
        view.addSubview(recordingView)
        
        //record button frame based on device
        if UIDevice().userInterfaceIdiom == .phone {
            switch UIScreen.main.nativeBounds.height {
            case 2436:
                let vConsts = NSLayoutConstraint(item:self.recordingView , attribute: .bottom, relatedBy: .equal, toItem: self.view, attribute: .bottom, multiplier: 1.0, constant: -35)
                
                let hConsts = NSLayoutConstraint(item: self.recordingView, attribute: .trailing, relatedBy: .equal, toItem: self.view, attribute: .trailing, multiplier: 1.0, constant: -10)
                view.addConstraints([hConsts])
                view.addConstraints([vConsts])
                
            case 2688:
                let vConsts = NSLayoutConstraint(item:self.recordingView , attribute: .bottom, relatedBy: .equal, toItem: self.view, attribute: .bottom, multiplier: 1.0, constant: -35)
                
                let hConsts = NSLayoutConstraint(item: self.recordingView, attribute: .trailing, relatedBy: .equal, toItem: self.view, attribute: .trailing, multiplier: 1.0, constant: -10)
                
                view.addConstraints([hConsts])
                view.addConstraints([vConsts])
                
            case 1792:
                
                let vConsts = NSLayoutConstraint(item:self.recordingView , attribute: .bottom, relatedBy: .equal, toItem: self.view, attribute: .bottom, multiplier: 1.0, constant: -35)
                
                let hConsts = NSLayoutConstraint(item: self.recordingView, attribute: .trailing, relatedBy: .equal, toItem: self.view, attribute: .trailing, multiplier: 1.0, constant: -10)
                
                view.addConstraints([hConsts])
                view.addConstraints([vConsts])
                
            default:
                
                let vConsts = NSLayoutConstraint(item:self.recordingView , attribute: .bottom, relatedBy: .equal, toItem: self.view, attribute: .bottom, multiplier: 1.0, constant: 0)
                
                let hConsts = NSLayoutConstraint(item: self.recordingView, attribute: .trailing, relatedBy: .equal, toItem: self.view, attribute: .trailing, multiplier: 1.0, constant: -10)
                
                view.addConstraints([hConsts])
                view.addConstraints([vConsts])
                
            }
        }
        
    }
    @IBAction func calendarAction(_ sender: Any) {
        //calendar filter action
        
        calendar.reloadData()
        self.view.endEditing(true)
        icnCalendar.isEnabled = false
        calendar.layer.cornerRadius = 10
        
        bgCalander.isHidden = false
        recordingView.isUserInteractionEnabled = false
        
        self.view.bringSubview(toFront: bgCalander)
    }
    
    @objc func doneClick() {
        icnCalendar.isEnabled = true
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let seletedDate = formatter.string(from: datePicker.date)
        let date = Date()
        let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: Date())
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "YYYY-MM-dd"
        let someDate = dateFormatter.string(from: date)
        let someDateYes = dateFormatter.string(from: yesterday!)
        var msgDateString : String!
        if someDate == seletedDate
        {
            msgDateString = "Today"
        }
        else if someDateYes == seletedDate
        {
            msgDateString = "Yesterday"
        }
        else
        {
            msgDateString =  seletedDate
        }
        var indexxx : Int!
        var flagSearch : Int!
        for i in 0..<arrayMessage .count
        {
            let message_date = arrayMessage[i]["message_date"]
            if msgDateString == message_date
            {
                indexxx = i
                flagSearch = 1
                break
            }
        }
        if flagSearch == 1
        {
            let indexPath = NSIndexPath(row: 0, section: indexxx)
            tbl.scrollToRow(at: indexPath as IndexPath, at: .top, animated: true)
        }
        else
        {
            //selected date not found, search nearst date
            let dateFor = DateFormatter()
            dateFor.dateFormat = "yyyy-MM-dd"
            let strDate = dateFor.date(from: seletedDate)
            for n in 0..<arrayMessage .count
            {
                let message_display_type = arrayMessage[n]["message_display_type"]
                if message_display_type == "44"
                {
                    var SelectedArrayDate = arrayMessage[n]["message_date"]!
                    if SelectedArrayDate == "Today"
                    {
                        SelectedArrayDate = dateFor.string(from: date)
                    }
                    else if SelectedArrayDate == "Yesterday"
                    {
                        SelectedArrayDate = dateFor.string(from: yesterday!)
                    }
                    let message_date = dateFor.date(from: SelectedArrayDate)
                    if strDate!  < message_date! {
                        let indexPath = NSIndexPath(row: 0, section: n)
                        tbl.scrollToRow(at: indexPath as IndexPath, at: .top, animated: true)
                        break
                    }
                }
            }
        }
        datePicker.isHidden = true
        self.toolBar.isHidden = true
    }
    @objc func cancelClick() {
        icnCalendar.isEnabled = true
        datePicker.isHidden = true
        self.toolBar.isHidden = true
    }
    @IBAction func doneBtnFromKeyboardClicked (sender: Any) {
        txtmsg.resignFirstResponder()
        emojiView.removeFromSuperview()
        emojiViewDidPressChangeKeyboardButton(emojiView)
    }
    
    @IBAction  func viewMoreAction(_ sender: UIButton)
    {
        let vc = ViewMorePopup()
        vc.modalPresentationStyle = .overFullScreen
        present(vc, animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @IBAction func MenuGrpInfoAction(_ sender: Any) {
        
    }
    @IBAction func backAction(_ sender: Any) {
        let nc = NotificationCenter.default
        nc.removeObserver("updateSocketChat")
        if Role != "1"
        {
            let vc = CustomerFeedbackPopup()
            vc.modalPresentationStyle = .overFullScreen
            present(vc, animated: true, completion: nil)
            
        }
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func cancelAction(_ sender: Any) {
        if selectAllFlag == 0
        {
            btnCancel.setImage(UIImage(named: "icnTickWhite"), for: .normal)
            arraySelectedArray = [Int]()
            selectAllFlag = 1
            for i in 0..<arrayMessage .count{
                let sendId = arrayMessage[i]["sender_id"]
                if sendId == userId
                {
                    let textt = arrayMessage[i]["message_text"]
                    let is_deleted  = arrayMessage[i]["is_deleted"]
                    if is_deleted != "1"
                    {
                        arraySelectedArray.append(i)
                        tbl.reloadData()
                    }
                }
            }
            
        }
        else
        {
            btnCancel.setImage(UIImage(named: "icnUnTickWhite"), for: .normal)
            selectAllFlag = 0
            deleteFlag = 0
            tbl.reloadData()
            arraySelectedArray = [Int]()
            tbl.reloadData()
        }
    }
    @IBAction func DeleteAPiAction(_ sender: Any) {
        if arraySelectedArray .count == 0
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "No messages selected")
            self.btnCancel.setImage(UIImage(named: "icnUnTickWhite"), for: .normal)
            self.deleteFlag = 0
            self.btnCancel.isHidden = true
            self.btnDelete.isHidden = true
            self.btnMenu.isHidden = false
            self.btnCancelAction.isHidden = true
            icnCalendar.isHidden = false
            arraySelectedArray = [Int]()
            tbl.reloadData()
        }else
        {
            let alert = UIAlertController(title: "Alert", message: "Are you sure, you want to delete selected messages?", preferredStyle: .alert)
            let yesButton = UIAlertAction(title: "Yes", style: .default, handler: {(_ action: UIAlertAction) -> Void in
                self.APiCallDelete()
             
            })
            let noButton = UIAlertAction(title: "No", style: .default, handler: {(_ action: UIAlertAction) -> Void in
                self.btnCancel.setImage(UIImage(named: "icnUnTickWhite"), for: .normal)
                self.deleteFlag = 0
                self.btnCancel.isHidden = true
                self.btnDelete.isHidden = true
                self.btnMenu.isHidden = false
                self.icnCalendar.isHidden = false
                self.btnCancelAction.isHidden = true
                self.arraySelectedArray = [Int]()
                self.tbl.reloadData()
            })
            alert.addAction(yesButton)
            alert.addAction(noButton)
            present(alert, animated: true)
        }
    }
    @IBAction func DeleteAllAction(_ sender: Any) {
        let alert = UIAlertController(title: "Alert", message: "Are you sure, you want to delete selected messages?", preferredStyle: .alert)
        let yesButton = UIAlertAction(title: "Yes", style: .default, handler: {(_ action: UIAlertAction) -> Void in
            self.bgMenuView.isHidden = true
            self.menuFlag = 0
            self.APiCallDeleteAllMessage()
        })
        let noButton = UIAlertAction(title: "No", style: .default, handler: {(_ action: UIAlertAction) -> Void in
        })
        alert.addAction(yesButton)
        alert.addAction(noButton)
        present(alert, animated: true)
    }
    func APiCallDeleteAllMessage()
    {
        AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let  userId = UserDefaults.standard.value(forKey: "userId") as! String
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let par = ["Authorization": headerrr]
        let str = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.deleteAllMessages)
        let url = String(format: "%@?userId=%@&groupId=%@", str,userId,senderId!)
        APiClass.apiCallGetWithHeaderAndBody(mainUrl: url, postParameters: par) { (responseArray) in
            let responseDict = responseArray[0]
            if (responseDict.object(forKey: "error") != nil)
            {
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["error"]
                AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
            }
            else
            {
                AppHelper.HidePrograss(vc: self.view)
                self.arraySelectedArray = [Int]()
                self.flagScrollToBottom = 0
                self.getMsgList()
            }
        }
    }
    func APiCallDelete()
    {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy HH:mm:ss"
        let date = Date()
        let dateString = formatter.string(from: date)
        var ArraySelectedMem = [String]()
        for i in 0..<arraySelectedArray .count{
            let idIndex = arraySelectedArray[i] as! Int
            let sendId = arrayMessage[idIndex]["id"]
            ArraySelectedMem.append(sendId!)
        }
        let exampleDict: [String: Any] = [
            "userid" : userId,
            "messageId" : ArraySelectedMem
        ]
        if let jsonString = JSONStringEncoder().encode(exampleDict) {
            AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
            let accessToken = UserDefaults.standard.value(forKey: "accessToken")
            let tokenType = UserDefaults.standard.value(forKey: "tokenType")
            let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
            let HeaderPar = ["Authorization": headerrr]
            let str = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.deleteMessage)
            let par = ["threadPid": jsonString]
            print(par)
            APiClass.apiCallPostValueWithHeader(mainUrl: str, postParameters: par,headerParams:HeaderPar) { (responseArray) in
                let responseDict = responseArray[0]
                if (responseDict.object(forKey: "error") != nil)
                {
                    AppHelper.HidePrograss(vc: self.view)
                    let message = responseDict["error"]
                    AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
                }
                else
                {
                    let arrayAllResponse = responseDict["value"] as! NSArray
                    let dict = arrayAllResponse[0] as! [String : Any]
                    AppHelper.HidePrograss(vc: self.view)
                    let message = dict["status"] as! String
                    if message == "success"
                    { self.btnCancel.setImage(UIImage(named: "icnUnTickWhite"), for: .normal)
                        self.deleteFlag = 0
                        
                        self.btnCancel.isHidden = true
                        self.btnDelete.isHidden = true
                        self.btnMenu.isHidden = false
                        self.icnCalendar.isHidden = false
                        self.lbltitleName.isHidden = false
                        self.btnCancelAction.isHidden = true
                        self.arraySelectedArray = [Int]()
                        self.flagScrollToBottom = 0
                        self.getMsgList()
                    }
                    else
                    {
                        AppHelper.HidePrograss(vc: self.view)
                        AppHelper.showAlertMessage(vc: self, title: "Sorry", message: "Something went wrong")
                    }
                }
            }
        }
        else
        {
            AppHelper.showAlertMessage(vc: self, title: "Sorry", message: "Something went wrong")
        }
    }
    //MARK: API Call
    func getMsgList(){
        //load messages from server
        //        self.arraySelectedArray = [Int]()
        if let savedValue = UserDefaults.standard.string(forKey: "loginStatus"){
            AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
            let accessToken = UserDefaults.standard.value(forKey: "accessToken")
            let tokenType = UserDefaults.standard.value(forKey: "tokenType")
            let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
            let par = ["Authorization": headerrr]
            let str = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.messageList)
            let count = "123"
            var isGroup = ""
            if groupFlag == "yes"
            {
                isGroup = "true"
            }
            else
            {
                isGroup = "false"
            }
            
            var url = ""
            if Role == "1"
            {
                url = String(format: "%@?productId=%@&contactId=%@&isUser=%@&userId=%@", str,productId,ownerID,"false",userId)
                
            }
            else
            {
                url = String(format: "%@?productId=%@&contactId=%@&isUser=%@&userId=%@", str,senderId,reciverId,"true",userId)
            }
            
            
            
            print(url)
            //   let uu = "http://192.168.1.176:8080/api/getMessageAll?productId=5d4bb213bd2d4b0a8c9c08d5&contactId=&isUser=true&userId=5d5a42cebd2d4b122c809d08"
            APiClass.apiCallGetWithHeader(mainUrl: url, postParameters: par) { (responseArray) in
                DispatchQueue.main.async {
                    AppHelper.HidePrograss(vc: self.view)
                }
                let responseDict = responseArray[0]
                if (responseDict.object(forKey: "error") != nil)
                {
                    AppHelper.HidePrograss(vc: self.view)
                    let message = responseDict["error"]
                    AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
                }
                else
                {
                    
                    
                    if self.flagInitailTime == 1
                    {
                        self.flagInitailTime = 0
                        if self.arrayMessage.count != 0
                        {
                            self.arrayMessagedup = self.arrayMessage
                        }
                        
                    }
                    
                    self.datesWithChatArray = [String]()
                    self.arrayMessage = [[String:String]]()
                    self.arrayDate = [String]()
                    let arrayAllResponse = responseDict["value"] as! NSArray
                    let arrayResposeChat = arrayAllResponse[0]
                        as! [[String:Any]]
                    
                    for i in 0..<arrayResposeChat .count
                    {
                        let  messageType = String(format: "%d",  arrayResposeChat[i]["messageType"]! as! Int)
                        if messageType != "6"
                        {
                            let  is_deleted = String(format: "%d",  arrayResposeChat[i]["isDeleted"]! as! Int)
                            var  attachment = "0"
                            if arrayResposeChat[i]["attachmentId"]! is String
                            {
                                attachment = "1"
                                
                            }
                            else
                            {
                                attachment = "0"
                            }
                            
                            var  message_date =   AppHelper.UTCToLocalDate(date: arrayResposeChat[i]["messageDate"] as! String)
                            
                            //removing T from message_date
                            message_date = message_date.replacingOccurrences(of: "T", with: " ")
                            //split message_date for date and time
                            let strArray = message_date.split(separator: ".")
                            message_date = String(strArray[0])
                            if !self.datesWithChatArray.contains(message_date)
                            {
                                self.datesWithChatArray.append(message_date)
                            }
                            let strArrayNew = message_date.split(separator: " ")
                            let date = Date()
                            // chat today, yesterday and date
                            let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: Date())
                            let dateFormatter = DateFormatter()
                            dateFormatter.dateFormat = "YYYY-MM-dd"
                            let someDate = dateFormatter.string(from: date)
                            let someDateYes = dateFormatter.string(from: yesterday!)
                            var msgDateString : String!
                            if someDate == String(strArrayNew[0])
                            {
                                msgDateString = "Today"
                            }
                            else if someDateYes == String(strArrayNew[0])
                            {
                                msgDateString = "Yesterday"
                            }
                            else
                            {
                                msgDateString =  String(strArrayNew[0])
                            }
                            
                            if self.arrayDate.contains(msgDateString)
                            {
                                //add time
                                message_date = AppHelper.UTCToLocalTime(date: arrayResposeChat[i]["time"] as! String)
                            }
                            else
                            {
                                // add message date as cell center information message
                                //date
                                self.arrayDate.append(msgDateString)
                                message_date = AppHelper.UTCToLocalTime(date: arrayResposeChat[i]["time"] as! String)
                                let   dict = ["replyCheck":"0","message_date":msgDateString,"senderName":"","attachment":"0","sender_id":"" ,"reciever_id":"","message_text":"","id":"","message_display_type":"44"] as! [String : String]
                                
                                self.arrayMessage.append(dict )
                            }
                            
                            var dict : [String:String]!
                            
                            //check is attachment or deleted deleted
                            if attachment == "0" ||  is_deleted == "1"
                            {
                                var  SenderName : String!
                                
                                SenderName = ""
                                
                                var message_text = ""
                                if  is_deleted == "1"
                                {
                                    message_text = "This message was deleted"
                                }
                                else
                                {
                                    message_text = arrayResposeChat[i]["messageText"] as! String
                                }
                                
                                //applaying string formats
                                message_text = message_text.replacingOccurrences(of: "<div></div>", with: " \n ")
                                message_text = message_text.replacingOccurrences(of: "<div>", with: "\n")
                                message_text = message_text.replacingOccurrences(of: "</div>", with: "")
                                message_text = message_text.replacingOccurrences(of: "<br>", with: "")
                                message_text = message_text.replacingOccurrences(of: "&nbsp;", with: " ")
                                message_text = message_text.replacingOccurrences(of: "&lt;", with: "<")
                                message_text = message_text.replacingOccurrences(of: "&gt;", with: ">")
                                
                                message_text = message_text.replacingOccurrences(of: "amp;", with: "")
                                
                                
                                
                                var replyCheck = ""
                                if let replyMessage = arrayResposeChat[i]["replyUserId"]! as? String
                                {
                                    replyCheck = "1"
                                }
                                else
                                {
                                    replyCheck = ""
                                }
                                
                                
                                if replyCheck == "1"
                                {
                                    
                                    let replyUserId = arrayResposeChat[i]["replyUserId"]! as? String
                                    
                                    var replyMsgUserName = ""
                                    
                                    
                                    if self.Role == "1"
                                    {
                                        if replyUserId == self.customerId
                                        {
                                            replyMsgUserName = self.lbltitleName.text!
                                        }
                                        else
                                        {
                                            replyMsgUserName = "You"
                                        }
                                    }
                                    else
                                    {
                                        if replyUserId == self.reciverId
                                        {
                                            replyMsgUserName = self.lbltitleName.text!
                                        }
                                        else
                                        {
                                            replyMsgUserName = "You"
                                        }
                                    }
                                    
                                    
                                    var replyAttachmentExtension = ""
                                    replyAttachmentExtension =  String(format: "%@",(arrayResposeChat[i]["replyAttachmentFormat"] as! CVarArg ))
                                    if replyAttachmentExtension == "<null>"
                                    {
                                        replyAttachmentExtension = ""
                                    }
                                    
                                    var replyAttachmentId = ""
                                    replyAttachmentId =  String(format: "%@",(arrayResposeChat[i]["replyAttachmentId"] as! CVarArg ))
                                    if replyAttachmentId == "<null>"
                                    {
                                        replyAttachmentId = ""
                                    }
                                    
                                    let replyIsAttachmentAPi = String(format: "%d",arrayResposeChat[i]["replyIsAttachment"] as! Int)
                                    
                                    let replyMessageType = String(format: "%d",arrayResposeChat[i]["replyMessageType"] as! Int)
                                    
                                    
                                    dict = (["replyMessageType":replyMessageType,"replyIsAttachment":replyIsAttachmentAPi,"replyAttachmentExtension":replyAttachmentExtension,"replyAttachmentId":replyAttachmentId,"replyMsgUserName":replyMsgUserName, "replyCheck":replyCheck,"replyUserId":arrayResposeChat[i]["replyUserId"], "replyMessageText":arrayResposeChat[i]["replyMessageText"], "replyMessageId":arrayResposeChat[i]["replyMessageId"],"is_deleted":is_deleted,"message_date":message_date,"senderName":SenderName,"attachment":"0","sender_id":arrayResposeChat[i]["senderId"] ,"reciever_id":arrayResposeChat[i]["receiverId"],"message_text":message_text,"id":arrayResposeChat[i]["id"],"message_display_type":String(format: "%d",  arrayResposeChat[i]["messageType"]! as! Int)] as! [String : String])
                                    
                                }
                                else
                                {
                                    dict = (["replyCheck":"0","is_deleted":is_deleted,"message_date":message_date,"senderName":SenderName,"attachment":"0","sender_id":arrayResposeChat[i]["senderId"] ,"reciever_id":arrayResposeChat[i]["receiverId"],"message_text":message_text,"id":arrayResposeChat[i]["id"],"message_display_type":String(format: "%d",  arrayResposeChat[i]["messageType"]! as! Int)] as! [String : String])
                                }
                            }
                            else
                            {
                                var  SenderName : String!
                                
                                SenderName = ""
                                
                                
                                var message_text = arrayResposeChat[i]["messageText"] as! String
                                
                                //applaying string formats
                                message_text = message_text.replacingOccurrences(of: "<div></div>", with: " \n ")
                                message_text = message_text.replacingOccurrences(of: "<div>", with: "\n")
                                message_text = message_text.replacingOccurrences(of: "</div>", with: "")
                                message_text = message_text.replacingOccurrences(of: "<br>", with: "")
                                message_text = message_text.replacingOccurrences(of: "&nbsp;", with: " ")
                                message_text = message_text.replacingOccurrences(of: "&lt;", with: "<")
                                message_text = message_text.replacingOccurrences(of: "&gt;", with: ">")
                                message_text = message_text.replacingOccurrences(of: "amp;", with: "")
                                
                                
                                
                                
                                var replyCheck = ""
                                if let replyMessage = arrayResposeChat[i]["replyUserId"]! as? String
                                {
                                    replyCheck = "1"
                                }
                                else
                                {
                                    replyCheck = ""
                                }
                                if replyCheck == "1"
                                {
                                    
                                    let replyUserId = arrayResposeChat[i]["replyUserId"]! as? String
                                    var replyMsgUserName = ""
                                    
                                    
                                    if self.Role == "1"
                                    {
                                        if replyUserId == self.customerId
                                        {
                                            replyMsgUserName = self.lbltitleName.text!
                                        }
                                        else
                                        {
                                            replyMsgUserName = "You"
                                        }
                                    }
                                    else
                                    {
                                        if replyUserId == self.reciverId
                                        {
                                            replyMsgUserName = self.lbltitleName.text!
                                        }
                                        else
                                        {
                                            replyMsgUserName = "You"
                                        }
                                    }
                                    
                                    
                                    
                                    var replyAttachmentId = ""
                                    
                                    replyAttachmentId =  String(format: "%@",(arrayResposeChat[i]["replyAttachmentId"] as! CVarArg ))
                                    if replyAttachmentId == "<null>"
                                    {
                                        replyAttachmentId = ""
                                    }
                                    
                                    var replyAttachmentExtension = ""
                                    replyAttachmentExtension =  String(format: "%@",(arrayResposeChat[i]["replyAttachmentFormat"] as! CVarArg ))
                                    if replyAttachmentExtension == "<null>"
                                    {
                                        replyAttachmentExtension = ""
                                    }
                                    
                                    let replyUserIdApi = arrayResposeChat[i]["replyUserId"]
                                    let replyImageThumbnailApi = "sadasda"//arrayResposeChat[i]["replyImageThumbnail"]
                                    
                                    let replyMessageTextAPI = arrayResposeChat[i]["replyMessageText"]
                                    let replyMessageIdAPi = arrayResposeChat[i]["replyMessageId"]
                                    let replyIsAttachmentAPi = String(format: "%d",arrayResposeChat[i]["replyIsAttachment"] as! Int)
                                    //                              let replyImageThumbnailApi = arrayResposeChat[i]["replyImageThumbnail"]
                                    
                                    let attachment_extension = arrayResposeChat[i]["attachment_extension"]
                                    let attachment_nameApi = arrayResposeChat[i]["attachment_name"]
                                    let attachment_idApi = arrayResposeChat[i]["attachment_id"]
                                    let sender_idApi = arrayResposeChat[i]["sender_id"]
                                    
                                    let reciever_idApi = arrayResposeChat[i]["reciever_id"]
                                    let replyMessageType = String(format: "%d",arrayResposeChat[i]["replyMessageType"] as! Int)
                                    dict = (["replyMessageType":replyMessageType,"replyAttachmentExtension":replyAttachmentExtension,"replyAttachmentId":replyAttachmentId,"replyMsgUserName":replyMsgUserName,"replyCheck":replyCheck,"replyUserId":replyUserIdApi, "replyImageThumbnail":replyImageThumbnailApi, "replyIsAttachment":replyIsAttachmentAPi, "replyMessageText":replyMessageTextAPI, "replyMessageId":replyMessageIdAPi,"attachmentName":  arrayResposeChat[i]["attachmentName"] ,  "is_deleted":is_deleted,"message_date":message_date,"senderName":SenderName,"attachment":attachment,"attachment_extension":arrayResposeChat[i]["attachmentExt"],"attachment_id":arrayResposeChat[i]["attachmentId"],"sender_id":arrayResposeChat[i]["senderId"] ,"reciever_id":arrayResposeChat[i]["receiverId"],"message_text":message_text,"id":arrayResposeChat[i]["id"],"message_display_type":String(format: "%d",  arrayResposeChat[i]["messageType"]! as! Int)] as! [String : String])
                                    
                                    
                                }
                                else
                                {
                                    dict = (["replyCheck":"0","attachmentName":  arrayResposeChat[i]["attachmentName"] ,  "is_deleted":is_deleted,"message_date":message_date,"senderName":SenderName,"attachment":attachment,"attachment_extension":arrayResposeChat[i]["attachmentExt"],"attachment_id":arrayResposeChat[i]["attachmentId"],"sender_id":arrayResposeChat[i]["senderId"] ,"reciever_id":arrayResposeChat[i]["receiverId"],"message_text":message_text,"id":arrayResposeChat[i]["id"],"message_display_type":String(format: "%d",  arrayResposeChat[i]["messageType"]! as! Int)] as! [String : String])
                                }
                                
                            }
                            
                            self.arrayMessage.append(dict as! [String : String])
                        }
                    }
                    self.tbl.reloadData()
                    self.calendar.reloadData()
                    if self.arrayMessage.count != 0
                    {
                        if self.arrayMessagedup.count != 0
                        {
                            for i in 0..<self.arrayMessagedup .count
                            {
                                self.arrayMessage.append(self.arrayMessagedup[i])
                                
                            }
                        }
                        
                        self.arrayMessage = self.arrayMessage.removingDuplicates()
                        //scroll to table bottom
                        if self.flagScrollToBottom != 0
                        {
                            
                            self.tbl.scrollToBottom()
                        }
                        print(self.arrayMessage)
                        
                    }
                }
            }
        }
    }
    @IBAction func SendAction(_ sender: Any){
        //send message
        if Connectivity.isConnectedToInternet {
            
            if imageFlag != 0
            {
                uploadData(fileName: lblAttachemntName.text!, mimetype: mimetypeUploading, UploadData: uploadingData,messageType:"3")
            }
            else
            {
               
                var strWhiteSpace = txtmsg.text.replacingOccurrences(of: "\n", with: "")
                strWhiteSpace =  strWhiteSpace.trimmingCharacters(in: .whitespacesAndNewlines)
                
                if txtmsg.text != "Send a message" || txtmsg.isFirstResponder
                {
                    if txtmsg.text != ""
                    {
                        if  strWhiteSpace != ""
                        {
                            
                            var msgText = ""
                            let arrayofstring = txtmsg.text.characters.map { (Character) -> Character in
                                return Character
                            }
                            var flagString = 0
                            for i in 0..<arrayofstring .count
                            {
                                let str = String(arrayofstring[i])
                                if str == "\n"
                                {
                                    if flagString == 0
                                    {
                                        flagString = 1
                                        msgText = String(format: "%@%@", msgText,"</>")
                                        
                                    }
                                    else if flagString == 1
                                    {
                                        flagString = 2
                                        
                                        msgText = String(format: "%@%@", msgText,str)
                                    }
                                    else
                                    {
                                        flagString = 2
                                        msgText = String(format: "%@%@", msgText,str)
                                    }
                                }
                                else
                                {
                                    flagString = 0
                                    msgText = String(format: "%@%@", msgText,str)
                                }
                            }
                            msgText = msgText.replacingOccurrences(of: "<", with: "&lt;")
                            msgText = msgText.replacingOccurrences(of: ">", with: "&gt;")
                            msgText = msgText.replacingOccurrences(of: "&lt;/&gt;", with: "<div></div>")
                            msgText = msgText.replacingOccurrences(of: "\n", with: "<div><br></div>")
                            
                            if replyFlag == 1
                            {
                                var isAttachemt = ""
                                if replyIsAttachment == 1
                                {
                                    isAttachemt = "true"
                                }
                                else
                                {
                                    isAttachemt = "false"
                                }
                                
                                if Role == "1"
                                {
                                    let message = ["replyImageExtension":replyAttachemntExtension,"iosReplyMessage":"true","replyUserId":replySelectedUSerUd,"replyMessageText":lblReplyMessage.text!,"replyMessageId":replySelectedid,"reply_is_attachment":"false","replyMsgEnable":"true","attachmentId":replyAttachemntID,"replySenderId":userId,"replyIsAttachment":isAttachemt,"replyUserName":self.lblReplyName.text!,"replyIndUserName":self.lbltitleName.text!,"replyMessageContent":lblReplyMessage.text!,"replyProfileImageUrl":"","replyStatus":"reply_msg","messageType":"1","messageText":msgText,"receiverId":customerId ,"senderId":userId,"type":"1","status":"textMessage","customerId":customerId,"contactId":contactId,"productId":productId, "isUser":"false"] as [String : Any]
                                    
                                    if let jsonString = JSONStringEncoder().encode(message) {
                                        socket.write(string: jsonString)
                                    }
                                }
                                else
                                {
                                    let message = ["replyImageExtension":replyAttachemntExtension,"iosReplyMessage":"true","replyUserId":replySelectedUSerUd,"replyMessageText":lblReplyMessage.text!,"replyMessageId":replySelectedid,"reply_is_attachment":"false","replyMsgEnable":"true","attachmentId":replyAttachemntID,"replySenderId":userId,"replyIsAttachment":isAttachemt,"replyUserName":self.lblReplyName.text!,"replyIndUserName":self.lbltitleName.text!,"replyMessageContent":lblReplyMessage.text!,"replyProfileImageUrl":"","replyStatus":"reply_msg","messageType":"1","messageText":msgText,"receiverId":reciverId ,"productId":senderId,"type":"1","status":"textMessage","senderId":userId,"customerId":userId, "isUser":"true"] as [String : Any]
                                    
                                    if let jsonString = JSONStringEncoder().encode(message) {
                                        socket.write(string: jsonString)
                                    }
                                }
                            }
                            else
                            {
                                if Role == "1"
                                {
                                    let message = ["messageType":"1","messageText":msgText,"receiverId":customerId ,"senderId":userId,"type":"1","status":"textMessage","customerId":customerId,"contactId":contactId,"productId":productId, "isUser":"false"] as [String : Any]
                                    
                                    if let jsonString = JSONStringEncoder().encode(message) {
                                        socket.write(string: jsonString)
                                    }
                                }
                                else
                                {
                                    let message = ["messageType":"1","messageText":msgText,"receiverId":reciverId ,"productId":senderId,"type":"1","status":"textMessage","senderId":userId,"customerId":userId, "isUser":"true"] as [String : Any]
                                    
                                    if let jsonString = JSONStringEncoder().encode(message) {
                                        socket.write(string: jsonString)
                                    }
                                }
                            }
                            
                            
                            txtmsg.text = ""
                            txtmsg.isScrollEnabled = false
                            txtmsg.translatesAutoresizingMaskIntoConstraints = false
                            
                            self.replyFlag = 0
                            self.replyView.isHidden = true
                            self.btnReplClose.isHidden=true
                        }
                    }
                }
            }
        }
        else
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Please check your internet connection")
        }
    }
    
    //MARK:- Menu
    @IBAction func menuAction(_ sender: Any) {
        if menuFlag == 1
        {
            bgMenuView.isHidden = true
            menuFlag = 0
        }
        else
        {
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.tapBlurButton(_:)))
            bgMenuView.addGestureRecognizer(tapGesture)
            bgMenuView.isHidden = false
            menuFlag = 1
        }
    }
    @objc func tapBlurButton(_ sender: UITapGestureRecognizer) {
        bgMenuView.isHidden = true
        menuFlag = 0
    }
    
    @IBAction func deleteMsgCancelAction(_ sender: Any) {
        
        self.btnCancel.setImage(UIImage(named: "icnUnTickWhite"), for: .normal)
        self.deleteFlag = 0
        self.btnCancel.isHidden = true
        self.btnDelete.isHidden = true
        self.btnMenu.isHidden = false
        self.icnCalendar.isHidden = false
        self.arraySelectedArray = [Int]()
        self.lbltitleName.isHidden = false
        self.btnCancelAction.isHidden = true
        self.tbl.reloadData()
    }
    
    @IBAction func DeleteMessageActin(_ sender: Any) {
        self.view.endEditing(true)
        
        
        var deleteOptionAvailable = 0
        
        self.view.endEditing(true)
        for index in 0..<arrayMessage .count
        {
            let sendId = arrayMessage[index]["sender_id"]
            let is_deleted = arrayMessage[index]["is_deleted"]
            let message_display_type = arrayMessage[index]["message_display_type"]
            if message_display_type != "44"
            {
                if message_display_type != "4"
                {
                    if sendId == userId
                    {
                        let textt = arrayMessage[index]["message_text"]
                        if is_deleted != "1"
                        {
                            deleteOptionAvailable = 1
                        }
                    }
                }}
        }
        
        if deleteOptionAvailable == 1
        {
            
            if deleteFlag == 0
            {
                btnCancel.isHidden = false
                btnDelete.isHidden = false
                deleteFlag = 1
                tbl.reloadData()
                bgMenuView.isHidden = true
                menuFlag = 0
                btnMenu.isHidden = true
                icnCalendar.isHidden = true
                self.btnCancelAction.isHidden = false
            }
            else
            {
                deleteFlag = 0
                btnCancel.isHidden = true
                btnDelete.isHidden = true
                icnCalendar.isHidden = false
                btnMenu.isHidden = false
                self.btnCancelAction.isHidden = true
            }
        }
        else
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "You have no messages for delete")
        }
    }
    //MARK:- TableView Delegate
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return arrayMessage.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    //MyCellAttachmentL
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let replayCheck = arrayMessage[indexPath.section]["replyCheck"] as! String
        var replyMesageContain = 0
        var textt = ""
        var replyMesage = ""
        var replyMessageName = ""
        var replyMessageType = ""
        var replayIsAttachement = 0
        let is_deleted  = arrayMessage[indexPath.section]["is_deleted"]
        
        if replayCheck == "1"
        {
            if arrayMessage[indexPath.section]["replyAttachmentId"] == nil
            {
                replayIsAttachement = 0
            }
            else
            {
                if arrayMessage[indexPath.section]["replyAttachmentId"] != ""
                {
                    replayIsAttachement = 1
                }
                
            }
            replyMessageType = arrayMessage[indexPath.section]["replyMessageType"] as! String
            
            replyMesage = arrayMessage[indexPath.section]["replyMessageText"]!
            textt = arrayMessage[indexPath.section]["message_text"]!
            replyMessageName = arrayMessage[indexPath.section]["replyMsgUserName"]!
            replyMesage = replyMesage.replacingOccurrences(of: "<div></div>", with: " \n ")
            replyMesage = replyMesage.replacingOccurrences(of: "<div>", with: "\n")
            replyMesage = replyMesage.replacingOccurrences(of: "</div>", with: "")
            replyMesage = replyMesage.replacingOccurrences(of: "<br>", with: "")
            replyMesage = replyMesage.replacingOccurrences(of: "&nbsp;", with: " ")
            replyMesage = replyMesage.replacingOccurrences(of: "&lt;", with: "<")
            replyMesage = replyMesage.replacingOccurrences(of: "&gt;", with: ">")
            replyMesage = replyMesage.replacingOccurrences(of: "amp;", with: "")
            
            replyMesage = replyMesage.replacingOccurrences(of: "\n\t\t\t\t\t", with: "")
            
            if is_deleted == "1"
            {
                replyMesageContain = 0
            }
            else
            {
                replyMesageContain = 1
            }
            
        }
        else
        {
            
            replyMesageContain = 0
            textt = arrayMessage[indexPath.section]["message_text"]!
        }
        let message_date = arrayMessage[indexPath.section]["message_date"]
        let sendId = arrayMessage[indexPath.section]["sender_id"]
        //  textt =  textt!.trimmingCharacters(in: .whitespacesAndNewlines)
        let message_display_type = arrayMessage[indexPath.section]["message_display_type"]
        let attachment = arrayMessage[indexPath.section]["attachment"]
        
        //    let messageType = arrayMessage[indexPath.section]["messageType"]
        
        
        
        //chat Center information message
        if message_display_type == "4"
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cellCenter", for: indexPath as IndexPath)
            let lblMsg : UILabel = cell.viewWithTag(1) as! UILabel
            lblMsg.text = textt
            cell.selectionStyle = .none
            return cell
        }
        if message_display_type == "44"
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cellCenter", for: indexPath as IndexPath)
            let lblMsg : UILabel = cell.viewWithTag(1) as! UILabel
            lblMsg.text = message_date
            cell.selectionStyle = .none
            return cell
            
        }
        // MARK: - my Message - Right side Attachment
        if sendId == userId
        {
            if attachment != "0"
            {
                //Right side  attachemnt
                let cell = tableView.dequeueReusableCell(withIdentifier: "MyCellAttachmentR", for: indexPath as IndexPath)
                let img : UIImageView = cell.viewWithTag(1) as! UIImageView
                let lblDate : UILabel = cell.viewWithTag(2) as! UILabel
                let viewLeft : UIView = cell.viewWithTag(3) as! UIView
                let viewBGSelect : UIView = cell.viewWithTag(32) as! UIView
                
                viewLeft.layer.cornerRadius = 8
                lblDate.text = message_date
                let imgReplay : UIImageView = cell.viewWithTag(390) as! UIImageView
                let lblMsg : UILabel = cell.viewWithTag(22) as! UILabel
                let lblAttachementName : UILabel = cell.viewWithTag(21) as! UILabel
                let viewReply : UIView = cell.viewWithTag(602) as! UIView
                let lblReplyMessageNameCell : UILabel = cell.viewWithTag(62) as! UILabel
                let lblReplyMessagCell : UILabel = cell.viewWithTag(63) as! UILabel
                let replyNavButton : UIButton = cell.viewWithTag(210) as! UIButton
                replyNavButton.addTarget(self, action: #selector(replyNavigationAction(_:)), for: .touchUpInside)
                viewReply.layer.cornerRadius = 4
                let attachment_extension = arrayMessage[indexPath.section]["attachment_extension"]
                if attachment_extension == "jpeg" || attachment_extension == "png" || attachment_extension == "jpg" || attachment_extension == "webp" || attachment_extension == "tiff" || attachment_extension == "BMP" || attachment_extension == "ico" || attachment_extension == "gif" || attachment_extension == "svg" || attachment_extension == "svgz" || attachment_extension == "TIF" || attachment_extension == "JFIF" || attachment_extension == "DIB" || attachment_extension == "dib" || attachment_extension == "pjp" || attachment_extension == "PJP" || attachment_extension == "pjpeg" || attachment_extension == "PJPEG" || attachment_extension == "DIB" || attachment_extension == "dib" || attachment_extension == "pjp" || attachment_extension == "PJP" || attachment_extension == "pjpeg" || attachment_extension == "PJPEG"
                    
                {
                    img.sd_imageIndicator = SDWebImageActivityIndicator.gray
                    let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                    let attachment_id = arrayMessage[indexPath.section]["attachment_id"]
                    let imgUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id!)
                    img.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                }
                else if message_display_type == "2"
                {
                    img.image = UIImage(named: "icnVoiceMessage.png")
                }
                else if attachment_extension == "mp4" || attachment_extension == "quicktime"
                {
                    img.sd_imageIndicator = SDWebImageActivityIndicator.gray
                    let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                    let attachment_id = arrayMessage[indexPath.section]["attachment_id"]
                    let imgUrl = String(format: "%@/api/attachmentasbody/%@/true", apiUrl,attachment_id!)
                    img.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                    
                    //                    img.image = UIImage(named: "IcnMp4.jpg")
                }
                else if attachment_extension == "mp3"
                {
                    img.image = UIImage(named: "icnMp3.jpg")
                }
                    
                else if attachment_extension == "pdf"
                {
                    img.image = UIImage(named: "icnPdf.jpg")
                }
                else if attachment_extension == "ppt" || attachment_extension == "pptx"
                {
                    img.image = UIImage(named: "icnPpt.jpg")
                }
                else if attachment_extension == "txt" || attachment_extension == "text"
                {
                    img.image = UIImage(named: "icnTxt.jpg")
                }
                else if attachment_extension == "doc" || attachment_extension == "docx"
                {
                    img.image = UIImage(named: "icnWord.jpg")
                }
                else if attachment_extension == "xls" || attachment_extension == "xlsx"
                {
                    img.image = UIImage(named: "icnXls.jpg")
                }
                else
                {
                    img.image = UIImage(named: "icnFileChat")
                }
                if arraySelectedArray.contains(indexPath.section)
                {
                    viewBGSelect.isHidden = false
                }
                else
                {
                    viewBGSelect.isHidden = true
                }
                
                lblReplyMessagCell.text = replyMesage
                lblReplyMessageNameCell.text = replyMessageName
                
                lblAttachementName.text=arrayMessage[indexPath.section]["attachmentName"]
                lblMsg.text=textt
                
                if message_display_type == "2"
                {
                    lblAttachementName.text = ""
                    lblMsg.text=""
                }
                
                var wid = lblMsg.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:12.0)])
                lblMsg.textAlignment = .left
                
                
                if wid.width < 244
                {
                    let filteredConstraints = cell.contentView.constraints.filter { $0.identifier == "leadingConst" }
                    if let leadingConst = filteredConstraints.first {
                        // DO YOUR LOGIC HERE
                        leadingConst.constant = viewLeft.frame.origin.x + viewLeft.frame.size.width - wid.width - 30
                        let viewWIdthy = self.view.bounds.width//
                        
                        if viewWIdthy - wid.width - 32 >= viewWIdthy-132
                        {
                            leadingConst.constant = viewWIdthy-132 - 13
                        }
                        else
                        {
                            if wid.width < 132
                            {
                                leadingConst.constant = viewWIdthy - 132-13
                            }
                            else
                            {
                                leadingConst.constant = viewWIdthy - wid.width-22
                            }
                            
                        }
                    }
                    
                    
                    if replyMesageContain != 0
                    {
                        var rplyWidth = lblReplyMessagCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:11.0)])
                        let rplyWidthName = lblReplyMessageNameCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:12.0)])
                        if rplyWidthName.width > rplyWidth.width
                        {
                            rplyWidth = rplyWidthName
                        }
                        if rplyWidth.width > wid.width{
                            
                            if rplyWidth.width < 244
                            {
                                let filteredConstraints = cell.contentView.constraints.filter { $0.identifier == "leadingConst" }
                                if let leadingConst = filteredConstraints.first {
                                    leadingConst.constant = viewLeft.frame.origin.x + viewLeft.frame.size.width - rplyWidth.width - 30
                                    
                                    let viewWIdthy = self.view.bounds.width//viewLeft.frame.size.width
                                    if replayIsAttachement == 1
                                    {
                                        if rplyWidth.width<80
                                        {
                                            leadingConst.constant = viewWIdthy - 140
                                            
                                        }
                                        else
                                        {
                                            leadingConst.constant = viewWIdthy - rplyWidth.width - 22-40
                                            
                                        }
                                        
                                    }
                                    else{
                                        leadingConst.constant = viewWIdthy - rplyWidth.width - 22-100
                                    }
                                    
                                }
                                
                            }
                            else
                            {
                                viewLeft.translatesAutoresizingMaskIntoConstraints = false
                                let filteredConstraints = cell.contentView.constraints.filter { $0.identifier == "leadingConst" }
                                if let leadingConst = filteredConstraints.first {
                                    // DO YOUR LOGIC HERE
                                    leadingConst.constant = 60
                                }
                            }
                            
                            
                        }
                    }
                    
                    
                }
                else
                {
                    
                    viewLeft.translatesAutoresizingMaskIntoConstraints = false
                    let filteredConstraints = cell.contentView.constraints.filter { $0.identifier == "leadingConst" }
                    if let leadingConst = filteredConstraints.first {
                        leadingConst.constant = 60
                    }
                    
                }
                
                
                if replyMesageContain != 0
                {
                    
                    imgReplay.isHidden=false
                    viewReply.isHidden = false
                    let filteredConstraints = viewReply.constraints.filter { $0.identifier == "rowHeight" }
                    if let leadingConst = filteredConstraints.first {
                        // DO YOUR LOGIC HERE
                        leadingConst.constant = 51
                    }
                    
                    let filteredConstraintsTop = viewLeft.constraints.filter { $0.identifier == "replyTop" }
                    if let leadingConstTop = filteredConstraintsTop.first {
                        // DO YOUR LOGIC HERE
                        leadingConstTop.constant = 61
                    }
                    
                    
                    //attachement show
                    
                    if replayIsAttachement == 1
                    {
                        imgReplay.isHidden = false
                        
                        let attachment_extension = arrayMessage[indexPath.section]["replyAttachmentExtension"]
                        if attachment_extension == "jpeg" || attachment_extension == "png" || attachment_extension == "jpg" || attachment_extension == "webp" || attachment_extension == "tiff" || attachment_extension == "BMP" || attachment_extension == "ico" || attachment_extension == "gif" || attachment_extension == "svg" || attachment_extension == "svgz" || attachment_extension == "TIF" || attachment_extension == "JFIF" || attachment_extension == "DIB" || attachment_extension == "dib" || attachment_extension == "pjp" || attachment_extension == "PJP" || attachment_extension == "pjpeg" || attachment_extension == "PJPEG"
                            
                        {
                            imgReplay.sd_imageIndicator = SDWebImageActivityIndicator.gray
                            let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                            let attachment_id = arrayMessage[indexPath.section]["replyAttachmentId"]
                            let imgUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id!)
                            imgReplay.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                        }
                        else if replyMessageType == "2"
                        {
                            imgReplay.image = UIImage(named: "icnVoiceMessage.png")
                        }
                        else if attachment_extension == "mp4" || attachment_extension == "quicktime"
                        {
                            // img.image = UIImage(named: "IcnMp4.jpg")
                            
                            imgReplay.sd_imageIndicator = SDWebImageActivityIndicator.gray
                            let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                            let attachment_id = arrayMessage[indexPath.section]["replyAttachmentId"]
                            let imgUrl = String(format: "%@/api/attachmentasbody/%@/true", apiUrl,attachment_id!)
                            imgReplay.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                            
                            
                        }
                        else if attachment_extension == "mp3"
                        {
                            imgReplay.image = UIImage(named: "icnMp3.jpg")
                        }
                            
                        else if attachment_extension == "pdf"
                        {
                            imgReplay.image = UIImage(named: "icnPdf.jpg")
                        }
                        else if attachment_extension == "ppt" || attachment_extension == "pptx" || attachment_extension == "vnd.ms-powerpoint" || attachment_extension == "vnd.openxmlformats-officedocument.presentationml.presentation"
                        {
                            imgReplay.image = UIImage(named: "icnPpt.jpg")
                        }
                        else if attachment_extension == "txt" || attachment_extension == "text/plain" || attachment_extension == "plain"
                        {
                            imgReplay.image = UIImage(named: "icnTxt.jpg")
                        }
                        else if attachment_extension == "doc" || attachment_extension == "docx" || attachment_extension == "msword" || attachment_extension == "vnd.openxmlformats-officedocument.wordprocessingml.document"
                        {
                            imgReplay.image = UIImage(named: "icnWord.jpg")
                        }
                        else if attachment_extension == "xls" || attachment_extension == "xlsx" || attachment_extension == "vnd.ms-excel" || attachment_extension == "vnd.ms-excel"   || attachment_extension == "vnd.openxmlformats-officedocument.spreadsheetml.sheet"              {
                            imgReplay.image = UIImage(named: "icnXls.jpg")
                        }
                        else
                        {
                            imgReplay.image = UIImage(named: "icnFile.jpg")
                        }
                        
                    }
                    else
                    {
                        imgReplay.isHidden = true
                    }
                    
                    
                }
                else
                {
                    viewReply.isHidden = true
                    imgReplay.isHidden=true
                    let filteredConstraints = viewReply.constraints.filter { $0.identifier == "rowHeight" }
                    if let leadingConst = filteredConstraints.first {
                        // DO YOUR LOGIC HERE
                        leadingConst.constant = 0
                    }
                    
                    let filteredConstraintsTop = viewLeft.constraints.filter { $0.identifier == "replyTop" }
                    if let leadingConstTop = filteredConstraintsTop.first {
                        // DO YOUR LOGIC HERE
                        leadingConstTop.constant = 5
                    }
                }
                
                
                cell.selectionStyle = .none
                return cell  //my Message attachement End
            }
            else{
                // MARK: - Right side  without attachmnet - text messgae
                let cell = tableView.dequeueReusableCell(withIdentifier: "MyCellNew", for: indexPath as IndexPath)
                let lblMsg : UILabel = cell.viewWithTag(1) as! UILabel
                let lblDate : UILabel = cell.viewWithTag(2) as! UILabel
                let viewLeft : UIView = cell.viewWithTag(3) as! UIView
                let viewBGSelect : UIView = cell.viewWithTag(32) as! UIView
                let viewDelete : UIView = cell.viewWithTag(848) as! UIView
                let viewReply : UIView = cell.viewWithTag(602) as! UIView
                let lblReplyMessageNameCell : UILabel = cell.viewWithTag(62) as! UILabel
                let replyNavButton : UIButton = cell.viewWithTag(210) as! UIButton
                replyNavButton.addTarget(self, action: #selector(replyNavigationAction(_:)), for: .touchUpInside)
                
                let imgReplay : UIImageView = cell.viewWithTag(390) as! UIImageView
                let lblReplyMessagCell : UILabel = cell.viewWithTag(63) as! UILabel
                viewReply.layer.cornerRadius = 4
                viewLeft.layer.cornerRadius = 8
                viewDelete.layer.cornerRadius = 8
                lblDate.text = message_date
                lblDate.text = message_date
                lblMsg.text = textt
                
                if is_deleted == "1"
                {
                    lblMsg.font = UIFont.italicSystemFont(ofSize: 10)
                    
                    viewDelete.isHidden=false
                    viewLeft.isHidden=true
                    
                }
                else
                {
                    lblMsg.font = UIFont.systemFont(ofSize: 12)
                    
                    
                    viewDelete.isHidden=true
                    viewLeft.isHidden=false
                    
                }
                
                lblReplyMessagCell.text = replyMesage
                lblReplyMessageNameCell.text = replyMessageName
                
                var wid = textt.size(withAttributes:[.font: UIFont.systemFont(ofSize:12.0)])
                lblMsg.textAlignment = .left
                 if wid.width < 244
                {
                    
                    let filteredConstraints = cell.contentView.constraints.filter { $0.identifier == "leadingConst" }
                    if let leadingConst = filteredConstraints.first {
                        // DO YOUR LOGIC HERE
                        leadingConst.constant = viewLeft.frame.origin.x + viewLeft.frame.size.width - wid.width - 30
                        
                        
                        let viewWIdthy = self.view.bounds.width//viewLeft.frame.size.width
                        
                        if replyMesageContain != 0
                        {
                            leadingConst.constant = viewWIdthy - wid.width - 60
                        }
                        
                        
                    }
                    // reply message top message width
                    
                    if replyMesageContain != 0
                    {
                        
                        
                        var rplyWidth = lblReplyMessagCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:11.0)])
                        let replyUsernameWidth = lblReplyMessageNameCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:12.0)])
                        if replyUsernameWidth.width > rplyWidth.width
                        {
                            rplyWidth = replyUsernameWidth
                        }
                        
                        
                        if replayIsAttachement == 1
                        {
                            rplyWidth.width = rplyWidth.width + 30
                            
                        }
                        else
                        {
                            rplyWidth = lblReplyMessagCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:11.0)])
                            if replyUsernameWidth.width > rplyWidth.width
                            {
                                rplyWidth = replyUsernameWidth
                            }
                            
                        }
                        
                        if rplyWidth.width == 0
                        {
                            rplyWidth.width = 40
                        }
                        if rplyWidth.width > wid.width{
                            
                            if rplyWidth.width < 244
                            {
                                let filteredConstraints = cell.contentView.constraints.filter { $0.identifier == "leadingConst" }
                                if let leadingConst = filteredConstraints.first {
                                    leadingConst.constant = viewLeft.frame.origin.x + viewLeft.frame.size.width - rplyWidth.width - 30
                                    
                                    let viewWIdthy = self.view.bounds.width//viewLeft.frame.size.width
                                    
                                    
                                    if replayIsAttachement == 1
                                    {
                                        leadingConst.constant = viewWIdthy - rplyWidth.width - 80
                                    }
                                    else
                                    {
                                        leadingConst.constant = viewWIdthy - rplyWidth.width - 80
                                        
                                    }
                                }
                                
                            }
                            else
                            {
                                viewLeft.translatesAutoresizingMaskIntoConstraints = false
                                let filteredConstraints = cell.contentView.constraints.filter { $0.identifier == "leadingConst" }
                                if let leadingConst = filteredConstraints.first {
                                    // DO YOUR LOGIC HERE
                                    leadingConst.constant = 60
                                }
                            }
                            
                        }
                    }
                    
                    
                    
                }
                else
                {
                    
                    viewLeft.translatesAutoresizingMaskIntoConstraints = false
                    let filteredConstraints = cell.contentView.constraints.filter { $0.identifier == "leadingConst" }
                    if let leadingConst = filteredConstraints.first {
                        // DO YOUR LOGIC HERE
                        leadingConst.constant = 60
                    }
                    
                }
                
                if replyMesageContain != 0
                {
                    imgReplay.isHidden = false
                    replyNavButton.isHidden = false
                    viewReply.isHidden = false
                    let filteredConstraints = viewReply.constraints.filter { $0.identifier == "rowHeight" }
                    if let leadingConst = filteredConstraints.first {
                        // DO YOUR LOGIC HERE
                        leadingConst.constant = 51
                    }
                    
                    let filteredConstraintsTop = viewLeft.constraints.filter { $0.identifier == "replyTop" }
                    if let leadingConstTop = filteredConstraintsTop.first {
                        // DO YOUR LOGIC HERE
                        leadingConstTop.constant = 5
                    }
                    
                    
                    //attachement show
                    
                    if replayIsAttachement == 1
                    {
                        imgReplay.isHidden = false
                        
                        let attachment_extension = arrayMessage[indexPath.section]["replyAttachmentExtension"]
                        if attachment_extension == "jpeg" || attachment_extension == "png" || attachment_extension == "jpg" || attachment_extension == "webp" || attachment_extension == "tiff" || attachment_extension == "BMP" || attachment_extension == "ico" || attachment_extension == "gif" || attachment_extension == "svg" || attachment_extension == "svgz" || attachment_extension == "TIF" || attachment_extension == "JFIF" || attachment_extension == "DIB" || attachment_extension == "dib" || attachment_extension == "pjp" || attachment_extension == "PJP" || attachment_extension == "pjpeg" || attachment_extension == "PJPEG"
                            
                        {
                            imgReplay.sd_imageIndicator = SDWebImageActivityIndicator.gray
                            let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                            let attachment_id = arrayMessage[indexPath.section]["replyAttachmentId"]
                            let imgUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id!)
                            imgReplay.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                        }
                        else if replyMessageType == "2"
                        {
                            imgReplay.image = UIImage(named: "icnVoiceMessage.png")
                        }
                        else if attachment_extension == "mp4" || attachment_extension == "quicktime"
                        {
                            // img.image = UIImage(named: "IcnMp4.jpg")
                            
                            imgReplay.sd_imageIndicator = SDWebImageActivityIndicator.gray
                            let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                            let attachment_id = arrayMessage[indexPath.section]["replyAttachmentId"]
                            let imgUrl = String(format: "%@/api/attachmentasbody/%@/true", apiUrl,attachment_id!)
                            imgReplay.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                            
                            
                        }
                        else if attachment_extension == "mp3"
                        {
                            imgReplay.image = UIImage(named: "icnMp3.jpg")
                        }
                            
                        else if attachment_extension == "pdf"
                        {
                            imgReplay.image = UIImage(named: "icnPdf.jpg")
                        }
                        else if attachment_extension == "ppt" || attachment_extension == "pptx" || attachment_extension == "vnd.ms-powerpoint" || attachment_extension == "vnd.openxmlformats-officedocument.presentationml.presentation"
                        {
                            imgReplay.image = UIImage(named: "icnPpt.jpg")
                        }
                        else if attachment_extension == "txt" || attachment_extension == "text/plain" || attachment_extension == "plain"
                        {
                            imgReplay.image = UIImage(named: "icnTxt.jpg")
                        }
                        else if attachment_extension == "doc" || attachment_extension == "docx" || attachment_extension == "msword" || attachment_extension == "vnd.openxmlformats-officedocument.wordprocessingml.document"
                        {
                            imgReplay.image = UIImage(named: "icnWord.jpg")
                        }
                        else if attachment_extension == "xls" || attachment_extension == "xlsx" || attachment_extension == "vnd.ms-excel" || attachment_extension == "vnd.ms-excel"   || attachment_extension == "vnd.openxmlformats-officedocument.spreadsheetml.sheet"              {
                            imgReplay.image = UIImage(named: "icnXls.jpg")
                        }
                        else
                        {
                            imgReplay.image = UIImage(named: "icnFile.jpg")
                        }
                        
                        let filteredConstraintsreplyLblWidth = viewReply.constraints.filter { $0.identifier == "replyLblWidth" }
                        if let leadingConst = filteredConstraintsreplyLblWidth.first {
                            // DO YOUR LOGIC HERE
                            leadingConst.constant = 40
                        }
                        
                        
                    }
                    else
                    {
                        imgReplay.isHidden = true
                        
                        let filteredConstraintsreplyLblWidth = viewReply.constraints.filter { $0.identifier == "replyLblWidth" }
                        if let leadingConst = filteredConstraintsreplyLblWidth.first {
                            // DO YOUR LOGIC HERE
                            leadingConst.constant = 5
                        }
                        
                    }
                    
                    
                }
                else
                {
                    
                    
                    imgReplay.isHidden = true
                    replyNavButton.isHidden = true
                    viewReply.isHidden = true
                    let filteredConstraints = viewReply.constraints.filter { $0.identifier == "rowHeight" }
                    if let leadingConst = filteredConstraints.first {
                        // DO YOUR LOGIC HERE
                        leadingConst.constant = 0
                    }
                    
                    
                    
                    let filteredConstraintsTop = viewLeft.constraints.filter { $0.identifier == "replyTop" }
                    if let leadingConstTop = filteredConstraintsTop.first {
                        // DO YOUR LOGIC HERE
                        leadingConstTop.constant = 0
                    }
                }
                
                if arraySelectedArray.contains(indexPath.section)
                {
                    viewBGSelect.isHidden = false
                }
                else
                {
                    viewBGSelect.isHidden = true
                }
                lblMsg.textAlignment = .right
                lblMsg.textColor = UIColor.white
                cell.selectionStyle = .none
                return cell  //Right side  End
            }
        }
            // Recever Message - Left Side
        else
        {
            
            
            // MARK: - Left Side individual chat attachmnets message
            if attachment != "0"
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "MyCellAttachmentLSingle", for: indexPath as IndexPath)
                let img : UIImageView = cell.viewWithTag(1) as! UIImageView
                let lblDate : UILabel = cell.viewWithTag(2) as! UILabel
                let viewLeft : UIView = cell.viewWithTag(3) as! UIView
                let viewBGSelect : UIView = cell.viewWithTag(32) as! UIView
                
                
                let lblAttachementName : UILabel = cell.viewWithTag(21) as! UILabel
                let lblMsg : UILabel = cell.viewWithTag(22) as! UILabel
                
                let imgReplay : UIImageView = cell.viewWithTag(390) as! UIImageView
                
                let replyNavButton : UIButton = cell.viewWithTag(210) as! UIButton
                replyNavButton.addTarget(self, action: #selector(replyNavigationAction(_:)), for: .touchUpInside)
                
                let viewReply : UIView = cell.viewWithTag(602) as! UIView
                let lblReplyMessageNameCell : UILabel = cell.viewWithTag(62) as! UILabel
                let lblReplyMessagCell : UILabel = cell.viewWithTag(63) as! UILabel
                
                viewReply.layer.cornerRadius = 4
                
                lblReplyMessagCell.text = replyMesage
                lblReplyMessageNameCell.text = replyMessageName
                
                
                
                lblDate.text = message_date
                viewLeft.layer.cornerRadius = 8
                let attachment_extension = arrayMessage[indexPath.section]["attachment_extension"]
                if attachment_extension == "jpeg" || attachment_extension == "png" || attachment_extension == "jpg" || attachment_extension == "webp" || attachment_extension == "tiff" || attachment_extension == "BMP" || attachment_extension == "ico" || attachment_extension == "gif" || attachment_extension == "svg" || attachment_extension == "svgz" || attachment_extension == "TIF" || attachment_extension == "JFIF" || attachment_extension == "DIB" || attachment_extension == "dib" || attachment_extension == "pjp" || attachment_extension == "PJP" || attachment_extension == "pjpeg" || attachment_extension == "PJPEG"
                    
                {
                    img.sd_imageIndicator = SDWebImageActivityIndicator.gray
                    let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                    let attachment_id = arrayMessage[indexPath.section]["attachment_id"]
                    let imgUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id!)
                    img.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                    
                    
                }
                else if message_display_type == "2"
                {
                    img.image = UIImage(named: "icnVoiceMessage.png")
                }
                    
                else if attachment_extension == "mp4" || attachment_extension == "quicktime"
                {
                    img.image = UIImage(named: "IcnMp4.jpg")
                }
                else if attachment_extension == "mp3"
                {
                    img.image = UIImage(named: "icnMp3.jpg")
                }
                else if attachment_extension == ".mp3" || attachment_extension == ".mp4"
                {
                    img.image = UIImage(named: "icnVoiceMessage.png")
                }
                else if attachment_extension == "pdf"
                {
                    img.image = UIImage(named: "icnPdf.jpg")
                }
                else if attachment_extension == "ppt" || attachment_extension == "pptx"
                {
                    img.image = UIImage(named: "icnPpt.jpg")
                }
                else if attachment_extension == "txt" || attachment_extension == "text"
                {
                    img.image = UIImage(named: "icnTxt.jpg")
                }
                else if attachment_extension == "doc" || attachment_extension == "docx"
                {
                    img.image = UIImage(named: "icnWord.jpg")
                }
                else if attachment_extension == "xls" || attachment_extension == "xlsx"
                {
                    img.image = UIImage(named: "icnXls.jpg")
                }
                else
                {
                    img.image = UIImage(named: "icnFile.jpg")
                }
                if arraySelectedArray.contains(indexPath.section)
                {
                    viewBGSelect.isHidden = false
                }
                else
                {
                    viewBGSelect.isHidden = true
                }
                
                
                
                lblAttachementName.text=arrayMessage[indexPath.section]["attachmentName"]
                lblMsg.text=textt
                
                if message_display_type == "2"
                {
                    lblAttachementName.text = ""
                    lblMsg.text=""
                }
                
                var wid =   lblMsg.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:12.0)]).width
                
                if wid <= lblDate.frame.size.width
                {
                    wid = lblDate.frame.size.width + 10
                }
                    
                else
                {
                    wid = lblMsg.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:12.0)]).width
                    
                }
                if wid < 244
                {
                    let   heig = lblMsg.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:12.0)]).height
                    viewLeft.translatesAutoresizingMaskIntoConstraints = false
                    viewLeft.frame = CGRect(x: viewLeft.frame.origin.x, y: viewLeft.frame.origin.y, width: wid + 30, height: heig+30)
                    
                    let filteredConstraints = cell.contentView.constraints.filter { $0.identifier == "leadingConst" }
                    if let leadingConst = filteredConstraints.first {
                        
                        
                        
                        let widhtFrame = self.view.bounds.width - wid - 30
                        if widhtFrame >= self.view.bounds.width - 142
                        {
                            leadingConst.constant =  self.view.bounds.width - 142
                        }
                        else
                        {
                            leadingConst.constant = widhtFrame
                        }
                    }
                    
                    if replyMesageContain != 0
                    {
                        if lblReplyMessageNameCell.text != "You"
                        {
                            print("")
                        }
                        var rplyWidth = lblReplyMessagCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:11.0)]).width
                        let rplyWidthName = lblReplyMessageNameCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:12.0)]).width
                        print(rplyWidth)
                        print(rplyWidthName)
                        if rplyWidthName > rplyWidth
                        {
                            rplyWidth = rplyWidthName
                        }
                        
                        if rplyWidth > wid{
                            if rplyWidth < 244
                            {
                                let   heig = lblReplyMessagCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:11.0)]).height
                                viewLeft.translatesAutoresizingMaskIntoConstraints = false
                                viewLeft.frame = CGRect(x: viewLeft.frame.origin.x, y: viewLeft.frame.origin.y, width: wid + 30, height: heig+30)
                                let filteredConstraints = cell.contentView.constraints.filter { $0.identifier == "leadingConst" }
                                if let leadingConst = filteredConstraints.first {
                                    
                                    let widhtFrame = self.view.bounds.width - rplyWidth
                                        - 30
                                    
                                    if replayIsAttachement == 1
                                    {
                                        
                                        if widhtFrame >= self.view.bounds.width - 142
                                        {
                                            leadingConst.constant =  self.view.bounds.width - 182
                                        }
                                        else
                                        {
                                            leadingConst.constant = widhtFrame - 40
                                        }
                                    }
                                    else
                                    {
                                        
                                        if widhtFrame >= self.view.bounds.width - 142
                                        {
                                            leadingConst.constant =  self.view.bounds.width - rplyWidth - 80
                                        }
                                        else
                                        {
                                            leadingConst.constant = widhtFrame
                                        }
                                    }
                                    
                                }
                            }
                            else
                            {
                                //justTest
                                viewLeft.translatesAutoresizingMaskIntoConstraints = false
                                let filteredConstraints = cell.contentView.constraints.filter { $0.identifier == "leadingConst" }
                                if let leadingConst = filteredConstraints.first {
                                    leadingConst.constant = 60
                                }
                            }
                            
                            
                        }
                    }
                    
                    
                    
                }
                else
                {
                    viewLeft.translatesAutoresizingMaskIntoConstraints = false
                    let filteredConstraints = cell.contentView.constraints.filter { $0.identifier == "leadingConst" }
                    if let leadingConst = filteredConstraints.first {
                        // DO YOUR LOGIC HERE
                        leadingConst.constant = 60
                    }
                }
                
                
                
                if replyMesageContain != 0
                {imgReplay.isHidden = false
                    viewReply.isHidden = false
                    let filteredConstraints = viewReply.constraints.filter { $0.identifier == "rowHeight" }
                    if let leadingConst = filteredConstraints.first {
                        // DO YOUR LOGIC HERE
                        leadingConst.constant = 51
                    }
                    
                    let filteredConstraintsTop = viewLeft.constraints.filter { $0.identifier == "replyTop" }
                    if let leadingConstTop = filteredConstraintsTop.first {
                        // DO YOUR LOGIC HERE
                        leadingConstTop.constant = 61
                    }
                    
                    
                    //attachement show
                    
                    if replayIsAttachement == 1
                    { imgReplay.isHidden = false
                        
                        let attachment_extension = arrayMessage[indexPath.section]["replyAttachmentExtension"]
                        if attachment_extension == "jpeg" || attachment_extension == "png" || attachment_extension == "jpg" || attachment_extension == "webp" || attachment_extension == "tiff" || attachment_extension == "BMP" || attachment_extension == "ico" || attachment_extension == "gif" || attachment_extension == "svg" || attachment_extension == "svgz" || attachment_extension == "TIF" || attachment_extension == "JFIF" || attachment_extension == "DIB" || attachment_extension == "dib" || attachment_extension == "pjp" || attachment_extension == "PJP" || attachment_extension == "pjpeg" || attachment_extension == "PJPEG"
                            
                        {
                            imgReplay.sd_imageIndicator = SDWebImageActivityIndicator.gray
                            let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                            let attachment_id = arrayMessage[indexPath.section]["replyAttachmentId"]
                            let imgUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id!)
                            imgReplay.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                        }
                        else if replyMessageType == "2"
                        {
                            imgReplay.image = UIImage(named: "icnVoiceMessage.png")
                        }
                        else if attachment_extension == "mp4" || attachment_extension == "quicktime"
                        {
                            // img.image = UIImage(named: "IcnMp4.jpg")
                            
                            imgReplay.sd_imageIndicator = SDWebImageActivityIndicator.gray
                            let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                            let attachment_id = arrayMessage[indexPath.section]["replyAttachmentId"]
                            let imgUrl = String(format: "%@/api/attachmentasbody/%@/true", apiUrl,attachment_id!)
                            imgReplay.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                            
                            
                        }
                        else if attachment_extension == "mp3"
                        {
                            imgReplay.image = UIImage(named: "icnMp3.jpg")
                        }
                            
                        else if attachment_extension == "pdf"
                        {
                            imgReplay.image = UIImage(named: "icnPdf.jpg")
                        }
                        else if attachment_extension == "ppt" || attachment_extension == "pptx" || attachment_extension == "vnd.ms-powerpoint" || attachment_extension == "vnd.openxmlformats-officedocument.presentationml.presentation"
                        {
                            imgReplay.image = UIImage(named: "icnPpt.jpg")
                        }
                        else if attachment_extension == "txt" || attachment_extension == "text/plain" || attachment_extension == "plain"
                        {
                            imgReplay.image = UIImage(named: "icnTxt.jpg")
                        }
                        else if attachment_extension == "doc" || attachment_extension == "docx" || attachment_extension == "msword" || attachment_extension == "vnd.openxmlformats-officedocument.wordprocessingml.document"
                        {
                            imgReplay.image = UIImage(named: "icnWord.jpg")
                        }
                        else if attachment_extension == "xls" || attachment_extension == "xlsx" || attachment_extension == "vnd.ms-excel" || attachment_extension == "vnd.ms-excel"   || attachment_extension == "vnd.openxmlformats-officedocument.spreadsheetml.sheet"              {
                            imgReplay.image = UIImage(named: "icnXls.jpg")
                        }
                        else
                        {
                            imgReplay.image = UIImage(named: "icnFile.jpg")
                        }
                        
                    }
                    else
                    {
                        imgReplay.isHidden = true
                    }
                    
                    
                }
                else
                {imgReplay.isHidden = true
                    viewReply.isHidden = true
                    let filteredConstraints = viewReply.constraints.filter { $0.identifier == "rowHeight" }
                    if let leadingConst = filteredConstraints.first {
                        // DO YOUR LOGIC HERE
                        leadingConst.constant = 0
                    }
                    
                    let filteredConstraintsTop = viewLeft.constraints.filter { $0.identifier == "replyTop" }
                    if let leadingConstTop = filteredConstraintsTop.first {
                        // DO YOUR LOGIC HERE
                        leadingConstTop.constant = 5
                    }
                }
                
                
                
                
                cell.selectionStyle = .none
                return cell
                
            }
            else
            {
                // MARK: - Left Side individual chat text message
                let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath as IndexPath)
                let lblMsg : UILabel = cell.viewWithTag(1) as! UILabel
                let lblDate : UILabel = cell.viewWithTag(2) as! UILabel
                let viewLeft : UIView = cell.viewWithTag(3) as! UIView
                let viewDelete : UIView = cell.viewWithTag(848) as! UIView
                
                
                
                
                let imgReplay : UIImageView = cell.viewWithTag(390) as! UIImageView
                let viewReply : UIView = cell.viewWithTag(602) as! UIView
                let lblReplyMessageNameCell : UILabel = cell.viewWithTag(62) as! UILabel
                let lblReplyMessagCell : UILabel = cell.viewWithTag(63) as! UILabel
                viewReply.layer.cornerRadius = 4
                let replyNavButton : UIButton = cell.viewWithTag(210) as! UIButton
                replyNavButton.addTarget(self, action: #selector(replyNavigationAction(_:)), for: .touchUpInside)
                
                
                viewLeft.layer.cornerRadius = 8
                lblMsg.text = textt
                lblDate.text = message_date
                viewDelete.layer.cornerRadius = 8
                if is_deleted == "1"
                {
                    lblMsg.font = UIFont.italicSystemFont(ofSize: 10)
                    viewLeft.isHidden=true
                    viewDelete.isHidden=false
                    //  imgDlt.isHidden = false
                }
                else
                {
                    lblMsg.font = UIFont.systemFont(ofSize: 12)
                    //  imgDlt.isHidden = true
                    viewLeft.isHidden=false
                    viewDelete.isHidden=true
                }
                lblReplyMessagCell.text = replyMesage
                lblReplyMessageNameCell.text = replyMessageName
                
                var wid =  textt.size(withAttributes:[.font: UIFont.systemFont(ofSize:12.0)]).width
                if wid <= lblDate.frame.size.width
                {
                    wid = lblDate.frame.size.width + 10
                }
                else
                {
                    wid = textt.size(withAttributes:[.font: UIFont.systemFont(ofSize:12.0)]).width
                }
                if wid < 244
                {
                    let   heig = textt.size(withAttributes:[.font: UIFont.systemFont(ofSize:12.0)]).height
                    viewLeft.translatesAutoresizingMaskIntoConstraints = false
                    viewLeft.frame = CGRect(x: viewLeft.frame.origin.x, y: viewLeft.frame.origin.y, width: wid + 30, height: heig+30)
                    
                    let filteredConstraints = cell.contentView.constraints.filter { $0.identifier == "trConst" }
                    if let leadingConst = filteredConstraints.first {
                        
                        let widhtFrame = self.view.bounds.width - textt.size(withAttributes:[.font: UIFont.systemFont(ofSize:12.0)]).width - 50
                        
                        if replyMesageContain != 0
                        {
                            
                            var replayWit =  lblReplyMessagCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:11.0)]).width
                            let replayNameWit =  lblReplyMessageNameCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:12.0)]).width
                            //found
                            if replayNameWit > replayWit
                            {
                                replayWit = replayNameWit
                            }
                            else
                            {
                                replayWit =  lblReplyMessagCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:11.0)]).width
                                
                            }
                            
                            
                            if widhtFrame > replayWit
                            {
                                replayWit = widhtFrame
                            }
                            else
                            {
                                replayWit =  lblReplyMessagCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:11.0)]).width
                                
                            }
                            print(self.view.bounds.width - replayWit)
                            
                            leadingConst.constant = self.view.bounds.width - replayWit + 100
                        }
                        else
                        {
                            leadingConst.constant = widhtFrame
                        }
                        
                        
                    }
                    if replyMesageContain != 0
                    {
                        let rplyWidth = lblReplyMessagCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:11.0)])
                        
                        if rplyWidth.width > wid{
                            
                            if rplyWidth.width < 244
                            {
                                let   heig = lblReplyMessagCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:11.0)]).height
                                viewLeft.translatesAutoresizingMaskIntoConstraints = false
                                viewLeft.frame = CGRect(x: viewLeft.frame.origin.x, y: viewLeft.frame.origin.y, width: wid + 30, height: heig+30)
                                
                                let filteredConstraints = cell.contentView.constraints.filter { $0.identifier == "trConst" }
                                if let leadingConst = filteredConstraints.first {
                                    
                                    
                                    if replayIsAttachement == 1
                                    {
                                        
                                        
                                        var replayWit =  lblReplyMessagCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:11.0)]).width
                                        let replayNameWit =  lblReplyMessageNameCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:12.0)]).width
                                        if replayNameWit > replayWit
                                        {
                                            replayWit = replayNameWit
                                        }
                                        else
                                        {
                                            replayWit =  lblReplyMessagCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:11.0)]).width
                                            
                                        }
                                        
                                        let widhtFrame = self.view.bounds.width - replayWit - 90
                                        leadingConst.constant = widhtFrame
                                    }
                                    else
                                    {
                                        
                                        var replayWit =  lblReplyMessagCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:11.0)]).width
                                        let replayNameWit =  lblReplyMessageNameCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:12.0)]).width
                                        if replayNameWit > replayWit
                                        {
                                            replayWit = replayNameWit
                                        }
                                        else
                                        {
                                            replayWit =  lblReplyMessagCell.text!.size(withAttributes:[.font: UIFont.systemFont(ofSize:11.0)]).width
                                        }
                                        
                                        
                                        let widhtFrame = self.view.bounds.width - replayWit - 90
                                        leadingConst.constant = widhtFrame
                                    }
                                    
                                }
                            }
                            else
                            {
                                viewLeft.translatesAutoresizingMaskIntoConstraints = false
                                let filteredConstraints = cell.contentView.constraints.filter { $0.identifier == "trConst" }
                                if let leadingConst = filteredConstraints.first {
                                    // DO YOUR LOGIC HERE
                                    leadingConst.constant = 60
                                }
                            }
                            
                            
                        }
                    }
                    
                }
                else
                {
                    viewLeft.translatesAutoresizingMaskIntoConstraints = false
                    let filteredConstraints = cell.contentView.constraints.filter { $0.identifier == "trConst" }
                    if let leadingConst = filteredConstraints.first {
                        // DO YOUR LOGIC HERE
                        leadingConst.constant = 60
                    }
                }
                if replyMesageContain != 0
                {
                    imgReplay.isHidden = false
                    viewReply.isHidden = false
                    let filteredConstraints = viewReply.constraints.filter { $0.identifier == "rowHeight" }
                    if let leadingConst = filteredConstraints.first {
                        // DO YOUR LOGIC HERE
                        leadingConst.constant = 51
                    }
                    
                    let filteredConstraintsTop = viewLeft.constraints.filter { $0.identifier == "replyTop" }
                    if let leadingConstTop = filteredConstraintsTop.first {
                        // DO YOUR LOGIC HERE
                        leadingConstTop.constant = 61
                    }
                    //attachement show
                    
                    if replayIsAttachement == 1
                    {
                        imgReplay.isHidden = false
                        
                        let attachment_extension = arrayMessage[indexPath.section]["replyAttachmentExtension"]
                        if attachment_extension == "jpeg" || attachment_extension == "png" || attachment_extension == "jpg" || attachment_extension == "webp" || attachment_extension == "tiff" || attachment_extension == "BMP" || attachment_extension == "ico" || attachment_extension == "gif" || attachment_extension == "svg" || attachment_extension == "svgz" || attachment_extension == "TIF" || attachment_extension == "JFIF" || attachment_extension == "DIB" || attachment_extension == "dib" || attachment_extension == "pjp" || attachment_extension == "PJP" || attachment_extension == "pjpeg" || attachment_extension == "PJPEG"
                            
                        {
                            imgReplay.sd_imageIndicator = SDWebImageActivityIndicator.gray
                            let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                            let attachment_id = arrayMessage[indexPath.section]["replyAttachmentId"]
                            let imgUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id!)
                            imgReplay.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                        }
                        else if replyMessageType == "2"
                        {
                            imgReplay.image = UIImage(named: "icnVoiceMessage.png")
                        }
                        else if attachment_extension == "mp4" || attachment_extension == "quicktime"
                        {
                            // img.image = UIImage(named: "IcnMp4.jpg")
                            
                            imgReplay.sd_imageIndicator = SDWebImageActivityIndicator.gray
                            let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                            let attachment_id = arrayMessage[indexPath.section]["replyAttachmentId"]
                            let imgUrl = String(format: "%@/api/attachmentasbody/%@/true", apiUrl,attachment_id!)
                            imgReplay.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                            
                            
                        }
                        else if attachment_extension == "mp3"
                        {
                            imgReplay.image = UIImage(named: "icnMp3.jpg")
                        }
                            
                        else if attachment_extension == "pdf"
                        {
                            imgReplay.image = UIImage(named: "icnPdf.jpg")
                        }
                        else if attachment_extension == "ppt" || attachment_extension == "pptx" || attachment_extension == "vnd.ms-powerpoint" || attachment_extension == "vnd.openxmlformats-officedocument.presentationml.presentation"
                        {
                            imgReplay.image = UIImage(named: "icnPpt.jpg")
                        }
                        else if attachment_extension == "txt" || attachment_extension == "text/plain" || attachment_extension == "plain"
                        {
                            imgReplay.image = UIImage(named: "icnTxt.jpg")
                        }
                        else if attachment_extension == "doc" || attachment_extension == "docx" || attachment_extension == "msword" || attachment_extension == "vnd.openxmlformats-officedocument.wordprocessingml.document"
                        {
                            imgReplay.image = UIImage(named: "icnWord.jpg")
                        }
                        else if attachment_extension == "xls" || attachment_extension == "xlsx" || attachment_extension == "vnd.ms-excel" || attachment_extension == "vnd.ms-excel"   || attachment_extension == "vnd.openxmlformats-officedocument.spreadsheetml.sheet"              {
                            imgReplay.image = UIImage(named: "icnXls.jpg")
                        }
                        else
                        {
                            imgReplay.image = UIImage(named: "icnFile.jpg")
                        }
                        
                    }
                    else
                    {
                        imgReplay.isHidden = true
                    }
                    
                }
                else
                {
                    
                    imgReplay.isHidden = true
                    
                    viewReply.isHidden = true
                    let filteredConstraints = viewReply.constraints.filter { $0.identifier == "rowHeight" }
                    if let leadingConst = filteredConstraints.first {
                        // DO YOUR LOGIC HERE
                        leadingConst.constant = 0
                    }
                    
                    let filteredConstraintsTop = viewLeft.constraints.filter { $0.identifier == "replyTop" }
                    if let leadingConstTop = filteredConstraintsTop.first {
                        // DO YOUR LOGIC HERE
                        leadingConstTop.constant = 5
                    }
                }
                
                let viewBGSelect : UIView = cell.viewWithTag(32) as! UIView
                if arraySelectedArray.contains(indexPath.section)
                {
                    viewBGSelect.isHidden = false
                }
                else
                {
                    viewBGSelect.isHidden = true
                }
                cell.selectionStyle = .none
                return cell
            }
            // Left Side single chat message end
            
            
        }
        
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.view.endEditing(true)
        if deleteFlag == 1
        {
            let sendId = arrayMessage[indexPath.section]["sender_id"]
            let is_deleted  = arrayMessage[indexPath.section]["is_deleted"]
            if sendId == userId
            {
                let textt = arrayMessage[indexPath.section]["message_text"]
                if is_deleted != "1"
                {
                    if arraySelectedArray.contains(indexPath.section)
                    {
                        let str = arraySelectedArray.index(of: indexPath.section)
                        arraySelectedArray.remove(at: str!)
                    }
                    else
                    {
                        arraySelectedArray.append(indexPath.section)
                    }
                    tbl.reloadData()
                }
            }
        }
        else
        {
            let attachment = arrayMessage[indexPath.section]["attachment"]
            let message_display_type = arrayMessage[indexPath.section]["message_display_type"]
            
            if attachment != "0"
            {
                let attachment_extension = arrayMessage[indexPath.section]["attachment_extension"]
                if attachment_extension == "jpeg" || attachment_extension == "png" || attachment_extension == "jpg" || attachment_extension == "webp" || attachment_extension == "tiff" || attachment_extension == "BMP" || attachment_extension == "ico" || attachment_extension == "gif" || attachment_extension == "svg" || attachment_extension == "svgz" || attachment_extension == "TIF" || attachment_extension == "JFIF" || attachment_extension == "DIB" || attachment_extension == "dib" || attachment_extension == "pjp" || attachment_extension == "PJP" || attachment_extension == "pjpeg" || attachment_extension == "PJPEG"
                { let attachment_id = arrayMessage[indexPath.section]["attachment_id"]
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "ImageViewController") as! ImageViewController
                    let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                    vc.ImageLink = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id!)
                    vc.ActualFileName =  arrayMessage[indexPath.section]["attachmentName"]
                    vc.videoUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id!)
                    vc.flagScreenType = 0
                    self.navigationController?.pushViewController(vc,
                                                                  animated: true)
                }
                else if message_display_type == "2"{
                    let attachment_id = arrayMessage[indexPath.section]["attachment_id"]
                    let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                    let videoURL = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id!)
                    let urlVideo = URL(string: videoURL)
                    let accessToken = UserDefaults.standard.value(forKey: "accessToken")
                    let tokenType = UserDefaults.standard.value(forKey: "tokenType")
                    let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
                    let headers: HTTPHeaders = [
                        "Authorization": headerrr
                    ]
                    let asset = AVURLAsset(url: urlVideo!, options: ["AVURLAssetHTTPHeaderFieldsKey": headers])
                    let playerItem = AVPlayerItem(asset: asset)
                    let  player = AVPlayer(playerItem: playerItem)
                    let playerViewController = AVPlayerViewController()
                    playerViewController.player = player
                    self.present(playerViewController, animated: true) {
                        playerViewController.player!.play()
                    }
                }
                else if attachment_extension == "mp4" || attachment_extension == "quicktime"
                {
                    
                    let attachment_id = arrayMessage[indexPath.section]["attachment_id"]
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "ImageViewController") as! ImageViewController
                    let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                    vc.ImageLink =   String(format: "%@/api/attachmentasbody/%@/true", apiUrl,attachment_id!)
                    vc.flagScreenType = 1
                    vc.videoUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id!)
                    vc.ActualFileName =  arrayMessage[indexPath.section]["attachmentName"]
                    self.navigationController?.pushViewController(vc,
                                                                  animated: true)
                }
                else if attachment_extension == "mp3" || attachment_extension == ".mp3"
                {
                    let attachment_id = arrayMessage[indexPath.section]["attachment_id"]
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "ImageViewController") as! ImageViewController
                    let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                    vc.ImageLink =   String(format: "%@/api/attachmentasbody/%@/true", apiUrl,attachment_id!)
                    vc.flagScreenType = 2
                    vc.audioIcon = UIImage(named: "icnMp3.jpg")
                    vc.videoUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id!)
                    vc.ActualFileName =  arrayMessage[indexPath.section]["attachmentName"]
                    self.navigationController?.pushViewController(vc,
                                                                  animated: true)
                }
                else if attachment_extension == "ai" || attachment_extension == "indd" || attachment_extension == "eps"
                {
                    
                    let attachment_id = arrayMessage[indexPath.section]["attachment_id"]
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "ImageViewController") as! ImageViewController
                    let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                    let url = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id!)
                    let FileName =  arrayMessage[indexPath.section]["attachmentName"]
                    
                    self.saveOtherFile(downloadUrl: url, fileName: FileName!)
                    
                    
                }
                else
                {
                    let attachment_id = arrayMessage[indexPath.section]["attachment_id"]
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "WebviewViewController") as! WebviewViewController
                    let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                    vc.webUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id!)
                    vc.ActualFileName =  arrayMessage[indexPath.section]["attachmentName"]
                    self.navigationController?.pushViewController(vc,
                                                                  animated: true)
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        if section != 0
        {
            return 4
        }
        return 0
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool{
        
        let message_display_type = arrayMessage[indexPath.section]["message_display_type"]
        let is_deleted = self.arrayMessage[indexPath.section]["is_deleted"]
        if message_display_type == "4" || message_display_type == "44" || is_deleted == "1" || self.arraySelectedArray.count != 0 ||  self.deleteFlag == 1
        {
            return false
        }
        
        return true
    }
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        if self.deleteFlag != 1
        {
            let action =  UIContextualAction(style: .normal, title: "", handler: { (action,view,completionHandler ) in
                //do stuff
                
                self.replyFlag = 1
                
                self.replyView.isHidden = false
                self.btnReplClose.isHidden=false
                if self.groupFlag == "yes"
                {
                    self.lblReplyName.text = self.arrayMessage[indexPath.section]["senderName"]
                    
                    self.replySelectedUSerUd = self.arrayMessage[indexPath.section]["sender_id"]
                    
                    
                }
                else
                {
                    self.lblReplyName.text = self.lbltitleName.text
                    //  self.replySelectedUSerUd = self.senderId
                    self.replySelectedUSerUd = self.arrayMessage[indexPath.section]["sender_id"]
                }
                
                self.lblReplyMessage.text = self.arrayMessage[indexPath.section]["message_text"]
                self.replySelectedid = self.arrayMessage[indexPath.section]["id"]
                if self.lblReplyMessage.text == ""
                {
                    self.lblReplyMessage.isHidden  = true
                    self.replayHeight.constant = 40
                    self.replyViewY.constant = -48
                    
                }
                else
                {
                    self.lblReplyMessage.isHidden  = false
                    self.replayHeight.constant = 65
                    self.replyViewY.constant = -75
                }
                let message_display_type = self.arrayMessage[indexPath.section]["message_display_type"]
                let attachment = self.arrayMessage[indexPath.section]["attachment"]
                self.replyAttachemntID = ""
                if attachment != "0"
                {
                    self.replyAttachemntID = self.arrayMessage[indexPath.section]["attachment_id"]
                    
                    
                    self.replyIsAttachment = 1
                    self.imgReplyImage.isHidden = false
                    self.replyAttachemntExtension = self.arrayMessage[indexPath.section]["attachment_extension"]
                    //attachementImage
                    let attachment_extension = self.arrayMessage[indexPath.section]["attachment_extension"]
                    if attachment_extension == "jpeg" || attachment_extension == "png" || attachment_extension == "jpg" || attachment_extension == "webp" || attachment_extension == "tiff" || attachment_extension == "BMP" || attachment_extension == "ico" || attachment_extension == "gif" || attachment_extension == "svg" || attachment_extension == "svgz" || attachment_extension == "TIF" || attachment_extension == "JFIF" || attachment_extension == "DIB" || attachment_extension == "dib" || attachment_extension == "pjp" || attachment_extension == "PJP" || attachment_extension == "pjpeg" || attachment_extension == "PJPEG"
                        
                    {
                        self.imgReplyImage.sd_imageIndicator = SDWebImageActivityIndicator.gray
                        let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                        let attachment_id = self.arrayMessage[indexPath.section]["attachment_id"]
                        let imgUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id!)
                        self.imgReplyImage.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                    }
                    else if message_display_type  == "2"
                    {
                        self.imgReplyImage.image = UIImage(named: "icnVoiceMessage.png")
                    }
                    else if attachment_extension == "mp4" || attachment_extension == "quicktime"
                    {
                        
                        
                        
                        self.imgReplyImage.sd_imageIndicator = SDWebImageActivityIndicator.gray
                        let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                        let attachment_id = self.arrayMessage[indexPath.section]["attachment_id"]
                        let imgUrl = String(format: "%@/api/attachmentasbody/%@/true", apiUrl,attachment_id!)
                        self.imgReplyImage.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                        
                    }
                    else if attachment_extension == "mp3"
                    {
                        self.imgReplyImage.image = UIImage(named: "icnMp3.jpg")
                    }
                        
                    else if attachment_extension == "pdf"
                    {
                        self.imgReplyImage.image = UIImage(named: "icnPdf.jpg")
                    }
                    else if attachment_extension == "ppt" || attachment_extension == "pptx" || attachment_extension == "vnd.ms-powerpoint" || attachment_extension == "vnd.openxmlformats-officedocument.presentationml.presentation"
                    {
                        self.imgReplyImage.image = UIImage(named: "icnPpt.jpg")
                    }
                    else if attachment_extension == "txt" || attachment_extension == "plain"
                    {
                        self.imgReplyImage.image = UIImage(named: "icnTxt.jpg")
                    }
                    else if attachment_extension == "doc" || attachment_extension == "docx" || attachment_extension == "msword" || attachment_extension == "vnd.openxmlformats-officedocument.wordprocessingml.document"
                    {
                        self.imgReplyImage.image = UIImage(named: "icnWord.jpg")
                    }
                    else if attachment_extension == "xls" || attachment_extension == "xlsx" || attachment_extension == "vnd.ms-excel" ||  attachment_extension == "ms-excel" ||  attachment_extension == "vnd.ms-excel"   || attachment_extension == "vnd.openxmlformats-officedocument.spreadsheetml.sheet"              {
                        self.imgReplyImage.image = UIImage(named: "icnXls.jpg")
                    }
                    else
                    {
                        self.imgReplyImage.image = UIImage(named: "icnFile.jpg")
                    }
                    if self.AttaxchmentView.isHidden != true
                    {
                        if self.lblReplyMessage.text == ""
                        {
                            
                            self.replayHeight.constant = 40
                            self.replyViewY.constant = -102
                            
                        }
                        else
                        {
                            
                            self.replayHeight.constant = 65
                            self.replyViewY.constant = -129
                        }
                    }
                    
                }
                else
                {
                    self.imgReplyImage.isHidden = true
                    
                    self.replyIsAttachment = 0
                    
                }
                completionHandler(true)
            })
            action.image = UIImage(named: "icnRply.png")
            action.backgroundColor = ColorChanger().color(from: "888888")
            let configuration = UISwipeActionsConfiguration(actions: [action])
            configuration.performsFirstActionWithFullSwipe = false
            let sendId = arrayMessage[indexPath.section]["sender_id"]
            if sendId != userId{
                return configuration
            }
            else
            {
                return UISwipeActionsConfiguration.init()
            }
            return UISwipeActionsConfiguration.init()
        }
        return nil
    }
    
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        if self.deleteFlag != 1
        {
            let action =  UIContextualAction(style: .normal, title: "", handler: { (action,view,completionHandler ) in
                //do stuff
                self.replyFlag = 1
                
                self.replyView.isHidden = false
                self.btnReplClose.isHidden=false
                print(self.arrayMessage[indexPath.section])
                self.lblReplyName.text = "You"
                self.lblReplyMessage.text = self.arrayMessage[indexPath.section]["message_text"]
                self.replySelectedid = self.arrayMessage[indexPath.section]["id"]
                self.replySelectedUSerUd = self.userId
                
                if self.lblReplyMessage.text == ""
                {
                    self.lblReplyMessage.isHidden  = true
                    self.replayHeight.constant = 40
                    self.replyViewY.constant = -48
                    
                }
                else
                {
                    self.lblReplyMessage.isHidden  = false
                    self.replayHeight.constant = 65
                    self.replyViewY.constant = -75
                }
                
                let attachment = self.arrayMessage[indexPath.section]["attachment"]
                self.replyAttachemntID = ""
                if attachment != "0"
                {
                    self.replyAttachemntID = self.arrayMessage[indexPath.section]["attachment_id"]
                    self.replyIsAttachment = 1
                    self.imgReplyImage.isHidden = false
                    let message_display_type = self.arrayMessage[indexPath.section]["message_display_type"]
                    //attachementImage
                    let attachment_extension = self.arrayMessage[indexPath.section]["attachment_extension"]
                    self.replyAttachemntExtension = self.arrayMessage[indexPath.section]["attachment_extension"]
                    if attachment_extension == "jpeg" || attachment_extension == "png" || attachment_extension == "jpg" || attachment_extension == "webp" || attachment_extension == "tiff" || attachment_extension == "BMP" || attachment_extension == "ico" || attachment_extension == "gif" || attachment_extension == "svg" || attachment_extension == "svgz" || attachment_extension == "TIF" || attachment_extension == "JFIF" || attachment_extension == "DIB" || attachment_extension == "dib" || attachment_extension == "pjp" || attachment_extension == "PJP" || attachment_extension == "pjpeg" || attachment_extension == "PJPEG"
                        
                    {
                        self.imgReplyImage.sd_imageIndicator = SDWebImageActivityIndicator.gray
                        let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                        let attachment_id = self.arrayMessage[indexPath.section]["attachment_id"]
                        let imgUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id!)
                        self.imgReplyImage.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                    }
                    else if message_display_type  == "2"
                    {
                        self.imgReplyImage.image = UIImage(named: "icnVoiceMessage.png")
                    }
                    else if attachment_extension == "mp4" || attachment_extension == "quicktime"
                    {
                        
                        
                        
                        self.imgReplyImage.sd_imageIndicator = SDWebImageActivityIndicator.gray
                        let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                        let attachment_id = self.arrayMessage[indexPath.section]["attachment_id"]
                        let imgUrl = String(format: "%@/api/attachmentasbody/%@/true", apiUrl,attachment_id!)
                        self.imgReplyImage.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                        
                    }
                    else if attachment_extension == "mp3"
                    {
                        self.imgReplyImage.image = UIImage(named: "icnMp3.jpg")
                    }
                        
                    else if attachment_extension == "pdf"
                    {
                        self.imgReplyImage.image = UIImage(named: "icnPdf.jpg")
                    }
                    else if attachment_extension == "ppt" || attachment_extension == "pptx" || attachment_extension == "vnd.ms-powerpoint" || attachment_extension == "vnd.openxmlformats-officedocument.presentationml.presentation"
                    {
                        self.imgReplyImage.image = UIImage(named: "icnPpt.jpg")
                    }
                    else if attachment_extension == "txt" || attachment_extension == "plain"
                    {
                        self.imgReplyImage.image = UIImage(named: "icnTxt.jpg")
                    }
                    else if attachment_extension == "doc" || attachment_extension == "docx" || attachment_extension == "msword" || attachment_extension == "vnd.openxmlformats-officedocument.wordprocessingml.document"
                    {
                        self.imgReplyImage.image = UIImage(named: "icnWord.jpg")
                    }
                    else if attachment_extension == "xls" || attachment_extension == "xlsx" || attachment_extension == "vnd.ms-excel" ||  attachment_extension == "ms-excel" ||  attachment_extension == "vnd.ms-excel"   || attachment_extension == "vnd.openxmlformats-officedocument.spreadsheetml.sheet"              {
                        self.imgReplyImage.image = UIImage(named: "icnXls.jpg")
                    }
                    else
                    {
                        self.imgReplyImage.image = UIImage(named: "icnFile.jpg")
                    }
                    
                }
                else
                {
                    self.imgReplyImage.isHidden = true
                    self.replyIsAttachment = 0
                    
                }
                
                if self.AttaxchmentView.isHidden != true
                {
                    if self.lblReplyMessage.text == ""
                    {
                        
                        self.replayHeight.constant = 40
                        self.replyViewY.constant = -102
                        
                    }
                    else
                    {
                        
                        self.replayHeight.constant = 65
                        self.replyViewY.constant = -129
                    }
                }
                
                completionHandler(true)
            })
            action.image = UIImage(named: "icnRply.png")
            action.backgroundColor = ColorChanger().color(from: "888888")
            let actionDelete =  UIContextualAction(style: .normal, title: "", handler: { (action,view,completionHandler ) in
                //do stuff
                self.btnCancel.isHidden = false
                self.btnDelete.isHidden = false
                self.deleteFlag = 1
                self.bgMenuView.isHidden = true
                self.menuFlag = 0
                self.btnMenu.isHidden = true
                self.icnCalendar.isHidden = true
                self.lbltitleName.isHidden = true
                self.btnCancelAction.isHidden = false
                let sendId = self.arrayMessage[indexPath.section]["sender_id"]
                let is_deleted = self.arrayMessage[indexPath.section]["is_deleted"]
                if sendId == self.userId
                {
                    let textt = self.arrayMessage[indexPath.section]["message_text"]
                    if is_deleted != "1"
                    {
                        if self.arraySelectedArray.contains(indexPath.section)
                        {
                            let str = self.arraySelectedArray.index(of: indexPath.section)
                            self.arraySelectedArray.remove(at: str!)
                        }
                        else
                        {
                            self.arraySelectedArray.append(indexPath.section)
                        }
                        self.tbl.reloadData()
                    }
                }
                completionHandler(true)
            })
            actionDelete.image = UIImage(named: "icnDelete.png")
            actionDelete.backgroundColor = ColorChanger().color(from: "CCCCCC")
            let configuration = UISwipeActionsConfiguration(actions: [action,actionDelete])
            configuration.performsFirstActionWithFullSwipe = false
            let sendId = arrayMessage[indexPath.section]["sender_id"]
            if sendId == userId{
                return configuration
            }
            else
            {
                return UISwipeActionsConfiguration.init()
            }
            return UISwipeActionsConfiguration.init()
        }
        return nil
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if arrayMessage.count != 0 {
            let indexPath = IndexPath(row: 0, section: arrayMessage.count-1)
            let cellRect = tbl.rectForRow(at: indexPath)
            let completelyVisible = tbl.bounds.contains(cellRect)
            if (completelyVisible)
            {
                self.btnNewMessage.isHidden=true
            }
        }
        
        
    }
    @IBAction func scrollToLastAction(_ sender: Any) {
        self.tbl.scrollToBottom()
        self.btnNewMessage.isHidden=true
    }
    @IBAction func attachementCloseAction(_ sender: Any) {
        mimetypeUploading = ""
        //  uploadingData : Data!
        imageFlag = 0
        lblAttachemntName.text = ""
        if self.lblReplyMessage.text == ""
        {
            
            self.replayHeight.constant = 40
            self.replyViewY.constant = -48
            
        }
        else
        {
            self.replayHeight.constant = 65
            self.replyViewY.constant = -75
        }
        
        
        self.replyViewY.constant = -102
        
        AttaxchmentView.isHidden = true
        btnAttachmentCancel.isHidden = true
    }
    @objc func replyNavigationAction(_ sender:AnyObject) {
        if deleteFlag != 1
        {
            //tableView cell index
            let buttonPosition:CGPoint = sender.convert(CGPoint.zero, to:self.tbl)
            let indexPath = self.tbl.indexPathForRow(at: buttonPosition)
            
            
            
            let replayMessageID = self.arrayMessage[indexPath!.section]["replyMessageId"]
            if replayMessageID != ""
            {
                let replayMessageIndex = self.arrayMessage.filter({$0["id"] as! String == replayMessageID}).first
                let ind = self.arrayMessage.lastIndex(of: replayMessageIndex!)
                
                DispatchQueue.main.async {
                    let indexPath = IndexPath(row: (indexPath?.row)!, section: ind!)
                    
                    let is_deleted = self.arrayMessage[ind!]["is_deleted"]
                    if is_deleted != "1"
                    {
                        
                        
                        self.arraySelectedArray.append(ind!)
                        self.tbl.reloadData()
                        
                        self.tbl.selectRow(at: indexPath, animated: true, scrollPosition: .none)
                        self.tbl.scrollToRow(at: indexPath, at: .middle, animated: true)
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                            // your function here
                            self.arraySelectedArray = [Int]()
                            self.tbl.reloadData()
                        }
                    }
                }
            }
        }
    }
    @IBAction func closeReplyAction(_ sender: Any) {
        btnReplClose.isHidden=true
        replyView.isHidden=true
        self.view.endEditing(true)
        
    }
    func saveOtherFile(downloadUrl:String,fileName:String)
    {
        AppHelper.showPrograss(vc: self.view, title: "downloading...", message: "")
        let destination = DownloadRequest.suggestedDownloadDestination(for: .documentDirectory)
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let header = ["Authorization": headerrr]
        Alamofire.download(
            downloadUrl,
            method: .get,
            parameters: nil,
            encoding: JSONEncoding.default,
            headers: header,
            to: destination).downloadProgress(closure: { (progress) in
                //progress closure
                print("download Progress: \(progress.fractionCompleted)")
            }).response(completionHandler: { (DefaultDownloadResponse) in
                //here you able to access the DefaultDownloadResponse
                //result closure
                AppHelper.HidePrograss(vc: self.view)
                let strrr = DefaultDownloadResponse.error
                if (strrr != nil)
                {
                    
                    AppHelper.showAlertMessage(vc: self, title: "", message: (strrr?.localizedDescription)! )
                }
                else
                {
                    self.shareVideo(from: DefaultDownloadResponse.destinationURL!,fileName: fileName)
                }
            })
    }
    
    func shareVideo(from url: URL,fileName : String) {
        
        let filemanager = FileManager.default
        let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory,.userDomainMask,true)[0] as NSString
        let destinationPath = documentsPath.appendingPathComponent(fileName)
        do {
            try filemanager.removeItem(atPath: destinationPath)
            print("Local path removed successfully")
        } catch let error as NSError {
            print("------Error",error.debugDescription)
        }
        
        let str = String(describing: url.absoluteURL)
        let orginalFileNameArray = str.components(separatedBy: "/")
        let orginalFileName =  orginalFileNameArray.last
        
        do {
            let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
            let documentDirectory = URL(fileURLWithPath: path)
            let originPath = documentDirectory.appendingPathComponent(orginalFileName!)
            let destinationPath = documentDirectory.appendingPathComponent(fileName)
            try FileManager.default.moveItem(at: url.absoluteURL, to: destinationPath.absoluteURL)
            let activityViewController = UIActivityViewController(activityItems: [destinationPath], applicationActivities: nil)
            present(activityViewController, animated: true, completion: nil)
            
            
        } catch {
            print(error)
        }
        
    }
    // MARK: - EmojiViewDelegate
    @IBAction func doneBtnEmoji (sender: Any) {
        if emojiFlag == 1
        {
            emojiFlag = 0
            self.view.endEditing(true)
            txtmsg.inputView = nil
            txtmsg.becomeFirstResponder()
        }
        else
        {
            emojiFlag = 1
            txtmsg.resignFirstResponder()
            let keyboardSettings = KeyboardSettings(bottomType: .categories)
            emojiView = EmojiView(keyboardSettings: keyboardSettings)
            emojiView.translatesAutoresizingMaskIntoConstraints = false
            emojiView.delegate = self
            txtmsg.inputView = emojiView
            let ViewForDoneButtonOnKeyboard = UIToolbar()
            ViewForDoneButtonOnKeyboard.sizeToFit()
            let btnSmiley = UIBarButtonItem(title: "🙂", style: .plain, target: self, action: #selector(self.doneBtnEmoji))
            let btnDoneOnKeyboard = UIBarButtonItem(title: "Dpc4rfone", style: .done, target: self, action: #selector(self.doneBtnFromKeyboardClicked))
            ViewForDoneButtonOnKeyboard.items = [btnSmiley,btnDoneOnKeyboard]
            txtmsg.inputAccessoryView = nil
            txtmsg.becomeFirstResponder()
        }
    }
    func emojiViewDidSelectEmoji(_ emoji: String, emojiView: EmojiView) {
        txtmsg.insertText(emoji)
    }
    func emojiViewDidPressChangeKeyboardButton(_ emojiView: EmojiView) {
        txtmsg.inputView = nil
        txtmsg.keyboardType = .default
        txtmsg.reloadInputViews()
    }
    func emojiViewDidPressDeleteBackwardButton(_ emojiView: EmojiView) {
        txtmsg.deleteBackward()
    }
    func emojiViewDidPressDismissKeyboardButton(_ emojiView: EmojiView) {
        txtmsg.resignFirstResponder()
    }
    //MARK:- TextView Delegate
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        
        //change table bottom layoutbased on screen size
        if UIDevice().userInterfaceIdiom == .phone {
            switch UIScreen.main.nativeBounds.height {
            case 2436:
                if   deleteFlag != 1
                {
                    if emojiFlag == 1
                    {
                        tblBtn.constant = 300
                    }
                    else
                    {
                        tblBtn.constant = 330
                    }
                    
                    return true
                }
                
            case 2688:
                if   deleteFlag != 1
                {
                    if emojiFlag == 1
                    {
                        tblBtn.constant = 300
                    }
                    else
                    {
                        tblBtn.constant = 330
                    }
                    
                    return true
                }
                
            case 1792:
                if   deleteFlag != 1
                {
                    if emojiFlag == 1
                    {
                        tblBtn.constant = 300
                    }
                    else
                    {
                        tblBtn.constant = 330
                    }
                    
                    return true
                }
                
            default:
                if   deleteFlag != 1
                {
                    if emojiFlag == 1
                    {
                        tblBtn.constant = 300
                    }
                    else
                    {
                        tblBtn.constant = 280
                    }
                    
                    return true
                }
            }
        }
        return false
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
        tapGestureTable = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboardTableBg))
        self.tbl.addGestureRecognizer(tapGestureTable)
        if textView.text == "Send a message"
        {
            textView.text = ""
            textView.textColor = UIColor.black
            
        }
        
        if flagEditingOver9Line == 1
        {
            print( UIScreen.main.nativeBounds.height)
            if UIDevice().userInterfaceIdiom == .phone {
                switch UIScreen.main.nativeBounds.height {
                case 2436:
                    textView.frame.origin.y=textView.frame.origin.y-166-35-45
                case 2688:
                    textView.frame.origin.y=textView.frame.origin.y-166-35-40
                    
                case 1792:
                    textView.frame.origin.y=textView.frame.origin.y-166-35-75
                    
                default:
                    textView.frame.origin.y=textView.frame.origin.y-166-35-20
                }
                
            }
            
        }
    }
    @objc func dismissKeyboardTableBg() {
        
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        self.view.endEditing(true)
        tblBtn.constant = 45
        
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        let textNo = numberOfLines(textView: textView)
        if textNo >= 9 {
            
            flagEditingOver9Line = 1
            textView.isScrollEnabled = true
            textView.translatesAutoresizingMaskIntoConstraints = true
            let size = CGSize(width: textView.frame.size.width, height: 166.5)
            textView.frame.size.height = 166.5
            
            textviewNewHeight  = textView.frame.height
            textviewNewY = textView.frame.origin.y
        }
        else
        {
            flagEditingOver9Line = 0
            textView.isScrollEnabled = false
            textView.translatesAutoresizingMaskIntoConstraints = false
        }
        
        if flagEditingOver9Line == 1
        {
            
            print( UIScreen.main.nativeBounds.height)
            if UIDevice().userInterfaceIdiom == .phone {
                switch UIScreen.main.nativeBounds.height {
                case 2436:
                    textView.frame.origin.y=(textviewOrginslY+130)-textviewNewHeight
                    
                case 2688:
                    textView.frame.origin.y=(textviewOrginslY+220)-textviewNewHeight
                case 2208:
                    textView.frame.origin.y=(textviewOrginslY+90)-textviewNewHeight
                case 1792:
                    textView.frame.origin.y=(textviewOrginslY+225)-textviewNewHeight
                    
                default:
                    textView.frame.origin.y=(textviewOrginslY+35)-textviewNewHeight
                }
                
            }
        }
        
        self.tbl.removeGestureRecognizer(tapGestureTable)
        tblBtn.constant = 45
        if textView.text == ""
        {
            textView.text = "Send a message"
            textView.textColor = UIColor.lightGray

        }
    }
    
    
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        //300 chars restriction
        
        let textNo = numberOfLines(textView: textView)
        
        if textNo >= 9 {
            if flagEditingOver9Line != 1
            {
                flagEditingOver9Line = 1
                let size = CGSize(width: textView.frame.size.width, height: 166.5)
                textView.contentSize = textView.sizeThatFits(size)
                //  textView.contentSize = textView.sizeThatFits(textView.frame.size)
                textviewNewHeight  = textView.frame.height
                textviewNewY = textView.frame.origin.y
                
                
                textView.isScrollEnabled = true
                textView.translatesAutoresizingMaskIntoConstraints = true
            }
        }
        else
        {
            flagEditingOver9Line = 0
            textView.isScrollEnabled = false
            textView.translatesAutoresizingMaskIntoConstraints = false
        }
        
        
        return textView.text.count + (text.count - range.length) <= 7000
    }
    
    func textViewDidChange(_ textView: UITextView) {
        
    }
    //MARK:- Attachment
    @IBAction func CamaraAction(_ sender: Any)
    {
        if self.deleteFlag != 1
        {
            self.ImageFromCamera()
        }
    }
    @IBAction func GallaryAction(_ sender: Any)
    {
        if self.deleteFlag != 1
        {
            self.ImageFromGallary()
        }
    }
    @IBAction func DocumentAction(_ sender: Any)
    {
        if self.deleteFlag != 1
        {
            self.DocumentSelect()
        }
    }
    @IBAction func chooseAction(_ sender: Any)
    {
        let actionSheet=UIAlertController(title:nil, message: nil, preferredStyle:UIAlertControllerStyle.alert )
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: {
            _ in
        }))
        actionSheet.addAction(UIAlertAction(title: "Take photo", style: UIAlertActionStyle.default, handler: {
            _ in
            self.ImageFromCamera()
        }))
        actionSheet.addAction(UIAlertAction(title: "Choose photo", style: UIAlertActionStyle.default, handler: {
            _ in
            self.ImageFromGallary()
        }))
        actionSheet.popoverPresentationController?.sourceView = self.view
        actionSheet.popoverPresentationController?.permittedArrowDirections = UIPopoverArrowDirection()
        actionSheet.popoverPresentationController?.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
        present(actionSheet, animated: true, completion: nil)
    }
    func ImageFromCamera() -> Void
    {
        picker.prefersStatusBarHidden
        picker.allowsEditing = true
        picker.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
        picker.sourceType = UIImagePickerControllerSourceType.camera
        present(picker, animated: true, completion: nil)
    }
    func ImageFromGallary() -> Void
    {
        picker.prefersStatusBarHidden
        picker.allowsEditing = false
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary))
        {
            picker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        }
        else
        {
            picker.sourceType = UIImagePickerControllerSourceType.savedPhotosAlbum
        }
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera))
        {
            picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: UIImagePickerControllerSourceType.camera)!
        }
        picker.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
        picker.navigationBar.isTranslucent = true
        picker.navigationBar.barTintColor = .black
        picker.navigationBar.tintColor = .white
        picker.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
        present(picker, animated: true, completion: nil)
    }
    public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        if let mediaType = info[UIImagePickerControllerMediaType] as? String {
            if mediaType  == "public.image" {
                if let img = info[UIImagePickerControllerEditedImage] as? UIImage
                {
                    chosenImage = fixOrientation(img: img)
                    
                }
                else if let img = info[UIImagePickerControllerOriginalImage] as? UIImage
                {
                    chosenImage = fixOrientation(img: img)
                }
                imageFlag = 1
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "HHmmss"
                let dateStr = dateFormatter.string(from: Date())
                let strFileName = String(format: "img%@.jpg",dateStr)
                let  imageData = UIImageJPEGRepresentation(chosenImage, 0.5)!
                uploadingData = imageData
                if self.lblReplyMessage.text == ""
                {
                    
                    self.replayHeight.constant = 40
                    self.replyViewY.constant = -102
                    
                }
                else
                {
                    
                    self.replayHeight.constant = 65
                    self.replyViewY.constant = -129
                }
                
                
                
                
                lblAttachemntName.text = strFileName
                AttaxchmentView.isHidden = false
                btnAttachmentCancel.isHidden = false
                mimetypeUploading = "image/jpeg"

            }
            else
            {
                let videoURL = info[UIImagePickerControllerMediaURL] as? NSURL
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "HHmmss"
                let dateStr = dateFormatter.string(from: Date())
                let strFileName = String(format: "video%@.mp4",dateStr)
                
                let videoData = NSData(contentsOf: videoURL! as URL)
                uploadingData = videoData as! Data
                imageFlag = 1
                mimetypeUploading = "video/mp4"
                if self.lblReplyMessage.text == ""
                {
                    
                    self.replayHeight.constant = 40
                    self.replyViewY.constant = -102
                    
                }
                else
                {
                    
                    self.replayHeight.constant = 65
                    self.replyViewY.constant = -129
                }
                
                lblAttachemntName.text = strFileName
                AttaxchmentView.isHidden = false
                btnAttachmentCancel.isHidden = false
                
            }
        }
        dismiss(animated:true, completion: nil)
    }
    func fixOrientation(img: UIImage) -> UIImage {
        if (img.imageOrientation == .up) {
            return img
        }
        UIGraphicsBeginImageContextWithOptions(img.size, false, img.scale)
        let rect = CGRect(x: 0, y: 0, width: img.size.width, height: img.size.height)
        img.draw(in: rect)
        let normalizedImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return normalizedImage
    }
    //MARK:- Document
    func DocumentSelect() -> Void
    {
        let importMenu = UIDocumentMenuViewController(documentTypes:["public.item"], in: .import)
        importMenu.delegate = self
        importMenu.modalPresentationStyle = .formSheet
        self.present(importMenu, animated: true, completion: nil)
    }
    func saveDocument(PdfData: Data,named: String) -> Bool
    {
        guard let directory = try? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false) as NSURL else {
            return false
        }
        do {
            try PdfData.write(to: directory.appendingPathComponent(named)!)
            return true
        } catch {
            print(error.localizedDescription)
            return false
        }
    }
    func getSavedDoc(named: String) -> URL {
        do{
            let directoryURL =  try? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            let docURL = NSURL(string:"named", relativeTo:directoryURL)
            return directoryURL!
        }
        catch{print("ERROR")
        }
    }
    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentAt url: URL) {
        let myURL = url as URL
        let fileURL = url as URL
        pdfpath = String(format: "%@",fileURL as CVarArg)
        let fileNameWithoutExtension = fileURL.pathExtension
        do {
            dataPDF = try Data(contentsOf: fileURL)
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "HHmmss"
            let dateStr = dateFormatter.string(from: Date())
            //    let docName = String(format: "Doc%@.%@",dateStr,fileNameWithoutExtension)
            let docName = fileURL.lastPathComponent
            
            var mimetypeExt = ""
            if fileNameWithoutExtension == "mp4"
            {
                mimetypeExt = "video/mp4"
            }
            else if fileNameWithoutExtension == "mp3"
            {
                mimetypeExt = "audio/mp3"
            }
            else
            {
                mimetypeExt = String(format: "application/%@",fileNameWithoutExtension)
            }
            
            mimetypeUploading = mimetypeExt
            uploadingData = dataPDF
            imageFlag = 3
            lblAttachemntName.text = docName
            self.replyViewY.constant = -102
            AttaxchmentView.isHidden = false
            btnAttachmentCancel.isHidden = false
        }
        catch {/* error handling here */}
    }
    public func documentMenu(_ documentMenu:UIDocumentMenuViewController, didPickDocumentPicker documentPicker: UIDocumentPickerViewController) {
        documentPicker.delegate = self
        present(documentPicker, animated: true, completion: nil)
    }
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        dismiss(animated: true, completion: nil)
    }
    func uploadData(fileName:String,mimetype:String,UploadData:Data,messageType:String)
    {
        AppHelper.showPrograss(vc: self.view, title: "uploading..", message: "Please wait")
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy HH:mm:ss"
        let date = Date()
        let dateString = formatter.string(from: date)
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let HeaderPar = ["Authorization": headerrr]
        let uploadParameterName = "file"
        let fileName = fileName
        let mimetype = mimetype
        
        
        var msg = ""
        if txtmsg.text != "Send a message"
        {
            msg = txtmsg.text
        }
        else
        {
            msg = ""
        }
        
        
        var receiver_Id = ""
        var param = [String:String]()
        
        if Role == "1"
        {
            if replyFlag == 1
            {
                param = ["replyImageExtension":replyAttachemntExtension,"attachmentId":replyAttachemntID,"replyUserId":replySelectedUSerUd,"replyMessageId":replySelectedid,"replyMessageText":lblReplyMessage.text!,  "replyStatus":"reply_msg","messageType" : messageType ,"message":msg,"receiverId":customerId,"senderId":userId,"status":"message_ind","customerId":customerId,"productId":productId,"replyIsAttachment":"true"]
            }
                
            else
            {
                param = ["messageType" : messageType ,"message":msg,"receiverId":customerId,"senderId":userId,"status":"message_ind","customerId":customerId,"productId":productId,"replyIsAttachment":"false"]
            }
            
        }
        else
        {
            if replyFlag == 1
            {
                param = ["replyImageExtension":replyAttachemntExtension,"attachmentId":replyAttachemntID,"replyUserId":replySelectedUSerUd,"replyMessageId":replySelectedid,"replyMessageText":lblReplyMessage.text!,  "replyStatus":"reply_msg","messageType" : messageType ,"message":msg,"receiverId":reciverId,"senderId":userId,"status":"message_ind","customerId":userId,"productId":senderId,"replyIsAttachment":"true","isUser":"true"]
            }
            else
            {
                param = ["messageType" : messageType ,"message":msg,"receiverId":reciverId,"senderId":userId,"status":"message_ind","customerId":userId,"productId":senderId,"replyIsAttachment":"false","isUser":"true"]
            }
            
            
        }
        
        
        
        
        
        
        let  imageData = UploadData
        let apiUrl = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.uploadAttachment)
        APiClass.ApiCallImageUploadWithHeade(mainUrl: apiUrl,HeaderParameters:HeaderPar, postParameters: param as! Dictionary<String, String> , mimeType: mimetype, uploadParameterName: uploadParameterName, fileName: fileName, uploadFileData: imageData)
        {
            (responseArray) in
            AppHelper.HidePrograss(vc: self.view)
            let responseDict = responseArray[0]
            if (responseDict.object(forKey: "error") != nil)
            {
                let message = responseDict["error"]
                AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
            }
            else
            {
                let message = responseDict["status"] as! String
                if message == "messageUploaded"
                {  self.mimetypeUploading = ""
                    self.imageFlag = 0
                    self.lblAttachemntName.text = ""
                    self.AttaxchmentView.isHidden = true
                    self.btnAttachmentCancel.isHidden = true
                    
                    self.btnReplClose.isHidden=true
                    self.replyView.isHidden=true
                    self.view.endEditing(true)
                    if mimetype != ".mp4"
                    {
                        self.txtmsg.text = ""
                        
                        self.txtmsg.isScrollEnabled = false
                        self.txtmsg.translatesAutoresizingMaskIntoConstraints = false
                        
                        self.view.endEditing(true)
                        self.txtmsg.text = "Send a message"
                        self.txtmsg.textColor = UIColor.lightGray
                    }
                    self.flagScrollToBottom = 1
                    self.getMsgList()
                }
                else
                {
                    AppHelper.showAlertMessage(vc: self, title: "Sorry", message: "Something went wrong")
                }
            }
        }
    }
    
    //MARK:- Recording
    @IBAction func RecordAction(_ sender: Any)
    {
    }
    func startRecording() {
        let audioFilename = getDocumentsDirectory().appendingPathComponent("recording.m4a")
        let settings = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 12000,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]
        do {
            audioRecorder = try AVAudioRecorder(url: audioFilename, settings: settings)
            audioRecorder.delegate = self
            audioRecorder.record()
        } catch {
            finishRecording(success: false)
        }
    }
    func finishRecording(success: Bool) {
        audioRecorder.stop()
        audioRecorder = nil
        if success {
        } else {
        }
    }
    func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if !flag {
            finishRecording(success: false)
        }
    }
    //MARK: FSCalander
    func calendar(_ calendar: FSCalendar, numberOfEventsFor date: Date) -> Int {
        let dateString = self.dateFormatter2.string(from: date)
        if self.datesWithChatArray.contains(dateString) {
            return 1
        }
        
        return 0
    }
    
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, eventColorFor date: Date) -> UIColor? {
        let dateString = self.dateFormatter2.string(from: date)
        if self.datesWithChatArray.contains(dateString) {
            return UIColor.purple
        }
        return nil
    }
    
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, eventDefaultColorsFor date: Date) -> [UIColor]? {
        let key = self.dateFormatter2.string(from: date)
        
        return nil
    }
    
    
    
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, borderRadiusFor date: Date) -> CGFloat {
        
        return 1.0
    }
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        
        icnCalendar.isEnabled = true
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let seletedDate = formatter.string(from: date)
        let date = Date()
        let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: Date())
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "YYYY-MM-dd"
        let someDate = dateFormatter.string(from: date)
        let someDateYes = dateFormatter.string(from: yesterday!)
        var msgDateString : String!
        if someDate == seletedDate
        {
            msgDateString = "Today"
        }
        else if someDateYes == seletedDate
        {
            msgDateString = "Yesterday"
        }
        else
        {
            msgDateString =  seletedDate
        }
        var indexxx : Int!
        var flagSearch : Int!
        for i in 0..<arrayMessage .count
        {
            let message_date = arrayMessage[i]["message_date"]
            if msgDateString == message_date
            {
                indexxx = i
                flagSearch = 1
                break
            }
        }
        if flagSearch == 1
        {
            let indexPath = NSIndexPath(row: 0, section: indexxx)
            tbl.scrollToRow(at: indexPath as IndexPath, at: .top, animated: true)
        }
        else
        {
            //selected date not found, search nearst date
            let dateFor = DateFormatter()
            dateFor.dateFormat = "yyyy-MM-dd"
            let strDate = dateFor.date(from: seletedDate)
            for n in 0..<arrayMessage .count
            {
                let message_display_type = arrayMessage[n]["message_display_type"]
                if message_display_type == "44"
                {
                    var SelectedArrayDate = arrayMessage[n]["message_date"]!
                    if SelectedArrayDate == "Today"
                    {
                        SelectedArrayDate = dateFor.string(from: date)
                    }
                    else if SelectedArrayDate == "Yesterday"
                    {
                        SelectedArrayDate = dateFor.string(from: yesterday!)
                    }
                    let message_date = dateFor.date(from: SelectedArrayDate)
                    if strDate!  < message_date! {
                        let indexPath = NSIndexPath(row: 0, section: n)
                        tbl.scrollToRow(at: indexPath as IndexPath, at: .top, animated: true)
                        break
                    }
                }
            }
        }
        recordingView.isUserInteractionEnabled = true
        bgCalander.isHidden = true
        icnCalendar.isEnabled = true
        calendar.reloadData()
    }
    func calendar(_ calendar: FSCalendar, shouldSelect date: Date, at monthPosition: FSCalendarMonthPosition) -> Bool {
        
        let dateString = self.dateFormatter2.string(from: date)
        if self.datesWithChatArray.contains(dateString) {
            return  true
        }
        return false
    }
    @IBAction func calanderCloseAction(_ sender: Any) {
        bgCalander.isHidden = true
        icnCalendar.isEnabled = true
        recordingView.isUserInteractionEnabled = true
        calendar.reloadData()
    }
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, titleDefaultColorFor date: Date) -> UIColor? {
        let dateString = self.dateFormatter2.string(from: date)
        if self.datesWithChatArray.contains(dateString) {
            return  UIColor.red
        }
        return UIColor.gray
        
    }
    //MARK: Socket Connection
    func removeSocket(_ s: WebSocket?) {
        socketArray = socketArray.filter{$0 != s}
    }
    func socketCoennection() {
        if Connectivity.isConnectedToInternet
        {
            let SocketURL = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverSocketDomain")!, DefineClass.SocketUrl)
            socket = WebSocket(url: URL(string: SocketURL)!, protocols: ["wss"])
            socket.delegate = self
            socketArray.append(socket)
            socket.onText = { [weak self]  (text: String) in
                if let c = Int(text) {
                    self?.caseCount = c
                }
            }
            socket.onDisconnect = { [weak self, weak socket]  (error: Error?) in
                self?.getTestInfo(1)
                self?.removeSocket(socket)
            }
            socket.disableSSLCertValidation = false
            socket.connect()
        }
        else
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Unable to get access to the Chat Server. Please check your internet connection!!!")
            
            timer = Timer.scheduledTimer(timeInterval: 5,
                                         target: self,
                                         selector: #selector(self.networkCheck),
                                         userInfo: nil,
                                         repeats: true)
        }
    }
    @objc func networkCheck() {
        if Connectivity.isConnectedToInternet {
            DispatchQueue.main.async {
                self.timer.invalidate()
                if let savedValue = UserDefaults.standard.string(forKey: "loginStatus"){
                    let  roleId = UserDefaults.standard.string(forKey: "roleIdd")
                    if roleId == "1"
                    {
                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                        
                        let rootVC:ProductViewController = storyboard.instantiateViewController(withIdentifier: "product") as! ProductViewController
                        let nvc:UINavigationController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController") as! UINavigationController
                        nvc.viewControllers = [rootVC]
                        let appDelegate = UIApplication.shared.delegate as! AppDelegate
                        appDelegate.window?.rootViewController = nvc
                    }
                    else
                    {
                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                        
                        let rootVC:HomeViewController = storyboard.instantiateViewController(withIdentifier: "home") as! HomeViewController
                        let nvc:UINavigationController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController") as! UINavigationController
                        nvc.viewControllers = [rootVC]
                        let appDelegate = UIApplication.shared.delegate as! AppDelegate
                        appDelegate.window?.rootViewController = nvc
                    }
                    
                    
                }
                
            }
        }
    }
    
    func getTestInfo(_ caseNum: Int) {
        let s = createSocket("getCaseInfo",caseNum)
        socketArray.append(s)
        s.onText = { (text: String) in
        }
        var once = false
        s.onDisconnect = { [weak self, weak s]  (error: Error?) in
            if !once {
                once = true
                self?.runTest(caseNum)
            }
            self?.removeSocket(s)
        }
        s.connect()
    }
    
    func runTest(_ caseNum: Int) {
        let s = createSocket("runCase",caseNum)
        self.socketArray.append(s)
        s.onText = { [weak s]  (text: String) in
            s?.write(string: text)
        }
        s.onData = { [weak s]  (data: Data) in
            s?.write(data: data)
        }
        var once = false
        s.onDisconnect = {[weak self, weak s] (error: Error?) in
            if !once {
                once = true
                let nextCase = caseNum+1
                if nextCase <= (self?.caseCount)! {
                    self?.runTest(nextCase)
                } else {
                    self?.finishReports()
                }
                self?.removeSocket(s)
            }
        }
        s.connect()
    }
    
    func verifyTest(_ caseNum: Int) {
        let s = createSocket("getCaseStatus",caseNum)
        self.socketArray.append(s)
        s.onText = { (text: String) in
            let data = text.data(using: String.Encoding.utf8)
            do {
                let resp: Any? = try JSONSerialization.jsonObject(with: data!,
                                                                  options: JSONSerialization.ReadingOptions())
                if let dict = resp as? Dictionary<String,String> {
                    if let status = dict["behavior"] {
                        if status == "OK" {
                            print("SUCCESS: \(caseNum)")
                            return
                        }
                    }
                }
            } catch {
            }
        }
        var once = false
        s.onDisconnect = { [weak self, weak s]  (error: Error?) in
            if !once {
                once = true
                let nextCase = caseNum+1
                if nextCase <= (self?.caseCount)! {
                    self?.getTestInfo(nextCase)
                } else {
                    self?.finishReports()
                }
            }
            self?.removeSocket(s)
        }
        s.connect()
    }
    func finishReports() {
        let s = createSocket("updateReports",0)
        self.socketArray.append(s)
        s.onDisconnect = { [weak self, weak s]  (error: Error?) in
            self?.removeSocket(s)
        }
        s.connect()
    }
    func createSocket(_ cmd: String, _ caseNum: Int) -> WebSocket {
        let SocketURL = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverSocketDomain")!, DefineClass.SocketUrl)
        return WebSocket(url: URL(string: "\(SocketURL)\(buildPath(cmd,caseNum))")!, protocols: [])
    }
    func buildPath(_ cmd: String, _ caseNum: Int) -> String {
        return "/\(cmd)?case=\(caseNum)&agent=Starscream"
    }
    func websocketDidConnect(socket: WebSocketClient) {
        if let savedValue = UserDefaults.standard.string(forKey: "loginStatus"){
            print("websocket is connected")
            let dict = ["message": String(format: "%@", userId),"status":"connect"]
            if let jsonString = JSONStringEncoder().encode(dict) {
                print(jsonString)
                socket.write(string: jsonString)
            }
        }
    }
    func websocketDidDisconnect(socket: WebSocketClient, error: Error?) {
        if let e = error as? WSError {
            print("--------------------->websocket is disconnected: \(e.message)")
        } else if let e = error {
            print("--------------------->websocket is disconnected: \(e.localizedDescription)")
        } else {
            print("--------------------->websocket disconnected")
        }
        socketCoennection()
    }
    @objc func updateSocket() {
        print("-----------chat------------")
        let nc = NotificationCenter.default
        nc.removeObserver("updateSocketChat")
        if Connectivity.isConnectedToInternet
        {
            if UserDefaults.standard.string(forKey: "lastUpdated") == "yes"
            {
                UserDefaults.standard.set("nooo", forKey: "lastUpdated")
                
                let dict = ["senderUserId": String(format: "%@", userId),"status":"ping"]
                if let jsonString = JSONStringEncoder().encode(dict) {
                    socket.write(string: jsonString)
                }
            }
        }
    }
    func websocketDidReceiveMessage(socket: WebSocketClient, text: String) {
        print("Received text: \(text)")
        let data1 = text.data(using: String.Encoding.utf8)
        do {
            let resp: AnyObject? = try JSONSerialization.jsonObject(with: data1!,
                                                                    options: JSONSerialization.ReadingOptions()) as AnyObject
            
            if let dict = resp as? Dictionary<String,Any> {
                // individualChat
                
                
                let  todayDate = self.dateFormatter2.string(from: Date())
                if !self.datesWithChatArray.contains(todayDate)
                {
                    self.datesWithChatArray.append(todayDate)
                }
                
                if let receverDict = dict["individualMessageDTO"] as? Dictionary<String,Any>{
                    //  let  attachment = String(format: "%d",  receverDict["isAttachment"]! as! Int)
                    let  attachment = 0
                    var dict : [String:String]!
                    let custID = receverDict["senderId"] as! String
                    let resId = receverDict["receiverId"] as! String
                    let mId = receverDict["id"] as! String
                    if userId == custID
                    {
                        if let strattachmentName =  receverDict["attachmentName"] as? String
                        {
                            self.flagScrollToBottom = 0
                            self.getMsgList()
                        }
                    }
                    else if userId == receverDict["receiverId"] as! String && productId == receverDict["productId"] as! String
                    {
                        if let strattachmentName =  receverDict["attachmentName"] as? String
                        {
                            self.flagScrollToBottom = 0
                            self.getMsgList()
                        }
                    }
                    
                    //time
                    let   StrDate = AppHelper.UTCToLocalTime(date: receverDict["time"] as! String)
                    
                    var  message_text = receverDict["messageText"] as! String
                    //applaying string formats
                    message_text = message_text.replacingOccurrences(of: "<div></div>", with: "\n")
                    message_text = message_text.replacingOccurrences(of: "<div>", with: "\n")
                    message_text = message_text.replacingOccurrences(of: "</div>", with: "")
                    message_text = message_text.replacingOccurrences(of: "<br>", with: "")
                    message_text = message_text.replacingOccurrences(of: "&nbsp;", with: " ")
                    message_text = message_text.replacingOccurrences(of: "&lt;", with: "<")
                    message_text = message_text.replacingOccurrences(of: "&gt;", with: ">")
                    message_text = message_text.replacingOccurrences(of: "amp;", with: "")
                    
                    var replyCheck = ""
                    if  receverDict["replyUserId"] != nil
                    {
                        replyCheck = "1"
                    }
                    else
                    {
                        replyCheck = ""
                    }
                    if replyCheck == "1"
                    {
                        let replyUserId = receverDict["replyUserId"]! as? String
                        var replyMsgUserName = ""
                        
                        if Role == "1"
                        {
                            if replyUserId == self.customerId
                            {
                                replyMsgUserName = self.lbltitleName.text!
                            }
                            else
                            {
                                replyMsgUserName = "You"
                            }
                        }
                        else
                        {
                            if replyUserId == self.reciverId
                            {
                                replyMsgUserName = self.lbltitleName.text!
                            }
                            else
                            {
                                replyMsgUserName = "You"
                            }
                        }
                        
                        
                        var replyAttachmentExtension = ""
                        if receverDict.keys.contains("replyAttachmentFormat")
                        {
                            replyAttachmentExtension =  String(format: "%@",receverDict["replyAttachmentFormat"] as! CVarArg )
                        }
                        else
                        {
                            replyAttachmentExtension = ""
                        }
                        
                        if replyAttachmentExtension == "<null>"
                        {
                            replyAttachmentExtension = ""
                        }
                        
                        
                        var replyAttachmentId = ""
                        
                        
                        if receverDict.keys.contains("replyAttachmentId")
                        {
                            
                            replyAttachmentId =  String(format: "%@",(receverDict["replyAttachmentId"] as! CVarArg ))
                        }
                        else
                        {
                            replyAttachmentId = ""
                        }
                        
                        
                        
                        if replyAttachmentId == "<null>"
                        {
                            replyAttachmentId = ""
                        }
                        let replyIsAttachmentAPi = String(format: "%d",receverDict["replyIsAttachment"] as! Int)
                        
                        let replyMessageType = String(format: "%d",receverDict["replyMessageType"] as! Int)
                        
                        dict = ["replyMessageType":replyMessageType,"replyIsAttachment":replyIsAttachmentAPi,"replyAttachmentExtension":replyAttachmentExtension,"replyAttachmentId":replyAttachmentId,"replyMsgUserName":replyMsgUserName, "replyCheck":replyCheck,"replyUserId":receverDict["replyUserId"], "replyMessageText":receverDict["replyMessageText"], "replyMessageId":receverDict["replyMessageId"],"message_date":StrDate,"attachment":String(format: "%d", attachment) ,"sender_id":custID ,"receiverId":resId ,"message_text":message_text,"id":mId] as! [String : String]
                        
                    }
                    else
                    {
                        dict = ["replyCheck":"0","message_date":StrDate,"attachment":String(format: "%d", attachment) ,"sender_id":custID ,"receiverId":resId ,"message_text":message_text,"id":mId] as! [String : String]
                    }
                    
                    
                    
                    // }
                    
                    if userId == custID
                    {
                        
                        if !self.arrayDate.contains("Today")
                        {
                            self.arrayDate.append("Today")
                            let   dict = ["replyCheck":"0","message_date":"Today","senderName":"","attachment":"0","sender_id":"" ,"reciever_id":"","message_text":"","id":"","message_display_type":"44"] as! [String : String]
                            self.arrayMessage.append(dict as! [String : String])
                        }
                        arrayMessage.append(dict as! [String : String])
                        
                    }
                    else if userId == receverDict["receiverId"] as! String && productId == receverDict["productId"] as! String
                    {
                        
                        
                        if !self.arrayDate.contains("Today")
                        {
                            self.arrayDate.append("Today")
                            let   dict = ["replyCheck":"0","message_date":"Today","senderName":"","attachment":"0","sender_id":"" ,"reciever_id":"","message_text":"","id":"","message_display_type":"44"] as! [String : String]
                            self.arrayMessage.append(dict as! [String : String])
                        }
                        
                        
                        let message = ["messageId":[mId],"senderId": custID,"recieverId":resId,"status":"iosMessageRead"] as [String : Any]
                        
                        if let jsonString = JSONStringEncoder().encode(message) {
                            socket.write(string: jsonString)
                        }
                        
                        
                        arrayMessage.append(dict as! [String : String])
                        
                    }
                    
                    if arrayMessage.count != 0
                    {
                        var sendId = arrayMessage[arrayMessage.count-1]["sender_id"]
                        if sendId != userId
                        {
                            
                            let indexPath = IndexPath(row: 0, section: arrayMessage.count-2)
                            let cellRect = tbl.rectForRow(at: indexPath)
                            let completelyVisible = tbl.bounds.contains(cellRect)
                            if !(completelyVisible)
                            {
                                self.btnNewMessage.isHidden=false
                            }
                        }
                        
                        tbl.reloadData()
                        if sendId == userId
                        {
                            tbl.scrollToBottom()
                        }
                    }
                    
                }
                else   if dict["status"] as?  String == "onlineStatus"{
                    if Role == "1"
                    {
                        if dict["senderUserId"]  as! String == customerId {
                            
                            
                            if dict["onlineStatus"] as! Int == 1
                            {
                                navigationView.backgroundColor = ColorChanger().color(from: "24A5A4")
                                self.view.backgroundColor = ColorChanger().color(from: "24A5A4")
                            }
                            else
                            {
                                navigationView.backgroundColor = ColorChanger().color(from: "808080")
                                self.view.backgroundColor = ColorChanger().color(from: "808080")
                                
                            }
                            
                        }
                    }
                    else
                    {
                        if dict["senderUserId"]  as! String == reciverId {
                            if dict["onlineStatus"] as! Int == 1
                            {
                                navigationView.backgroundColor = ColorChanger().color(from: "24A5A4")
                                self.view.backgroundColor = ColorChanger().color(from: "24A5A4")
                            }
                            else
                            {
                                navigationView.backgroundColor = ColorChanger().color(from: "808080")
                                self.view.backgroundColor = ColorChanger().color(from: "808080")
                                
                            }
                        }
                        
                    }
                }
                else if let receverDict = dict["ProfileUpdateDTO"] as? Dictionary<String,Any>{
                    
                    if let val = receverDict["id"] {
                        
                        
                        
                        
                        if val as! String == self.reciverId ||  val as! String == customerId
                        {
                            if  receverDict["firstName"] as! String != "notChanged"
                            {
                                self.lblChatUserName.text =  receverDict["firstName"] as! String
                                
                                self.flagScrollToBottom = 0
                                self.getMsgList()
                            }
                            if let checkKey = receverDict["attachmentId"] {
                                
                                
                                if  receverDict["attachmentId"] as? String != "notChanged"
                                {
                                    
                                    let accessToken = UserDefaults.standard.value(forKey: "accessToken")
                                    let tokenType = UserDefaults.standard.value(forKey: "tokenType")
                                    let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
                                    SDWebImageDownloader.shared.setValue(headerrr, forHTTPHeaderField:"Authorization")
                                    let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                                    let imgUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl, receverDict["attachmentId"] as! String)
                                    userDp.sd_imageIndicator = SDWebImageActivityIndicator.gray
                                    userDp.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                                    
                                }
                            }
                        }
                        
                    }
                }
                    
                    
                    
                    
                else  if let receverDict = dict["productDTO"] as? Dictionary<String,Any>{
                    
                    UserDefaults.standard.set("yes", forKey: "productDTOhave")
                    let requstedID = receverDict["id"] as? String
                    let productId =  UserDefaults.standard.value(forKey: "productid") as! String
                    if requstedID == productId
                    {
                        if dict["status"] as? String == "deletedProducts"
                        {
                            let alert = UIAlertController(title: "Alert", message: String(format: "%@ removed from product list", self.lblItemTitle.text!), preferredStyle: .alert)
                            let yesButton = UIAlertAction(title: "Ok", style: .default, handler: {(_ action: UIAlertAction) -> Void in
                                
                                self.backToHomeDeregister()
                            })
                            
                            alert.addAction(yesButton)
                            present(alert, animated: true)
                        }
                        
                        lblItemTitle.text = receverDict["productName"] as? String
                    }
                    let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                    
                    var link = receverDict[ "productImageUrl"] as? String
                    link = link!.replacingOccurrences(of: "/", with: "-")
                    var imgUrlPro = String(format: "%@/api/attachmentsByPath/%@", apiUrl,link!)
                    imgUrlPro = imgUrlPro.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
                    itemDp.sd_setImage(with: URL(string:  imgUrlPro), placeholderImage: UIImage(named: "chat_logo.png"))
                    
                    
                    UserDefaults.standard.set( receverDict["productName"] as? String, forKey: "productName")
                    UserDefaults.standard.set(link, forKey: "productImageUrl")
                    
                    UserDefaults.standard.set(receverDict["categoryName"] as? String, forKey: "Category")
                    UserDefaults.standard.set(receverDict["productTitle"] as? String, forKey: "productTitle")
                    
                    
                    if UserDefaults.standard.string(forKey: "viewMoreScreen") == "yes"{
                        let nc = NotificationCenter.default
                        nc.post(name: Notification.Name("viewMoreSocketPush"), object: nil)
                    }
                    
                    
                }
                    
                    
                else  if let receverDict = dict["productAttributeDTO"] as? Dictionary<String,Any>{
                    UserDefaults.standard.set("yes", forKey: "productDTOhave")
                    
                    let requstedID = receverDict["productId"] as? String
                    let productId =  UserDefaults.standard.value(forKey: "productid") as! String
                    if requstedID == productId
                    {
                        lblItemTitle.text = receverDict["productName"] as? String
                    }
                    
                    if UserDefaults.standard.string(forKey: "viewMoreScreen") == "yes"{
                        let nc = NotificationCenter.default
                        nc.post(name: Notification.Name("viewMoreSocketPush"), object: nil)
                    }
                    
                    
                }
                    
                    
                else  if dict["status"] as! String == "newCategory"    {
                    UserDefaults.standard.set("yes", forKey: "productDTOhave")
                    
                }
                    
                else  if dict["status"] as! String == "deleteCategory"    {
                    UserDefaults.standard.set("yes", forKey: "productDTOhave")
                }
                    
                    
                    
                else  if dict["status"] as! String == "updatedCategory"    {
                    UserDefaults.standard.set("yes", forKey: "productDTOhave")
                    
                    if let categoryDTO = dict["categoryDTO"] as? Dictionary<String,Any>{
                        let cateName =  UserDefaults.standard.value(forKey: "Category") as! String
                        if cateName == categoryDTO["oldCategory"] as? String
                        {
                            UserDefaults.standard.set(categoryDTO["oldCategory"] as? String, forKey: "oldCategoryName")
                            UserDefaults.standard.set(categoryDTO["category"] as? String, forKey: "NewCategoryName")
                            UserDefaults.standard.set("yes", forKey: "oldCategory")
                            
                            
                            UserDefaults.standard.set(categoryDTO["category"] as? String, forKey: "Category")
                            if UserDefaults.standard.string(forKey: "viewMoreScreen") == "yes"{
                                let nc = NotificationCenter.default
                                nc.post(name: Notification.Name("viewMoreSocketPush"), object: nil)
                            } 
                            
                            
                        }
                    }
                }
                    
                    
                    
                    
                    
                    
                else  if let receverDict = dict["deregisterDTO"] as? Dictionary<String,Any>{
                    if receverDict["status"] as? String == "User_deregistered"
                    {
                        if receverDict["id"] as? String == self.reciverId ||  receverDict["id"] as? String == customerId
                        {
                            
                            let alert = UIAlertController(title: "Alert", message: String(format: "%@ deregistered from profield-chat.This user will be removed from contact list", self.lbltitleName.text!), preferredStyle: .alert)
                            let yesButton = UIAlertAction(title: "Ok", style: .default, handler: {(_ action: UIAlertAction) -> Void in
                                
                                self.backToHomeDeregister()
                            })
                            
                            alert.addAction(yesButton)
                            present(alert, animated: true)
                        }
                    }
                }
                    
                else  if dict["status"] as! String == "DeletedOwner"    {
                    if let receverDict = dict["user"] as? Dictionary<String,Any>{
                        if  receverDict["id"] as? String == userId
                        {
                            self.deleteByAdmin()
                        }
                        else
                        {
                            if  receverDict["id"] as? String == reciverId
                            {
                                let alert = UIAlertController(title: "Alert", message: String(format: "%@ removed from profield-chat.This user will be removed from contact list", self.lbltitleName.text!), preferredStyle: .alert)
                                let yesButton = UIAlertAction(title: "Ok", style: .default, handler: {(_ action: UIAlertAction) -> Void in
                                    
                                    self.backToHomeDeregister()
                                })
                                
                                alert.addAction(yesButton)
                                present(alert, animated: true)
                            }
                        }
                    }
                }
                else  if dict["status"] as! String == "DeletedUserByadmin"    {
                    if let receverDict = dict["user"] as? Dictionary<String,Any>{
                        if  receverDict["id"] as? String == userId
                        {
                            self.deleteByAdmin()
                        }else
                        {
                            if  receverDict["id"] as? String == customerId
                            {
                                let alert = UIAlertController(title: "Alert", message: String(format: "%@ removed from profield-chat.This user will be removed from contact list", self.lbltitleName.text!), preferredStyle: .alert)
                                let yesButton = UIAlertAction(title: "Ok", style: .default, handler: {(_ action: UIAlertAction) -> Void in
                                    
                                    self.backToHomeDeregister()
                                })
                                
                                alert.addAction(yesButton)
                                present(alert, animated: true)
                            }
                        }
                    }
                    
                }
                    
                    
                else
                {
                    self.flagScrollToBottom = 0
                    self.getMsgList()
                }
            }
            else
            {
                self.flagScrollToBottom = 0
                self.getMsgList()
            }
        } catch {
            print("error parsing the json")
        }
    }
    @IBAction func deleteByAdmin() {
        //  timer.invalidate()
        socket.disconnect()
        //delete all values in database
        let realm = try! Realm()
        try! realm.write {
            realm.deleteAll()
        }
        
        //remove values from UserDefaults
        UserDefaults.standard.removeObject(forKey: "accessToken")
        UserDefaults.standard.removeObject(forKey: "tokenType")
        UserDefaults.standard.removeObject(forKey: "userId")
        UserDefaults.standard.removeObject(forKey: "loginStatus")
        UserDefaults.standard.removeObject(forKey: "defualtImage")
        UserDefaults.standard.removeObject(forKey: "email")
        UserDefaults.standard.removeObject(forKey: "profileUrl")
        UserDefaults.standard.removeObject(forKey: "lastName")
        UserDefaults.standard.removeObject(forKey: "firstName")
        UserDefaults.standard.removeObject(forKey: "gender")
        UserDefaults.standard.removeObject(forKey: "attachmentid")
        UserDefaults.standard.removeObject(forKey: "userName")
        
        //navigate to login screen
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "loginScreen") as! ViewController
        vc.sessionOutFlag = 5
        self.navigationController?.pushViewController(vc,
                                                      animated: false)
    }
    func backToHome()
    {
        
        
        
        let nc = NotificationCenter.default
        nc.removeObserver("updateSocketChat")
        if Role != "1"
        {
            let vc = CustomerFeedbackPopup()
            vc.modalPresentationStyle = .overFullScreen
            present(vc, animated: true, completion: nil)
            
        }else
        {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "home") as! HomeViewController
            self.navigationController?.pushViewController(vc,
                                                          animated: false)
            
        }
        
    }
    func backToHomeDeregister()
    {
        
        
        
        let nc = NotificationCenter.default
        nc.removeObserver("updateSocketChat")
        if Role != "1"
        {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "product") as! ProductViewController
            self.navigationController?.pushViewController(vc,
                                                          animated: true)
            
        }else
        {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "home") as! HomeViewController
            self.navigationController?.pushViewController(vc,
                                                          animated: false)
            
        }
        
    }
    func websocketDidReceiveData(socket: WebSocketClient, data: Data) {
        print("Received data: \(data.count)")
    }
    func numberOfLines(textView: UITextView) -> Int {
        let layoutManager = textView.layoutManager
        let numberOfGlyphs = layoutManager.numberOfGlyphs
        var lineRange: NSRange = NSMakeRange(0, 1)
        var index = 0
        var numberOfLines = 0
        while index < numberOfGlyphs {
            layoutManager.lineFragmentRect(forGlyphAt: index, effectiveRange: &lineRange)
            index = NSMaxRange(lineRange)
            numberOfLines += 1
        }
        return numberOfLines
    }
    struct JSONStringEncoder {
        func encode(_ dictionary: [String: Any]) -> String? {
            guard JSONSerialization.isValidJSONObject(dictionary) else {
                assertionFailure("Invalid json object received.")
                return nil
            }
            let jsonObject: NSMutableDictionary = NSMutableDictionary()
            let jsonData: Data
            dictionary.forEach { (arg) in
                jsonObject.setValue(arg.value, forKey: arg.key)
            }
            do {
                jsonData = try JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted)
            } catch {
                assertionFailure("JSON data creation failed with error: \(error).")
                return nil
            }
            guard let jsonString = String.init(data: jsonData, encoding: String.Encoding.utf8) else {
                assertionFailure("JSON string creation failed.")
                return nil
            }
            print("JSON string: \(jsonString)")
            return jsonString
        }
    }
}
extension UITableView {
    func scrollToBottom(){
        DispatchQueue.main.async {
            let indexPath = IndexPath(
                row: self.numberOfRows(inSection:  self.numberOfSections - 1) - 1,
                section: self.numberOfSections - 1)
            self.scrollToRow(at: indexPath, at: .bottom, animated: false)
        }
    }
    func scrollToTop() {
        DispatchQueue.main.async {
            let indexPath = IndexPath(row: 0, section: 0)
            self.scrollToRow(at: indexPath, at: .top, animated: false)
        }
    }
}
extension ChatViewController: SKRecordViewDelegate {
    //recoder delegate methods
    func SKRecordViewDidSelectRecord(_ sender: SKRecordView, button: UIView) {
        if deleteFlag != 1
        {
            stackVieww.isHidden = true
            btnDocument.isHidden = true
            
            sender.state = .recording
            sender.setupRecordButton(UIImage(named: "rec-1.png")!)
            recordingView.recordButton.imageView?.startAnimating()
            self.txtmsg.text = ""
        }
    }
    func SKRecordViewDidStopRecord(_ sender: SKRecordView, button: UIView) {
        stackVieww.isHidden = false
        btnDocument.isHidden = false
        sender.state = .none
        sender.setupRecordButton(UIImage(named: "mic.png")!)
        let fileMgr = FileManager.default
        let dirPaths = fileMgr.urls(for: .documentDirectory,
                                    in: .userDomainMask)
        let outputUrl = dirPaths[0].appendingPathComponent("audiosound.mp4")
        let asset = AVAsset.init(url: recordingView.getFileURL())
        recordingView.recordButton.imageView?.stopAnimating()
        let exportSession = AVAssetExportSession.init(asset: asset, presetName: AVAssetExportPresetHighestQuality)
        // remove file if already exits
        let fileManager = FileManager.default
        do{
            try? fileManager.removeItem(at: outputUrl)
            
        }catch{
            print("can't")
        }
        //export to mp4
        exportSession?.outputFileType = AVFileType.mp4
        exportSession?.outputURL = outputUrl
        exportSession?.metadata = asset.metadata
        exportSession?.exportAsynchronously(completionHandler: {
            if (exportSession?.status == .completed)
            {
                let audioData = NSData(contentsOf: (exportSession?.outputURL)!)
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "HHmmss"
                let dateStr = dateFormatter.string(from: Date())
                let strFileName = String(format: "audio%@.mp4",dateStr)
                DispatchQueue.main.async {
                    self.uploadData(fileName: strFileName, mimetype: "mp4",UploadData:audioData! as Data,messageType:"2" )
                }
            }
            else if (exportSession?.status == .cancelled)
            {
                // print("AV export cancelled.")
            }
            else
            {
                //  print ("Error is \(String(describing: exportSession?.error))")
                
            }
        })
        
        self.view.bringSubview(toFront: self.btnEmoji)
        self.view.bringSubview(toFront: self.btnSend)
        self.view.bringSubview(toFront: self.btnDocument)
        
    }
    func SKRecordViewDidCancelRecord(_ sender: SKRecordView, button: UIView) {
        stackVieww.isHidden = false
        btnDocument.isHidden = false
        sender.state = .none
        sender.setupRecordButton(UIImage(named: "mic.png")!)
        recordingView.recordButton.imageView?.stopAnimating()
        
        self.view.bringSubview(toFront: self.btnEmoji)
        self.view.bringSubview(toFront: self.btnSend)
        self.view.bringSubview(toFront: self.btnDocument)
    }
}
extension String {
    func fromBase64() -> String? {
        guard let data = Data(base64Encoded: self, options: Data.Base64DecodingOptions(rawValue: 0)) else {
            return nil
        }
        return String(data: data as Data, encoding: String.Encoding.utf8)
    }
    func toBase64() -> String? {
        guard let data = self.data(using: String.Encoding.utf8) else {
            return nil
        }
        return data.base64EncodedString(options: Data.Base64EncodingOptions(rawValue: 0))
    }
}
extension NSAttributedString {
    func htmlString() -> String? {
        let documentAttributes = [NSAttributedString.DocumentAttributeKey.documentType: NSAttributedString.DocumentType.html]
        do {
            let htmlData = try self.data(from: NSMakeRange(0, self.length), documentAttributes:documentAttributes)
            if let htmlString = String(data:htmlData, encoding:String.Encoding.utf8) {
                return htmlString
            }
        }
        catch {}
        return nil
    }
}
extension String
{
    func encodeUrl() -> String?
    {
        return self.addingPercentEncoding( withAllowedCharacters: NSCharacterSet.urlQueryAllowed)
    }
    func decodeUrl() -> String?
    {
        return self.removingPercentEncoding
    }
}

extension Array where Element: Hashable {
    func removingDuplicates() -> [Element] {
        var addedDict = [Element: Bool]()
        
        return filter {
            addedDict.updateValue(true, forKey: $0) == nil
        }
    }
    
    mutating func removeDuplicates() {
        self = self.removingDuplicates()
    }
}

