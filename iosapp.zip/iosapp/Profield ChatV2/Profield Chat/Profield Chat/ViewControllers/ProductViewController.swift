//
//  ProductViewController.swift
//  Profield Chat
//
//  Created by USER on 2019/07/11.
//  Copyright Â© 2019 indocosmo. All rights reserved.
//

import Foundation
import UIKit
import Floaty
import RealmSwift
import Alamofire
import Starscream
import AVKit
import IQKeyboardManager
import SDWebImage
class ProductViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,WebSocketDelegate,UITextFieldDelegate,UIScrollViewDelegate,UIPickerViewDelegate, UIPickerViewDataSource {
    @IBOutlet weak var bgMenuView: UIView!
    @IBOutlet weak var bgMenuViewInner: UIView!
    @IBOutlet weak var userDp: UIImageView!
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var tblHome: UITableView!
    @IBOutlet weak var titleView: UIView!
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var categoryView: UIView!
    @IBOutlet weak var btnCategory: UIButton!
    @IBOutlet weak var dropDowncategory = UIPickerView()
    @IBOutlet weak var viewToolBar: UIView!
    @IBOutlet weak var segmntCntlrHeight: NSLayoutConstraint!
    @IBOutlet weak var segmntCntlr: UISegmentedControl!
    @IBOutlet weak var titleViewHeight: NSLayoutConstraint!
    var darkBgView : UIView!
    var flagTableReloading:Int!
    var bgViewOnDashboard : UIView!
    var pageControlOnDashboard: UIPageControl!
    var isNewDataLoading : Bool!
    var productList = [[String : Any]]()
    var socket: WebSocket!
    var caseCount = 300 //starting cases
    var socketArray = [WebSocket]()
    var userId : String!
    var menuFlag : Int!
    var ChatNotificationArray=[String]()
    let refreshControl = UIRefreshControl()
    var senderId : String!
    var receverId : String!
    var flagLogin : String!
    var categoryId : String!
    var categoryId2 : String!
    var categorytxt2 : String!
    let floaty = Floaty()
    var categoryList = [[String:String]]()
    var arraySample = [Int]()
    var spinner : UIActivityIndicatorView!
    var selectedIndex : Int!
    var paginationCount : Int!
    var ondashboard : Int!
    var productCount : Int!
    var flagChatConfirm : Int!
    var timer = Timer()
    var flagToTop : Int!
    var searchingText = ""
    
    // MARK: - ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        //  UserDefaults.standard.set("accessToken", forKey: "accessToken")
        
        UserDefaults.standard.set("", forKey: "oldCategoryName")
        UserDefaults.standard.set("", forKey: "NewCategoryName")
        UserDefaults.standard.set("", forKey: "oldCategory")
        UserDefaults.standard.set("", forKey: "productDTOhave")
        productCount = 0
        if flagLogin == "1"
        {
            pageviewSetUp()
        }
        self.appversionCheck()
        UserDefaults.standard.set("Chat", forKey: "socketMain")
        isNewDataLoading = false
        categoryId = ""
        categoryId2 = ""
        categorytxt2 = "Category - All"
        //IQKeyboard disable
        IQKeyboardManager.shared().disabledToolbarClasses.add(ProductViewController.self)
        IQKeyboardManager.shared().disabledDistanceHandlingClasses.add(ProductViewController.self)
        for AttributeIndex in 0..<4
        {
            arraySample.append(AttributeIndex)
        }
        paginationCount = 0
        //sdImageView set header values
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        SDWebImageDownloader.shared.setValue(headerrr, forHTTPHeaderField:"Authorization")
        SDWebImageDownloader.shared.setValue(headerrr, forHTTPHeaderField:"Authorization")
        userId = UserDefaults.standard.value(forKey: "userId") as! String
        let categoryDict = ["Name":"All","Id":""] as [String : String]
        categoryList.append(categoryDict)
        //config screen
        screenSetup()
        // set floating type button
        //  setFloatButton()
        //Load Profile Details
        getHomeList(strCateId: "", productName: "", PaginationCountBegin: paginationCount, PaginationCountEnd: 12)
        getProfileDetail()
        refreshControl.addTarget(self, action: #selector(tableReload), for: .valueChanged)
        tblHome.refreshControl = refreshControl
        txtSearch.delegate = self
        let nc = NotificationCenter.default
        nc.removeObserver("updateSocketHomeProduct")
        nc.addObserver(self, selector: #selector(updateSocket), name: Notification.Name("updateSocketHomeProduct"), object: nil)
    }
    func screenSetup()
    {
        let txtToolbar = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 44))
        txtToolbar.backgroundColor = titleView.backgroundColor
        let btnCancel:UIButton = UIButton(frame: CGRect(x: 15, y: 0, width: 75, height: 44))
        btnCancel.setTitle("Cancel", for: .normal)
        btnCancel.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        btnCancel.addTarget(self, action:#selector(self.searchCancel), for: .touchUpInside)
        self.view.addSubview(btnCancel)
        let btnsearch:UIButton = UIButton(frame: CGRect(x: self.view.bounds.width - 90, y: 0, width: 75, height: 44))
        btnsearch.setTitle("Search >", for: .normal)
        btnsearch.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        btnsearch.addTarget(self, action:#selector(self.searchDone), for: .touchUpInside)
        self.view.addSubview(btnsearch)
        txtToolbar.addSubview(btnCancel)
        txtToolbar.addSubview(btnsearch)
        categoryId = ""
        txtSearch.inputAccessoryView = txtToolbar
        btnCategory.setTitle("Category - All", for: .normal)
        btnCategory.setTitleColor(ColorChanger().color(from: "C7C7CD"), for: .normal)
        dropDowncategory?.isHidden = true
        viewToolBar.isHidden = true
        self.txtSearch.isEnabled = true
        bgMenuView.isHidden = true
        searchView.layer.cornerRadius = 8
        categoryView.layer.cornerRadius = 8
        userDp.layer.cornerRadius = userDp.frame.size.width/2
        bgMenuViewInner.layer.borderColor = UIColor.gray.cgColor
        bgMenuViewInner.layer.borderWidth = 1
        bgMenuViewInner.layer.cornerRadius = 4
        spinner = UIActivityIndicatorView(activityIndicatorStyle: .gray)
        spinner.frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: tblHome.bounds.width, height: CGFloat(44))
    }
    //MARK:- onDarshBoard
    func pageviewSetUp()
    {
        var yAxisAdjustable : CGFloat = 0 // used to adjust y point difference i varias device
        if UIScreen.main.nativeBounds.height == 2436 || UIScreen.main.nativeBounds.height == 1792 || UIScreen.main.nativeBounds.height == 2688
        {
            yAxisAdjustable =  15
        }
        ondashboard = 1
        bgViewOnDashboard = UIView(frame: CGRect(x: 0, y: 0, width: self.view.bounds.width, height: self.view.bounds.height))
        bgViewOnDashboard.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        self.view.addSubview(bgViewOnDashboard)
        let scrollView = UIScrollView(frame: CGRect(x: 0, y: 0, width: self.view.bounds.width, height: self.view.bounds.height))
        let numberOfPages: CGFloat = 7
        scrollView.contentSize = CGSize(width: scrollView.frame.width * numberOfPages, height: self.view.bounds.height)
        scrollView.delegate = self
        scrollView.isPagingEnabled = true
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        scrollView.backgroundColor = UIColor.clear
        scrollView.bounces = false
        bgViewOnDashboard.addSubview(scrollView)
        //search
        var imageView1 : UIImageView
        imageView1  = UIImageView(frame:CGRect(x:  30, y: searchView.frame.origin.y + 10 + yAxisAdjustable, width:280, height:280));
        imageView1.image = UIImage(named:"search.png")
        scrollView.addSubview(imageView1)
        var imageView1Icn : UIImageView
        imageView1Icn  = UIImageView(frame:CGRect(x:  (self.view.frame.width/2) - 20 , y: imageView1.frame.origin.y + imageView1.frame.size.height + 20, width:40, height:41));
        imageView1Icn.image = UIImage(named:"OnDasSearch-icon.png")
        scrollView.addSubview(imageView1Icn)
        var lbl1 : UILabel
        lbl1 = UILabel(frame:CGRect(x:  0, y: imageView1Icn.frame.origin.y + 41, width:self.view.bounds.width, height:40));
        lbl1.text = "Search Products"
        lbl1.font = UIFont(name: "Chalkduster", size: 18)
        lbl1.textAlignment = .center
        lbl1.textColor = UIColor.white
        lbl1.numberOfLines = 0
        scrollView.addSubview(lbl1)
        //category
        var imageView2 : UIImageView
        imageView2  = UIImageView(frame:CGRect(x:self.view.frame.width + 30, y:searchView.frame.origin.y+10+yAxisAdjustable, width:280, height:280));
        imageView2.image = UIImage(named:"categoryImage.png")
        scrollView.addSubview(imageView2)
        var imageView2Icn : UIImageView
        imageView2Icn  = UIImageView(frame:CGRect(x:  self.view.frame.width + (self.view.frame.width/2) - 20 , y: imageView2.frame.origin.y + imageView2.frame.size.height + 20, width:40, height:41));
        imageView2Icn.image = UIImage(named:"OnDasCategory-icon.png")
        scrollView.addSubview(imageView2Icn)
        var lbl2 : UILabel
        lbl2 = UILabel(frame:CGRect(x:  self.view.bounds.width, y: imageView2Icn.frame.origin.y + 41 , width:self.view.bounds.width, height:40));
        lbl2.text = "Search Category wise"
        lbl2.font = UIFont(name: "Chalkduster", size: 18)
        lbl2.textAlignment = .center
        lbl2.textColor = UIColor.white
        lbl2.numberOfLines = 0
        scrollView.addSubview(lbl2)
        //allProducts
        var imageView3 : UIImageView
        imageView3  = UIImageView(frame:CGRect(x:(self.view.frame.width * 2)+30, y:segmntCntlr.frame.origin.y+10 + yAxisAdjustable, width:280, height:280));
        imageView3.image = UIImage(named:"allImage.png")
        scrollView.addSubview(imageView3)
        var imageView3Icn : UIImageView
        imageView3Icn  = UIImageView(frame:CGRect(x:  (self.view.frame.width * 2) + (self.view.frame.width/2) - 20, y: imageView3.frame.origin.y + imageView3.frame.size.height + 20, width:40, height:41));
        imageView3Icn.image = UIImage(named:"OnDasAll-products-icon.png")
        scrollView.addSubview(imageView3Icn)
        var lbl3 : UILabel
        lbl3 = UILabel(frame:CGRect(x:  self.view.frame.width * 2, y: imageView3Icn.frame.origin.y + 41 , width:self.view.bounds.width, height:40));
        lbl3.text = "All Products"
        lbl3.textColor = UIColor.white
        lbl3.font = UIFont(name: "Chalkduster", size: 18)
        lbl3.textAlignment = .center
        lbl3.numberOfLines = 0
        scrollView.addSubview(lbl3)
        //recentProducts
        var imageView4 : UIImageView
        imageView4  = UIImageView(frame:CGRect(x:(self.view.frame.width * 3)+70, y:segmntCntlr.frame.origin.y+10 + yAxisAdjustable, width:280, height:280));
        imageView4.image = UIImage(named:"recentImage.png")
        scrollView.addSubview(imageView4)
        var imageView4Icn : UIImageView
        imageView4Icn  = UIImageView(frame:CGRect(x:  (self.view.frame.width * 3) + (self.view.frame.width/2) - 20 , y: imageView4.frame.origin.y + imageView4.frame.size.height + 20, width:40, height:41));
        imageView4Icn.image = UIImage(named:"OnDasRecent-icon.png")
        scrollView.addSubview(imageView4Icn)
        var lbl4 : UILabel
        lbl4 = UILabel(frame:CGRect(x:  self.view.frame.width * 3 ,y: imageView4Icn.frame.origin.y + 41 , width:self.view.bounds.width, height:40));
        lbl4.text = "Recent Products"
        lbl4.textColor = UIColor.white
        lbl4.font = UIFont(name: "Chalkduster", size: 18)
        lbl4.textAlignment = .center
        lbl4.numberOfLines = 0
        scrollView.addSubview(lbl4)
        //swipe
        var imageView5 : UIImageView
        imageView5  = UIImageView(frame:CGRect(x:(self.view.frame.width * 4)+(self.view.bounds.width/2)-140, y:segmntCntlr.frame.origin.y+50 + yAxisAdjustable, width:280, height:280));
        imageView5.image = UIImage(named:"swipeImage.png")
        scrollView.addSubview(imageView5)
        var imageView5Icn : UIImageView
        imageView5Icn  = UIImageView(frame:CGRect(x: (self.view.frame.width * 4)+(self.view.bounds.width/2) - 30 , y: imageView5.frame.origin.y + imageView5.frame.size.height + 15, width:60, height:61));
        imageView5Icn.image = UIImage(named:"OnDasSwipe-lr-icon.png")
        scrollView.addSubview(imageView5Icn)
        var lbl5 : UILabel
        lbl5 = UILabel(frame:CGRect(x:  self.view.frame.width * 4, y: imageView5Icn.frame.origin.y + 56, width:self.view.bounds.width, height:40));
        lbl5.text = "Swipe Left/Right"
        lbl5.font = UIFont(name: "Chalkduster", size: 18)
        lbl5.textAlignment = .center
        lbl5.numberOfLines = 0
        lbl5.textColor = UIColor.white
        scrollView.addSubview(lbl5)
        //chat
        var imageView6 : UIImageView
        imageView6  = UIImageView(frame:CGRect(x:(self.view.frame.width * 5)+(self.view.bounds.width/2)-140, y:segmntCntlr.frame.origin.y + yAxisAdjustable, width:280, height:280));
        imageView6.image = UIImage(named:"chat")
        scrollView.addSubview(imageView6)
        var imageView6Icn : UIImageView
        imageView6Icn  = UIImageView(frame:CGRect(x:  (self.view.frame.width * 5)+(self.view.bounds.width/2) - 20 , y: imageView6.frame.origin.y + 280 + 20, width:40, height:41));
        imageView6Icn.image = UIImage(named:"OnDasChat with product owner icon.png")
        scrollView.addSubview(imageView6Icn)
        var lbl6 : UILabel
        lbl6 = UILabel(frame:CGRect(x:  self.view.frame.width * 5, y: imageView6Icn.frame.origin.y + 41 , width:self.view.bounds.width, height:40));
        lbl6.text = "Chat With Product Owner"
        lbl6.textColor = UIColor.white
        lbl6.font = UIFont(name: "Chalkduster", size: 18)
        lbl6.textAlignment = .center
        lbl6.numberOfLines = 0
        scrollView.addSubview(lbl6)
        var lblTnq : UILabel
        lblTnq = UILabel(frame:CGRect(x:  self.view.frame.width * 6, y: (self.view.frame.height/2)-60 ,width:self.view.frame.width, height:60));
        lblTnq.text = "Thank You"
        lblTnq.textColor = UIColor.white
        lblTnq.font = UIFont.boldSystemFont(ofSize: 30)
        lblTnq.textAlignment = .center
        lblTnq.numberOfLines = 0
        scrollView.addSubview(lblTnq)
        var btnFinish : UIButton
        btnFinish = UIButton(frame:CGRect(x:  (self.view.frame.width * 6)  + (self.view.frame.width / 2) - 85, y: lblTnq.frame.origin.y + 60 ,width:175, height:50));
        btnFinish.setTitle("Let's Start...", for: .normal)
        btnFinish.tintColor = UIColor.white
        btnFinish.backgroundColor = self.view.backgroundColor
        btnFinish.layer.cornerRadius = 10
        btnFinish.titleLabel!.font = UIFont.boldSystemFont(ofSize: 18)
        btnFinish.addTarget(self, action: #selector(paginationRemove(_:)), for: .touchUpInside)
        scrollView.addSubview(btnFinish)
        //tank You
        pageControlOnDashboard = UIPageControl(frame: CGRect(x: 0, y: scrollView.frame.height - 70, width: scrollView.frame.width, height: 37))
        pageControlOnDashboard.numberOfPages = Int(numberOfPages)
        pageControlOnDashboard.currentPage = 0
        var btnSkip : UIButton
        btnSkip = UIButton(frame:CGRect(x: self.view.frame.width - 65 , y: 30,width:50, height:30));
        btnSkip.setTitle("Skip", for: .normal)
        btnSkip.tintColor = UIColor.white
        btnSkip.backgroundColor = UIColor.clear
        btnSkip.layer.cornerRadius = 10
        btnSkip.titleLabel!.font = UIFont.boldSystemFont(ofSize: 18)
        btnSkip.addTarget(self, action: #selector(paginationRemove(_:)), for: .touchUpInside)
        bgViewOnDashboard.addSubview(btnSkip)
        bgViewOnDashboard.addSubview(pageControlOnDashboard)
    }
    @IBAction  func paginationRemove(_ sender: UIButton)
    {
        bgViewOnDashboard.removeFromSuperview()
        ondashboard = 0
    }
    override func viewWillAppear(_ animated: Bool) {
        //config web socket
        socketCoennection()
        if UserDefaults.standard.string(forKey: "oldCategory") == "yes"{
            if btnCategory.titleLabel?.text == UserDefaults.standard.string(forKey: "oldCategoryName"){
                btnCategory.setTitle(UserDefaults.standard.string(forKey: "NewCategoryName"), for: .normal)
            }
        }
        if UserDefaults.standard.string(forKey: "productDTOhave") == "yes"{
            categoryList = [[String:String]]()
            let categoryDict = ["Name":"All","Id":""] as [String : String]
            categoryList.append(categoryDict)
            getHomeList(strCateId: categoryId, productName: txtSearch.text!, PaginationCountBegin: paginationCount, PaginationCountEnd: 12)
        }
        UserDefaults.standard.set("", forKey: "oldCategoryName")
        UserDefaults.standard.set("", forKey: "NewCategoryName")
        UserDefaults.standard.set("", forKey: "oldCategory")
        UserDefaults.standard.set("", forKey: "productDTOhave")
        //top Image
        if let savedValue = UserDefaults.standard.string(forKey: "attachmentid"){
            let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
            let attachment_id = savedValue
            let imgUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id)
            userDp.sd_imageIndicator = SDWebImageActivityIndicator.gray
            userDp.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
        }
        let nc = NotificationCenter.default
        nc.addObserver(self, selector: #selector(socketCloseStatus), name: Notification.Name("AppClosedNotification"), object: nil)
    }
    override func viewWillDisappear(_ animated: Bool)
    {
        let nc = NotificationCenter.default
        nc.removeObserver("UserLoggedInPreCRE")
    }
    @objc func socketCloseStatus()
    {
        //online status change to offline
        let dict = ["senderUserId": String(format: "%@", self.userId),"status":"logout"]
        if let jsonString = JSONStringEncoder().encode(dict) {
            print(jsonString)
            self.socket.write(string: jsonString)
        }
    }
    //MARK:- Menu
    @IBAction func menuAction(_ sender: Any) {
        if menuFlag == 1
        {
            bgMenuView.isHidden = true
            menuFlag = 0
        }
        else
        {
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.tapBlurButton(_:)))
            bgMenuView.addGestureRecognizer(tapGesture)
            bgMenuView.isHidden = false
            self.view.bringSubview(toFront: bgMenuView)
            menuFlag = 1
        }
    }
    @objc func tapBlurButton(_ sender: UITapGestureRecognizer) {
        bgMenuView.isHidden = true
        menuFlag = 0
    }
    @IBAction func MenuProfile(_ sender: Any) {
        bgMenuView.isHidden = true
        menuFlag = 0
    }
    @IBAction func MenuChangePassword(_ sender: Any) {
        bgMenuView.isHidden = true
        menuFlag = 0
        let vc = ChangePasswordPopup()
        vc.modalPresentationStyle = .overFullScreen
        present(vc, animated: true, completion: nil)
    }
    @IBAction func MenuDeregister(_ sender: Any) {
        bgMenuView.isHidden = true
        menuFlag = 0
        let alert = UIAlertController(title: "Alert", message: "Your account will immediately deleted. You no longer be able to connect with any chat users and access the related messages or data. Are you sure, you still want to deactivate your account?", preferredStyle: .alert)
        let yesButton = UIAlertAction(title: "Yes", style: .default, handler: {(_ action: UIAlertAction) -> Void in
            print("you pressed Yes, please button")
            self.DeregisterAPi()
        })
        let noButton = UIAlertAction(title: "No", style: .default, handler: {(_ action: UIAlertAction) -> Void in
        })
        alert.addAction(yesButton)
        alert.addAction(noButton)
        present(alert, animated: true)
    }
    func SuccessDeregister()
    {
        //Deregister account
        let dict = ["senderUserId": String(format: "%@", self.userId),"status":"logout"]
        if let jsonString = JSONStringEncoder().encode(dict) {
            print(jsonString)
            self.socket.write(string: jsonString)
        }
        let realm = try! Realm()
        try! realm.write {
            realm.deleteAll()
        }
        UserDefaults.standard.removeObject(forKey: "accessToken")
        UserDefaults.standard.removeObject(forKey: "tokenType")
        UserDefaults.standard.removeObject(forKey: "userId")
        UserDefaults.standard.removeObject(forKey: "loginStatus")
        UserDefaults.standard.removeObject(forKey: "defualtImage")
        UserDefaults.standard.removeObject(forKey: "email")
        UserDefaults.standard.removeObject(forKey: "profileUrl")
        UserDefaults.standard.removeObject(forKey: "lastName")
        UserDefaults.standard.removeObject(forKey: "firstName")
        UserDefaults.standard.removeObject(forKey: "gender")
        UserDefaults.standard.removeObject(forKey: "attachmentid")
        UserDefaults.standard.removeObject(forKey: "userName")
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "loginScreen") as! ViewController
        self.navigationController?.pushViewController(vc,
                                                      animated: true)
    }
    @IBAction func menuLogout(_ sender: Any) {
        bgMenuView.isHidden = true
        menuFlag = 0
        let alert = UIAlertController(title: "Alert", message: "Are you sure you want to logout now.?", preferredStyle: .alert)
        let yesButton = UIAlertAction(title: "Yes", style: .default, handler: {(_ action: UIAlertAction) -> Void in
            //online status change to logout
            let dict = ["senderUserId": String(format: "%@", self.userId),"status":"logout"]
            if Connectivity.isConnectedToInternet {
                if let jsonString = JSONStringEncoder().encode(dict) {
                    self.socket.write(string: jsonString)
                }
            }
            //delete all values in database
            let realm = try! Realm()
            try! realm.write {
                realm.deleteAll()
            }
            //remove values from UserDefaults
            UserDefaults.standard.removeObject(forKey: "accessToken")
            UserDefaults.standard.removeObject(forKey: "tokenType")
            UserDefaults.standard.removeObject(forKey: "userId")
            UserDefaults.standard.removeObject(forKey: "loginStatus")
            UserDefaults.standard.removeObject(forKey: "defualtImage")
            UserDefaults.standard.removeObject(forKey: "email")
            UserDefaults.standard.removeObject(forKey: "profileUrl")
            UserDefaults.standard.removeObject(forKey: "lastName")
            UserDefaults.standard.removeObject(forKey: "firstName")
            UserDefaults.standard.removeObject(forKey: "gender")
            UserDefaults.standard.removeObject(forKey: "attachmentid")
            UserDefaults.standard.removeObject(forKey: "userName")
            //navigate to login screen
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "loginScreen") as! ViewController
            self.navigationController?.pushViewController(vc,
                                                          animated: true)
        })
        let noButton = UIAlertAction(title: "No", style: .default, handler: {(_ action: UIAlertAction) -> Void in
        })
        alert.addAction(yesButton)
        alert.addAction(noButton)
        present(alert, animated: true)
    }
    
    @IBAction func sessionOut() {
        // to logout when api token is expired
        //online status change to logout
        let dict = ["senderUserId": String(format: "%@", self.userId),"status":"logout"]
        if let jsonString = JSONStringEncoder().encode(dict) {
            self.socket.write(string: jsonString)
        }
        //delete all values in database
        let realm = try! Realm()
        try! realm.write {
            realm.deleteAll()
        }
        //remove values from UserDefaults
        UserDefaults.standard.removeObject(forKey: "accessToken")
        UserDefaults.standard.removeObject(forKey: "tokenType")
        UserDefaults.standard.removeObject(forKey: "userId")
        UserDefaults.standard.removeObject(forKey: "loginStatus")
        UserDefaults.standard.removeObject(forKey: "defualtImage")
        UserDefaults.standard.removeObject(forKey: "email")
        UserDefaults.standard.removeObject(forKey: "profileUrl")
        UserDefaults.standard.removeObject(forKey: "lastName")
        UserDefaults.standard.removeObject(forKey: "firstName")
        UserDefaults.standard.removeObject(forKey: "gender")
        UserDefaults.standard.removeObject(forKey: "attachmentid")
        UserDefaults.standard.removeObject(forKey: "userName")
        
        //navigate to login screen
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "loginScreen") as! ViewController
        vc.sessionOutFlag = 1
        self.navigationController?.pushViewController(vc,
                                                      animated: true)
        
        
    }
    // MARK: - segement controller
    @IBAction func segementValueChanged(_ sender: Any) {
        
        tblHome.isHidden = true
        self.view.endEditing(true)
        dropDowncategory?.isHidden = true
        viewToolBar.isHidden = true
        if segmntCntlr.selectedSegmentIndex == 1
        {
            btnCategory.isEnabled = false
            txtSearch.isEnabled = false
            txtSearch.textColor = ColorChanger().color(from: "C7C7CD")
            btnCategory.setTitleColor(ColorChanger().color(from: "C7C7CD"), for: .normal)
            getRecentList()
        }
        else
        {
            btnCategory.isEnabled = true
            txtSearch.isEnabled = true
            txtSearch.textColor = UIColor.darkText
            if btnCategory.titleLabel?.text == "Category - All"
            {
                btnCategory.setTitleColor(ColorChanger().color(from: "C7C7CD"), for: .normal)
            }
            else
            {
                btnCategory.setTitleColor(txtSearch.textColor, for: .normal)
            }
            paginationCount = 0
            self.flagTableReloading=1
            getHomeList(strCateId: categoryId, productName: txtSearch.text!, PaginationCountBegin: 0, PaginationCountEnd: 12)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    // MARK: - TableView Delegate
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell") as! CarouselView
        cell.attributesList = productList[indexPath.row]
        if flagTableReloading == 1
        {
            cell.carouselView.scrollToItem(at: 0, animated: true)
        }
        else
        {
            cell.carouselView.scrollToItem(at: 0, animated: false)
        }
        cell.carouselView.reloadData()
        let btnChat : UIButton = cell.viewWithTag(20) as! UIButton
        btnChat.addTarget(self, action: #selector(ChatAction(_:)), for: .touchUpInside)
        return cell
        
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if let lastVisibleIndexPath = tableView.indexPathsForVisibleRows?.last {
            if indexPath == lastVisibleIndexPath {
                flagTableReloading=0
            }
        }
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        print("enterd................")
        //Bottom Refresh
        if ondashboard != 1
        {
            var curentPage = paginationCount
            curentPage = curentPage! + 1
            let currantProducts = curentPage! * 12
            print(paginationCount)
            print(currantProducts)
            print(productCount)
            if self.productCount > currantProducts {
                
                if scrollView == self.tblHome{
                    if segmntCntlr.selectedSegmentIndex != 1{
                        if ((scrollView.contentOffset.y + scrollView.frame.size.height) >= scrollView.contentSize.height-300)
                        {
                            print(scrollView.contentOffset.y + scrollView.frame.size.height)
                            print(scrollView.contentSize.height)
                            if !isNewDataLoading{
                                isNewDataLoading = true
                                print("loading................")
                                spinner.startAnimating()
                                self.tblHome.tableFooterView = spinner
                                self.tblHome.tableFooterView?.isHidden = false
                                loadNewData()
                            }
                        }
                    }
                }
            }
            
            if scrollView.panGestureRecognizer.translation(in: scrollView).y < 0{
                segmntCntlr.isHidden = true
                segmntCntlrHeight.constant = 0
                titleViewHeight.constant = 70
                searchView.isHidden = true
                categoryView.isHidden = true
                
            }
            else{
                segmntCntlr.isHidden = false
                segmntCntlrHeight.constant = 33
                titleViewHeight.constant = 115
                searchView.isHidden = false
                categoryView.isHidden = false
            }
        }
    }
    
    func loadNewData()
    { paginationCount = paginationCount + 1
        getHomeListPagination(strCateId: categoryId, productName: txtSearch.text!, PaginationCountBegin: paginationCount, PaginationCountEnd: 12)
    }
    @IBAction  func ChatAction(_ sender: UIButton)
    {
        if flagChatConfirm != 1
        {
            self.view.endEditing(true)
            if (dropDowncategory?.isHidden)!
            {
                flagChatConfirm = 1
                let buttonPosition:CGPoint = sender.convert(CGPoint.zero, to:self.tblHome)
                let indexPath = self.tblHome.indexPathForRow(at: buttonPosition)
                
                selectedIndex = indexPath?.row
                print("selectedIndex -----> %d",selectedIndex)
                darkBgView = UIView(frame: CGRect(x: 0, y: 0, width: self.view.bounds.width, height: self.view.bounds.height))
                let cusstomAlertBox = UINib.init(nibName: "AlertBoxView", bundle: nil).instantiate(withOwner: self)[0] as! UIView
                cusstomAlertBox.frame =  CGRect(x: (self.view.frame.size.width/2)-150 , y: (self.view.frame.size.height/2)-85, width:cusstomAlertBox.frame.size.width, height: cusstomAlertBox.frame.size.height)
                cusstomAlertBox.layer.cornerRadius = 5
                darkBgView.addSubview(cusstomAlertBox)
                let btnYes : UIButton = cusstomAlertBox.viewWithTag(1) as! UIButton
                let btnNo : UIButton = cusstomAlertBox.viewWithTag(2) as! UIButton
                btnYes.layer.cornerRadius = 4
                btnNo.layer.cornerRadius = 4
                btnYes.addTarget(self, action: #selector(alertOkAction(_:)), for: .touchUpInside)
                btnNo.addTarget(self, action: #selector(alertNoAction(_:)), for: .touchUpInside)
                self.view.addSubview(darkBgView)
                darkBgView.backgroundColor = UIColor.black.withAlphaComponent(0.6)
            }
        }
    }
    @IBAction  func alertOkAction(_ sender: UIButton)
    {
        darkBgView.removeFromSuperview()
        flagChatConfirm = 0
        UserDefaults.standard.set(self.productList[self.selectedIndex]["productName"] as! String, forKey: "productName")
        UserDefaults.standard.set(self.productList[self.selectedIndex]["categoryName"] as! String, forKey: "Category")
        UserDefaults.standard.set(self.productList[self.selectedIndex]["productTitle"] as! String, forKey: "productTitle")
        UserDefaults.standard.set(self.productList[self.selectedIndex]["productImageUrl"] as! String, forKey: "productImageUrl")
        UserDefaults.standard.set(self.productList[self.selectedIndex]["id"] as! String, forKey: "productid")
        self.chatWithOwnerApi()
    }
    @IBAction  func alertNoAction(_ sender: UIButton)
    {
        flagChatConfirm = 0
        darkBgView.removeFromSuperview()
    }
    
    // MARK:- ScrollVIew
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if ondashboard == 1
        {
            let value = scrollView.contentOffset.x / scrollView.frame.size.width
            pageControlOnDashboard.currentPage = Int(round(value))
        }
    }
    // MARK: - APIS
    func getHomeList( strCateId:String,productName:String,PaginationCountBegin : Int,PaginationCountEnd : Int ){
        //load chat list
        AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let par = ["Authorization": headerrr]
        let url = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.productList)
        let parameter = ["userId": userId,"CategoryId": strCateId,"sortBy":"_id","sortOrder":"ASC","productName":productName,"PaginationCountBegin":PaginationCountBegin,"PaginationCountEnd":PaginationCountEnd] as [String : Any]
        
        APiClass.apiCallRESTProduct(mainUrl: url, postParameters: parameter,HeaderParameters:par) { (responseArray) in
            print(responseArray[0])
            let responseDict = responseArray[0]
            
            self.dropDowncategory?.isHidden = true
            self.viewToolBar.isHidden = true
            self.txtSearch.isEnabled = true
            if (responseDict.object(forKey: "error") != nil)
            {
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["error"]
                if message as! String == "Unauthorized"
                {
                    //tocken expired
                    self.sessionOut()
                }
                else
                {
                    AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
                }
            }
            else
            {
                if PaginationCountBegin == 0
                {
                    self.productList = [[String : Any]]()
                }
                
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["status"] as! String
                if message == "success"
                {
                    self.productCount = (responseDict["productCount"] as! Int)
                    if self.categoryList.count == 1
                    {
                        let catagoryArray = responseDict["dataCategoryList"] as! [[String:Any]]
                        for category in catagoryArray {
                            let categoryDict = ["Name":category["category"],"Id":category["id"]]
                            self.categoryList.append(categoryDict as! [String : String])
                            self.dropDowncategory?.reloadAllComponents()
                            
                        }
                    }
                    let productListArray = responseDict["dataProductList"] as! [[String:Any]]
                    for list in productListArray
                    {
                        let attributeList = list["productAttributeList"] as! [[String:Any]]
                        var attributeListArray = [[String:Any]]()
                        for attList in attributeList
                        {
                            let dictA = ["id":attList["id"],"productId":attList["productId"],"attribute":attList["attribute"],"description":attList["description"],"imageUrl":attList["imageUrl"],"fileName":attList["fileName"]]
                            attributeListArray.append(dictA as [String : Any])
                            
                        }
                        let dict = ["id":list["id"],"productName":list["productName"],"productTitle":list["productTitle"],"productImageUrl":list["productImageUrl"],"categoryName":list["categoryName"],"attributes":attributeListArray]
                        
                        self.productList.append(dict as [String : Any])
                    }
                    if self.productList.count == 0
                    {
                        AppHelper.showAlertMessage(vc: self, title: "", message: "No search result found")
                    }
                    self.segmntCntlr.selectedSegmentIndex = 0
                    self.tblHome.isHidden = false
                    self.tblHome.reloadData()
                       self.dropDowncategory?.reloadAllComponents()
                    
                    if PaginationCountBegin == 0
                    {
                        if  self.productList.count != 0
                        {
                            if self.flagToTop != 1
                            {
                                self.tblHome.scrollToTop()
                            }
                            else
                            {
                                self.flagToTop = 0
                            }
                        }
                    }
                    
                }
                else
                {
                    AppHelper.HidePrograss(vc: self.view)
                    AppHelper.showAlertMessage(vc: self, title: "", message: message)
                }
            }
        }
        
    }
    func getHomeListPagination( strCateId:String,productName:String,PaginationCountBegin : Int,PaginationCountEnd : Int ){
        //load chat list
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let par = ["Authorization": headerrr]
        let url = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.productList)
        let parameter = ["userId": userId,"CategoryId": strCateId,"sortBy":"_id","sortOrder":"ASC","productName":productName,"PaginationCountBegin":PaginationCountBegin,"PaginationCountEnd":PaginationCountEnd] as [String : Any]
        
        APiClass.apiCallRESTProduct(mainUrl: url, postParameters: parameter,HeaderParameters:par) { (responseArray) in
            let responseDict = responseArray[0]
            
            self.dropDowncategory?.isHidden = true
            self.viewToolBar.isHidden = true
            self.txtSearch.isEnabled = true
            
            if (responseDict.object(forKey: "error") != nil)
            {
                self.isNewDataLoading = false
                self.spinner.stopAnimating()
                self.tblHome.tableFooterView = nil
                self.tblHome.tableFooterView?.isHidden = true
                
                
                let message = responseDict["error"]
                
                if message as! String == "Unauthorized"
                {
                    //tocken expired
                    self.sessionOut()
                    
                }
                else
                {
                    AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
                }
            }
            else
            {
                if PaginationCountBegin == 0
                {
                    self.productList = [[String : Any]]()
                }
                
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["status"] as! String
                if message == "success"
                {
                    
                    
                    self.productCount = (responseDict["productCount"] as! Int)
                    
                    if self.categoryList.count == 1
                    {
                        let catagoryArray = responseDict["dataCategoryList"] as! [[String:Any]]
                        
                        
                        for category in catagoryArray {
                            
                            let categoryDict = ["Name":category["category"],"Id":category["id"]]
                            self.categoryList.append(categoryDict as! [String : String])
                            self.dropDowncategory?.reloadAllComponents()
                        }
                    }
                    let productListArray = responseDict["dataProductList"] as! [[String:Any]]
                    for list in productListArray
                    {
                        let attributeList = list["productAttributeList"] as! [[String:Any]]
                        var attributeListArray = [[String:Any]]()
                        
                        for attList in attributeList
                        {
                            let dictA = ["id":attList["id"],"productId":attList["productId"],"attribute":attList["attribute"],"description":attList["description"],"imageUrl":attList["imageUrl"],"fileName":attList["fileName"]]
                            attributeListArray.append(dictA as [String : Any])
                            
                        }
                        
                        let dict = ["id":list["id"],"productName":list["productName"],"productTitle":list["productTitle"],"productImageUrl":list["productImageUrl"],"categoryName":list["categoryName"],"attributes":attributeListArray]
                        self.productList.append(dict as [String : Any])
                    }
                    self.isNewDataLoading = false
                    self.spinner.stopAnimating()
                    self.tblHome.tableFooterView = nil
                    self.tblHome.tableFooterView?.isHidden = true
                    self.tblHome.reloadData()
                    self.tblHome.isHidden = false
                    
                }
                else
                {
                    self.isNewDataLoading = false
                    self.spinner.stopAnimating()
                    self.tblHome.tableFooterView = nil
                    self.tblHome.tableFooterView?.isHidden = true
                    AppHelper.showAlertMessage(vc: self, title: "", message: message)
                    self.tblHome.isHidden = false
                }
            }
        }
        
    }
    func getRecentList(){
        //load chat list
        AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let par = ["Authorization": headerrr]
        let url = String(format: "%@%@?userId=%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.recentProductList,userId)
        let parameter = ["":""]
        APiClass.apiCallRESTProduct(mainUrl: url, postParameters: parameter,HeaderParameters:par) { (responseArray) in
            let responseDict = responseArray[0]
            self.refreshControl.endRefreshing()
            if (responseDict.object(forKey: "error") != nil)
            {
                self.flagToTop = 0
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["error"]
                if message as! String == "Unauthorized"
                {
                    //tocken expired
                    self.sessionOut()
                    
                }
                else
                {
                    AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
                }
                AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
            }
            else
            {
                
                self.productList = [[String : Any]]()
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["status"] as! String
                if message == "success"
                {
                    let productListArray = responseDict["recentProductList"] as! [[String:Any]]
                    for list in productListArray
                    {
                        let attributeList = list["productAttributeList"] as! [[String:Any]]
                        var attributeListArray = [[String:Any]]()
                        
                        for attList in attributeList
                        {
                            let dictA = ["id":attList["id"],"productId":attList["productId"],"attribute":attList["attribute"],"description":attList["description"],"imageUrl":attList["imageUrl"],"fileName":attList["fileName"]]
                            attributeListArray.append(dictA as [String : Any])
                            
                        }
                        
                        let dict = ["id":list["id"],"productName":list["productName"],"productTitle":list["productTitle"],"productImageUrl":list["productImageUrl"],"categoryName":list["categoryId"],"attributes":attributeListArray]
                        
                        
                        self.productList.append(dict as [String : Any])
                        
                        
                    }
                    self.tblHome.isHidden = false
                    self.flagTableReloading=1
                    self.tblHome.reloadData()
                    if self.productList.count != 0
                    {
                        if self.flagToTop != 1
                        {
                            self.tblHome.scrollToTop()
                        }
                        else
                        {
                            self.flagToTop = 0
                        }
                        
                    }
                    
                }
                    
                else
                {
                    self.flagToTop = 0
                    AppHelper.HidePrograss(vc: self.view)
                    AppHelper.showAlertMessage(vc: self, title: "", message: message)
                }
            }
        }
        
    }
    func chatWithOwnerApi(){
        //load chat list
        AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let par = ["Authorization": headerrr]
        let productID = productList[selectedIndex]["id"] as! String
        let url = String(format: "%@%@?userId=%@&productId=%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.chatWithOwner,userId,productID)
        
        let parameter = ["":""]
        
        APiClass.apiCallRESTProduct(mainUrl: url, postParameters: parameter,HeaderParameters:par) { (responseArray) in
            let responseDict = responseArray[0]
            if (responseDict.object(forKey: "error") != nil)
            {
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["error"]
                AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
            }
            else
            {
                
                
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["status"] as! String
                if message == "chatWithOwner"
                {    let nc = NotificationCenter.default
                    nc.removeObserver("updateSocketHomeProduct")
                    let ownerId = responseDict["id"] as! String
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "chatScreen") as! ChatViewController
                    vc.socket = self.socket
                    vc.senderId = self.productList[self.selectedIndex]["id"] as! String
                    vc.productName = self.productList[self.selectedIndex]["productName"] as! String
                    //   productID and senderid are same
                    vc.productId = self.productList[self.selectedIndex]["id"] as! String
                    vc.ChatUserName = responseDict["firstName"] as! String
                    vc.senderName = responseDict["userName"] as! String
                    vc.userAttachemntId = responseDict["attachmentId"] as! String
                    vc.online = responseDict["online"] as! Int
                    UserDefaults.standard.set(ownerId, forKey: "ownerId")
                    vc.reciverId = ownerId
                    self.navigationController?.pushViewController(vc,
                                                                  animated: true)
                    
                }
                    
                else if message == "Unauthorized Error"
                {
                    AppHelper.HidePrograss(vc: self.view)
                    AppHelper.showAlertMessage(vc: self, title: "", message: "Owner Not Found")
                }
                    
                else
                {
                    AppHelper.HidePrograss(vc: self.view)
                    AppHelper.showAlertMessage(vc: self, title: "", message: message)
                }
            }
        }
        
    }
    @objc func tableReload()
    {
        
        if segmntCntlr.selectedSegmentIndex == 1
        {
            getRecentList()
        }
        else
        {
            getHomeListRefresh()
        }
    }
    
    @objc func getHomeListRefresh(){
        //load chat list when table refresh
        //load chat list
        
        paginationCount = 0
        if segmntCntlr.selectedSegmentIndex != 1
        {
            let accessToken = UserDefaults.standard.value(forKey: "accessToken")
            let tokenType = UserDefaults.standard.value(forKey: "tokenType")
            let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
            let par = ["Authorization": headerrr]
            let url = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.productList)
            
            let parameter = ["userId": userId,"CategoryId": categoryId,"sortBy":"_id","sortOrder":"ASC","productName":txtSearch.text!,"PaginationCountBegin":0,"PaginationCountEnd":12] as [String : Any]
            
            
            APiClass.apiCallRESTProduct(mainUrl: url, postParameters: parameter,HeaderParameters:par) { (responseArray) in
                print(responseArray[0])
                let responseDict = responseArray[0]
                
                self.refreshControl.endRefreshing()
                
                if (responseDict.object(forKey: "error") != nil)
                {
                    AppHelper.HidePrograss(vc: self.view)
                    let message = responseDict["error"]
                    if message as! String == "Unauthorized"
                    {
                        //tocken expired
                        self.sessionOut()
                        
                    }
                    else
                    {
                        self.refreshControl.endRefreshing()
                        AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
                    }
                }
                else
                {
                    
                    self.productList = [[String : Any]]()
                    
                    
                    AppHelper.HidePrograss(vc: self.view)
                    let message = responseDict["status"] as! String
                    if message == "success"
                    {
                        
                        self.productCount = (responseDict["productCount"] as! Int)
                        let productListArray = responseDict["dataProductList"] as! [[String:Any]]
                        for list in productListArray
                        {
                            
                            
                            let attributeList = list["productAttributeList"] as! [[String:Any]]
                            var attributeListArray = [[String:Any]]()
                            
                            for attList in attributeList
                            {
                                let dictA = ["id":attList["id"],"productId":attList["productId"],"attribute":attList["attribute"],"description":attList["description"],"imageUrl":attList["imageUrl"],"fileName":attList["fileName"]]
                                attributeListArray.append(dictA as [String : Any])
                                
                            }
                            
                            let dict = ["id":list["id"],"productName":list["productName"],"productTitle":list["productTitle"],"productImageUrl":list["productImageUrl"],"categoryName":list["categoryName"],"attributes":attributeListArray]
                            
                            
                            self.productList.append(dict as [String : Any])
                            
                            
                        }
                        
                        self.refreshControl.endRefreshing()
                        self.flagTableReloading=1
                        self.tblHome.reloadData()
                        
                    }
                        
                        
                        
                    else
                    {
                        self.refreshControl.endRefreshing()
                        AppHelper.HidePrograss(vc: self.view)
                        AppHelper.showAlertMessage(vc: self, title: "", message: message)
                    }
                }
            }
        }
        else
        {
            self.refreshControl.endRefreshing()
            
        }
    }
    
    func getProfileDetail(){
        
        //load profile details
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let par = ["Authorization": headerrr]
        let str = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.loadUserDetails)
        let url = String(format: "%@?userId=%@", str,userId)
        APiClass.apiCallGetWithHeader(mainUrl: url, postParameters: par) { (responseArray) in
            let responseDict = responseArray[0]
            if (responseDict.object(forKey: "error") != nil)
            {
                
            }
            else
            {
                //save details to userDefault
                
                let arrayAllResponse = responseDict["value"] as! [[String:Any]]
                
                let arrayResponse = arrayAllResponse[0]["user"] as! [String:Any]
                print(arrayResponse)
                let dftImg = String(format: "%d", arrayResponse["defualtImage"] as! Int)
                UserDefaults.standard.set(dftImg, forKey: "defualtImage")
                
                UserDefaults.standard.set(arrayResponse["userName"], forKey: "userName")
                UserDefaults.standard.set(arrayResponse["email"], forKey: "email")
                UserDefaults.standard.set(arrayResponse["profileUrl"], forKey: "profileUrl")
                UserDefaults.standard.set(arrayResponse["lastName"], forKey: "lastName")
                UserDefaults.standard.set(arrayResponse["firstName"], forKey: "firstName")
                UserDefaults.standard.set(arrayResponse["gender"], forKey: "gender")
                UserDefaults.standard.set(arrayResponse["attachmentId"], forKey: "attachmentid")
                let apiUrl = String(format: "%@",UserDefaults.standard.string(   forKey: "serverDomain")!)
                let attachment_id = String(format:"%@", arrayResponse["attachmentId"] as! String)
                let imgUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id)
                self.userDp.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
            }
        }
    }
    
    func DeregisterAPi(){
        //Deregister Api
        AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let HeaderPar = ["Authorization": headerrr]
        let str = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.deRegisterUser)
        let par = ["userId": userId]
        APiClass.apiCallPostValueWithHeader(mainUrl: str, postParameters: par as! Dictionary<String, String>,headerParams:HeaderPar) { (responseArray) in
            let responseDict = responseArray[0]
            if (responseDict.object(forKey: "error") != nil)
            {
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["error"]
                AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
            }
            else
            {
                let arrayAllResponse = responseDict["value"] as! NSArray
                let dict = arrayAllResponse[0] as! [String : Any]
                
                let message = dict["status"] as! String
                if message == "de-registered"
                {
                    AppHelper.HidePrograss(vc: self.view)
                    self.SuccessDeregister()
                }
                else
                {
                    AppHelper.HidePrograss(vc: self.view)
                    AppHelper.showAlertMessage(vc: self, title: "Sorry", message: "Something went wrong, Please try again after some time.")
                }
            }
        }
    }
    
    
    //MARK: Search
    
    @objc func searchCancel() {
        txtSearch.text = searchingText
        self.view.endEditing(true)
    }
    @objc func searchDone() {
        self.view.endEditing(true)
        paginationCount = 0
        self.flagTableReloading=1
        getHomeList(strCateId: categoryId, productName: txtSearch.text!, PaginationCountBegin: paginationCount, PaginationCountEnd: 12)
    }
    @IBAction   func textFieldDidChange(textField : UITextField){
        
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == txtSearch {
            
            searchingText = textField.text!
            
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == txtSearch {
            textField.resignFirstResponder()
            self.flagTableReloading=1
            
            getHomeList(strCateId: categoryId, productName: txtSearch.text!, PaginationCountBegin: paginationCount, PaginationCountEnd: 12)
            return false
        }
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    func search()
    {
        
    }
    
    //MARK: Dropdown
    @IBAction func CategoryClearAction(_ sender: Any) {
        dropdownClose()
        
    }
    func dropdownClose()   {
        
        txtSearch.isEnabled = true
        
        categoryId = categoryId2
        if categorytxt2 == "Category - All" || categorytxt2 == "All"
        {
            btnCategory.setTitle("Category - All", for: .normal)
            
            btnCategory.setTitleColor(ColorChanger().color(from: "C7C7CD"), for: .normal)
        }
        else
        {
            btnCategory.setTitleColor(txtSearch.textColor, for: .normal)
        }
        btnCategory.setTitle(categorytxt2, for: .normal)
        print(categorytxt2)
        
        self.view.endEditing(true)
        dropDowncategory?.isHidden = true
        viewToolBar.isHidden = true
    }
    @IBAction func CategorySearchAction(_ sender: Any) {
        
        paginationCount = 0
        
        self.flagTableReloading=1
        
        getHomeList(strCateId: categoryId, productName: txtSearch.text!, PaginationCountBegin: paginationCount, PaginationCountEnd: 12)
    }
    @IBAction func categoryAction(_ sender: Any) {
        
        
        self.txtSearch.isEnabled = false
        
        categoryId2 = categoryId
        categorytxt2 = btnCategory.titleLabel?.text
        dropDowncategory?.layer.borderColor = UIColor.lightGray.cgColor
        dropDowncategory?.backgroundColor = UIColor.lightGray
        dropDowncategory?.layer.borderWidth = 1
        dropDowncategory?.isHidden = false
        viewToolBar.isHidden = false
        
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        return categoryList.count
    }
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 40
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        self.view.endEditing(true)
        return categoryList[row]["Name"] as! String
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.btnCategory.setTitle(categoryList[row]["Name"] as! String, for: .normal)
        categoryId = categoryList[row]["Id"] as! String
        btnCategory.setTitleColor(txtSearch.textColor, for: .normal)
        
        
        if categoryList[row]["Name"] as! String == "All"
        {
            
            self.btnCategory.setTitle( "Category - All", for: .normal)
            
            
            btnCategory.setTitleColor(ColorChanger().color(from: "C7C7CD"), for: .normal)
        }
        
        
        
    }
    //MARK: Socket Connection
    @objc func updateSocket() {
        print("-----------chat------------")
        let nc = NotificationCenter.default
        nc.removeObserver("updateSocketHomeProduct")
        if Connectivity.isConnectedToInternet
        {
            if UserDefaults.standard.string(forKey: "lastUpdated") == "yes"
            {
                UserDefaults.standard.set("nooo", forKey: "lastUpdated")
                
                let dict = ["senderUserId": String(format: "%@", userId),"status":"ping"]
                print(dict)
                if let jsonString = JSONStringEncoder().encode(dict) {
                    socket.write(string: jsonString)
                }
            }
        }
    }
    //Check internet Connection
    struct Connectivity
    {
        static let sharedInstance = NetworkReachabilityManager()!
        static var isConnectedToInternet:Bool {
            return self.sharedInstance.isReachable
        }
    }
    func removeSocket(_ s: WebSocket?) {
        socketArray = socketArray.filter{$0 != s}
    }
    func socketCoennection() {
        if Connectivity.isConnectedToInternet {
            //config socketConnection
            let SocketURL = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverSocketDomain")!, DefineClass.SocketUrl)
            socket = WebSocket(url: URL(string: SocketURL)!, protocols: ["wss"])
            socket.delegate = self
            socketArray.append(socket)
            socket.onText = { [weak self]  (text: String) in
                if let c = Int(text) {
                    print("number of cases is: \(c)")
                    self?.caseCount = c
                }
            }
            socket.onDisconnect = { [weak self, weak socket]  (error: Error?) in
                self?.getTestInfo(1)
                self?.removeSocket(socket)
            }
            socket.disableSSLCertValidation = false
            socket.connect()
        }
        else
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Unable to get access to the Chat Server. Please check your internet connection!!!")
            timer = Timer.scheduledTimer(timeInterval: 5,
                                         target: self,
                                         selector: #selector(self.networkCheck),
                                         userInfo: nil,
                                         repeats: true)
            
        }
    }
    @objc func networkCheck() {
        if Connectivity.isConnectedToInternet {
            DispatchQueue.main.async {
                self.timer.invalidate()
                if let savedValue = UserDefaults.standard.string(forKey: "loginStatus"){
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    let rootVC:ProductViewController = storyboard.instantiateViewController(withIdentifier: "product") as! ProductViewController
                    let nvc:UINavigationController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController") as! UINavigationController
                    nvc.viewControllers = [rootVC]
                    let appDelegate = UIApplication.shared.delegate as! AppDelegate
                    appDelegate.window?.rootViewController = nvc
                    
                }
                
            }
        }
    }
    func getTestInfo(_ caseNum: Int) {
        let s = createSocket("getCaseInfo",caseNum)
        socketArray.append(s)
        s.onText = { (text: String) in
        }
        var once = false
        s.onDisconnect = { [weak self, weak s]  (error: Error?) in
            if !once {
                once = true
                self?.runTest(caseNum)
            }
            self?.removeSocket(s)
        }
        s.connect()
    }
    
    func runTest(_ caseNum: Int) {
        let s = createSocket("runCase",caseNum)
        self.socketArray.append(s)
        s.onText = { [weak s]  (text: String) in
            s?.write(string: text)
        }
        s.onData = { [weak s]  (data: Data) in
            s?.write(data: data)
        }
        var once = false
        s.onDisconnect = {[weak self, weak s] (error: Error?) in
            if !once {
                once = true
                //self?.verifyTest(caseNum) //disabled since it slows down the tests
                let nextCase = caseNum+1
                if nextCase <= (self?.caseCount)! {
                    self?.runTest(nextCase)
                    //self?.getTestInfo(nextCase) //disabled since it slows down the tests
                } else {
                    self?.finishReports()
                }
                self?.removeSocket(s)
            }
        }
        s.connect()
    }
    
    func verifyTest(_ caseNum: Int) {
        let s = createSocket("getCaseStatus",caseNum)
        self.socketArray.append(s)
        s.onText = { (text: String) in
            let data = text.data(using: String.Encoding.utf8)
            do {
                let resp: Any? = try JSONSerialization.jsonObject(with: data!,
                                                                  options: JSONSerialization.ReadingOptions())
                if let dict = resp as? Dictionary<String,String> {
                    if let status = dict["behavior"] {
                        if status == "OK" {
                            return
                        }
                    }
                }
            } catch {
            }
        }
        var once = false
        s.onDisconnect = { [weak self, weak s]  (error: Error?) in
            if !once {
                once = true
                let nextCase = caseNum+1
                print("next test is: \(nextCase)")
                if nextCase <= (self?.caseCount)! {
                    self?.getTestInfo(nextCase)
                } else {
                    self?.finishReports()
                }
            }
            self?.removeSocket(s)
        }
        s.connect()
    }
    
    func finishReports() {
        let s = createSocket("updateReports",0)
        self.socketArray.append(s)
        s.onDisconnect = { [weak self, weak s]  (error: Error?) in
            self?.removeSocket(s)
        }
        s.connect()
    }
    
    func createSocket(_ cmd: String, _ caseNum: Int) -> WebSocket {
        let SocketURL = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverSocketDomain")!, DefineClass.SocketUrl)
        return WebSocket(url: URL(string: "\(SocketURL)\(buildPath(cmd,caseNum))")!, protocols: [])
    }
    
    func buildPath(_ cmd: String, _ caseNum: Int) -> String {
        return "/\(cmd)?case=\(caseNum)&agent=Starscream"
    }
    func websocketDidConnect(socket: WebSocketClient) {
        if let savedValue = UserDefaults.standard.string(forKey: "loginStatus"){
            print("websocket is connected")
            let dict = ["message": String(format: "%@", userId),"status":"connect"]
            if let jsonString = JSONStringEncoder().encode(dict) {
                print(jsonString)
                socket.write(string: jsonString)
            }
        }
    }
    func websocketDidDisconnect(socket: WebSocketClient, error: Error?) {
        if let e = error as? WSError {
            print("--------------------->websocket is disconnected: \(e.message)")
        } else if let e = error {
            print("--------------------->websocket is disconnected: \(e.localizedDescription)")
        } else {
            print("--------------------->websocket disconnected")
        }
        socketCoennection()
    }
    func websocketDidReceiveMessage(socket: WebSocketClient, text: String) {
        print(text)
        let data1 = text.data(using: String.Encoding.utf8)
        do {
            let resp: AnyObject? = try JSONSerialization.jsonObject(with: data1!,
                                                                    options: JSONSerialization.ReadingOptions()) as AnyObject
            
            if let dict = resp as? Dictionary<String,Any> {
                
                if let receverDict = dict["productDTO"] as? Dictionary<String,Any>{
                    
                    let requstedID = receverDict["id"] as? String
                    let productContain = self.productList.filter({$0["id"] as! String == requstedID}).first
                    if (productContain != nil)
                    {
                        
                        if segmntCntlr.selectedSegmentIndex == 1
                        {
                            self.flagToTop = 1
                            getRecentList()
                        }
                        else
                        {
                            self.flagToTop = 1
                            self.getHomeList(strCateId: categoryId, productName: txtSearch.text!, PaginationCountBegin: paginationCount, PaginationCountEnd: 12)
                        }
                    }
                    else
                    {
                    }
                    
                }
                
                if let receverDict = dict["productAttributeDTO"] as? Dictionary<String,Any>{
                    
                    let requstedID = receverDict["productId"] as? String
                    let productContain = self.productList.filter({$0["id"] as! String == requstedID}).first
                    if (productContain != nil)
                    {
                        
                        if segmntCntlr.selectedSegmentIndex == 1
                        {
                            self.flagToTop = 1
                            getRecentList()
                        }
                        else
                        {
                            self.flagToTop = 1
                            self.getHomeList(strCateId: categoryId, productName: txtSearch.text!, PaginationCountBegin: paginationCount, PaginationCountEnd: 12)
                        }
                    }
                    else
                    {
                    }
                    
                }
                    
                else  if dict["status"] as! String == "DeletedOwner"    {
                    if let receverDict = dict["user"] as? Dictionary<String,Any>{
                        if  receverDict["id"] as? String == userId
                        {
                            self.deleteByAdmin()
                        }
                    }
                }
                else  if dict["status"] as! String == "DeletedUserByadmin"    {
                    if let receverDict = dict["user"] as? Dictionary<String,Any>{
                        if  receverDict["id"] as? String == userId
                        {
                            self.deleteByAdmin()
                        }
                        
                    }                    }
                    
                else  if dict["status"] as! String == "newCategory"    {
                    if let categoryDTO = dict["categoryDTO"] as? Dictionary<String,Any>{
                        let categoryDict = ["Name":categoryDTO["category"],"Id":categoryDTO["id"]]
                        self.categoryList.append(categoryDict as! [String : String])
                        self.dropDowncategory?.reloadAllComponents()
                    }
                }
                else  if dict["status"] as! String == "deleteCategory"    {
                    if let categoryDTO = dict["categoryDTO"] as? Dictionary<String,Any>{
                        let categoryIdToChange = categoryDTO["id"] as! String
                        print(self.categoryList)
                        let categoryIndex = self.categoryList.filter({$0["Id"] == categoryIdToChange}).first
                        let ind = self.categoryList.lastIndex(of: categoryIndex!)
                        self.categoryList.remove(at: ind!)
                        self.dropDowncategory?.reloadAllComponents()
                        if self.categoryId == categoryIdToChange{
                            
                            self.btnCategory.setTitle( "Category - All", for: .normal)
                            self.categoryId = ""
                            self.categoryId2 = ""
                            self.categorytxt2 = "Category - All"
                            btnCategory.setTitleColor(ColorChanger().color(from: "C7C7CD"), for: .normal)
                            self.getHomeList(strCateId: categoryId, productName: txtSearch.text!, PaginationCountBegin: paginationCount, PaginationCountEnd: 12)
                        }
                        
                    }
                }
                else  if dict["status"] as! String == "updatedCategory"    {
                    if let categoryDTO = dict["categoryDTO"] as? Dictionary<String,Any>{
                        let categoryIdToChange = categoryDTO["id"] as! String
                        print(self.categoryList)
                        let categoryIndex = self.categoryList.filter({$0["Id"] == categoryIdToChange}).first
                        let ind = self.categoryList.lastIndex(of: categoryIndex!)
                        
                        let categoryDict = ["Name":categoryDTO["category"],"Id":categoryDTO["id"]]
                        
                        if self.categoryId == categoryIdToChange{
                            
                            self.btnCategory.setTitle( categoryDTO["category"] as! String, for: .normal)
                            self.getHomeList(strCateId: categoryId, productName: txtSearch.text!, PaginationCountBegin: paginationCount, PaginationCountEnd: 12)
                        }
                        if btnCategory.titleLabel?.text == "Category - All"
                        {
                            self.getHomeList(strCateId: categoryId, productName: txtSearch.text!, PaginationCountBegin: paginationCount, PaginationCountEnd: 12)
                        }
                        
                        
                        self.categoryList[ind!] = categoryDict as! [String : String]
                        self.dropDowncategory?.reloadAllComponents()
                    }
                }
                
            }
            
        } catch {
        }
        
    }
    @IBAction func deleteByAdmin() {
        //  timer.invalidate()
        socket.disconnect()
        //delete all values in database
        let realm = try! Realm()
        try! realm.write {
            realm.deleteAll()
        }
        
        //remove values from UserDefaults
        UserDefaults.standard.removeObject(forKey: "accessToken")
        UserDefaults.standard.removeObject(forKey: "tokenType")
        UserDefaults.standard.removeObject(forKey: "userId")
        UserDefaults.standard.removeObject(forKey: "loginStatus")
        
        UserDefaults.standard.removeObject(forKey: "defualtImage")
        UserDefaults.standard.removeObject(forKey: "email")
        UserDefaults.standard.removeObject(forKey: "profileUrl")
        UserDefaults.standard.removeObject(forKey: "lastName")
        UserDefaults.standard.removeObject(forKey: "firstName")
        UserDefaults.standard.removeObject(forKey: "gender")
        UserDefaults.standard.removeObject(forKey: "attachmentid")
        UserDefaults.standard.removeObject(forKey: "userName")
        
        //navigate to login screen
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "loginScreen") as! ViewController
        vc.sessionOutFlag = 5
        self.navigationController?.pushViewController(vc,
                                                      animated: false)
    }
    func websocketDidReceiveData(socket: WebSocketClient, data: Data) {
    }
    struct JSONStringEncoder {
        func encode(_ dictionary: [String: Any]) -> String? {
            guard JSONSerialization.isValidJSONObject(dictionary) else {
                assertionFailure("Invalid json object received.")
                return nil
            }
            let jsonObject: NSMutableDictionary = NSMutableDictionary()
            let jsonData: Data
            dictionary.forEach { (arg) in
                jsonObject.setValue(arg.value, forKey: arg.key)
            }
            do {
                jsonData = try JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted)
            } catch {
                assertionFailure("JSON data creation failed with error: \(error).")
                return nil
            }
            guard let jsonString = String.init(data: jsonData, encoding: String.Encoding.utf8) else {
                assertionFailure("JSON string creation failed.")
                return nil
            }
            return jsonString
        }
    }
    
    
    
    
    //MARK:- App Version Check
    func appversionCheck()
    {
        let defaults = UserDefaults.standard
        
        let currentBuild = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as! String
        let currentVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String
        let currentAppVersion = String(format: "%@.%@", currentVersion,currentBuild)
        print("App cureent version -------- >%@",currentAppVersion)
        
        
        
        let previousVersion = defaults.string(forKey: "appVersion")
        if previousVersion == nil {
            // first launch
            defaults.set(currentAppVersion, forKey: "appVersion")
            defaults.synchronize()
        } else if previousVersion == currentAppVersion {
            // same version
        } else {
            // other version
            defaults.set(currentAppVersion, forKey: "appVersion")
            defaults.synchronize()
            
            
            
            //delete all values in database
            let realm = try! Realm()
            try! realm.write {
                realm.deleteAll()
            }
            
            //remove values from UserDefaults
            
            //navigate to login screen
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "loginScreen") as! ViewController
            vc.sessionOutFlag = 2
            self.navigationController?.pushViewController(vc,
                                                          animated: true)
            
        }
    }
}
extension UIView{
    func constraintWith(identifier: String) -> NSLayoutConstraint?{
        return self.constraints.first(where: {$0.identifier == identifier})
    }
}
