//
//  ProfileViewController.swift
//  Profield Chat
//
//  Created by Apple on 10/01/19.
//  Copyright © 2019 indocosmo. All rights reserved.
//

import UIKit
import SDWebImage
class ProfileViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    @IBOutlet weak var imgDp: UIImageView!
    @IBOutlet weak var titleImage: UIImageView!
    @IBOutlet weak var btnDp: UIButton!
    @IBOutlet weak var btnmale: UIButton!
    @IBOutlet weak var lblFirstName: UILabel!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var btnFeMale: UIButton!
    @IBOutlet weak var txtlastName: UITextField!
    @IBOutlet weak var txtFirstname: UITextField!
    var defualtImage :String!
    var chosenImage = UIImage()
    let picker = UIImagePickerController()
    var imageFlag = 0
    var flagGender = 0
    var flagGenderChanged = 0
    var imageTypeFlag = ""
    //MARK:- viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        ScreenSetup()
    }
    @IBAction func MaleAction(_ sender: Any) {
        btnFeMale.setImage(UIImage(named: "radio"), for: .normal)
        btnmale.setImage(UIImage(named: "radio_selected"), for: .normal)
        flagGender = 1
        if defualtImage != "0"
        {
            chosenImage = UIImage(named: "boy.png")!
            flagGenderChanged = 1
            imageTypeFlag = "1"
            imgDp.image = UIImage(named: "boy.png")
        }
    }
    @IBAction func FemaleAction(_ sender: Any) {
        btnmale.setImage(UIImage(named: "radio"), for: .normal)
        btnFeMale.setImage(UIImage(named: "radio_selected"), for: .normal)
        flagGender = 2
        if defualtImage != "0"
        {
            flagGenderChanged = 1
            imageTypeFlag = "2"
            chosenImage = UIImage(named: "girl.png")!
            imgDp.image = UIImage(named: "girl.png")
        }
    }
    func ScreenSetup()
    {
        defualtImage = UserDefaults.standard.value(forKey: "defualtImage") as! String
        //profileImage
        imgDp.layer.cornerRadius = 50
        btnDp.layer.cornerRadius = 50
        titleImage.layer.cornerRadius = titleImage.frame.size.width/2
        let strGender = UserDefaults.standard.value(forKey: "gender") as! String
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        SDWebImageDownloader.shared.setValue(headerrr, forHTTPHeaderField:"Authorization")
        let attachment_id = UserDefaults.standard.value(forKey: "attachmentid")
        let ApiURL = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
        let imgUrl = String(format: "%@/api/attachmentasbody/%@", ApiURL,attachment_id! as! CVarArg)
        titleImage.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
        if defualtImage == "0"
        {
            imgDp.sd_imageIndicator = SDWebImageActivityIndicator.gray
            imgDp.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
            titleImage.sd_imageIndicator = SDWebImageActivityIndicator.gray
            titleImage.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
        }
        else
        {
            if strGender == "male"
            {
                imgDp.image = UIImage(named: "boy.png")
            }
            else
            {
                imgDp.image = UIImage(named: "girl.png")
            }
        }
        //Display User details
        txtFirstname.text = UserDefaults.standard.value(forKey: "firstName") as! String
        txtlastName.text = UserDefaults.standard.value(forKey: "lastName") as! String
        txtUserName.text = UserDefaults.standard.value(forKey: "userName") as! String
        txtEmail.text = UserDefaults.standard.value(forKey: "email") as! String
        if strGender == "male"
        {flagGender = 1
            btnmale.setImage(UIImage(named: "radio_selected"), for: .normal)
        }
        else
        {
            btnFeMale.setImage(UIImage(named: "radio_selected"), for: .normal)
            flagGender = 2
        }
        //textfield bottom line
        txtUserName.setBottomBorder()
        txtFirstname.setBottomBorder()
        txtlastName.setBottomBorder()
        txtEmail.setBottomBorder()
        if let placeholder = txtFirstname.placeholder {
            txtFirstname.attributedPlaceholder = NSAttributedString(string:placeholder,
                                                                    attributes: [NSAttributedStringKey.foregroundColor: lblFirstName.textColor])
        }
        if let placeholder = txtlastName.placeholder {
            txtlastName.attributedPlaceholder = NSAttributedString(string:placeholder,
                                                                   attributes: [NSAttributedStringKey.foregroundColor: lblFirstName.textColor])
        }
        if let placeholder = txtUserName.placeholder {
            txtUserName.attributedPlaceholder = NSAttributedString(string:placeholder,
                                                                   attributes: [NSAttributedStringKey.foregroundColor: lblFirstName.textColor])
        }
        
        if let placeholder = txtEmail.placeholder {
            txtEmail.attributedPlaceholder = NSAttributedString(string:placeholder,
                                                                attributes: [NSAttributedStringKey.foregroundColor: lblFirstName.textColor])
        }
    }
    @IBAction func backAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func updateProfileApi(_ sender: Any){
        //profile update api
        if txtFirstname.text == ""{
            AppHelper.showAlertMessage(vc:self, title: "", message: "Please enter a first name")
        }
        else
        {
            let  userId = UserDefaults.standard.value(forKey: "userId") as! String
            var gender = ""
            if flagGender==1
            {
                gender = "male"
            }
            else
            {
                gender = "female"
            }
            let exampleDict: [String: Any] = [
                "userid":userId,
                "lastName" :txtlastName.text,
                "firstName" : txtFirstname.text,
                "gender":gender
            ]
            if let jsonString = JSONStringEncoder().encode(exampleDict) {
                AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
                let accessToken = UserDefaults.standard.value(forKey: "accessToken")
                let tokenType = UserDefaults.standard.value(forKey: "tokenType")
                let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
                let HeaderPar = ["Authorization": headerrr]
                let str = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.updateProfile)
                let par = ["threadPid": jsonString]
                APiClass.apiCallPostValueWithHeader(mainUrl: str, postParameters: par,headerParams:HeaderPar) { (responseArray) in
                    let responseDict = responseArray[0]
                    if (responseDict.object(forKey: "error") != nil)
                    {
                        AppHelper.HidePrograss(vc: self.view)
                        let message = responseDict["error"]
                        AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
                    }
                    else
                    {
                        let arrayAllProject = responseDict["value"] as! NSArray
                        let dict = arrayAllProject[0] as! [String : Any]
                        let message = dict["status"] as! String
                        if message == "success"
                        {
                            AppHelper.HidePrograss(vc: self.view)
                            UserDefaults.standard.set(self.txtlastName.text, forKey: "lastName")
                            UserDefaults.standard.set(self.txtFirstname.text, forKey: "firstName")
                            UserDefaults.standard.set(gender, forKey: "gender")
                            if self.flagGenderChanged == 1
                            {
                                self.uploadProfileImage()
                            }
                            else
                            {
                                AppHelper.showAlertMessage(vc: self, title: "", message: "Profile saved.")
                            }
                            
                        }
                        else
                        {
                            AppHelper.HidePrograss(vc: self.view)
                            AppHelper.showAlertMessage(vc: self, title: "Sorry", message: "Something went wrong")
                        }
                    }
                }
            }
            else
            {
                AppHelper.showAlertMessage(vc: self, title: "Sorry", message: "Something went wrong")
            }
        }
    }
    
    func getProfileDetail(){
        //load profile details from server
        //load profile details
        let  userId = UserDefaults.standard.value(forKey: "userId") as! String
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let par = ["Authorization": headerrr]
        let str = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.loadUserDetails)
        let url = String(format: "%@?userId=%@", str,userId)
        APiClass.apiCallGetWithHeader(mainUrl: url, postParameters: par) { (responseArray) in
            let responseDict = responseArray[0]
            if (responseDict.object(forKey: "error") != nil)
            {
                
            }
            else
            {
                //save details to userDefault
                let arrayAllResponse = responseDict["value"] as! [[String:Any]]
                let arrayResponse = arrayAllResponse[0]["user"] as! [String:Any]
                let dftImg = String(format: "%d", arrayResponse["defualtImage"] as! Int)
                UserDefaults.standard.set(dftImg, forKey: "defualtImage")
                UserDefaults.standard.set(arrayResponse["userName"], forKey: "userName")
                UserDefaults.standard.set(arrayResponse["email"], forKey: "email")
                UserDefaults.standard.set(arrayResponse["profileUrl"], forKey: "profileUrl")
                UserDefaults.standard.set(arrayResponse["lastName"], forKey: "lastName")
                UserDefaults.standard.set(arrayResponse["firstName"], forKey: "firstName")
                UserDefaults.standard.set(arrayResponse["gender"], forKey: "gender")
                UserDefaults.standard.set(arrayResponse["attachmentId"], forKey: "attachmentid")
                let apiUrl = String(format: "%@",UserDefaults.standard.string(   forKey: "serverDomain")!)
                let attachment_id = String(format:"%@", arrayResponse["attachmentId"] as! String)
                let imgUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id)
                self.imgDp.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                self.titleImage.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
            }
        }
    }
    //MARK:- Image Uploading
    @IBAction func chooseAction(_ sender: Any)
    {
        //alertview config
        let actionSheet=UIAlertController(title:nil, message: nil, preferredStyle:UIAlertControllerStyle.alert )
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: {
            _ in
        }))
        actionSheet.addAction(UIAlertAction(title: "Take photo", style: UIAlertActionStyle.default, handler: {
            _ in
            self.ImageFromCamera()
        }))
        actionSheet.addAction(UIAlertAction(title: "Choose photo", style: UIAlertActionStyle.default, handler: {
            _ in
            self.ImageFromGallary()
        }))
        actionSheet.popoverPresentationController?.sourceView = self.view
        actionSheet.popoverPresentationController?.permittedArrowDirections = UIPopoverArrowDirection()
        actionSheet.popoverPresentationController?.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
        present(actionSheet, animated: true, completion: nil)
    }
    func ImageFromCamera() -> Void
    {
        picker.prefersStatusBarHidden
        picker.allowsEditing = true
        picker.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
        picker.sourceType = UIImagePickerControllerSourceType.camera
        present(picker, animated: true, completion: nil)
    }
    func ImageFromGallary() -> Void
    {
        picker.prefersStatusBarHidden
        picker.allowsEditing = false
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary))
        {
            picker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        }
        else
        {
            picker.sourceType = UIImagePickerControllerSourceType.savedPhotosAlbum
        }
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera))
        {
            picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: UIImagePickerControllerSourceType.camera)!
        }
        picker.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
        picker.navigationBar.isTranslucent = true
        picker.navigationBar.barTintColor = .black
        picker.navigationBar.tintColor = .white
        picker.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
        present(picker, animated: true, completion: nil)
    }
    public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        if let mediaType = info[UIImagePickerControllerMediaType] as? String {
            if mediaType  == "public.image" {
                if let img = info[UIImagePickerControllerEditedImage] as? UIImage
                {
                    chosenImage = fixOrientation(img: img)
                }
                else if let img = info[UIImagePickerControllerOriginalImage] as? UIImage
                {
                    chosenImage = fixOrientation(img: img)
                }
                self.imageFlag = 1
            }
        }
        dismiss(animated:true, completion: nil)
        if imageFlag == 1
        {
            let alert = UIAlertController(title: "Alert", message: "Are you sure you want to change profile image.?", preferredStyle: .alert)
            let yesButton = UIAlertAction(title: "Yes", style: .default, handler: {(_ action: UIAlertAction) -> Void in
                self.imgDp.image = self.chosenImage
                //upload to server
                self.flagGenderChanged = 0
                
                self.imageTypeFlag = "3"
                self.uploadProfileImage()
            })
            let noButton = UIAlertAction(title: "No", style: .default, handler: {(_ action: UIAlertAction) -> Void in
            })
            alert.addAction(yesButton)
            alert.addAction(noButton)
            present(alert, animated: true)
        }
    }
    func fixOrientation(img: UIImage) -> UIImage {
        //change image orintation
        if (img.imageOrientation == .up) {
            return img
        }
        UIGraphicsBeginImageContextWithOptions(img.size, false, img.scale)
        let rect = CGRect(x: 0, y: 0, width: img.size.width, height: img.size.height)
        img.draw(in: rect)
        let normalizedImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return normalizedImage
    }
    func uploadProfileImage()
    {
        //upload profile image api
        AppHelper.showPrograss(vc: self.view, title: "", message: "")
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy HH:mm:ss"
        let date = Date()
        let dateString = formatter.string(from: date)
        print(dateString)
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let HeaderPar = ["Authorization": headerrr]
        let uploadParameterName = "file"
        let fileName = "file.jpg"
        let mimetype = "image/jpg"
        let  userId = UserDefaults.standard.value(forKey: "userId") as! String
        let param = ["userId":userId,"imageTypeFlag":imageTypeFlag]
        let  imageData = UIImageJPEGRepresentation(chosenImage, 0.5)!
        let str = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.updateProfileImage)
        APiClass.ApiCallImageUploadWithHeade(mainUrl: str,HeaderParameters:HeaderPar, postParameters: param , mimeType: mimetype, uploadParameterName: uploadParameterName, fileName: fileName, uploadFileData: imageData)
        {
            (responseArray) in
            AppHelper.HidePrograss(vc: self.view)
            let responseDict = responseArray[0]
            if (responseDict.object(forKey: "error") != nil)
            {
                let message = responseDict["error"]
                AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
            }
            else
            {
                if self.flagGenderChanged != 1
                    
                {
                    self.defualtImage = "0"
                }
                self.getProfileDetail()
                AppHelper.showAlertMessage(vc: self, title: "", message: "Profile saved.")
                AppHelper.HidePrograss(vc: self.view)
            }
        }
    }
    struct JSONStringEncoder {
        func encode(_ dictionary: [String: Any]) -> String? {
            guard JSONSerialization.isValidJSONObject(dictionary) else {
                assertionFailure("Invalid json object received.")
                return nil
            }
            let jsonObject: NSMutableDictionary = NSMutableDictionary()
            let jsonData: Data
            dictionary.forEach { (arg) in
                jsonObject.setValue(arg.value, forKey: arg.key)
            }
            do {
                jsonData = try JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted)
                
            } catch {
                assertionFailure("JSON data creation failed with error: \(error).")
                return nil
            }
            guard let jsonString = String.init(data: jsonData, encoding: String.Encoding.utf8) else {
                assertionFailure("JSON string creation failed.")
                return nil
            }
            print("JSON string: \(jsonString)")
            return jsonString
        }
    }
}
