//
//  WebviewViewController.swift
//  Profield Chat
//
//  Created by Apple on 25/03/19.
//  Copyright © 2019 indocosmo. All rights reserved.
//

import UIKit
import SDWebImage
import Alamofire
import WebKit

class WebviewViewController: UIViewController,WKNavigationDelegate, WKUIDelegate {
    @IBOutlet weak var webKit: WKWebView!
    var documentsURL : URL!
    var webUrl : String!
    var ActualFileName : String!
    //MARK:- viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        SDWebImageDownloader.shared.setValue(headerrr, forHTTPHeaderField:"Authorization")
        //load file url to webview
        let str = URL(string: webUrl)
        let request = NSMutableURLRequest(url:  str!)
        request.setValue(headerrr, forHTTPHeaderField:"Authorization")
        //   web.loadRequest(request as URLRequest)
        webKit.navigationDelegate = self
        webKit.load(request as URLRequest)
        AppHelper.showPrograss(vc: self.view, title: "", message: "")
    }
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func shareAction(_ sender: Any) {
        AppHelper.showPrograss(vc: self.view, title: "downloading...", message: "")
        let destination = DownloadRequest.suggestedDownloadDestination(for: .documentDirectory)
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let header = ["Authorization": headerrr]
        Alamofire.download(
            webUrl,
            method: .get,
            parameters: nil,
            encoding: JSONEncoding.default,
            headers: header,
            to: destination).downloadProgress(closure: { (progress) in
                print("download Progress: \(progress.fractionCompleted)")
            }).response(completionHandler: { (DefaultDownloadResponse) in
                AppHelper.HidePrograss(vc: self.view)
                let strrr = DefaultDownloadResponse.error
                if (strrr != nil)
                {
                    
                    AppHelper.showAlertMessage(vc: self, title: "", message: (strrr?.localizedDescription)! )
                }
                else
                {
                    self.shareVideo(from: DefaultDownloadResponse.destinationURL!)
                }
            })
    }
    func shareVideo(from url: URL) {
        
        let filemanager = FileManager.default
        let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory,.userDomainMask,true)[0] as NSString
        let destinationPath = documentsPath.appendingPathComponent(ActualFileName)
        do {
            try filemanager.removeItem(atPath: destinationPath)
            print("Local path removed successfully")
        } catch let error as NSError {
            print("------Error",error.debugDescription)
        }
        let str = String(describing: url.absoluteURL)
        let orginalFileNameArray = str.components(separatedBy: "/")
        let orginalFileName =  orginalFileNameArray.last
        do {
            let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
            let documentDirectory = URL(fileURLWithPath: path)
            let originPath = documentDirectory.appendingPathComponent(orginalFileName!)
            let destinationPath = documentDirectory.appendingPathComponent(ActualFileName)
            try FileManager.default.moveItem(at: url.absoluteURL, to: destinationPath.absoluteURL)
            let activityViewController = UIActivityViewController(activityItems: [destinationPath], applicationActivities: nil)
            present(activityViewController, animated: true, completion: nil)
        } catch {
            print(error)
        }
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        AppHelper.HidePrograss(vc: self.view)
    }
    
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        AppHelper.HidePrograss(vc: self.view)
    }
}
