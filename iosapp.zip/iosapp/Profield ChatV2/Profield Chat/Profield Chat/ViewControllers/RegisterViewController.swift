//
//  RegisterViewController.swift
//  Profield Chat
//
//  Created by Apple on 22/11/18.
//  Copyright © 2018 indocosmo. All rights reserved.
//

import UIKit
import Alamofire
class RegisterViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate {
    @IBOutlet weak var btnmale: UIButton!
    @IBOutlet weak var txtConfirmpassword: UITextField!
    @IBOutlet weak var lblFirstName: UILabel!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var btnFeMale: UIButton!
    @IBOutlet weak var txtlastName: UITextField!
    @IBOutlet weak var txtFirstname: UITextField!
    @IBOutlet weak var imgDp: UIImageView!
    @IBOutlet weak var btnDp: UIButton!
    @IBOutlet weak var viewBgDeactive: UIView!
    @IBOutlet weak var viewDeactive: UIView!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblOTPDec: UILabel!
    @IBOutlet weak var viewConfirm: UIView!
    @IBOutlet weak var txtOtp: UITextField!
    var chosenImage = UIImage()
    let picker = UIImagePickerController()
    var imageFlag = 0
    var flagGender = 0
    var flagImageType = 0
    let ACCEPTABLE_CHARACTERS = "<>"
    let RISTRICTED_CHARACTERS = "'*=+[]\\|;:'\",<>/?%"
    //MARK:- ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        //config Screen
        screenSetUp()
    }
    func screenSetUp()
    {
        txtOtp.placeholder = "Enter OTP here"
        txtUserName.setBottomBorder()
        txtFirstname.setBottomBorder()
        txtlastName.setBottomBorder()
        txtPassword.setBottomBorder()
        txtConfirmpassword.setBottomBorder()
        txtEmail.setBottomBorder()
        txtOtp.setBottomBorder()
        imgDp.layer.cornerRadius = 50
        btnDp.layer.cornerRadius = 50
        viewConfirm.layer.cornerRadius = 10
        viewDeactive.layer.cornerRadius = 10
        viewBgDeactive.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        txtUserName.delegate = self
        
        //textfield placeholder color
        if let placeholder = txtFirstname.placeholder {
            txtFirstname.attributedPlaceholder = NSAttributedString(string:placeholder,
                                                                    attributes: [NSAttributedStringKey.foregroundColor: lblFirstName.textColor])
        }
        if let placeholder = txtOtp.placeholder {
            txtOtp.attributedPlaceholder = NSAttributedString(string:placeholder,
                                                              attributes: [NSAttributedStringKey.foregroundColor: lblFirstName.textColor])
        }
        if let placeholder = txtlastName.placeholder {
            txtlastName.attributedPlaceholder = NSAttributedString(string:placeholder,
                                                                   attributes: [NSAttributedStringKey.foregroundColor: lblFirstName.textColor])
        }
        
        
        if let placeholder = txtUserName.placeholder {
            txtUserName.attributedPlaceholder = NSAttributedString(string:placeholder,
                                                                   attributes: [NSAttributedStringKey.foregroundColor: lblFirstName.textColor])
        }
        
        if let placeholder = txtEmail.placeholder {
            txtEmail.attributedPlaceholder = NSAttributedString(string:placeholder,
                                                                attributes: [NSAttributedStringKey.foregroundColor: lblFirstName.textColor])
        }
        
        
        if let placeholder = txtPassword.placeholder {
            txtPassword.attributedPlaceholder = NSAttributedString(string:placeholder,
                                                                   attributes: [NSAttributedStringKey.foregroundColor: lblFirstName.textColor])
        }
        if let placeholder = txtConfirmpassword.placeholder {
            txtConfirmpassword.attributedPlaceholder = NSAttributedString(string:placeholder,
                                                                          attributes: [NSAttributedStringKey.foregroundColor: lblFirstName.textColor])
        }
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let characters = ["'","*","=","+","[","]","\"","|",";",":","'","\\","<",">","/","?","%","`","~","(",")"]
        for character in characters{
            if string == character{
                return false
            }
        }
        let maxLength = 20
        let currentString: NSString = textField.text! as NSString
        let newString: NSString =
            currentString.replacingCharacters(in: range, with: string) as NSString
        return newString.length <= maxLength
        
    }
    @IBAction func MaleAction(_ sender: Any) {
        btnFeMale.setImage(UIImage(named: "radio"), for: .normal)
        btnmale.setImage(UIImage(named: "radio_selected"), for: .normal)
        flagGender = 1
    }
    @IBAction func FemaleAction(_ sender: Any) {
        btnmale.setImage(UIImage(named: "radio"), for: .normal)
        btnFeMale.setImage(UIImage(named: "radio_selected"), for: .normal)
        flagGender = 2
    }
    @IBAction func deactivateNoAction(_ sender: Any) {
        viewBgDeactive.isHidden = true
    }
    @IBAction func deactivateYesAction(_ sender: Any) {
        txtOtp.text = ""
        lblOTPDec.text = String(format: "You might received an OTP into the email %@. Please provide the OTP for confirming the user reactivation", txtEmail.text!)
        self.reActivateAccountApi()
    }
    @IBAction func activateAccount(_ sender: Any) {
        self.view.endEditing(true)
        if txtOtp.text == ""
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Please enter OTP")
        }
        else if(txtOtp.text?.count)! > 10
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Please enter a valid OTP")
        }
        else
        {
            self.ActivateAccountApi()
        }
    }
    
    @IBAction func SubmitAction(_ sender: Any)
    {
        self.view.endEditing(true)
        let regex = try! NSRegularExpression(pattern: "<[^>]+>", options: NSRegularExpression.Options())
        if txtFirstname.text == ""
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Please enter first name.")
        }
        else if txtUserName.text == ""
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Please enter user name.")
        }
        else if ((txtUserName.text?.count)!) <= 1
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "User name minimum length is 2 characters.")
            
        }
        else if txtEmail.text == ""
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Please enter email.")
        }
        else if txtPassword.text == ""
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Please enter password.")
        }
        else if txtConfirmpassword.text == ""
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Please enter confirm password.")
        }
        else if flagGender == 0
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Please select your gender.")
        }
        else if txtConfirmpassword.text != txtPassword.text
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Password and confirmation password do not match.")
        }
        else if(txtConfirmpassword.text?.count)! < 6
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "minimum password length is 6 characters.")
        }
        else if !AppHelper.isValidEmail(testStr: txtEmail.text!)
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Please enter a valid email.")
        }
        else  if regex.firstMatch(in: txtFirstname.text!, options: NSRegularExpression.MatchingOptions(), range:NSMakeRange(0, txtFirstname.text!.characters.count)) != nil {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Please enter a valid first name.")
        }
            
        else  if regex.firstMatch(in: txtlastName.text!, options: NSRegularExpression.MatchingOptions(), range:NSMakeRange(0, txtlastName.text!.characters.count)) != nil {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Please enter a valid last name.")
        }
            
        else  if regex.firstMatch(in: txtUserName.text!, options: NSRegularExpression.MatchingOptions(), range:NSMakeRange(0, txtUserName.text!.characters.count)) != nil {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Please enter a valid user name.")
        }
        else
        {
            registerApi()
        }
    }
    //MARK:- API
    func registerApi(){
        AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
        var gender = ""
        flagImageType = 3
        if flagGender==1
        {
            if self.imageFlag != 1
            {
                flagImageType = 1
                self.imageFlag = 1
                chosenImage = UIImage(named: "boy.png")!
            }
            gender = "male"
        }
        else
        {
            gender = "female"
            if self.imageFlag != 1
            { self.imageFlag = 1
                flagImageType=2
                chosenImage = UIImage(named: "girl.png")!
                
            }
        }
        let par = ["firstName": txtFirstname.text!,"lastName": txtlastName.text!,"username":txtUserName.text!,"email":txtEmail.text!,"password":txtConfirmpassword.text!,"role":"USER","gender":gender]
        let apiUrl = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.Register)
        APiClass.apiCallREST(mainUrl: apiUrl, postParameters: par) { (responseArray) in
            let responseDict = responseArray[0]
            if (responseDict.object(forKey: "error") != nil)
            {
                AppHelper.HidePrograss(vc: self.view)
                var message = responseDict["error"]as! String
                if message  == "Bad Request"
                {
                    let dict = responseDict["errors"]as! [[String:Any]]
                    message = dict[0]["defaultMessage"] as! String
                    
                    if message == "must be a well-formed email address"
                    {
                        message = "Please enter a valid email."
                    }
                    else if message == "size must be between 3 and 50"
                    {
                        message = "First name minimum length is 3 characters."
                    }
                }
                AppHelper.showAlertMessage(vc: self, title: "", message: message )
            }
            else
            {
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["status"] as! String
                if message == "success"
                {
                    let actionSheetController: UIAlertController = UIAlertController(title: "You have been successfully registered", message: "", preferredStyle: .alert)
                    let cancelAction: UIAlertAction = UIAlertAction(title: "OK", style: .cancel) { action -> Void in
                        self.loginAPi()
                    }
                    actionSheetController.addAction(cancelAction)
                    self.present(actionSheetController, animated: true, completion: nil)
                    
                }
                else if message == "deregisteredUser"
                {
                    AppHelper.HidePrograss(vc: self.view)
                    self.lblUserName.text = String(format: ": %@", responseDict["userName"] as! String)
                    self.lblEmail.text = String(format: ": %@", responseDict["email"] as! String)
                    self.viewConfirm.isHidden = true
                    self.viewDeactive.isHidden = false
                    self.viewBgDeactive.isHidden = false
                }
                else
                {
                    AppHelper.HidePrograss(vc: self.view)
                    AppHelper.showAlertMessage(vc: self, title: "", message: message)
                }
            }
        }
    }
    func uploadProfileImage()
    {
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let HeaderPar = ["Authorization": headerrr]
        let uploadParameterName = "file"
        let fileName = "file.jpg"
        let mimetype = "image/jpg"
        let  userId = UserDefaults.standard.value(forKey: "userId") as! String
        let param = ["userId":userId,"imageTypeFlag":String(format: "%d", flagImageType)]
        let  imageData = UIImageJPEGRepresentation(chosenImage, 0.5)!
        let apiUrl = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.updateProfileImage)
        APiClass.ApiCallImageUploadWithHeade(mainUrl: apiUrl,HeaderParameters:HeaderPar, postParameters: param , mimeType: mimetype, uploadParameterName: uploadParameterName, fileName: fileName, uploadFileData: imageData)
        {
            (responseArray) in
            AppHelper.HidePrograss(vc: self.view)
            let responseDict = responseArray[0]
            if (responseDict.object(forKey: "error") != nil)
            {
                let message = responseDict["error"]
                AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
            }
            else
            {
                AppHelper.HidePrograss(vc: self.view)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "product") as! ProductViewController
                vc.flagLogin = "1"
                self.navigationController?.pushViewController(vc,
                                                              animated: true)
            }
        }
    }
    
    func loginAPi(){
        AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
        let par = ["username": txtUserName.text!,"password": txtPassword.text!]
        let apiUrl = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.LoginApi)
        APiClass.apiCallREST(mainUrl: apiUrl, postParameters: par) { (responseArray) in
            let responseDict = responseArray[0]
            if (responseDict.object(forKey: "error") != nil)
            {
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["error"]
                AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
            }
            else
            {
                AppHelper.HidePrograss(vc: self.view)
                let status = responseDict["status"] as! String
                if status == "Scucess"
                {
                    let  accessToken = responseDict["accessToken"] as! String
                    let  tokenType = responseDict["tokenType"] as! String
                    let  userIdd = responseDict["userId"] as! String
                    let  roleIdd = String(format: "%d", responseDict["role"] as! Int)
                    UserDefaults.standard.set(roleIdd, forKey: "roleIdd")
                    UserDefaults.standard.set(accessToken, forKey: "accessToken")
                    UserDefaults.standard.set(tokenType, forKey: "tokenType")
                    UserDefaults.standard.set(userIdd, forKey: "userId")
                    UserDefaults.standard.set("logind", forKey: "loginStatus")
                    
                    AppHelper.HidePrograss(vc: self.view)
                    if self.imageFlag == 1
                    {
                        self.uploadProfileImage()
                    }
                    else
                    {
                        //let vc = self.storyboard?.instantiateViewController(withIdentifier: "home") as! HomeViewController
                        let vc = self.storyboard?.instantiateViewController(withIdentifier: "product") as! ProductViewController
                        vc.flagLogin = "1"
                        self.navigationController?.pushViewController(vc,
                                                                      animated: true)
                    }
                }
            }
        }
    }
    func reActivateAccountApi(){
        AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
        let par = ["email":txtEmail.text!]
        let apiUrl = String(format: "%@%@?email=%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.activateAccount,txtEmail.text!)
        APiClass.apiCallREST(mainUrl: apiUrl, postParameters: par) { (responseArray) in
            let responseDict = responseArray[0]
            if (responseDict.object(forKey: "error") != nil)
            {
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["error"]
                AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
            }
            else
            {
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["status"] as! String
                if message == "tokenSend"
                {
                    self.viewDeactive.isHidden = true
                    self.viewConfirm.isHidden = false
                }
                else
                {
                    AppHelper.HidePrograss(vc: self.view)
                    AppHelper.showAlertMessage(vc: self, title: "", message: message)
                }
            }
        }
    }
    func ActivateAccountApi(){
        AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
        let par = ["email":txtEmail.text!]
        var gender = ""
        if flagGender==1
        {
            gender = "male"
        }
        else
        {
            gender = "female"
            
        }
        var apiUrl = String(format: "%@%@?email=%@&otp=%@&firstName=%@&lastName=%@&username=%@&password=%@&role=%@&gender=%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.OtpActivateAccount,txtEmail.text!,txtOtp.text!,txtFirstname.text!,txtlastName.text!,txtUserName.text!,txtConfirmpassword.text!,"USER",gender)
        apiUrl = apiUrl.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        APiClass.apiCallREST(mainUrl: apiUrl, postParameters: par) { (responseArray) in
            let responseDict = responseArray[0]
            if (responseDict.object(forKey: "error") != nil)
            {
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["error"]
                AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
            }
            else
            {
                AppHelper.HidePrograss(vc: self.view)
                var message = responseDict["status"] as! String
                if message == "success"
                {
                    
                    let actionSheetController: UIAlertController = UIAlertController(title: "Success!", message: "Account successfully restored.", preferredStyle: .alert)
                    let cancelAction: UIAlertAction = UIAlertAction(title: "OK", style: .cancel) { action -> Void in
                        self.loginAPi()
                    }
                    actionSheetController.addAction(cancelAction)
                    self.present(actionSheetController, animated: true, completion: nil)
                }
                else
                {
                    if message == "tokenExpired"
                    {
                        message = "Token expired ,Please retry"
                    }
                    else if message == "invalid-otp"
                    {
                        message = "Invalid OTP"
                    }
                    AppHelper.HidePrograss(vc: self.view)
                    AppHelper.showAlertMessage(vc: self, title: "", message: message)
                }
            }
        }
    }
    //MARK:- Image picker
    @IBAction func chooseAction(_ sender: Any)
    {
        let actionSheet=UIAlertController(title:nil, message: nil, preferredStyle:UIAlertControllerStyle.alert )
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: {
            _ in
        }))
        actionSheet.addAction(UIAlertAction(title: "Take photo", style: UIAlertActionStyle.default, handler: {
            _ in
            self.ImageFromCamera()
        }))
        actionSheet.addAction(UIAlertAction(title: "Choose photo", style: UIAlertActionStyle.default, handler: {
            _ in
            self.ImageFromGallary()
        }))
        actionSheet.popoverPresentationController?.sourceView = self.view
        actionSheet.popoverPresentationController?.permittedArrowDirections = UIPopoverArrowDirection()
        actionSheet.popoverPresentationController?.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
        present(actionSheet, animated: true, completion: nil)
    }
    func ImageFromCamera() -> Void
    {
        picker.prefersStatusBarHidden
        picker.allowsEditing = true
        picker.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
        picker.sourceType = UIImagePickerControllerSourceType.camera
        present(picker, animated: true, completion: nil)
    }
    
    func ImageFromGallary() -> Void
    {
        picker.prefersStatusBarHidden
        picker.allowsEditing = false
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary))
        {
            picker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        }
        else
        {
            picker.sourceType = UIImagePickerControllerSourceType.savedPhotosAlbum
        }
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera))
        {
            picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: UIImagePickerControllerSourceType.camera)!
        }
        picker.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
        picker.navigationBar.isTranslucent = true
        picker.navigationBar.barTintColor = .black
        picker.navigationBar.tintColor = .white
        picker.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
        present(picker, animated: true, completion: nil)
    }
    
    public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        if let mediaType = info[UIImagePickerControllerMediaType] as? String {
            
            if mediaType  == "public.image" {
                
                if let img = info[UIImagePickerControllerEditedImage] as? UIImage
                {
                    chosenImage = fixOrientation(img: img)
                    self.imgDp.image = img
                    
                }
                else if let img = info[UIImagePickerControllerOriginalImage] as? UIImage
                {
                    chosenImage = fixOrientation(img: img)
                    self.imgDp.image = img
                }
                
                imageFlag = 1
            }
        }
        dismiss(animated:true, completion: nil)
    }
    func fixOrientation(img: UIImage) -> UIImage {
        //change image orienrataion
        if (img.imageOrientation == .up) {
            return img
        }
        UIGraphicsBeginImageContextWithOptions(img.size, false, img.scale)
        let rect = CGRect(x: 0, y: 0, width: img.size.width, height: img.size.height)
        img.draw(in: rect)
        let normalizedImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return normalizedImage
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}

