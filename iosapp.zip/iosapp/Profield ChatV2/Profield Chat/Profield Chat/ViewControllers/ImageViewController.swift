//
//  ImageViewController.swift
//  Profield Chat
//
//  Created by Apple on 17/12/18.
//  Copyright © 2018 indocosmo. All rights reserved.

import UIKit
import AVFoundation
import AVKit
import Alamofire
import MobileCoreServices
import SDWebImage
class ImageViewController: UIViewController {
    @IBOutlet weak var img: UIImageView!
    var ImageLink : String!
    @IBOutlet weak var btnPlay: UIButton!
    var ActualFileName : String!
    var flagScreenType : Int!
    var videoUrl : String!
    var audioIcon : UIImage!
    //MARK:- viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        // checking attachement is video file, Audio or image
        if flagScreenType == 1 || flagScreenType == 2
        {
            btnPlay.isHidden = false
            let accessToken = UserDefaults.standard.value(forKey: "accessToken")
            let tokenType = UserDefaults.standard.value(forKey: "tokenType")
            let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
            SDWebImageDownloader.shared.setValue(headerrr, forHTTPHeaderField:"Authorization")
            if flagScreenType == 2
            {
                img.image = audioIcon
            }
            else
            {
                img.sd_imageIndicator = SDWebImageActivityIndicator.gray
                img.sd_setImage(with: URL(string:  ImageLink), placeholderImage: UIImage(named: "chat_logo.png") )
            }
        }
        else
        {
            btnPlay.isHidden = true
            //load image to imageView
            let accessToken = UserDefaults.standard.value(forKey: "accessToken")
            let tokenType = UserDefaults.standard.value(forKey: "tokenType")
            let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
            SDWebImageDownloader.shared.setValue(headerrr, forHTTPHeaderField:"Authorization")
            img.sd_imageIndicator = SDWebImageActivityIndicator.gray
            img.sd_setImage(with: URL(string:  ImageLink), placeholderImage: UIImage(named: "chat_logo.png") )
        }
    }
    @IBAction func playAction(_ sender: Any) {
        let urlVideo = URL(string: videoUrl)
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let headers: HTTPHeaders = [
            "Authorization": headerrr
        ]
        if flagScreenType == 1
        {
            let asset = AVURLAsset(url: urlVideo!, options: ["AVURLAssetHTTPHeaderFieldsKey": headers])
            let playerItem = AVPlayerItem(asset: asset)
            let  player = AVPlayer(playerItem: playerItem)
            let playerViewController = AVPlayerViewController()
            playerViewController.player = player
            self.present(playerViewController, animated: true) {
                playerViewController.player!.play()
            }
        }
        else
        {
            let asset = AVURLAsset(url: urlVideo!, options: ["AVURLAssetHTTPHeaderFieldsKey": headers])
            let playerItem = AVPlayerItem(asset: asset)
            let  player = AVPlayer(playerItem: playerItem)
            let playerViewController = AVPlayerViewController()
            playerViewController.player = player
            self.present(playerViewController, animated: true) {
                playerViewController.player!.play()
            }
        }
    }
    
    func videoShare() {
        //download attachement data
        let filemanager = FileManager.default
        let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory,.userDomainMask,true)[0] as NSString
        var destinationPath = documentsPath.appendingPathComponent(ActualFileName)
        destinationPath = destinationPath.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        do {
            try filemanager.removeItem(atPath: destinationPath)
            print("Local path removed successfully")
        } catch let error as NSError {
            print("------Error",error.debugDescription)
        }
        AppHelper.showPrograss(vc: self.view, title: "downloading...", message: "")
        let destination = DownloadRequest.suggestedDownloadDestination(for: .documentDirectory)
        let accessToken = UserDefaults.standard.value(forKey: "accessToken")
        let tokenType = UserDefaults.standard.value(forKey: "tokenType")
        let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
        let header = ["Authorization": headerrr]
        Alamofire.download(
            videoUrl,
            method: .get,
            parameters: nil,
            encoding: JSONEncoding.default,
            headers: header,
            to: destination).downloadProgress(closure: { (progress) in
                //progress closure
                print("download Progress: \(progress.fractionCompleted)")
            }).response(completionHandler: { (DefaultDownloadResponse) in
                //here you able to access the DefaultDownloadResponse
                //result closure
                AppHelper.HidePrograss(vc: self.view)
                
                let strrr = DefaultDownloadResponse.error
                if (strrr != nil)
                {
                    
                    AppHelper.showAlertMessage(vc: self, title: "", message: (strrr?.localizedDescription)! )
                }
                else
                {
                    self.shareVideo(from: (DefaultDownloadResponse.destinationURL?.absoluteURL)!)
                }
            })
    }
    func shareVideo(from url: URL) {
        //showing attachement share activityViewController
        
        // removing already added file with same name
        let filemanager = FileManager.default
        let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory,.userDomainMask,true)[0] as NSString
        let destinationPath = documentsPath.appendingPathComponent(ActualFileName)
        do {
            try filemanager.removeItem(atPath: destinationPath)
            print("Local path removed successfully")
        } catch let error as NSError {
            print("------Error",error.debugDescription)
        }
        let str = String(describing: url.absoluteURL)
        let orginalFileNameArray = str.components(separatedBy: "/")
        let orginalFileName =  orginalFileNameArray.last
        
        do {
            let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
            let documentDirectory = URL(fileURLWithPath: path)
            let originPath = documentDirectory.appendingPathComponent(orginalFileName!)
            let destinationPath = documentDirectory.appendingPathComponent(ActualFileName)
            try FileManager.default.moveItem(at: url.absoluteURL, to: destinationPath.absoluteURL)
            let activityViewController = UIActivityViewController(activityItems: [destinationPath], applicationActivities: nil)
            present(activityViewController, animated: true, completion: nil)
        } catch {
            print(error)
        }
    }
    
    @IBAction func BackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @IBAction func shareAction(_ sender: Any) {
        if flagScreenType == 1 || flagScreenType == 2
        {
            videoShare()
        }
        else
        {
               videoShare()
//            let shareVC: UIActivityViewController = UIActivityViewController(activityItems: [(img.image) as Any, ""], applicationActivities: nil)
//            self.present(shareVC, animated: true, completion: nil)
        }
    }
}

