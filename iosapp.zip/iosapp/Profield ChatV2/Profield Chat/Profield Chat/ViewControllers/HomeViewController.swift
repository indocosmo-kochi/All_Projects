    //
    //  HomeViewController.swift
    //  Profield Chat
    //
    //  Created by Apple on 27/11/18.
    //  Copyright © 2018 indocosmo. All rights reserved.
    //
    
    import UIKit
    import Floaty
    import RealmSwift
    import Alamofire
    import Starscream
    import AVKit
    import SDWebImage
    class HomeViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,WebSocketDelegate,UITextFieldDelegate {
        @IBOutlet weak var bgMenuView: UIView!
        @IBOutlet weak var bgMenuViewInner: UIView!
        @IBOutlet weak var userDp: UIImageView!
        @IBOutlet weak var txtSearch: UITextField!
        @IBOutlet weak var tblHome: UITableView!
        @IBOutlet weak var titleView: UIView!
        @IBOutlet weak var searchView: UIView!
        @IBOutlet weak var lblCount: UILabel!
        
        var socket: WebSocket!
        var HomeList = [contactListModel]()
        var HomeListDuplicate : [contactListModel]!
        var caseCount = 300 //starting cases
        var socketArray = [WebSocket]()
        var userId : String!
        var menuFlag : Int!
        var ChatNotificationArray=[String]()
        var ChatOnlineArray=[String]()
        let refreshControl = UIRefreshControl()
        var senderId : String!
        var receverId : String!
        var flagLogin : String!
        let floaty = Floaty()
        var timer = Timer()
        
        // MARK: - ViewDidLoad
        override func viewDidLoad() {
            super.viewDidLoad()
            // UserDefaults.standard.set("accessToken", forKey: "accessToken")
            //sdImageView set header values
            let accessToken = UserDefaults.standard.value(forKey: "accessToken")
            let tokenType = UserDefaults.standard.value(forKey: "tokenType")
            let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
            SDWebImageDownloader.shared.setValue(headerrr, forHTTPHeaderField:"Authorization")
            UserDefaults.standard.set("Home", forKey: "socketMain")
            userId = UserDefaults.standard.value(forKey: "userId") as! String
            self.appversionCheck()
            //config screen
            screenSetup()
            // set floating type button
            //Load Profile Details
            getProfileDetail()
            refreshControl.addTarget(self, action: #selector(getHomeListRefresh), for: .valueChanged)
            tblHome.refreshControl = refreshControl
            txtSearch.delegate = self
            let nc = NotificationCenter.default
            nc.removeObserver("updateSocketHome")
            nc.addObserver(self, selector: #selector(updateSocket), name: Notification.Name("updateSocketHome"), object: nil)
        }
        func screenSetup()
        {
            lblCount.layer.masksToBounds = true
            lblCount.layer.cornerRadius = lblCount.frame.size.width/2
            bgMenuView.isHidden = true
            searchView.layer.cornerRadius = 8
            userDp.layer.cornerRadius = userDp.frame.size.width/2
            bgMenuViewInner.layer.borderColor = UIColor.gray.cgColor
            bgMenuViewInner.layer.borderWidth = 1
            bgMenuViewInner.layer.cornerRadius = 4
        }
        
        override func viewWillAppear(_ animated: Bool) {
            //config web socket
            socketCoennection()
            getHomeList()
            //top Image
            if let savedValue = UserDefaults.standard.string(forKey: "attachmentid"){
                let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                let attachment_id = savedValue
                let imgUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id)
                userDp.sd_imageIndicator = SDWebImageActivityIndicator.gray
                userDp.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
            }
            let nc = NotificationCenter.default
            nc.addObserver(self, selector: #selector(socketCloseStatus), name: Notification.Name("AppClosedNotification"), object: nil)
        }
        override func viewWillDisappear(_ animated: Bool)
        {
            let nc = NotificationCenter.default
            nc.removeObserver("UserLoggedInPreCRE")
        }
        @objc func socketCloseStatus()
        {
            //online status change to offline
            let dict = ["senderUserId": String(format: "%@", self.userId),"status":"logout"]
            if let jsonString = JSONStringEncoder().encode(dict) {
                print(jsonString)
                self.socket.write(string: jsonString)
            }
        }
        //MARK:- Menu
        @IBAction func menuAction(_ sender: Any) {
            self.view.endEditing(true)
            if menuFlag == 1
            {
                bgMenuView.isHidden = true
                menuFlag = 0
            }
            else
            {
                let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.tapBlurButton(_:)))
                bgMenuView.addGestureRecognizer(tapGesture)
                bgMenuView.isHidden = false
                menuFlag = 1
            }
        }
        @objc func tapBlurButton(_ sender: UITapGestureRecognizer) {
            bgMenuView.isHidden = true
            menuFlag = 0
        }
        @IBAction func MenuProfile(_ sender: Any) {
            bgMenuView.isHidden = true
            menuFlag = 0
        }
        @IBAction func MenuChangePassword(_ sender: Any) {
            bgMenuView.isHidden = true
            menuFlag = 0
            let vc = ChangePasswordPopup()
            vc.modalPresentationStyle = .overFullScreen
            present(vc, animated: true, completion: nil)
        }
        @IBAction func MenuDeregister(_ sender: Any) {
            bgMenuView.isHidden = true
            menuFlag = 0
            let alert = UIAlertController(title: "Alert", message: "Your account will immediately deleted. You no longer be able to connect with any chat users and access the related messages or data. Are you sure, you still want to deactivate your account?", preferredStyle: .alert)
            let yesButton = UIAlertAction(title: "Yes", style: .default, handler: {(_ action: UIAlertAction) -> Void in
                print("you pressed Yes, please button")
                self.DeregisterAPi()
            })
            let noButton = UIAlertAction(title: "No", style: .default, handler: {(_ action: UIAlertAction) -> Void in
            })
            alert.addAction(yesButton)
            alert.addAction(noButton)
            present(alert, animated: true)
        }
        func SuccessDeregister()
        {
            //Deregister account
            let dict = ["senderUserId": String(format: "%@", self.userId),"status":"logout"]
            if let jsonString = JSONStringEncoder().encode(dict) {
                print(jsonString)
                self.socket.write(string: jsonString)
            }
            let realm = try! Realm()
            try! realm.write {
                realm.deleteAll()
            }
            UserDefaults.standard.removeObject(forKey: "accessToken")
            UserDefaults.standard.removeObject(forKey: "tokenType")
            UserDefaults.standard.removeObject(forKey: "userId")
            UserDefaults.standard.removeObject(forKey: "loginStatus")
            UserDefaults.standard.removeObject(forKey: "defualtImage")
            UserDefaults.standard.removeObject(forKey: "email")
            UserDefaults.standard.removeObject(forKey: "profileUrl")
            UserDefaults.standard.removeObject(forKey: "lastName")
            UserDefaults.standard.removeObject(forKey: "firstName")
            UserDefaults.standard.removeObject(forKey: "gender")
            UserDefaults.standard.removeObject(forKey: "attachmentid")
            UserDefaults.standard.removeObject(forKey: "userName")
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "loginScreen") as! ViewController
            self.navigationController?.pushViewController(vc,
                                                          animated: true)
        }
        
        
        @IBAction func menuLogout(_ sender: Any) {
            bgMenuView.isHidden = true
            menuFlag = 0
            let alert = UIAlertController(title: "Alert", message: "Are you sure you want to logout now.?", preferredStyle: .alert)
            let yesButton = UIAlertAction(title: "Yes", style: .default, handler: {(_ action: UIAlertAction) -> Void in
                
                //online status change to logout
                let dict = ["senderUserId": String(format: "%@", self.userId),"status":"logout"]
                if let jsonString = JSONStringEncoder().encode(dict) {
                    self.socket.write(string: jsonString)
                }
                
                //delete all values in database
                let realm = try! Realm()
                try! realm.write {
                    realm.deleteAll()
                }
                
                //remove values from UserDefaults
                UserDefaults.standard.removeObject(forKey: "accessToken")
                UserDefaults.standard.removeObject(forKey: "tokenType")
                UserDefaults.standard.removeObject(forKey: "userId")
                UserDefaults.standard.removeObject(forKey: "loginStatus")
                
                UserDefaults.standard.removeObject(forKey: "defualtImage")
                UserDefaults.standard.removeObject(forKey: "email")
                UserDefaults.standard.removeObject(forKey: "profileUrl")
                UserDefaults.standard.removeObject(forKey: "lastName")
                UserDefaults.standard.removeObject(forKey: "firstName")
                UserDefaults.standard.removeObject(forKey: "gender")
                UserDefaults.standard.removeObject(forKey: "attachmentid")
                UserDefaults.standard.removeObject(forKey: "userName")
                
                //navigate to login screen
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "loginScreen") as! ViewController
                self.navigationController?.pushViewController(vc,
                                                              animated: true)
            })
            let noButton = UIAlertAction(title: "No", style: .default, handler: {(_ action: UIAlertAction) -> Void in
            })
            alert.addAction(yesButton)
            alert.addAction(noButton)
            present(alert, animated: true)
        }
        
        @IBAction func sessionOut() {
            // to logout when api token is expired
            //online status change to logout
            let dict = ["senderUserId": String(format: "%@", self.userId),"status":"logout"]
            if let jsonString = JSONStringEncoder().encode(dict) {
                self.socket.write(string: jsonString)
            }
            
            //delete all values in database
            let realm = try! Realm()
            try! realm.write {
                realm.deleteAll()
            }
            
            //remove values from UserDefaults
            UserDefaults.standard.removeObject(forKey: "accessToken")
            UserDefaults.standard.removeObject(forKey: "tokenType")
            UserDefaults.standard.removeObject(forKey: "userId")
            UserDefaults.standard.removeObject(forKey: "loginStatus")
            UserDefaults.standard.removeObject(forKey: "defualtImage")
            UserDefaults.standard.removeObject(forKey: "email")
            UserDefaults.standard.removeObject(forKey: "profileUrl")
            UserDefaults.standard.removeObject(forKey: "lastName")
            UserDefaults.standard.removeObject(forKey: "firstName")
            UserDefaults.standard.removeObject(forKey: "gender")
            UserDefaults.standard.removeObject(forKey: "attachmentid")
            UserDefaults.standard.removeObject(forKey: "userName")
            
            //navigate to login screen
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "loginScreen") as! ViewController
            vc.sessionOutFlag = 1
            self.navigationController?.pushViewController(vc,
                                                          animated: true)
            
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
        }
        // MARK: - TableView Delegate
        func numberOfSections(in tableView: UITableView) -> Int
        {
            return 1
        }
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return HomeList.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath as IndexPath)
            let lblUserName : UILabel = cell.viewWithTag(1) as! UILabel
            let lblGroupName : UILabel = cell.viewWithTag(31) as! UILabel
            let lblStatus : UILabel = cell.viewWithTag(2) as! UILabel
            let imgDp : UIImageView = cell.viewWithTag(3) as! UIImageView
            let imgSt : UIImageView = cell.viewWithTag(699) as! UIImageView
            let imgReadMessage : UIImageView = cell.viewWithTag(331) as! UIImageView
            
            imgSt.layer.cornerRadius = imgSt.frame.size.width/2
            imgDp.layer.cornerRadius = imgDp.frame.size.width/2
            
            var customerName =  NSMutableAttributedString(string: ((HomeList[indexPath.row] as AnyObject).value(forKey: "customerName") as? String)!)
            
            let customerUserName = (HomeList[indexPath.row] as AnyObject).value(forKey: "userName") as? String
            
            let myAttribute = [ NSAttributedString.Key.font:UIFont.systemFont(ofSize: 13)]
            
            var gString = NSMutableAttributedString(string: String(format: " (%@)",customerUserName!), attributes:myAttribute)
            customerName.append(gString)
            lblUserName.attributedText = customerName
            lblStatus.text =  (HomeList[indexPath.row] as AnyObject).value(forKey: "productName") as? String
            lblUserName.isHidden = false
            lblStatus.isHidden = false
            lblGroupName.isHidden = true
            imgDp.sd_imageIndicator = SDWebImageActivityIndicator.gray
            let attachment_id =  (HomeList[indexPath.row] as AnyObject).value(forKey: "ownerAttachemntId")as? String
            let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
            let imgUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id ?? "")
            imgDp.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
            
            let   onlineStr = (HomeList[indexPath.row] as AnyObject).value(forKey: "customerIsOnline") as? Int
            
            
            if onlineStr == 1
            {
                imgSt.isHidden = false
            }
            else
            {
                imgSt.isHidden = true
            }
            
            let chatID = (HomeList[indexPath.row] as AnyObject).value(forKey: "id") as? String
            
            
            if ChatNotificationArray.contains(chatID!)
                
            {
                imgReadMessage.isHidden = false
                
            }
            else
            {
                imgReadMessage.isHidden = true
                
            }
            
            return cell
        }
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let nc = NotificationCenter.default
            nc.removeObserver("updateSocketHome")
            self.view.endEditing(true)
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "chatScreen") as! ChatViewController
            vc.socket = socket
            vc.userId = userId
            vc.Role = "1"
            if HomeList.count >= indexPath.row
            {
                
                vc.senderName = (HomeList[indexPath.row] as AnyObject).value(forKey: "customerName") as? String
                vc.productname = (HomeList[indexPath.row] as AnyObject).value(forKey: "productName") as? String
                let online = (HomeList[indexPath.row] as AnyObject).value(forKey: "customerIsOnline") as? Int
                vc.online = online
                vc.contactId = (HomeList[indexPath.row] as AnyObject).value(forKey: "contactListId") as? String
                vc.ownerID = (HomeList[indexPath.row] as AnyObject).value(forKey: "id") as? String
                vc.productId = (HomeList[indexPath.row] as AnyObject).value(forKey: "productId") as? String
                vc.customerId = (HomeList[indexPath.row] as AnyObject).value(forKey: "customerId") as? String
                vc.userAttachemntId = (HomeList[indexPath.row] as AnyObject).value(forKey: "ownerAttachemntId") as? String
                vc.ChatUserName = (HomeList[indexPath.row] as AnyObject).value(forKey: "userName") as? String
                UserDefaults.standard.set((HomeList[indexPath.row] as AnyObject).value(forKey: "productName") as? String, forKey: "productName")
                UserDefaults.standard.set( (HomeList[indexPath.row] as AnyObject).value(forKey: "productId") as? String, forKey: "productid")
                let str = (HomeList[indexPath.row] as AnyObject).value(forKey: "categoryName") as? String
                UserDefaults.standard.set(str, forKey: "Category")
                UserDefaults.standard.set((HomeList[indexPath.row] as AnyObject).value(forKey: "productTitle") as? String, forKey: "productTitle")
                UserDefaults.standard.set((HomeList[indexPath.row] as AnyObject).value(forKey: "productImageUrl") as? String, forKey: "productImageUrl")
                self.navigationController?.pushViewController(vc,
                                                              animated: true)
            }
        }
        
        // MARK: - APIS
        func getHomeList(){
            //load chat list
            AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
            let accessToken = UserDefaults.standard.value(forKey: "accessToken")
            let tokenType = UserDefaults.standard.value(forKey: "tokenType")
            let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
            let par = ["Authorization": headerrr]
            let str = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.getContactList)
            let url = String(format: "%@?ownerId=%@", str,userId)
            APiClass.apiCallPostWithHeader(mainUrl: url, postParameters: par) { (responseArray) in
                let responseDict = responseArray[0]
                if (responseDict.object(forKey: "error") != nil)
                {
                    AppHelper.HidePrograss(vc: self.view)
                    DispatchQueue.main.async {
                        self.refreshControl.endRefreshing()
                        
                    }
                    let message = responseDict["error"]
                    if message as! String == "Unauthorized"
                    {
                        //tocken expired
                        self.sessionOut()
                    }
                    else
                    {
                        AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
                        
                    }
                }
                else
                {
                    //write to database
                    let realm = try! Realm()
                    let allChat = realm.objects(contactListModel.self)
                    try! realm.write {
                        realm.delete(allChat)
                    }
                    let arrayAllResponse = responseDict["value"] as! NSArray
                    let listedArray = arrayAllResponse[0] as! [[String:Any]]
                    self.ChatNotificationArray=[String]()
                    self.ChatOnlineArray=[String]()
                    
                    for i in 0..<listedArray .count
                    {
                        typealias GlobalAddress = contactListModel
                        let users = contactListModel()
                        users.id = listedArray[i]["id"] as? String
                        users.employeeId = listedArray[i]["employeeId"] as? String
                        users.contactListId = listedArray[i]["contactListId"] as? String
                        var strLastTime =  listedArray[i]["lastMessageTime"] as? String
                        strLastTime = strLastTime?.replacingOccurrences(of: "T", with: " ")
                        strLastTime = strLastTime?.replacingOccurrences(of: "+0000", with: "")
                        
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSS"
                        users.lastMessageTime = dateFormatter.date(from: strLastTime!)!
                        users.customerName = listedArray[i]["customerName"] as? String
                        users.userName = listedArray[i]["userName"] as? String
                        users.productName = listedArray[i]["productName"] as? String
                        users.categoryName = listedArray[i]["categoryName"] as? String
                        users.productImageUrl = listedArray[i]["productImageUrl"] as? String
                        users.productTitle = listedArray[i]["productTitle"] as? String
                        users.ownerAttachemntId = listedArray[i]["ownerAttachemntId"] as? String
                        users.customerIsOnline = (listedArray[i]["customerIsOnline"] as? Int)!
                        let dict = listedArray[i]["customerContact"] as? [String:Any]
                        users.offLineMessage = (dict!["offLineMessage"] as? Int)!
                        users.productId = dict!["productId"] as? String
                        users.isDeleted = dict!["isDeleted"] as? String
                        users.createdBy = dict!["createdBy"] as? String
                        users.customerId = dict!["customerId"] as? String
                        users.LId = dict!["id"] as? String
                        if dict!["offLineMessage"] as? Int == 1
                        {
                            self.ChatNotificationArray.append((listedArray[i]["id"] as? String)!)
                        }
                        if listedArray[i]["customerIsOnline"] as? Int == 1
                        {
                            if !self.ChatOnlineArray.contains((dict!["customerId"] as? String)!)
                            {
                                
                                self.ChatOnlineArray.append((dict!["customerId"] as? String)!)
                            }
                        }
                        let realm = try! Realm()
                        try! realm.write {
                            realm.add(users)
                        }
                    }
                    //
                    AppHelper.HidePrograss(vc: self.view)
                    self.loadDB()
                }
            }
        }
        @objc func getHomeListRefresh(){
            //load chat list when table refresh
            let accessToken = UserDefaults.standard.value(forKey: "accessToken")
            let tokenType = UserDefaults.standard.value(forKey: "tokenType")
            let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
            let par = ["Authorization": headerrr]
            let str = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.getContactList)
            let url = String(format: "%@?ownerId=%@", str,userId)
            APiClass.apiCallPostWithHeader(mainUrl: url, postParameters: par) { (responseArray) in
                let responseDict = responseArray[0]
                if (responseDict.object(forKey: "error") != nil)
                {
                    DispatchQueue.main.async {
                        self.refreshControl.endRefreshing()}
                    AppHelper.HidePrograss(vc: self.view)
                    let message = responseDict["error"]
                    if message as! String == "Unauthorized"
                    {
                        //tocken expired
                        self.sessionOut()
                    }
                    else
                    {
                        DispatchQueue.main.async {
                            self.refreshControl.endRefreshing()}
                    }
                }
                else
                {
                    //write to database
                    let realm = try! Realm()
                    let allChat = realm.objects(contactListModel.self)
                    try! realm.write {
                        realm.delete(allChat)
                    }
                    let arrayAllResponse = responseDict["value"] as! NSArray
                    let listedArray = arrayAllResponse[0] as! [[String:Any]]
                    self.ChatNotificationArray=[String]()
                    self.ChatOnlineArray=[String]()
                    for i in 0..<listedArray .count
                    {
                        typealias GlobalAddress = contactListModel
                        let users = contactListModel()
                        users.id = listedArray[i]["id"] as? String
                        users.employeeId = listedArray[i]["employeeId"] as? String
                        users.contactListId = listedArray[i]["contactListId"] as? String
                        
                        var strLastTime =  listedArray[i]["lastMessageTime"] as? String
                        strLastTime = strLastTime?.replacingOccurrences(of: "T", with: " ")
                        strLastTime = strLastTime?.replacingOccurrences(of: "+0000", with: "")
                        
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSS"
                        users.lastMessageTime = dateFormatter.date(from: strLastTime!)!
                        
                        
                        
                        users.customerName = listedArray[i]["customerName"] as? String
                        users.userName = listedArray[i]["userName"] as? String
                        
                        users.productName = listedArray[i]["productName"] as? String
                        
                        
                        users.categoryName = listedArray[i]["categoryName"] as? String
                        users.productImageUrl = listedArray[i]["productImageUrl"] as? String
                        users.productTitle = listedArray[i]["productTitle"] as? String
                        
                        
                        
                        users.ownerAttachemntId = listedArray[i]["ownerAttachemntId"] as? String
                        users.customerIsOnline = (listedArray[i]["customerIsOnline"] as? Int)!
                        
                        
                        let dict = listedArray[i]["customerContact"] as? [String:Any]
                        
                        
                        users.offLineMessage = (dict!["offLineMessage"] as? Int)!
                        users.productId = dict!["productId"] as? String
                        users.isDeleted = dict!["isDeleted"] as? String
                        users.createdBy = dict!["createdBy"] as? String
                        users.customerId = dict!["customerId"] as? String
                        users.LId = dict!["id"] as? String
                        
                        if dict!["offLineMessage"] as? Int == 1
                        {
                            self.ChatNotificationArray.append((listedArray[i]["id"] as? String)!)
                        }
                        if dict!["customerIsOnline"] as? Int == 1
                        {
                            if !self.ChatOnlineArray.contains((dict!["customerId"] as? String)!)
                            {
                                
                                self.ChatOnlineArray.append((dict!["customerId"] as? String)!)
                            }
                        }
                        
                        
                        let realm = try! Realm()
                        try! realm.write {
                            realm.add(users)
                        }
                    }
                    self.refreshControl.endRefreshing()
                    self.loadDB()
                }
            }
        }
        
        func getProfileDetail(){
            
            
            //load profile details
            let accessToken = UserDefaults.standard.value(forKey: "accessToken")
            let tokenType = UserDefaults.standard.value(forKey: "tokenType")
            let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
            let par = ["Authorization": headerrr]
            let str = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.loadUserDetails)
            let url = String(format: "%@?userId=%@", str,userId)
            APiClass.apiCallGetWithHeader(mainUrl: url, postParameters: par) { (responseArray) in
                let responseDict = responseArray[0]
                if (responseDict.object(forKey: "error") != nil)
                {
                    
                }
                else
                {
                    //save details to userDefault
                    
                    let arrayAllResponse = responseDict["value"] as! [[String:Any]]
                    let arrayResponse = arrayAllResponse[0]["user"] as! [String:Any]
                    let dftImg = String(format: "%d", arrayResponse["defualtImage"] as! Int)
                    
                    UserDefaults.standard.set(dftImg, forKey: "defualtImage")
                    
                    UserDefaults.standard.set(arrayResponse["userName"], forKey: "userName")
                    UserDefaults.standard.set(arrayResponse["email"], forKey: "email")
                    UserDefaults.standard.set(arrayResponse["profileUrl"], forKey: "profileUrl")
                    UserDefaults.standard.set(arrayResponse["lastName"], forKey: "lastName")
                    UserDefaults.standard.set(arrayResponse["firstName"], forKey: "firstName")
                    UserDefaults.standard.set(arrayResponse["gender"], forKey: "gender")
                    UserDefaults.standard.set(arrayResponse["attachmentId"], forKey: "attachmentid")
                    let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
                    let attachment_id = String(format:"%@", arrayResponse["attachmentId"] as! String)
                    let imgUrl = String(format: "%@/api/attachmentasbody/%@", apiUrl,attachment_id)
                    self.userDp.sd_setImage(with: URL(string:  imgUrl), placeholderImage: UIImage(named: "chat_logo.png"))
                }
            }
        }
        func DeregisterAPi(){
            //Deregister Api
            AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
            let accessToken = UserDefaults.standard.value(forKey: "accessToken")
            let tokenType = UserDefaults.standard.value(forKey: "tokenType")
            let headerrr = String(format: "%@ %@", tokenType as! CVarArg,accessToken as! CVarArg)
            let HeaderPar = ["Authorization": headerrr]
            let str = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.deRegisterUser)
            let par = ["userId": userId]
            APiClass.apiCallPostValueWithHeader(mainUrl: str, postParameters: par as! Dictionary<String, String>,headerParams:HeaderPar) { (responseArray) in
                let responseDict = responseArray[0]
                if (responseDict.object(forKey: "error") != nil)
                {
                    AppHelper.HidePrograss(vc: self.view)
                    let message = responseDict["error"]
                    AppHelper.showAlertMessage(vc: self, title: "", message: message as! String)
                }
                else
                {
                    let arrayAllResponse = responseDict["value"] as! NSArray
                    let dict = arrayAllResponse[0] as! [String : Any]
                    
                    let message = dict["message"] as! String
                    if message == "de-registered"
                    {
                        AppHelper.HidePrograss(vc: self.view)
                        self.SuccessDeregister()
                    }
                    else
                    {
                        AppHelper.HidePrograss(vc: self.view)
                        AppHelper.showAlertMessage(vc: self, title: "Sorry", message: "Something went wrong, Please try again after some time.")
                    }
                }
            }
        }
        //MARK: Database
        func loadDB() {
            //load values in database
            
            HomeList=[contactListModel]()
            HomeListDuplicate=[contactListModel]()
            let realm = try! Realm()
            let dbHome = realm.objects(contactListModel.self)
            HomeList  = Array(dbHome)
            HomeListDuplicate  = Array(dbHome)
            //            HomeList =   HomeList.sorted(by: { $0.Oder > $1.Oder } )
            // HomeList.reverse()
            HomeList =   HomeList.sorted(by: {  $0.lastMessageTime.compare($1.lastMessageTime) == .orderedDescending } )
            
            HomeListDuplicate  = HomeList
            print(HomeList)
            
            if txtSearch.text == "" {
                
                tblHome.reloadData()
            }
            else
            {
                search()
            }
        }
        
        //MARK: Search
        @IBAction func SearchAction(_ sender: Any) {
            if txtSearch.text == "" {
                HomeList  = HomeListDuplicate
                tblHome.reloadData()
            }
            else
            {
                search()
            }
        }
        @IBAction   func textFieldDidChange(textField : UITextField){
            if txtSearch.text == "" {
                HomeList  = HomeListDuplicate
                tblHome.reloadData()
            }
            else
            {
                search()
            }
            
        }
        func search()
        {
            //search actions
            HomeList=[contactListModel]()
            for i in 0..<HomeListDuplicate.count{
                var name : String!
                
                name = (HomeListDuplicate[i] as AnyObject).value(forKey: "userName") as? String
                
                if name?.lowercased().range(of:txtSearch.text?.lowercased() as! String) != nil {
                    HomeList.append(HomeListDuplicate[i])
                }
            }
            tblHome.reloadData()
        }
        //MARK: Socket Connection
        func removeSocket(_ s: WebSocket?) {
            socketArray = socketArray.filter{$0 != s}
        }
        @objc func updateSocket() {
            print("-----------chat------------")
            let nc = NotificationCenter.default
            nc.removeObserver("updateSocketHome")
            if Connectivity.isConnectedToInternet
            {
                if UserDefaults.standard.string(forKey: "lastUpdated") == "yes"
                {
                    UserDefaults.standard.set("nooo", forKey: "lastUpdated")
                    
                    let dict = ["senderUserId": String(format: "%@", userId),"status":"ping"]
                    print(dict)
                    if let jsonString = JSONStringEncoder().encode(dict) {
                        socket.write(string: jsonString)
                    }
                }
            }
        }
        //Check internet Connection
        struct Connectivity
        {
            static let sharedInstance = NetworkReachabilityManager()!
            static var isConnectedToInternet:Bool {
                return self.sharedInstance.isReachable
            }
        }
        func socketCoennection() {
            //config socketConnection
            if Connectivity.isConnectedToInternet {
                let SocketURL = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverSocketDomain")!, DefineClass.SocketUrl)
                socket = WebSocket(url: URL(string: SocketURL)!, protocols: ["wss"])
                socket.delegate = self
                socketArray.append(socket)
                socket.onText = { [weak self]  (text: String) in
                    if let c = Int(text) {
                        print("number of cases is: \(c)")
                        self?.caseCount = c
                    }
                }
                socket.onDisconnect = { [weak self, weak socket]  (error: Error?) in
                    self?.getTestInfo(1)
                    self?.removeSocket(socket)
                }
                socket.disableSSLCertValidation = false
                socket.connect()
            }
            else
            {
                AppHelper.showAlertMessage(vc: self, title: "", message: "Unable to get access to the Chat Server. Please check your internet connection!!!")
                timer = Timer.scheduledTimer(timeInterval: 5,
                                             target: self,
                                             selector: #selector(self.networkCheck),
                                             userInfo: nil,
                                             repeats: true)
                
                
            }
        }
        @objc func networkCheck() {
            if Connectivity.isConnectedToInternet {
                DispatchQueue.main.async {
                    self.timer.invalidate()
                    if let savedValue = UserDefaults.standard.string(forKey: "loginStatus"){
                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                        let rootVC:HomeViewController = storyboard.instantiateViewController(withIdentifier: "home") as! HomeViewController
                        let nvc:UINavigationController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController") as! UINavigationController
                        nvc.viewControllers = [rootVC]
                        let appDelegate = UIApplication.shared.delegate as! AppDelegate
                        appDelegate.window?.rootViewController = nvc
                        
                    }
                }
            }
        }
        func getTestInfo(_ caseNum: Int) {
            let s = createSocket("getCaseInfo",caseNum)
            socketArray.append(s)
            s.onText = { (text: String) in
            }
            var once = false
            s.onDisconnect = { [weak self, weak s]  (error: Error?) in
                if !once {
                    once = true
                    self?.runTest(caseNum)
                }
                self?.removeSocket(s)
            }
            s.connect()
        }
        
        func runTest(_ caseNum: Int) {
            let s = createSocket("runCase",caseNum)
            self.socketArray.append(s)
            s.onText = { [weak s]  (text: String) in
                s?.write(string: text)
            }
            s.onData = { [weak s]  (data: Data) in
                s?.write(data: data)
            }
            var once = false
            s.onDisconnect = {[weak self, weak s] (error: Error?) in
                if !once {
                    once = true
                    //self?.verifyTest(caseNum) //disabled since it slows down the tests
                    let nextCase = caseNum+1
                    if nextCase <= (self?.caseCount)! {
                        self?.runTest(nextCase)
                        //self?.getTestInfo(nextCase) //disabled since it slows down the tests
                    } else {
                        self?.finishReports()
                    }
                    self?.removeSocket(s)
                }
            }
            s.connect()
        }
        
        func verifyTest(_ caseNum: Int) {
            let s = createSocket("getCaseStatus",caseNum)
            self.socketArray.append(s)
            s.onText = { (text: String) in
                let data = text.data(using: String.Encoding.utf8)
                do {
                    let resp: Any? = try JSONSerialization.jsonObject(with: data!,
                                                                      options: JSONSerialization.ReadingOptions())
                    if let dict = resp as? Dictionary<String,String> {
                        if let status = dict["behavior"] {
                            if status == "OK" {
                                return
                            }
                        }
                    }
                } catch {
                }
            }
            var once = false
            s.onDisconnect = { [weak self, weak s]  (error: Error?) in
                if !once {
                    once = true
                    let nextCase = caseNum+1
                    print("next test is: \(nextCase)")
                    if nextCase <= (self?.caseCount)! {
                        self?.getTestInfo(nextCase)
                    } else {
                        self?.finishReports()
                    }
                }
                self?.removeSocket(s)
            }
            s.connect()
        }
        
        func finishReports() {
            let s = createSocket("updateReports",0)
            self.socketArray.append(s)
            s.onDisconnect = { [weak self, weak s]  (error: Error?) in
                self?.removeSocket(s)
            }
            s.connect()
        }
        
        func createSocket(_ cmd: String, _ caseNum: Int) -> WebSocket {
            let SocketURL = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverSocketDomain")!, DefineClass.SocketUrl)
            return WebSocket(url: URL(string: "\(SocketURL)\(buildPath(cmd,caseNum))")!, protocols: [])
        }
        
        func buildPath(_ cmd: String, _ caseNum: Int) -> String {
            return "/\(cmd)?case=\(caseNum)&agent=Starscream"
        }
        func websocketDidConnect(socket: WebSocketClient) {
            if let savedValue = UserDefaults.standard.string(forKey: "loginStatus"){
                userId = UserDefaults.standard.value(forKey: "userId") as! String
                print("websocket is connected")
                let dict = ["message": String(format: "%@", userId),"status":"connect"]
                if let jsonString = JSONStringEncoder().encode(dict) {
                    print(jsonString)
                    socket.write(string: jsonString)
                    
                }
            }
        }
        func websocketDidDisconnect(socket: WebSocketClient, error: Error?) {
            if let e = error as? WSError {
                print("----------------------------->websocket is disconnected: \(e.message)")
            } else if let e = error {
                print("---------------------->websocket is disconnected: \(e.localizedDescription)")
            } else {
                print("--------------------->websocket disconnected")
            }
            
            socketCoennection()
        }
        func websocketDidReceiveMessage(socket: WebSocketClient, text: String) {
            print(text)
            let data1 = text.data(using: String.Encoding.utf8)
            do {
                let resp: AnyObject? = try JSONSerialization.jsonObject(with: data1!,
                                                                        options: JSONSerialization.ReadingOptions()) as AnyObject
                
                if let dict = resp as? Dictionary<String,Any> {
                    //individual Chat
                    if let receverDict = dict["individualMessageDTO"] as? Dictionary<String,Any>{
                        ChatNotificationArray.append(receverDict["contactListId"] as! String)
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSS"
                        
                        let date = dateFormatter.date(from:  Date.getCurrentDate())
                        
                        
                        let strrr = String(format: "customerId = '%@'",receverDict["senderId"] as! String)
                        let productId = String(format: "productId = '%@'",receverDict["productId"] as! String)
                        let realm = try! Realm()
                        let dbGrpModel = realm.objects(contactListModel.self).filter(strrr).filter(productId)
                        if let dbGrpModel = dbGrpModel.first
                        {
                            try! realm.write
                            {
                                dbGrpModel.lastMessageTime = date!
                            }
                        }
                        self.loadDB()
                        // self.getHomeListRefresh()
                    }
                    else  if let receverDict = dict["deregisterDTO"] as? Dictionary<String,Any>{
                        if receverDict["status"] as? String == "User_deregistered"
                        {
                            self.getHomeListRefresh()
                        }}
                        
                    else  if dict["status"] as! String == "DeletedOwner"    {
                        if let receverDict = dict["user"] as? Dictionary<String,Any>{
                            if  receverDict["id"] as? String == userId
                            {
                                self.deleteByAdmin()
                            }
                            else
                            {
                                self.getHomeListRefresh()
                            }
                            
                        }                    }
                    else  if dict["status"] as! String == "DeletedUserByadmin"    {
                        if let receverDict = dict["user"] as? Dictionary<String,Any>{
                            if  receverDict["id"] as? String == userId
                            {
                                self.deleteByAdmin()
                            }
                            else
                            {
                                
                                self.getHomeListRefresh()
                                
                            }
                            
                        }                    }
                        
                    else   if dict["status"] as?  String == "onlineStatus"{
                        
                        self.getHomeListRefresh()
                        
                    }
                        
                    else
                    {
                        self.getHomeListRefresh()
                    }
                }
                
            } catch {
            }
            
        }
        @IBAction func deleteByAdmin() {
            //  timer.invalidate()
            socket.disconnect()
            //delete all values in database
            let realm = try! Realm()
            try! realm.write {
                realm.deleteAll()
            }
            
            //remove values from UserDefaults
            UserDefaults.standard.removeObject(forKey: "accessToken")
            UserDefaults.standard.removeObject(forKey: "tokenType")
            UserDefaults.standard.removeObject(forKey: "userId")
            UserDefaults.standard.removeObject(forKey: "loginStatus")
            UserDefaults.standard.removeObject(forKey: "defualtImage")
            UserDefaults.standard.removeObject(forKey: "email")
            UserDefaults.standard.removeObject(forKey: "profileUrl")
            UserDefaults.standard.removeObject(forKey: "lastName")
            UserDefaults.standard.removeObject(forKey: "firstName")
            UserDefaults.standard.removeObject(forKey: "gender")
            UserDefaults.standard.removeObject(forKey: "attachmentid")
            UserDefaults.standard.removeObject(forKey: "userName")
            //navigate to login screen
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "loginScreen") as! ViewController
            vc.sessionOutFlag = 5
            self.navigationController?.pushViewController(vc,
                                                          animated: false)
        }
        func websocketDidReceiveData(socket: WebSocketClient, data: Data) {
        }
        struct JSONStringEncoder {
            func encode(_ dictionary: [String: Any]) -> String? {
                guard JSONSerialization.isValidJSONObject(dictionary) else {
                    assertionFailure("Invalid json object received.")
                    return nil
                }
                let jsonObject: NSMutableDictionary = NSMutableDictionary()
                let jsonData: Data
                dictionary.forEach { (arg) in
                    jsonObject.setValue(arg.value, forKey: arg.key)
                }
                do {
                    jsonData = try JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted)
                } catch {
                    assertionFailure("JSON data creation failed with error: \(error).")
                    return nil
                }
                guard let jsonString = String.init(data: jsonData, encoding: String.Encoding.utf8) else {
                    assertionFailure("JSON string creation failed.")
                    return nil
                }
                return jsonString
            }
        }
        
        //MARK:- App Version Check
        func appversionCheck()
        {
            let defaults = UserDefaults.standard
            
            let currentBuild = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as! String
            let currentVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String
            let currentAppVersion = String(format: "%@.%@", currentVersion,currentBuild)
            print("App cureent version -------- >%@",currentAppVersion)
            
            
            
            let previousVersion = defaults.string(forKey: "appVersion")
            if previousVersion == nil {
                // first launch
                defaults.set(currentAppVersion, forKey: "appVersion")
                defaults.synchronize()
            } else if previousVersion == currentAppVersion {
                // same version
            } else {
                // other version
                defaults.set(currentAppVersion, forKey: "appVersion")
                defaults.synchronize()
                
                
                
                //delete all values in database
                let realm = try! Realm()
                try! realm.write {
                    realm.deleteAll()
                }
                
                //remove values from UserDefaults
                
                //navigate to login screen
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "loginScreen") as! ViewController
                vc.sessionOutFlag = 2
                self.navigationController?.pushViewController(vc,
                                                              animated: true)
                
            }
        }
    }
    extension Date {
        
        static func getCurrentDate() -> String {
            
            let dateFormatter = DateFormatter()
            
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSS"
            
            return dateFormatter.string(from: Date())
            
        }
    }
