//
//  ViewController.swift
//  Profield Chat
//
//  Created by Apple on 21/11/18.
//  Copyright © 2018 indocosmo. All rights reserved.
//

import UIKit
import Starscream
class ViewController: UIViewController,UITextFieldDelegate,UIPickerViewDelegate, UIPickerViewDataSource{
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var lblFirstName: UILabel!
    @IBOutlet weak var txtDomainType: UITextField!
    @IBOutlet weak var txtDomain: UITextField!
    @IBOutlet weak var dropDownDomain = UIPickerView()
    @IBOutlet weak var viewToolBar: UIView!
    @IBOutlet weak var viewServerDetailBg: UIView!
    @IBOutlet weak var viewServerDetails: UIView!
    var list = ["http://", "https://"]
    var sessionOutFlag : Int!
    //MARK: ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        if sessionOutFlag == 1
        {
            AppHelper.showAlertMessage(vc: self, title: "Alert", message: "Your session has expired.! Please login again")
        }
        if sessionOutFlag == 5
        {
            AppHelper.showAlertMessage(vc: self, title: "Alert", message: "You might have removed from the Chat application. Please contact the Administrator!!!")
        }
        if sessionOutFlag == 2
        {
            UserDefaults.standard.removeObject(forKey: "accessToken")
            UserDefaults.standard.removeObject(forKey: "tokenType")
            UserDefaults.standard.removeObject(forKey: "userId")
            UserDefaults.standard.removeObject(forKey: "loginStatus")
            
            AppHelper.showAlertMessage(vc: self, title: "Alert", message: "Your app is updated. Please login again")
        }
        //config screnn
        ScreenSetUp()
        //server Details
        let apiUrl = String(format: "%@",UserDefaults.standard.string(forKey: "serverDomain")!)
        let strArray = apiUrl.components(separatedBy: "//")
        txtDomainType.text = String(format: "%@//",String(strArray[0]))
        txtDomain.text = String(strArray[1])
        let defaults = UserDefaults.standard
        let currentBuild = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as! String
        let currentVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String
        let currentAppVersion = String(format: "%@.%@", currentVersion,currentBuild)
        defaults.set(currentAppVersion, forKey: "appVersion")
        defaults.synchronize()
    }
    @IBAction func DomainClose(_ sender: Any) {
        //server detail view close
        self.view.endEditing(true)
        dropDownDomain?.isHidden = true
        viewToolBar.isHidden = true
        self.dropDownDomain?.isHidden = true
        viewToolBar.isHidden = true
    }
    @IBAction func SaveAction(_ sender: Any) {
        //server detail save
        let stringUrl = String(format: "%@%@", txtDomainType.text!,txtDomain.text!)
        if txtDomain.text == ""
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Enter a valid chat server url")
        }
        else if !stringUrl.isValidURL {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Enter a valid chat server url")
        }
        else
        {
            UserDefaults.standard.set(stringUrl, forKey: "serverDomain")
            if txtDomainType.text == "http://"
            {
                UserDefaults.standard.set(stringUrl, forKey: "serverSocketDomain")
            }
            else
            {
                UserDefaults.standard.set(String(format: "wss://%@",txtDomain.text!), forKey: "serverSocketDomain")
            }
            dropDownDomain?.isHidden = true
            viewToolBar.isHidden = true
            self.dropDownDomain?.isHidden = true
            viewToolBar.isHidden = true
            viewServerDetailBg.isHidden = true
            AppHelper.showAlertMessage(vc: self, title: "", message: "Server details saved")
        }
    }
    //MARK:- Server details
    @IBAction func DomainMethodType(_ sender: Any) {
        //server detail picker
        self.view.endEditing(true)
        dropDownDomain?.layer.borderColor = UIColor.lightGray.cgColor
        dropDownDomain?.layer.borderWidth = 1
        dropDownDomain?.isHidden = false
        viewToolBar.isHidden = false
    }
    @IBAction func settingAction(_ sender: Any) {
        //server detail view show
        self.view.endEditing(true)
        viewServerDetailBg.isHidden = false
    }
    @IBAction func settingActionClose(_ sender: Any) {
        self.view.endEditing(true)
        dropDownDomain?.isHidden = true
        viewToolBar.isHidden = true
        viewServerDetailBg.isHidden = true
    }
    func ScreenSetUp()
    {
        txtPassword.text = ""
        txtUserName.text = ""
        txtPassword.isSecureTextEntry = true
        //textField bottom line
        txtUserName.setBottomBorder()
        txtPassword.setBottomBorder()
        txtDomain.delegate = self
        viewServerDetails.layer.cornerRadius = 4
        self.viewServerDetailBg.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        //textfield placeholder color
        if let placeholder = txtUserName.placeholder {
            txtUserName.attributedPlaceholder = NSAttributedString(string:placeholder,
                                                                   attributes: [NSAttributedStringKey.foregroundColor: lblFirstName.textColor])
        }
        if let placeholder = txtPassword.placeholder {
            txtPassword.attributedPlaceholder = NSAttributedString(string:placeholder,
                                                                   attributes: [NSAttributedStringKey.foregroundColor: lblFirstName.textColor])
        }
    }
    //MARK: forgotPassword
    @IBAction  func forgotPassword(_ sender: UIButton)
    {
        let vc = FogotPasswardPopup()
        vc.modalPresentationStyle = .overFullScreen
        present(vc, animated: true, completion: nil)
    }
    //MARK: loginAction
    @IBAction func btnLogin(_ sender: Any) {
        if txtUserName.text == ""
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Please enter user name.")
        }
        else if txtPassword.text == ""
        {
            AppHelper.showAlertMessage(vc: self, title: "", message: "Please enter password.")
        }
        else
        {
            loginAPi()
        }
    }
    //call login api
    func loginAPi(){
        AppHelper.showPrograss(vc: self.view, title: "Loading..", message: "Please wait")
        let par = ["username": txtUserName.text!,"password": txtPassword.text!]
        let apiUrl = String(format: "%@%@",UserDefaults.standard.string(forKey: "serverDomain")!, DefineClass.LoginApi)
        APiClass.apiCallREST(mainUrl: apiUrl, postParameters: par) { (responseArray) in
            let responseDict = responseArray[0]
            if (responseDict.object(forKey: "error") != nil)
            {
                AppHelper.HidePrograss(vc: self.view)
                let message = responseDict["error"] as!String
                if message == "Unauthorized"
                {
                    AppHelper.showAlertMessage(vc: self, title: "", message:"Invalid user name or password")
                }
                else  if message == "Bad Request"
                {
                    AppHelper.showAlertMessage(vc: self, title: "", message:"Invalid user name or password")
                }
                else  if message == "JSON could not be serialized because of error:\nThe data couldn’t be read because it isn’t in the correct format."
                {
                    AppHelper.showAlertMessage(vc: self, title: "Incorrect server details", message:"Please check server address valid or not")
                }
                else
                {
                    AppHelper.showAlertMessage(vc: self, title: "", message: message )
                }
            }
            else
            {
                let status = responseDict["status"] as! String
                if status == "Scucess"
                {
                    // store accessToken,tokenType and userId
                    let  accessToken = responseDict["accessToken"] as! String
                    let  tokenType = responseDict["tokenType"] as! String
                    let  userIdd = responseDict["userId"] as! String
                    let  roleIdd = String(format: "%d", responseDict["role"] as! Int)
                    UserDefaults.standard.set(roleIdd, forKey: "roleIdd")
                    UserDefaults.standard.set(accessToken, forKey: "accessToken")
                    UserDefaults.standard.set(tokenType, forKey: "tokenType")
                    UserDefaults.standard.set(userIdd, forKey: "userId")
                    UserDefaults.standard.set("logind", forKey: "loginStatus")
                    AppHelper.HidePrograss(vc: self.view)
                    //navigate to home screen
                    if roleIdd == "1"
                    {
                        let vc = self.storyboard?.instantiateViewController(withIdentifier: "product") as! ProductViewController
                        vc.flagLogin = "1"
                        self.navigationController?.pushViewController(vc,
                                                                      animated: true)
                    }
                    else  if roleIdd == "3"
                    {
                        let vc = self.storyboard?.instantiateViewController(withIdentifier: "home") as! HomeViewController
                        vc.flagLogin = "1"
                        self.navigationController?.pushViewController(vc,
                                                                      animated: true)
                    }
                }
                else
                {
                    AppHelper.HidePrograss(vc: self.view)
                    
                }
            }
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: Dropdown
    public func numberOfComponents(in pickerView: UIPickerView) -> Int{
        return 1
    }
    
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        return list.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        self.view.endEditing(true)
        return list[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.txtDomainType.text = self.list[row]
        self.dropDownDomain?.isHidden = true
        viewToolBar.isHidden = true
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        self.dropDownDomain?.isHidden = true
        viewToolBar.isHidden = true
        return true
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
    }
}
extension UITextField
{
    func setBottomBorder()
    {
        self.borderStyle = .none
        self.layer.backgroundColor = UIColor.white.cgColor
        self.layer.masksToBounds = false
        let color1 = hexStringToUIColor(hex: "#516073")
        self.layer.shadowColor = color1.cgColor
        self.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
        self.layer.shadowOpacity = 1.0
        self.layer.shadowRadius = 0.0
    }
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}
extension String {
    var isValidURL: Bool {
        let detector = try! NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue)
        if let match = detector.firstMatch(in: self, options: [], range: NSRange(location: 0, length: self.utf16.count)) {
            // it is a link, if the match covers the whole string
            return match.range.length == self.utf16.count
        } else {
            return false
        }
    }
}
