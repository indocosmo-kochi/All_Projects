//
//  AppDelegate.swift
//  Profield Chat
//
//  Created by Apple on 21/11/18.
//  Copyright © 2018 indocosmo. All rights reserved.
//

import UIKit
import SplunkMint
import SDWebImage
import SDWebImageWebPCoder
import SDWebImageSVGCoder
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    var timer = Timer()
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        UserDefaults.standard.set("no", forKey: "viewMoreScreen")
        let WebPCoder = SDImageWebPCoder.shared
        SDImageCodersManager.shared.addCoder(WebPCoder)
        let SVGCoder = SDImageSVGCoder.shared
        SDImageCodersManager.shared.addCoder(SVGCoder)
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.lightContent
        UserDefaults.standard.set("Home", forKey: "socketMain")
        //Splunk Mint config
        Mint.sharedInstance().initAndStartSession(withAPIKey: "f10e18f7");
        //login status check
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let savedValue = UserDefaults.standard.string(forKey: "loginStatus"){
            let  roleId = UserDefaults.standard.string(forKey: "roleIdd")
            let accessToken = UserDefaults.standard.value(forKey: "accessToken")
            timer = Timer.scheduledTimer(timeInterval: 60,
                                         target: self,
                                         selector: #selector(self.updatePing),
                                         userInfo: nil,
                                         repeats: true)
            
            if roleId == "1"
            {
                let rootVC:ProductViewController = storyboard.instantiateViewController(withIdentifier: "product") as! ProductViewController
                let nvc:UINavigationController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController") as! UINavigationController
                nvc.viewControllers = [rootVC]
                self.window?.rootViewController = nvc
            }
            else if roleId == "3"
            {
                let rootVC:HomeViewController = storyboard.instantiateViewController(withIdentifier: "home") as! HomeViewController
                let nvc:UINavigationController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController") as! UINavigationController
                nvc.viewControllers = [rootVC]
                self.window?.rootViewController = nvc
            }
        }
        if let serverDomain = UserDefaults.standard.string(forKey: "serverDomain"){
        }
        else
        {
            //set server details for default
            UserDefaults.standard.set("https://hikari.in/dev-chat", forKey: "serverDomain")
            UserDefaults.standard.set("wss://hikari.in/dev-chat", forKey: "serverSocketDomain")
        }
        return true
    }
    func applicationWillResignActive(_ application: UIApplication) {
    }
    func applicationDidEnterBackground(_ application: UIApplication) {
        timer.invalidate()
    }
    func applicationWillEnterForeground(_ application: UIApplication) {
        
        UserDefaults.standard.set("Home", forKey: "socketMain")
        if let savedValue = UserDefaults.standard.string(forKey: "loginStatus"){
            timer = Timer.scheduledTimer(timeInterval: 60,
                                         target: self,
                                         selector: #selector(self.updatePing),
                                         userInfo: nil,
                                         repeats: true)
        }
    }
    func timersetting()
    {
        timer = Timer.scheduledTimer(timeInterval: 60,
                                     target: self,
                                     selector: #selector(self.updatePing),
                                     userInfo: nil,
                                     repeats: true)
    }
    func applicationDidBecomeActive(_ application: UIApplication) {
    }
    func applicationWillTerminate(_ application: UIApplication) {
        // //socket connection config
        timer.invalidate()
        if UserDefaults.standard.string(forKey: "loginStatus") != nil{
            let nc = NotificationCenter.default
            nc.post(name: Notification.Name("AppClosedNotification"), object: nil)
        }
        //clear cache
        SDImageCache.shared.clearMemory()
        SDImageCache.shared.clearDisk()
    }
    @objc func updatePing()
    {
        if UserDefaults.standard.string(forKey: "loginStatus") != nil{
            UserDefaults.standard.set("yes", forKey: "lastUpdated")
            let  roleId = UserDefaults.standard.string(forKey: "roleIdd")
            if UserDefaults.standard.string(forKey: "socketMain") == "Home"
            {
                if roleId == "1"
                {
                    let nc = NotificationCenter.default
                    nc.post(name: Notification.Name("updateSocketHomeProduct"), object: nil)
                }
                else
                {
                    let nc = NotificationCenter.default
                    nc.post(name: Notification.Name("updateSocketHome"), object: nil)
                }
            }
            else
            {
                let nc = NotificationCenter.default
                nc.post(name: Notification.Name("updateSocketChat"), object: nil)
            }
        }
        
    }
}

