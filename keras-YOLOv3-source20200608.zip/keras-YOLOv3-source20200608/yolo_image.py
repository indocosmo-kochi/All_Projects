import sys
import argparse
from yolo import YOLO
from PIL import Image

def detect_img(yolo):
    while True:
        imgs = input('Input image filenames separated by comas:') #stored locations as a string separated by coma
        img_locations = imgs.split(',') 
        image_no = 1 #need to change into page number
        for i in img_locations:  
            try:
                image = Image.open(i)
            except:
                print('Open Error! Try again!')
                continue
            else:
                r_image,ROI_images = yolo.detect_image(image)
                #r_image.show()

                #Location for saving image with bounding box
                r_image.save('output_images/{}.jpg'.format(image_no))
                roi_no = 1
                #saving the regions of image
                for r in ROI_images:
                    r.save('output_images/image_{}_{}.jpg'.format(image_no,roi_no))
                    roi_no = roi_no + 1
            image_no = image_no + 1
    yolo.close_session()

FLAGS = None

if __name__ == '__main__':
    # class YOLO defines the default value, so suppress any default here
    parser = argparse.ArgumentParser(argument_default=argparse.SUPPRESS)
    '''
    Command line options
    '''
    parser.add_argument(
        '--model', type=str, dest='model_path',
        help='path to model weight file, default ' + YOLO.get_defaults("model_path")
    )

    parser.add_argument(
        '--classes', type=str, dest='classes_path',
        help='path to class definitions, default ' + YOLO.get_defaults("classes_path")
    )

    parser.add_argument(
        '--image', default=False, action="store_true",
        help='Image detection mode, will ignore all positional arguments'
    )
    

    FLAGS = parser.parse_args()
    print(FLAGS)
    if FLAGS.image:
        """
        Image detection mode, disregard any remaining command line arguments
        """
        print("Image detection mode")
        if "input" in FLAGS:
            print(" Ignoring remaining command line arguments: " + FLAGS.input + "," + FLAGS.output)
        detect_img(YOLO(**vars(FLAGS)))
    
