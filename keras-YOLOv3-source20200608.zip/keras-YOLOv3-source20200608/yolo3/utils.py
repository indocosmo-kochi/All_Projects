"""Miscellaneous utility functions."""

from functools import reduce

from PIL import Image
import numpy as np
from matplotlib.colors import rgb_to_hsv, hsv_to_rgb
import cv2

def compose(*funcs):
	"""Compose arbitrarily many functions, evaluated left to right.

	"""
	# return lambda x: reduce(lambda v, f: f(v), funcs, x)
	if funcs:
		return reduce(lambda f, g: lambda *a, **kw: g(f(*a, **kw)), funcs)
	else:
		raise ValueError('Composition of empty sequence not supported.')

def bounding_boxes(image):
	images = []
	starting_point_x = []
	starting_point_y = []
	#image1 = image
	image = np.array(image)
	gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
	# create a binary thresholded image
	_, binary = cv2.threshold(gray, 225, 255, cv2.THRESH_BINARY_INV)
	# show it
	# find the contours from the thresholded image
	cnts = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
	cnts = cnts[0] if len(cnts) == 2 else cnts[1]

	bound_boxes = []
	ROI_number = 0
	for c in cnts:
	    x,y,w,h = cv2.boundingRect(c)
	    if w >100 and h>100 :
	            bound_boxes.append([x,y,x+w,y+h])
	            #ROI = image[y:y+h, x:x+w]
	            #cv2.rectangle(image,(x,y),(x+w,y+h),(36,255,12),2)
	            #ROI = cv2.cvtColor(ROI, cv2.COLOR_BGR2RGB)
	            #ROI = Image.fromarray(ROI)
	            #images.append(ROI)
	            #starting_point_x.append(x)
	            #starting_point_y.append(y)
	#img = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
	#im_pil = Image.fromarray(image)
	#im_pil.save('/home/lap-011/Desktop/ML_work/13_04/binary_image.jpg')
	#cv2.imwrite('/home/lap-011/Desktop/ML_work/13_04/binary_image.jpg', image) 
	#return images,starting_point_x,starting_point_y
	return bound_boxes 

def crop_image_2(image):
	images = []
	starting_point_x = []
	starting_point_y = []
	croped_boxes = []
	image_width, image_height = image.size
	
	for i in range(0,1):
		if i == 0:
			left = 0
			right = image_width
		
		'''Image 1'''
		top = 0
		bottom = image_height/(100/75)
		croped_boxes.append([int(left),int(top),int(right),int(bottom)])
		image_1 = image.crop((left, top, right, bottom))
		#starting_point_x.append(left)
		#starting_point_y.append(top)
		#images.append(image_1)
		image_1.save('/home/lap-011/Desktop/ML_work/13_04/{}_image_100.jpg'.format(i))
		'''Image 2'''
		top = image_height/(100/25)
		bottom = image_height
		croped_boxes.append([int(left),int(top),int(right),int(bottom)]) 
		image_2 = image.crop((left, top, right, bottom))
		#starting_point_x.append(left)
		#starting_point_y.append(top)
		#images.append(image_2)
		image_2.save('/home/lap-011/Desktop/ML_work/13_04/{}_image_200.jpg'.format(i))
		

	#return images,starting_point_x,starting_point_y
	return croped_boxes


def crop_image_3(image):
	images = []
	starting_point_x = []
	starting_point_y = []
	image_width, image_height = image.size


	for i in range(0,2):
		if i == 0:
			left = 0
			right = image_width /(100/70)
		else:
			left = image_width / (100/30)
			right = image_width 
		'''Image 1'''
		top = 0
		bottom = image_height/(100/40)
		image_1 = image.crop((left, top, right, bottom))
		starting_point_x.append(left)
		starting_point_y.append(top)
		images.append(image_1)
		image_1.save('/home/lap-011/Desktop/ML_work/13_04/{}_image_1.jpg'.format(i))

		'''Image 2'''
		top = image_height/(100/40)
		bottom = image_height/(100/60)
		image_2 = image.crop((left, top, right, bottom))
		starting_point_x.append(left)
		starting_point_y.append(top)
		images.append(image_2)
		image_2.save('/home/lap-011/Desktop/ML_work/13_04/{}_image_2.jpg'.format(i))

		'''Image 3'''
		top = image_height/(100/40)
		bottom = image_height/(100/80)
		image_3 = image.crop((left, top, right, bottom))
		starting_point_x.append(left)
		starting_point_y.append(top)
		images.append(image_3)
		image_3.save('/home/lap-011/Desktop/ML_work/13_04/{}_image_3.jpg'.format(i))

		'''Image 4'''
		top = image_height/(100/80)
		bottom = image_height/(100/100)
		image_4 = image.crop((left, top, right, bottom))
		starting_point_x.append(left)
		starting_point_y.append(top)
		images.append(image_4)
		image_4.save('/home/lap-011/Desktop/ML_work/13_04/{}_image_4.jpg'.format(i))

		'''Image 5'''
		top = 0
		bottom = image_height/(100/60)
		image_5 = image.crop((left, top, right, bottom))
		starting_point_x.append(left)
		starting_point_y.append(top)
		images.append(image_5)
		image_5.save('/home/lap-011/Desktop/ML_work/13_04/{}_image_5.jpg'.format(i))

		'''Image 6'''
		top = image_height/(100/60)
		bottom = image_height/(100/100)
		image_6 = image.crop((left, top, right, bottom))
		starting_point_x.append(left)
		starting_point_y.append(top)
		images.append(image_6)
		image_6.save('/home/lap-011/Desktop/ML_work/13_04/{}_image_6.jpg'.format(i))

		'''Image 7'''
		top = 0
		bottom = image_height/(100/20)
		image_7 = image.crop((left, top, right, bottom))
		starting_point_x.append(left)
		starting_point_y.append(top)
		images.append(image_7)
		image_7.save('/home/lap-011/Desktop/ML_work/13_04/{}_image_7.jpg'.format(i))

		'''Image 8'''
		top = image_height/(100/20)
		bottom = image_height/(100/40)
		image_8 = image.crop((left, top, right, bottom))
		starting_point_x.append(left)
		starting_point_y.append(top)
		images.append(image_8)
		image_8.save('/home/lap-011/Desktop/ML_work/13_04/{}_image_8.jpg'.format(i))

	return images,starting_point_x,starting_point_y

def crop_image(image):
	images = []
	#starting_point_x = []
	#starting_point_y = []
	croped_boxes = []
	image_width, image_height = image.size

	for i in range(0,3):
		if i == 0:
			left = 0
			right = image_width // (100/40)
		elif i  == 1:
			left = image_width // (100/30)
			right = image_width // (100/70)
		else:
			left = image_width // (100/60)
			right = image_width

		'''Image 1'''
		top = image_height//(100/5)
		bottom = image_height//(100/35)
		image_1 = image.crop((left, top, right, bottom))
		#starting_point_x.append(left)
		#starting_point_y.append(top)
		#images.append(image_1)
		#image_1.save('/home/lap-011/Desktop/ML_work/13_04/{}_image_1.jpg'.format(i))
		croped_boxes.append([int(left),int(top),int(right),int(bottom)])

		'''Image 2'''
		top = image_height // (100/25)
		bottom = image_height // (100/55) 
		image_2 = image.crop((left, top, right, bottom))
		#starting_point_x.append(left)
		#starting_point_y.append(top)
		#images.append(image_2)
		#image_2.save('/home/lap-011/Desktop/ML_work/13_04/{}_image_2.jpg'.format(i))
		croped_boxes.append([int(left),int(top),int(right),int(bottom)])
		'''Image 3'''
		top = image_height // (100/45)
		bottom = image_height // (100/75)
		image_3 = image.crop((left, top, right, bottom))
		#starting_point_x.append(left)
		#starting_point_y.append(top)
		#images.append(image_3)
		#image_3.save('/home/lap-011/Desktop/ML_work/13_04/{}_image_3.jpg'.format(i))
		croped_boxes.append([int(left),int(top),int(right),int(bottom)])
		'''Image 4'''
		top = image_height // (100/65)
		bottom = image_height // (100/100)
		image_4 = image.crop((left, top, right, bottom))
		#starting_point_x.append(left)
		#starting_point_y.append(top)
		#images.append(image_4)
		#image_4.save('/home/lap-011/Desktop/ML_work/13_04/{}_image_4.jpg'.format(i))
		croped_boxes.append([int(left),int(top),int(right),int(bottom)])
		'''
		Image 5
		top = image_height/(100/60)
		bottom = image_height/(100/85)
		image_5 = image.crop((left, top, right, bottom))
		starting_point_x.append(left)
		starting_point_y.append(top)
		images.append(image_5)
		image_5.save('/home/lap-011/Desktop/ML_work/13_04/{}_image_5.jpg'.format(i))

		Image 6
		top = image_height/(100/75)
		bottom = image_height
		image_6 = image.crop((left, top, right, bottom))
		starting_point_x.append(left)
		starting_point_y.append(top)
		images.append(image_6)
		image_6.save('/home/lap-011/Desktop/ML_work/13_04/{}_image_6.jpg'.format(i))
		'''
	return croped_boxes

def letterbox_image(image, size):
	'''resize image with unchanged aspect ratio using padding'''
	image_width, image_height = image.size 
	model_width, model_height = size
	scale = min(model_width/image_width, model_height/image_height)
	new_width = int(image_width*scale)
	new_height = int(image_height*scale)

	image = image.resize((new_width,new_height), Image.BICUBIC) #Resizes image and resampling filter cubic spline interpolation is used.
	new_image = Image.new('RGB', size, (128,128,128)) #Creates new image with mode RGB, model size and color.This color is used as the background color.
	new_image.paste(image, ((model_width-new_width)//2, (model_height-new_height)//2)) #Paste image into new image.The values in tuple are the left upper cordinates of new image, where the image is pasted.
	return new_image

def rand(a=0, b=1):
	return np.random.rand()*(b-a) + a

def get_random_data(annotation_line, input_shape, random=True, max_boxes=20, jitter=.3, hue=.1, sat=1.5, val=1.5, proc_img=True):
	'''random preprocessing for real-time data augmentation'''
	line = annotation_line.split()
	image = Image.open(line[0])
	image_width, image_height = image.size
	h, w = input_shape
	box = np.array([np.array(list(map(int,box.split(',')))) for box in line[1:]])

	if not random:
		# resize image
		scale = min(w/image_width, h/image_height)
		new_width = int(image_width*scale)
		new_height = int(image_height*scale)
		dx = (w-new_width)//2
		dy = (h-new_height)//2
		image_data=0
		if proc_img:
			image = image.resize((new_width,new_height), Image.BICUBIC)
			new_image = Image.new('RGB', (w,h), (128,128,128))
			new_image.paste(image, (dx, dy))
			image_data = np.array(new_image)/255.

		# correct boxes
		box_data = np.zeros((max_boxes,5))
		if len(box)>0:
			np.random.shuffle(box)
			if len(box)>max_boxes: box = box[:max_boxes]
			box[:, [0,2]] = box[:, [0,2]]*scale + dx
			box[:, [1,3]] = box[:, [1,3]]*scale + dy
			box_data[:len(box)] = box

		return image_data, box_data

	# resize image
	new_ar = w/h * rand(1-jitter,1+jitter)/rand(1-jitter,1+jitter)
	scale = rand(.25, 2)
	if new_ar < 1:
		new_height = int(scale*h)
		new_width = int(new_height*new_ar)
	else:
		new_width = int(scale*w)
		new_height = int(new_width/new_ar)
	image = image.resize((new_width,new_height), Image.BICUBIC)

	# place image
	dx = int(rand(0, w-new_width))
	dy = int(rand(0, h-new_height))
	new_image = Image.new('RGB', (w,h), (128,128,128))
	new_image.paste(image, (dx, dy))
	image = new_image

	# flip image or not
	flip = rand()<.5
	if flip: image = image.transpose(Image.FLIP_LEFT_RIGHT)

	# distort image
	hue = rand(-hue, hue)
	sat = rand(1, sat) if rand()<.5 else 1/rand(1, sat)
	val = rand(1, val) if rand()<.5 else 1/rand(1, val)
	x = rgb_to_hsv(np.array(image)/255.)
	x[..., 0] += hue
	x[..., 0][x[..., 0]>1] -= 1
	x[..., 0][x[..., 0]<0] += 1
	x[..., 1] *= sat
	x[..., 2] *= val
	x[x>1] = 1
	x[x<0] = 0
	image_data = hsv_to_rgb(x) # numpy array, 0 to 1

	# correct boxes
	box_data = np.zeros((max_boxes,5))
	if len(box)>0:
		np.random.shuffle(box)
		box[:, [0,2]] = box[:, [0,2]]*new_width/image_width + dx
		box[:, [1,3]] = box[:, [1,3]]*new_height/image_height + dy
		if flip: box[:, [0,2]] = w - box[:, [2,0]]
		box[:, 0:2][box[:, 0:2]<0] = 0
		box[:, 2][box[:, 2]>w] = w
		box[:, 3][box[:, 3]>h] = h
		box_w = box[:, 2] - box[:, 0]
		box_h = box[:, 3] - box[:, 1]
		box = box[np.logical_and(box_w>1, box_h>1)] # discard invalid box
		if len(box)>max_boxes: box = box[:max_boxes]
		box_data[:len(box)] = box

	return image_data, box_data
