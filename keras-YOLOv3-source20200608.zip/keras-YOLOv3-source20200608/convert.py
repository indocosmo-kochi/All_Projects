#!/usr/bin/env python
# coding: utf-8

# In[7]:



"""
Reads Darknet config and weights and creates Keras model with TF backend.

"""

import argparse     #importing argparse module 
import io
import os
import configparser  #importing configparser,a Python class which implements a basic configuration language for Python programs.
from collections import defaultdict

import numpy as np
from keras import backend as K
from keras.layers import (Conv2D, Input, ZeroPadding2D, Add,
                          UpSampling2D, MaxPooling2D, Concatenate)
from keras.layers.advanced_activations import LeakyReLU
from keras.layers.normalization import BatchNormalization
from keras.models import Model
from keras.utils.vis_utils import plot_model as plot
from keras.regularizers import l2


parser = argparse.ArgumentParser(description='Convert Darknet To Keras.') #parser is creating with ArgumentParser
parser.add_argument('config_path', help='Path converted to Darknet cfg file.') #adding new parameter config_path ,help option gives argument help
parser.add_argument('weights_path', help='Path converted to Darknet weights file.') #adding new parameter weights_path ,help option gives argument help
parser.add_argument('output_path', help='Path converted to output Keras model file.') #adding new parameter output_path ,help option gives argument help
parser.add_argument(
    '-p',
    '--plot_model',
    help='Plot of keras model is generated and saves as image.',
    action='store_true') #plotting model and saving as an image,the action set to store_true will store the argument as True, if present.The help option gives argument help. 
parser.add_argument(
    '-w',
    '--weights_only',
    help='Instead of model file, save as keras weights file.',
    action='store_true') ##saving weights instead of model,the action set to store_true will store the argument as True, if present.The help option gives argument help. 

def unique_config_sections(config_file):
    """Convert all config sections to have unique names.

    Adds unique suffixes to config sections for compability with configparser.
    """
    config_sections = defaultdict(int)# initialising section_counters is equal to defaultdict(int) factory function.Interpreter is integer that means we’re going to work with only integer values.
    output_stream = io.StringIO()#StringIO() that reads and writes a string buffer ,it can be initialized to an existing string by passing the string to the constructor.
    with open(config_file) as finput:#opening config_file
        for line in finput:
            if line.startswith('['):
                first_section = line.strip().strip('[]')
                second_section = first_section + '_' + str(config_sections[first_section])
                config_sections[first_section] += 1
                line = line.replace(first_section, second_section)
            output_stream.write(line)
    output_stream.seek(0)
    return output_stream


def _main(args):
    config_path = os.path.expanduser(args.config_path) #expand initial path component-config_path
    weights_path = os.path.expanduser(args.weights_path)#expand initial path component-weights_path
    assert config_path.endswith('.cfg'), '{} is not a .cfg file'.format( 
        config_path)#checks whether path ends with .cfg
    assert weights_path.endswith(
        '.weights'), '{} is not a .weights file'.format(weights_path)

    output_path = os.path.expanduser(args.output_path)#expand initial path component-output_path
    assert output_path.endswith(
        '.h5'), 'output path {} is not a .h5 file'.format(output_path)#checks whether path ends with .h5
    output_root = os.path.splitext(output_path)[0]#split path into pair root and ext

    # Load weights and config.
     
    print('Loading weights.')
    weights_file = open(weights_path, 'rb')
    major, minor, revision = np.ndarray(
        shape=(3, ), dtype='int32', buffer=weights_file.read(12))
    if (major*10+minor)>=2 and major<1000 and minor<1000:
        seen = np.ndarray(shape=(1,), dtype='int64', buffer=weights_file.read(8))
    else:
        seen = np.ndarray(shape=(1,), dtype='int32', buffer=weights_file.read(4))
    print('Weights Header: ', major, minor, revision, seen)
    
    print('Parsing Darknet config...')
    unique_config_file = unique_config_sections(config_path)
    config_parser = configparser.ConfigParser()
    config_parser.read_file(unique_config_file)

    print('Creating Keras model...')
    input_layer = Input(shape=(None, None, 3))
    previous_layer = input_layer
    total_layers = []

    weight_decay = float(config_parser['net_0']['decay']
                         ) if 'net_0' in config_parser.sections() else 5e-4
    count = 0
    out_index = []
    for section in config_parser.sections():
        print('Parsing section {}'.format(section))
        if section.startswith('convolutional'):
            filters = int(config_parser[section]['filters'])
            size = int(config_parser[section]['size'])
            stride = int(config_parser[section]['stride'])#to contol filter convolution aroun input volume
            pad = int(config_parser[section]['pad'])
            activation = config_parser[section]['activation']
            batch_normalize = 'batch_normalize' in config_parser[section]#to increase training speed

            padding = 'same' if pad == 1 and stride == 1 else 'valid'#to maintain input dimension
            previous_layer_shape = K.int_shape(previous_layer)#Returns the shape of tensor or variable as a tuple of int or None entries
            weights_shape = (size, size, previous_layer_shape[-1], filters) # Setting weights.
            darknet_w_shape = (filters, weights_shape[2], size, size)# Darknet serializes convolutional weights as:[bias/beta, [gamma, mean, variance], conv_weights]
            weights_size = np.product(weights_shape)

            print('conv2d', 'bn'
                  if batch_normalize else '  ', activation, weights_shape)

            conv_bias = np.ndarray(
                shape=(filters, ),
                dtype='float32',
                buffer=weights_file.read(filters * 4))
            count += filters

            if batch_normalize:
                bn_weights = np.ndarray(
                    shape=(3, filters),
                    dtype='float32',
                    buffer=weights_file.read(filters * 12))
                count += 3 * filters

                bn_weight_list = [
                    bn_weights[0],  # scale gamma
                    conv_bias,  # shift beta
                    bn_weights[1],  # running mean
                    bn_weights[2]  # running var
                ]

            conv_weights = np.ndarray(
                shape=darknet_w_shape,
                dtype='float32',
                buffer=weights_file.read(weights_size * 4))
            count += weights_size

             
           
            conv_weights = np.transpose(conv_weights, [2, 3, 1, 0])#to find transpose of conv_weights
            conv_weights = [conv_weights] if batch_normalize else [
                conv_weights, conv_bias
            ]

            # Handle activation.
            act_fn = None
            if activation == 'leaky':
                pass  # Add advanced activation later.
            elif activation != 'linear':
                raise ValueError(
                    'Unknown activation function `{}` in section {}'.format(
                        activation, section))

            # Create Conv2D layer
            if stride>1:
                 #instead os 'same' mode , darknet uses top and left padding
                previous_layer = ZeroPadding2D(((1,0),(1,0)))(previous_layer)
            convolution_layer = (Conv2D(
                filters, (size, size),
                strides=(stride, stride),
                kernel_regularizer=l2(weight_decay),#Tries to reduce the weights W (excluding bias)
                use_bias=not batch_normalize,
                weights=conv_weights,
                activation=act_fn,
                padding=padding))(previous_layer)

            if batch_normalize:
                convolution_layer = (BatchNormalization(
                    weights=bn_weight_list))(convolution_layer)
            previous_layer = convolution_layer

            if activation == 'linear':#if activation function used is linear
                total_layers.append(previous_layer)
            elif activation == 'leaky':#if activation function used is leaky
                activation_layer = LeakyReLU(alpha=0.1)(previous_layer)
                previous_layer = activation_layer
                total_layers.append(activation_layer)

        elif section.startswith('route'):
            ids = [int(i) for i in config_parser[section]['layers'].split(',')]
            layers = [total_layers[i] for i in ids]
            if len(layers) > 1:
                print('Concatenating route layers:', layers)#concatenation of route layers
                concat_layer = Concatenate()(layers)
                total_layers.append(concat_layer)
                previous_layer = concat_layer
            else:
                skip_layer = layers[0]  # only one layer to route
                total_layers.append(skip_layer)
                previous_layer = skip_layer

        elif section.startswith('maxpool'):#if discretization process is maxpooling
            size = int(config_parser[section]['size'])
            stride = int(config_parser[section]['stride'])
            total_layers.append(
                MaxPooling2D(
                    pool_size=(size, size),
                    strides=(stride, stride),
                    padding='same')(previous_layer))
            previous_layer = total_layers[-1]

        elif section.startswith('shortcut'):#used to skip one or more layers
            index = int(config_parser[section]['from'])
            activation = config_parser[section]['activation']
            assert activation == 'linear', 'Only linear activation supported.'
            total_layers.append(Add()([total_layers[index], previous_layer]))
            previous_layer = total_layers[-1]

        elif section.startswith('upsample'):#to upsample which help to increase resolution, and reduce noise
            stride = int(config_parser[section]['stride'])
            assert stride == 2, 'Only stride=2 supported.'
            total_layers.append(UpSampling2D(stride)(previous_layer))
            previous_layer = total_layers[-1]

        elif section.startswith('yolo'):
            out_index.append(len(total_layers)-1)
            total_layers.append(None)
            previous_layer = total_layers[-1]

        elif section.startswith('net'):
            pass

        else:
            raise ValueError(
                'Unsupported section header type: {}'.format(section))

    # Create and save model.
    if len(out_index)==0: out_index.append(len(total_layers)-1)
    model = Model(inputs=input_layer, outputs=[total_layers[i] for i in out_index])
    print(model.summary())
    if args.weights_only:
        model.save_weights('{}'.format(output_path))
        print('Saved Keras weights to {}'.format(output_path))
    else:
        model.save('{}'.format(output_path))
        print('Saved Keras model to {}'.format(output_path))

    # To check if all weights have been read.
    remaining_weights = len(weights_file.read()) / 4
    weights_file.close()
    print('Read {} of {} from Darknet weights.'.format(count, count +
                                                       remaining_weights))
    if remaining_weights > 0:
        print('Warning: {} unused weights'.format(remaining_weights))

    if args.plot_model:
        plot(model, to_file='{}.png'.format(output_root), show_shapes=True)
        print('Saved model plot to {}.png'.format(output_root))


if __name__ == '__main__':
    _main(parser.parse_args())


# In[ ]:




