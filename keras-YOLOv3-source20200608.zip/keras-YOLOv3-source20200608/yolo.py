"""
Class Prediction of YOLO_v3 model  
"""
import os
import colorsys
import numpy as np
from PIL import Image, ImageFont, ImageDraw
from keras import backend as K
from keras.utils import multi_gpu_model
from keras.models import load_model
from keras.layers import Input
from yolo3.model import yolo_eval, yolo_body
from yolo3.utils import letterbox_image
from yolo3.utils import crop_image,bounding_boxes
import cv2
from skimage.util import random_noise

class YOLO(object):
	_defaults = {
		"model_path": 'model_data/yolo.h5',
		"anchors_path": 'model_data/yolo_anchors.txt',
		"classes_path": 'model_data/_classes.txt',
		"score" : 0.75,
		"iou" : 0.5,
		"model_image_size" : (416, 416),
	}

	@classmethod
	def get_defaults(cls, n):
		if n in cls._defaults:
			return cls._defaults[n]
		else:
			return "Unrecognized attribute name '" + n + "'"

	'''initializing the attributes of class'''
	def __init__(self, **kwargs):
		self.__dict__.update(self._defaults) # set up default values
		self.__dict__.update(kwargs) # and update with user overrides
		self.class_names = self._get_class()
		self.anchors = self._get_anchors()
		self.sess = K.get_session()
		self.boxes, self.scores, self.classes = self.generate()

	def _get_class(self):
		classes_path = os.path.expanduser(self.classes_path)
		with open(classes_path) as f:
			class_names = f.readlines()
		class_names = [c.strip() for c in class_names]
		return class_names

	def _get_anchors(self):
		anchors_path = os.path.expanduser(self.anchors_path)
		with open(anchors_path) as f:
			anchors = f.readline()
		anchors = [float(x) for x in anchors.split(',')]
		return np.array(anchors).reshape(-1, 2)

	def generate(self):
		model_path = os.path.expanduser(self.model_path)
		assert model_path.endswith('.h5'), 'Keras model or weights must be a .h5 file.'

		# Load model, or construct model and load weights.
		num_anchors = len(self.anchors)
		num_classes = len(self.class_names)
		self.yolo_model = yolo_body(Input(shape=(None,None,3)), num_anchors//3, num_classes)
		self.yolo_model.load_weights(self.model_path)
		print('{} model, anchors, and classes loaded.'.format(model_path))

		# Generate colors for drawing bounding boxes.
		hsv_tuples = [(x / len(self.class_names), 1., 1.)
					  for x in range(len(self.class_names))]
		self.colors = list(map(lambda x: colorsys.hsv_to_rgb(*x), hsv_tuples))
		self.colors = list(
			map(lambda x: (int(x[0] * 255), int(x[1] * 255), int(x[2] * 255)),
				self.colors))
		np.random.seed(10101)  # Fixed seed for consistent colors across runs.
		np.random.shuffle(self.colors)  # Shuffle colors to decorrelate adjacent classes.
		np.random.seed(None)  # Reset seed to default.

		# Generate output tensor targets for filtered bounding boxes.
		self.input_image_shape = K.placeholder(shape=(2, ))
		
		'''Evaluate YOLO model on given input and return filtered boxes'''
		boxes, scores, classes = yolo_eval(self.yolo_model.output, self.anchors,
				len(self.class_names), self.input_image_shape,
				score_threshold=self.score, iou_threshold=self.iou)
		return boxes, scores, classes

	def detect_image(self, pdf_image):
		#images,starting_point_x,starting_point_y = crop_image(pdf_image)
		#images,starting_point_x,starting_point_y = bounding_boxes(pdf_image)
		croped_boxes = crop_image(pdf_image)
		#print('croped_boxes:',type(croped_boxes[0][0]))
		bound_boxes = bounding_boxes(pdf_image)
		#print('bound_boxes:',type(bound_boxes[0][0]))
		#bound_boxes.append(croped_boxes)
		combined_images = []
		combined_images = bound_boxes + croped_boxes
		#print('combined_images:',combined_images)
		s_and_p_image = pdf_image
		ROI_images = [] #save objects from images
		for j,bound_box in enumerate(combined_images):
			#print(bound_box[0],bound_box[1],bound_box[2],bound_box[3])
			s_and_p_image = np.array(s_and_p_image)
			s_and_p_image = cv2.cvtColor(s_and_p_image, cv2.COLOR_BGR2RGB)
			#cv2.imwrite('/home/lap-011/Desktop/ML_work/13_04/binary_image2.jpg', s_and_p_image)
			#image = s_and_p_image.crop((bound_box[0],bound_box[1],bound_box[2],bound_box[3]))
			#print(type(s_and_p_image))
			image = s_and_p_image[bound_box[1]:bound_box[3],bound_box[0]:bound_box[2]]
			image = Image.fromarray(image)
			if self.model_image_size != (None, None):
				boxed_image = letterbox_image(image, tuple(reversed(self.model_image_size)))
			image_data = np.array(boxed_image, dtype='float32')
			#print(image_data.shape)
			image_data /= 255.
			image_data = np.expand_dims(image_data, 0)  # Add batch dimension.
			output_boxes, output_scores, output_classes = self.sess.run(
				[self.boxes, self.scores, self.classes],
				feed_dict={
					self.yolo_model.input: image_data,
					self.input_image_shape: [image.size[1], image.size[0]],
					K.learning_phase(): 0 #learning_phase flag 0 for test time
				})

			#print('Found {} boxes for {}'.format(len(output_boxes), j))
			
			font = ImageFont.truetype(font='font/FiraMono-Medium.otf',
						size=np.floor(3e-2 * image.size[1] + 0.5).astype('int32')) #font used to write class name on image
			thickness = (image.size[0] + image.size[1]) // 300 #thickness of box for class name

			roi = 1 #region of image
			
			for i, c in reversed(list(enumerate(output_classes))):
				predicted_class = self.class_names[c] #predicted class
				box = output_boxes[i] #predicted cordinates top_left_y,top_left_x,bottom_right_y,bottom_right_x
				score = output_scores[i] #predicted score of object

				if predicted_class != 'others': #removing unwanted objects from image

					label = '{} {:.2f}'.format(predicted_class, score) 
					draw = ImageDraw.Draw(pdf_image) #draw bounding boxes in image
					label_size = draw.textsize(label, font)
					#print(starting_point_x[j],starting_point_y[j])
					top_left_y, top_left_x, bottom_right_y, bottom_right_x = box
					top_left_y = max(0, np.floor(top_left_y + 0.5).astype('int32')) + bound_box[1] #starting_point_y[j]
					top_left_x = max(0, np.floor(top_left_x + 0.5).astype('int32')) + bound_box[0] #starting_point_x[j]
					bottom_right_y = min(image.size[1], np.floor(bottom_right_y + 0.5).astype('int32')) + bound_box[1] #starting_point_y[j]
					bottom_right_x = min(image.size[0], np.floor(bottom_right_x + 0.5).astype('int32')) + bound_box[0] #starting_point_x[j]
					print(label, (top_left_x, top_left_y), (bottom_right_x, bottom_right_y))
					im = pdf_image.crop((top_left_x, top_left_y, bottom_right_x, bottom_right_y)) #crop the particular object from image
					ROI_images.append(im)
					noise_pdf_image = random_noise(np.array(im), mode='salt',amount=1)
					noise_pdf_image = np.array(255*noise_pdf_image, dtype = 'uint8')
					s_and_p_image[top_left_y : bottom_right_y , top_left_x : bottom_right_x] = noise_pdf_image
					#s_and_p_image.paste(noise_pdf_image, (top_left_x, top_left_y))

					
					'''Variable for aligning the text'''
					if top_left_y - label_size[1] >= 0:
						text_origin = np.array([top_left_x, top_left_y - label_size[1]])
					else:
						text_origin = np.array([top_left_x, top_left_y + 1])

					for i in range(thickness):
						#Draw bounding box around object.
						draw.rectangle(
							[top_left_x + i, top_left_y + i, bottom_right_x - i, bottom_right_y - i],
							outline=self.colors[c])
					#Draw bounding box around class name and score.
					draw.rectangle(
						[tuple(text_origin), tuple(text_origin + label_size)],
						fill=self.colors[c])
					#Draw the text at particular position,with color and font.
					draw.text(text_origin, label, fill=(0, 0, 0), font=font)
					del draw
			#cv2.imwrite('/home/lap-011/Desktop/ML_work/13_04/binary_image.jpg', s_and_p_image)
		return pdf_image,ROI_images

	def close_session(self):
		self.sess.close()
