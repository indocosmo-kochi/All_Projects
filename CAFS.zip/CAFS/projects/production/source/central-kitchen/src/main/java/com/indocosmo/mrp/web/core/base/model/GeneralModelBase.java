package com.indocosmo.mrp.web.core.base.model;

public abstract class GeneralModelBase extends ModelBase {

}
