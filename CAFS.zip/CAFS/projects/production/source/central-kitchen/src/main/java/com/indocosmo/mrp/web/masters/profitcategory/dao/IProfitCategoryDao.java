package com.indocosmo.mrp.web.masters.profitcategory.dao;



import com.indocosmo.mrp.web.core.base.dao.IMasterBaseDao;
import com.indocosmo.mrp.web.masters.profitcategory.model.ProfitCategory;


public interface IProfitCategoryDao extends IMasterBaseDao<ProfitCategory>{

}
