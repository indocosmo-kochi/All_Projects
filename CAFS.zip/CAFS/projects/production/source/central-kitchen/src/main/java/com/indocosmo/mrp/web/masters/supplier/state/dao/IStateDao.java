package com.indocosmo.mrp.web.masters.supplier.state.dao;
import com.indocosmo.mrp.web.core.base.dao.IGeneralDao;
import com.indocosmo.mrp.web.masters.supplier.state.model.State;

public interface IStateDao extends  IGeneralDao<State>{


}