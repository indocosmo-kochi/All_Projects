package com.indocosmo.mrp.web.masters.reasons.dao;

import com.indocosmo.mrp.web.core.base.dao.IGeneralDao;
import com.indocosmo.mrp.web.masters.reasons.model.Reasons;


public interface IReasonsDao extends IGeneralDao<Reasons>{

	
	
}
