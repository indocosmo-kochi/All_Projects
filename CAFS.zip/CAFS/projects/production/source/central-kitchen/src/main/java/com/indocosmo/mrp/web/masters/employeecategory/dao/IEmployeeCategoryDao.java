package com.indocosmo.mrp.web.masters.employeecategory.dao;

import com.indocosmo.mrp.web.core.base.dao.IMasterBaseDao;
import com.indocosmo.mrp.web.masters.employeecategory.model.EmployeeCategory;


public interface IEmployeeCategoryDao extends IMasterBaseDao<EmployeeCategory> {

}
