package com.indocosmo.mrp.web.production.planning.bookingsummary.service;

import com.google.gson.JsonArray;
import com.indocosmo.mrp.web.core.base.application.ApplicationContext;
import com.indocosmo.mrp.web.core.base.service.GeneralService;
import com.indocosmo.mrp.web.production.planning.bookingsummary.dao.OrderBookingDao;
import com.indocosmo.mrp.web.production.planning.bookingsummary.model.OrderBoonkingSummary;
import com.indocosmo.mrp.web.production.planning.planningdetail.dao.PlanningDetailDao;
import com.indocosmo.mrp.web.production.planning.planningdetail.model.PlanningDetail;


public class OrderBookingService extends GeneralService<OrderBoonkingSummary,OrderBookingDao> implements IOrderBookingService{

	
	private OrderBookingDao planningDao;

	public OrderBookingService(ApplicationContext context) {
		super(context);
		planningDao=new OrderBookingDao(getContext());
	}

	@Override
	public OrderBookingDao getDao() {
		// TODO Auto-generated method stub
		return planningDao;
	}

	/**
	 * @return
	 */
	public JsonArray getBalanceQtyData() throws Exception{
		// TODO Auto-generated method stub
		return planningDao.getBalanceQtyData();
	}

	/**
	 * @param isWalkIn
	 * @return
	 */
	public Boolean checkIsWalkInCustomer(Integer isWalkIn) throws Exception{
		// TODO Auto-generated method stub
		return planningDao.checkIsWalkInCustomer(isWalkIn);
	}

}
