package com.indocosmo.mrp.web.masters.kitchen.service;



import com.indocosmo.mrp.web.core.base.service.IMasterBaseService;
import com.indocosmo.mrp.web.masters.kitchen.dao.KitchenDao;
import com.indocosmo.mrp.web.masters.kitchen.model.Kitchen;


public interface IKitchenService  extends IMasterBaseService<Kitchen,KitchenDao>{


}
