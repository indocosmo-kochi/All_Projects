package com.indocosmo.mrp.web.core.base.service;

import com.indocosmo.mrp.web.core.base.dao.MasterBaseDao;
import com.indocosmo.mrp.web.core.base.model.MasterModelBase;

public interface IMasterBaseService<T extends MasterModelBase, D extends MasterBaseDao<T>> extends IGeneralService<T,D>{
	

	
	
}
