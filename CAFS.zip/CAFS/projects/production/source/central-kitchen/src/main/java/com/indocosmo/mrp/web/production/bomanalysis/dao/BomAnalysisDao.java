package com.indocosmo.mrp.web.production.bomanalysis.dao;

import com.google.gson.JsonArray;
import com.indocosmo.mrp.web.core.base.application.ApplicationContext;
import com.indocosmo.mrp.web.core.base.dao.GeneralDao;
import com.indocosmo.mrp.web.production.bomanalysis.model.BomAnalysis;


public class BomAnalysisDao extends GeneralDao<BomAnalysis> implements IBomAnalysisDao{

	public BomAnalysisDao(ApplicationContext context) {
	
		super(context);
	}

	@Override
	public BomAnalysis getNewModelInstance() {
	
		// TODO Auto-generated method stub
		return new BomAnalysis();
	}

	@Override
	protected String getTable() {
	
		// TODO Auto-generated method stub
		return "stock_item_bom";
	}

	public JsonArray getItemData(String selectDate,String departmentId) throws Exception{
	String sql="";
		/*String sql="SELECT TBL.*,(TBL.opening_stock + TBL.stock_in) AS total,"
				+ "(TBL.opening_stock + TBL.stock_in - TBL.bom_consumption) AS closing_stock,"
				+ "0 AS actual_stock,'0' AS adjust "
				+ "FROM "
				+ "(SELECT skitm.id AS stock_item_id,skitm.`name` AS stock_item_name,"
				+ "skitm.`code` AS stock_item_code,SUM(mbm.prod_qty) AS bom_consumption,pdl.department_id AS department_id,"
				+"mdptm.`name` AS department_name,"
				+ "IFNULL((SELECT SUM(sregdtl.in_qty - sregdtl.out_qty) "
				+ "FROM mrp_stock_register_hdr sreghdr "
				+ "INNER JOIN mrp_stock_register_dtl sregdtl ON sreghdr.id = sregdtl.stock_register_hdr_id "
				+ "INNER JOIN mrp_department mdp ON sregdtl.department_id = mdp.id "
				+ "WHERE "
				+ "sregdtl.department_id = pdl.department_id AND sregdtl.stock_item_id = skitm.id "
				+ "AND sreghdr.txn_date < '"+selectDate+"' "
				+ "AND mdp.dept_type = 1 AND mdp.id != 0 GROUP BY department_id,stock_item_id),0) AS opening_stock,"
				+ "IFNULL((SELECT SUM(sregdtl.in_qty) "
				+ "FROM mrp_stock_register_hdr sreghdr "
				+ "INNER JOIN mrp_stock_register_dtl sregdtl ON sreghdr.id = sregdtl.stock_register_hdr_id "
				+ "INNER JOIN mrp_department mdp ON sregdtl.department_id = mdp.id "
				+ "WHERE "
				+ "sregdtl.department_id = pdl.department_id "
				+ "AND sregdtl.stock_item_id = skitm.id "
				+ "AND sreghdr.txn_date = '"+selectDate+"' "
				+ "AND mdp.dept_type = 1 "
				+ "AND mdp.id != 0 GROUP BY department_id,stock_item_id),0) AS stock_in "
				+ "FROM "
				+ "mrp_prod_hdr phdr "
				+ "INNER JOIN mrp_prod_dtl pdl ON phdr.id = pdl.prod_hdr_id "
				+ "INNER JOIN mrp_prod_bom mbm ON pdl.id = mbm.prod_dtl_id "
				+ "INNER JOIN mrp_stock_item skitm ON mbm.stock_item_id = skitm.id "
				+"INNER JOIN mrp_department mdptm ON mdptm.id=pdl.department_id"
				+ " WHERE phdr.prod_date = '"+selectDate+"' "
				+ "GROUP BY department_id,stock_item_id) TBL";*/
	
		if(departmentId==null){
			departmentId="0";
		}
		
		sql="CALL usp_bom_analysis('"+selectDate+"','"+departmentId+"')";
		return getTableRowsAsJson(sql);
	}

	public JsonArray getBomConsumption(String selectdate , String departmentId , String stockItemId) throws Exception{
	
		// TODO Auto-generated method stub
		/*String sql="SELECT phdr.prod_date,pdtl.department_id,pdtl.stock_item_id,pdtl.prod_qty,"
				+ "mstk.name AS stock_item_name,mstk.code stock_item_code,mpbm.stock_item_id AS bom_item_id,"
				+" msk.`name`as bom_item_name,"
				+ "mpbm.prod_qty AS bom_quantity "
				+ "FROM mrp_prod_hdr phdr "
				+ "INNER JOIN mrp_prod_dtl pdtl ON phdr.id = pdtl.prod_hdr_id "
				+ "INNER JOIN mrp_stock_item mstk ON pdtl.stock_item_id = mstk.id "
				+ "INNER JOIN mrp_prod_bom mpbm ON pdtl.id = mpbm.prod_dtl_id "
				+" INNER  JOIN mrp_stock_item msk ON mpbm.stock_item_id=msk.id"
				+ " WHERE "
				+ "phdr.prod_date = '"+selectdate+"' "
				+ "AND department_id = '"+departmentId+"' "
				+ "AND mpbm.stock_item_id = '"+stockItemId+"'";*/
		
		String sql="SELECT phdr.prod_date,pdtl.department_id,pdtl.stock_item_id,SUM(pdtl.prod_qty) AS prod_qty,"
				+ "mstk.name AS stock_item_name,mstk.code stock_item_code,mpbm.stock_item_id AS bom_item_id,"
				+" msk.`name`as bom_item_name,"
				+ "	SUM(mpbm.prod_qty) AS bom_quantity "
				+ "FROM mrp_prod_hdr phdr "
				+ "INNER JOIN mrp_prod_dtl pdtl ON phdr.id = pdtl.prod_hdr_id "
				+ "INNER JOIN mrp_stock_item mstk ON pdtl.stock_item_id = mstk.id "
				+ "INNER JOIN mrp_prod_bom mpbm ON pdtl.id = mpbm.prod_dtl_id "
				+" INNER  JOIN mrp_stock_item msk ON mpbm.stock_item_id=msk.id"
				+ " WHERE "
				+ "phdr.prod_date = '"+selectdate+"' "
				+ "AND department_id = '"+departmentId+"' "
				+ "AND mpbm.stock_item_id = '"+stockItemId+"' GROUP BY stock_item_id ";
		
		
		 return getTableRowsAsJson(sql);
	}




	
	
	
	
}
