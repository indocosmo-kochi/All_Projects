package com.indocosmo.mrp.web.core.base.dao;

import com.indocosmo.mrp.web.core.base.model.MasterModelBase;

/**
 * @author jojesh-13.2
 *
 * @param <T>
 */
public interface IMasterBaseDao <T extends MasterModelBase> extends IGeneralDao<T>{


	
}
