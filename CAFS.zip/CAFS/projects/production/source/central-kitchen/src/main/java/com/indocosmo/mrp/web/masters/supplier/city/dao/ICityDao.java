package com.indocosmo.mrp.web.masters.supplier.city.dao;
import com.indocosmo.mrp.web.core.base.dao.IGeneralDao;
import com.indocosmo.mrp.web.masters.supplier.city.model.City;

public interface ICityDao extends  IGeneralDao<City>{


}