package com.indocosmo.mrp.web.production.bomanalysis.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.indocosmo.mrp.web.core.base.model.GeneralModelBase;

@Entity
@Table(name="")
public class BomAnalysis extends GeneralModelBase{
	
}
