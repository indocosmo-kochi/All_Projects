package com.indocosmo.mrp.web.masters.usergroup.sysdefpermission.service;

import com.indocosmo.mrp.web.core.base.service.IGeneralService;
import com.indocosmo.mrp.web.masters.usergroup.sysdefpermission.dao.SysdefPermissionDao;
import com.indocosmo.mrp.web.masters.usergroup.sysdefpermission.model.SysdefPermission;


public interface ISysdefPermissionService  extends IGeneralService<SysdefPermission,SysdefPermissionDao>{

}
