package com.indocosmo.mrp.web.core.counter.model;

import com.indocosmo.mrp.web.core.base.model.ModelBase;

public class Counter extends ModelBase {

}
