package com.indocosmo.mrp.utils;

public class PosellaConstants {

	public PosellaConstants() {
		// TODO Auto-generated constructor stub
	}

}
