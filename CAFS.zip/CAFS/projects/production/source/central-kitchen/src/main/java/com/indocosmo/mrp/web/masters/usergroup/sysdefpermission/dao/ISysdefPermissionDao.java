package com.indocosmo.mrp.web.masters.usergroup.sysdefpermission.dao;

import com.indocosmo.mrp.web.core.base.dao.IGeneralDao;
import com.indocosmo.mrp.web.masters.usergroup.sysdefpermission.model.SysdefPermission;




public interface ISysdefPermissionDao extends IGeneralDao<SysdefPermission>{

}
