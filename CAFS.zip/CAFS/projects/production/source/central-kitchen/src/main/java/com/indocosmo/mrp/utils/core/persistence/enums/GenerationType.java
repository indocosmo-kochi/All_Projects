package com.indocosmo.mrp.utils.core.persistence.enums;

public enum GenerationType {
	
	IDENTITY,
	COUNTER;

}
