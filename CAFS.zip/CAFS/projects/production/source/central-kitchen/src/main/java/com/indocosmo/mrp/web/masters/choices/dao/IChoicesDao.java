package com.indocosmo.mrp.web.masters.choices.dao;

import com.indocosmo.mrp.web.core.base.dao.IMasterBaseDao;
import com.indocosmo.mrp.web.masters.choices.model.Choices;


public interface IChoicesDao extends IMasterBaseDao<Choices> {

}
