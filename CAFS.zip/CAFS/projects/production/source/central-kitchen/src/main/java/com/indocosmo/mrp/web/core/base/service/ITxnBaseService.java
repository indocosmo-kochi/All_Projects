package com.indocosmo.mrp.web.core.base.service;

import com.indocosmo.mrp.web.core.base.dao.GeneralDao;
import com.indocosmo.mrp.web.core.base.model.GeneralModelBase;

public interface ITxnBaseService<T extends GeneralModelBase, D extends GeneralDao<T>> extends IGeneralService<T,D>{
	

	
	
}
