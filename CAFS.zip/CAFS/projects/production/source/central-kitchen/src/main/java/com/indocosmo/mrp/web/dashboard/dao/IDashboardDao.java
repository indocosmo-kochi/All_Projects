package com.indocosmo.mrp.web.dashboard.dao;

import com.indocosmo.mrp.web.core.base.dao.IGeneralDao;
import com.indocosmo.mrp.web.dashboard.model.Dashboard;


public interface IDashboardDao extends IGeneralDao<Dashboard>{

}
