package com.indocosmo.mrp.web.production.bomanalysis.service;

import com.google.gson.JsonArray;
import com.indocosmo.mrp.web.core.base.application.ApplicationContext;
import com.indocosmo.mrp.web.core.base.service.GeneralService;
import com.indocosmo.mrp.web.production.bomanalysis.dao.BomAnalysisDao;
import com.indocosmo.mrp.web.production.bomanalysis.model.BomAnalysis;


public class BomAnalysisService extends GeneralService<BomAnalysis, BomAnalysisDao> implements IBomAnalysisService{

	
	private BomAnalysisDao bomAnalysisDao;
	public BomAnalysisService(ApplicationContext context) {
	
		super(context);
		bomAnalysisDao=new BomAnalysisDao(getContext());
		// TODO Auto-generated constructor stub
	}

	@Override
	public BomAnalysisDao getDao() {
	
		// TODO Auto-generated method stub
		return bomAnalysisDao;
	}

	public JsonArray getItemData(String selectDate,String departmentId)  throws Exception{
	
		// TODO Auto-generated method stub
		return bomAnalysisDao.getItemData(selectDate,departmentId);
	}

	public JsonArray getBomConsumption(String selectdate , String departmentId , String stockItemId) throws Exception{
	
		// TODO Auto-generated method stub
		return bomAnalysisDao.getBomConsumption(selectdate,departmentId,stockItemId);
	}
	
}
