package com.indocosmo.mrp.web.masters.companyprofile.dao;

import com.indocosmo.mrp.web.core.base.dao.IGeneralDao;
import com.indocosmo.mrp.web.masters.companyprofile.model.CompanyProfile;



public interface ICompanyProfileDao extends IGeneralDao<CompanyProfile>{

}
