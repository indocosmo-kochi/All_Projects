package com.indocosmo.mrp.web.masters.itemslist.dao;

import com.indocosmo.mrp.web.core.base.dao.IGeneralDao;
import com.indocosmo.mrp.web.masters.itemslist.model.ItemsList;

public interface IItemsListDao extends IGeneralDao<ItemsList>{
	
	/*public List<ItemsList> getItems() throws Exception ;*/

}
