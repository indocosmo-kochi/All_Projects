package com.indocosmo.mrp.web.report.bomanalysisreport.dao;

import com.indocosmo.mrp.web.core.base.dao.IGeneralDao;
import com.indocosmo.mrp.web.report.bomanalysisreport.model.BomAnalysisReportModel;


public interface IBomAnalysisReportDao  extends IGeneralDao<BomAnalysisReportModel>{
	
}
