package com.indocosmo.mrp.web.masters.timeslot.dao;

import com.indocosmo.mrp.web.core.base.dao.IMasterBaseDao;
import com.indocosmo.mrp.web.masters.timeslot.model.Timeslot;

public interface ITimeslotDao extends IMasterBaseDao<Timeslot>{

}
