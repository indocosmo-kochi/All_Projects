package com.indocosmo.mrp.web.masters.kitchen.dao;

import com.indocosmo.mrp.web.core.base.dao.IMasterBaseDao;
import com.indocosmo.mrp.web.masters.kitchen.model.Kitchen;


public interface IKitchenDao extends IMasterBaseDao<Kitchen> {

}
