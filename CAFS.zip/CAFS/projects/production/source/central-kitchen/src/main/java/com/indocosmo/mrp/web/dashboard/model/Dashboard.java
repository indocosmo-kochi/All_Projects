package com.indocosmo.mrp.web.dashboard.model;

import javax.persistence.Entity;

import com.indocosmo.mrp.web.core.base.model.GeneralModelBase;

@Entity
public class Dashboard extends GeneralModelBase{

}
