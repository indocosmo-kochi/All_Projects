package com.indocosmo.mrp.web.core.base.model;


/**
 * Base model for all model classes
 * @author jojesh-13.2
 *
 */
public abstract class ModelBase {

	public ModelBase() {
		// TODO Auto-generated constructor stub
	}


}
