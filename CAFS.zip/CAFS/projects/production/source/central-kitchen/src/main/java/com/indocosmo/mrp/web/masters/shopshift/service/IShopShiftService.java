package com.indocosmo.mrp.web.masters.shopshift.service;



import com.indocosmo.mrp.web.core.base.service.IMasterBaseService;
import com.indocosmo.mrp.web.masters.shopshift.dao.ShopShiftDao;
import com.indocosmo.mrp.web.masters.shopshift.model.ShopShift;


public interface IShopShiftService  extends IMasterBaseService<ShopShift,ShopShiftDao>{


}
