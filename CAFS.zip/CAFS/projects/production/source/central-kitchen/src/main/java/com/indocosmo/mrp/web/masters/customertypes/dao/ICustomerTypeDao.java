package com.indocosmo.mrp.web.masters.customertypes.dao;

import com.indocosmo.mrp.web.core.base.dao.IMasterBaseDao;
import com.indocosmo.mrp.web.masters.customertypes.model.CustomerType;



public interface ICustomerTypeDao extends IMasterBaseDao<CustomerType>{

	

}
