package com.indocosmo.mrp.web.masters.areacode.dao;

import com.indocosmo.mrp.web.core.base.dao.IMasterBaseDao;
import com.indocosmo.mrp.web.masters.areacode.model.AreaCode;

public interface IAreaCodeDao extends IMasterBaseDao<AreaCode>{

}
