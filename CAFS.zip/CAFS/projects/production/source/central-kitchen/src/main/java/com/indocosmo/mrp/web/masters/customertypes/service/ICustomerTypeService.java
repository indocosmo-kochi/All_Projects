package com.indocosmo.mrp.web.masters.customertypes.service;






import com.indocosmo.mrp.web.core.base.service.IMasterBaseService;
import com.indocosmo.mrp.web.masters.customertypes.dao.CustomerTypeDao;
import com.indocosmo.mrp.web.masters.customertypes.model.CustomerType;



public interface ICustomerTypeService extends IMasterBaseService<CustomerType,CustomerTypeDao>{
	
	
	
}
