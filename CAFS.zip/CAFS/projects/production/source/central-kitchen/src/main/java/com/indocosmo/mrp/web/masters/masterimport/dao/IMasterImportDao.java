package com.indocosmo.mrp.web.masters.masterimport.dao;

import com.indocosmo.mrp.web.core.base.dao.IGeneralDao;
import com.indocosmo.mrp.web.masters.masterimport.model.MasterImport;

public interface IMasterImportDao extends IGeneralDao<MasterImport> {

}
