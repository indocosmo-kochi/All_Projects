package com.indocosmo.mrp.web.masters.masterimport.model;

import com.indocosmo.mrp.web.core.base.model.GeneralModelBase;

public class MasterImport extends GeneralModelBase {
	
}
