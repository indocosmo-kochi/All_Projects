package com.indocosmo.mrp.web.masters.terminal.dao;

import com.indocosmo.mrp.web.core.base.dao.IMasterBaseDao;
import com.indocosmo.mrp.web.masters.terminal.model.Terminal;


public interface ITerminalDao extends IMasterBaseDao<Terminal> {

}
