package com.indocosmo.mrp.web.masters.discounts.dao;




import com.indocosmo.mrp.web.core.base.dao.IGeneralDao;
import com.indocosmo.mrp.web.masters.customer.model.Customers;
import com.indocosmo.mrp.web.masters.discounts.model.Discount;



public interface IDiscountDao extends IGeneralDao<Discount>{
	
}
