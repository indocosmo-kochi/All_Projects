package com.indocosmo.mrp.web.masters.vouchertypes.dao;

import com.indocosmo.mrp.web.core.base.dao.IGeneralDao;
import com.indocosmo.mrp.web.masters.vouchertypes.model.Vouchers;


public interface IVouchersDao extends IGeneralDao<Vouchers>{

	
}
