package com.indocosmo.mrp.web.masters.shopshift.dao;

import com.indocosmo.mrp.web.core.base.dao.IMasterBaseDao;
import com.indocosmo.mrp.web.masters.shopshift.model.ShopShift;


public interface IShopShiftDao extends IMasterBaseDao<ShopShift> {

}
