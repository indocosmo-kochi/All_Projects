package com.indocosmo.mrp.web.masters.supplier.country.dao;
import com.indocosmo.mrp.web.core.base.dao.IGeneralDao;
import com.indocosmo.mrp.web.masters.supplier.country.model.Country;


public interface ICountryDao extends  IGeneralDao<Country>{


}