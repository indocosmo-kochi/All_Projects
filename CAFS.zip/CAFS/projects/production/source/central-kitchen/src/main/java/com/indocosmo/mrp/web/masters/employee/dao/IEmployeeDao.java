package com.indocosmo.mrp.web.masters.employee.dao;

import com.indocosmo.mrp.web.core.base.dao.IGeneralDao;
import com.indocosmo.mrp.web.masters.employee.model.Employee;


public interface IEmployeeDao extends IGeneralDao<Employee> {

}
