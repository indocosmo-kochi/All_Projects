package com.indocosmo.mrp.web.company.dao;

import com.indocosmo.mrp.web.company.model.Company;
import com.indocosmo.mrp.web.core.base.dao.IGeneralDao;

public interface ICompanyDao extends IGeneralDao<Company> {


}
