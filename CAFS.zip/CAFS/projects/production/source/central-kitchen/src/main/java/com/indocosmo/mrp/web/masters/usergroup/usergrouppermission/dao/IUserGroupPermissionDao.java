package com.indocosmo.mrp.web.masters.usergroup.usergrouppermission.dao;

import com.indocosmo.mrp.web.core.base.dao.IGeneralDao;
import com.indocosmo.mrp.web.masters.usergroup.usergrouppermission.model.UserGroupPermission;



public interface IUserGroupPermissionDao extends IGeneralDao<UserGroupPermission> {

}
