
#region COPYRIGHTS 

/*	
    - - - - - - - - - - - - - - - - - - - - - - -
    File Name : DBHelper.cs
    - - - - - - - - - - - - - - - - - - - - - - -
    System				    :  	
    Module				    :  	DataLayer
    Author				    :	
    Date					:	1 July 2008
    Function				:	Define the Data Wrapper Class which provides the functionalities of DBProvider Factory.
    Desctiption	            :    
 */

#endregion

#region DIRECTIVES 

using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Collections;
using System.Configuration;
using System.Globalization;

#endregion

namespace Indocosmo.Framework.DatabaseManagement
{
    
    public class DatabaseManager
    {

        #region DECLARATIONS 

        private DbProviderFactory   dbFactory;
        private DbConnection        dbConnection;
        public  DbCommand           dbCommand;
        private DbParameter         dbParameter; 
        private DbTransaction       dbTransaction;
        private bool                isTransaction;

        private static readonly string ConnectionString = ConfigurationManager.AppSettings["CONNECTIONSTRING"];
        private static readonly string ProviderName = ConfigurationManager.AppSettings["PROVIDER"];
        
        #endregion                    

        #region ENUMERATORS

        public enum TransactionType : int
        {
            None = 0,
            Open = 1,
            Commit = 2,
            Rollback = 3
        }

        #endregion

        #region STRUCTURES

        /// <summary>
        ///Description	    :	This function is used to Execute the Command
        ///Author			:	 
        ///Date				:	1 July 2008
        ///Input			:	
        ///OutPut			:	
        ///Comments			:	
        /// </summary>
        public struct Parameters
        {
            public string Name;
            public object Value;
            public ParameterDirection Direction;

            public Parameters(string name, object value, ParameterDirection direction)
            {
                Name = name;
                Value = value;
                Direction = direction;
            }

            public Parameters(string name, object value)
            {
                Name = name;
                Value = value;
                Direction = ParameterDirection.Input;
            }
        }

        #endregion
        
        #region CONSTRUCTOR 

        public DatabaseManager()
        {
            dbFactory = DbProviderFactories.GetFactory(ProviderName);
        }

        #endregion

        #region DESTRUCTOR 

        ~DatabaseManager()
        {
            dbFactory = null;
        }

        #endregion

        #region CONNECTIONS 

        /// <summary>
        ///Description	    :	This function is used to Open Database Connection
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	NA
        ///OutPut			:	NA
        ///Comments			:	
        /// </summary>
        public void EstablishFactoryConnection()
        {
            
            dbConnection = dbFactory.CreateConnection();

            if (dbConnection.State == ConnectionState.Closed)
            {
                dbConnection.ConnectionString    = ConnectionString;
                dbConnection.Open();
            }
        }

        /// <summary>
        ///Description	    :	This function is used to Close Database Connection
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	NA
        ///OutPut			:	NA
        ///Comments			:	
        /// </summary>
        public void CloseFactoryConnection()
        {
            //check for an open connection            
            try
            {
                if (dbConnection.State == ConnectionState.Open)
                {
                    dbConnection.Close();
                }
            }
            catch (DbException oDbErr)
            {
                //catch any SQL server data provider generated error message
                throw new Exception(oDbErr.Message);
            }
            catch (System.NullReferenceException oNullErr)
            {
                throw new Exception(oNullErr.Message);
            }
            finally
            {
               if (null != dbConnection)
                   dbConnection.Dispose();
            }
        }

        #endregion

        #region TRANSACTION 

        /// <summary>
        ///Description	    :	This function is used to Handle Transaction Events
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Transaction Event Type
        ///OutPut			:	NA
        ///Comments			:	
        /// </summary>
        public void TransactionHandler(TransactionType transactionType)
        {
            switch (transactionType)
            {
                case TransactionType.Open:  //open a transaction
                    try
                    {
                        dbTransaction    = dbConnection.BeginTransaction();
                        isTransaction  = true;
                    }
                    catch (InvalidOperationException oErr)
                    {
                        throw new Exception("@TransactionHandler - " + oErr.Message);
                    }
                    break;

                case TransactionType.Commit:  //commit the transaction
                    if (null != dbTransaction.Connection)
                    {
                        try
                        {
                            dbTransaction.Commit();
                            isTransaction = false;
                        }
                        catch (InvalidOperationException oErr)
                        {
                            throw new Exception("@TransactionHandler - " + oErr.Message);
                        }
                    }
                    break;

                case TransactionType.Rollback:  //rollback the transaction
                    try
                    {
                        if (isTransaction)
                        {
                            dbTransaction.Rollback();
                        }
                        isTransaction = false;
                    }
                    catch (InvalidOperationException oErr)
                    {
                        throw new Exception("@TransactionHandler - " + oErr.Message);
                    }
                    break;
            }

        }

        #endregion

        #region COMMANDS 

        #region PARAMETERLESS METHODS 

        /// <summary>
        ///Description	    :	This function is used to Prepare Command For Execution
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Transaction, Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	NA
        ///Comments			:	Has to be changed/removed if object based array concept is removed.
        /// </summary>
        private void PrepareCommand(bool blTransaction, CommandType cmdType, string cmdText)
        {

            if (dbConnection.State != ConnectionState.Open)
            {
                dbConnection.ConnectionString    = ConnectionString;
                dbConnection.Open();
            }

            if (null == dbCommand)
                dbCommand = dbFactory.CreateCommand();

            dbCommand.Connection     = dbConnection;
            dbCommand.CommandText    = cmdText;
            dbCommand.CommandType    = cmdType;

            if (blTransaction)
                dbCommand.Transaction = dbTransaction;
        }

        #endregion

        #region OBJECT BASED PARAMETER ARRAY 

        /// <summary>
        ///Description	    :	This function is used to Prepare Command For Execution
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Transaction, Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	NA
        ///Comments			:	
        /// </summary>
        private void PrepareCommand(bool blTransaction, CommandType cmdType, string cmdText, object[,] cmdParameters)
        {

            if (dbConnection.State != ConnectionState.Open)
            {
                dbConnection.ConnectionString    = ConnectionString;
                dbConnection.Open();
            }

            if (null == dbCommand)
                dbCommand            = dbFactory.CreateCommand();

            dbCommand.Connection     = dbConnection;
            dbCommand.CommandText    = cmdText;
            dbCommand.CommandType    = cmdType;

            if (blTransaction)
                dbCommand.Transaction = dbTransaction;

            if (null != cmdParameters)
                CreateDBParameters(cmdParameters);
        }

        #endregion

        #region STRUCTURE BASED PARAMETER ARRAY 

        /// <summary>
        ///Description	    :	This function is used to Prepare Command For Execution
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Transaction, Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	NA
        ///Comments			:	
        /// </summary>
        private void PrepareCommand(bool blTransaction, CommandType cmdType, string cmdText, Parameters[] cmdParameters)
        {

            if (dbConnection.State != ConnectionState.Open)
            {
                dbConnection.ConnectionString    = ConnectionString;
                dbConnection.Open();
            }

            dbCommand                = dbFactory.CreateCommand();
            dbCommand.Connection     = dbConnection;
            dbCommand.CommandText    = cmdText;
            dbCommand.CommandType    = cmdType;

            if (blTransaction)
                dbCommand.Transaction = dbTransaction;

            if (null != cmdParameters)
                CreateDBParameters(cmdParameters);
        }

        #endregion
        
        #endregion

        #region PARAMETER METHODS 

        #region OBJECT BASED 

        /// <summary>
        ///Description	    :	This function is used to Create Parameters for the Command For Execution
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	2-Dimensional Parameter Array
        ///OutPut			:	NA
        ///Comments			:	
        /// </summary>
        private void CreateDBParameters(object[,] colParameters)
        {
            for (int i = 0; i < colParameters.Length / 2; i++)
            {
                dbParameter                  = dbCommand.CreateParameter();
                dbParameter.ParameterName    = colParameters[i, 0].ToString();
                dbParameter.Value            = colParameters[i, 1];
                dbCommand.Parameters.Add(dbParameter);
            }
        }

        #endregion

        #region STRUCTURE BASED 

        /// <summary>
        ///Description	    :	This function is used to Create Parameters for the Command For Execution
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	2-Dimensional Parameter Array
        ///OutPut			:	NA
        ///Comments			:	
        /// </summary>
        private void CreateDBParameters(Parameters[] colParameters)
        {
            for (int i = 0; i < colParameters.Length; i++)
            {
                Parameters param           = (Parameters)colParameters[i];
                
                    dbParameter                  = dbCommand.CreateParameter();
                    dbParameter.ParameterName    = param.Name;
                    dbParameter.Value            = param.Value;
                    dbParameter.Direction        = param.Direction;
                    dbCommand.Parameters.Add(dbParameter);
               
            }
        }
        
        #endregion

        #endregion

        #region EXCEUTE METHODS 

        #region PARAMETERLESS METHODS 

        /// <summary>
        ///Description	    :	This function is used to Execute the Command
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	Count of Records Affected
        ///Comments			:	
        ///                     Has to be changed/removed if object based array concept is removed.
        /// </summary>
        public int ExecuteNonQuery(CommandType cmdType, string cmdText)
        {
            try
            {

                EstablishFactoryConnection();
                PrepareCommand(false, cmdType, cmdText);
                return dbCommand.ExecuteNonQuery();
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (null != dbCommand)
                    dbCommand.Dispose(); 
                CloseFactoryConnection();
            }
        }

        /// <summary>
        ///Description	    :	This function is used to Execute the Command
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Transaction, Command Type, Command Text, 2-Dimensional Parameter Array, Clear Paramaeters
        ///OutPut			:	Count of Records Affected
        ///Comments			:	
        ///                     Has to be changed/removed if object based array concept is removed.
        /// </summary>
        public int ExecuteNonQuery(bool blTransaction, CommandType cmdType, string cmdText)
        {
            try
            {
                PrepareCommand(blTransaction, cmdType, cmdText);
                int val = dbCommand.ExecuteNonQuery();

                return val;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (null != dbCommand)
                    dbCommand.Dispose();
            }
        }

        #endregion
        
        #region OBJECT BASED PARAMETER ARRAY 

        /// <summary>
        ///Description	    :	This function is used to Execute the Command
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, 2-Dimensional Parameter Array, Clear Parameters
        ///OutPut			:	Count of Records Affected
        ///Comments			:	
        /// </summary>
        public int ExecuteNonQuery(CommandType cmdType, string cmdText, object[,] cmdParameters, bool blDisposeCommand)
        {
            try
            {

                EstablishFactoryConnection();
                PrepareCommand(false, cmdType, cmdText, cmdParameters);
                return dbCommand.ExecuteNonQuery();
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (blDisposeCommand && null != dbCommand)
                    dbCommand.Dispose();
                CloseFactoryConnection();                
            }           
        }

         /// <summary>
        ///Description	    :	This function is used to Execute the Command
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	Count of Records Affected
        ///Comments			:	Overloaded method. 
        /// </summary>
        public int ExecuteNonQuery(CommandType cmdType, string cmdText, object[,] cmdParameters)
        {
            return ExecuteNonQuery(cmdType, cmdText, cmdParameters, true);
        }

        /// <summary>
        ///Description	    :	This function is used to Execute the Command
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Transaction, Command Type, Command Text, 2-Dimensional Parameter Array, Clear Paramaeters
        ///OutPut			:	Count of Records Affected
        ///Comments			:	
        /// </summary>
        public int ExecuteNonQuery(bool blTransaction, CommandType cmdType, string cmdText, object[,] cmdParameters, bool blDisposeCommand)
        {
            try
            {

                PrepareCommand(blTransaction, cmdType, cmdText, cmdParameters);
                return dbCommand.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (blDisposeCommand && null != dbCommand)
                    dbCommand.Dispose();
            }
        }

        /// <summary>
        ///Description	    :	This function is used to Execute the Command
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Transaction, Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	Count of Records Affected
        ///Comments			:	Overloaded function. 
        /// </summary>
        public int ExecuteNonQuery(bool blTransaction, CommandType cmdType, string cmdText, object[,] cmdParameters)
        {
            return ExecuteNonQuery(blTransaction, cmdType, cmdText, cmdParameters, true);
        }

        #endregion

        #region STRUCTURE BASED PARAMETER ARRAY 

        /// <summary>
        ///Description	    :	This function is used to Execute the Command
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, Parameter Structure Array, Clear Parameters
        ///OutPut			:	Count of Records Affected
        ///Comments			:	
        /// </summary>
        public int ExecuteNonQuery(CommandType cmdType, string cmdText, Parameters[] cmdParameters, bool blDisposeCommand)
        {
            try
            {

                EstablishFactoryConnection();
                PrepareCommand(false, cmdType, cmdText, cmdParameters);
                return dbCommand.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (blDisposeCommand && null != dbCommand)
                    dbCommand.Dispose();
                CloseFactoryConnection();
            }
        }

        /// <summary>
        ///Description	    :	This function is used to Execute the Command
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, Parameter Structure Array
        ///OutPut			:	Count of Records Affected
        ///Comments			:	Overloaded method. 
        /// </summary>
        public int ExecuteNonQuery(CommandType cmdType, string cmdText, Parameters[] cmdParameters)
        {
            return ExecuteNonQuery(cmdType, cmdText, cmdParameters, true);
        }
        
        /// <summary>
        ///Description	    :	This function is used to Execute the Command
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Transaction, Command Type, Command Text, Parameter Structure Array, Clear Parameters
        ///OutPut			:	Count of Records Affected
        ///Comments			:	
        /// </summary>
        public int ExecuteNonQuery(bool blTransaction, CommandType cmdType, string cmdText, Parameters[] cmdParameters, bool blDisposeCommand)
        {
            try
            {

                PrepareCommand(blTransaction, cmdType, cmdText, cmdParameters);
                return dbCommand.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (blDisposeCommand && null != dbCommand)
                    dbCommand.Dispose();
            }
        }

        /// <summary>
        ///Description	    :	This function is used to Execute the Command
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Transaction, Command Type, Command Text, Parameter Structure Array
        ///OutPut			:	Count of Records Affected
        ///Comments			:	
        /// </summary>
        public int ExecuteNonQuery(bool blTransaction, CommandType cmdType, string cmdText, Parameters[] cmdParameters)
        {
            return ExecuteNonQuery(blTransaction, cmdType, cmdText, cmdParameters, true);
        }
        
        #endregion
                
        #endregion

        #region READER METHODS 

        #region PARAMETERLESS METHODS 

        /// <summary>
        ///Description	    :	This function is used to fetch data using Data Reader	
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	Data Reader
        ///Comments			:	
        ///                     Has to be changed/removed if object based array concept is removed.
        /// </summary>
        public DbDataReader ExecuteReader(CommandType cmdType, string cmdText)
        {

            // we use a try/catch here because if the method throws an exception we want to 
            // close the connection throw code, because no datareader will exist, hence the 
            // commandBehaviour.CloseConnection will not work
            try
            {

                EstablishFactoryConnection();
                PrepareCommand(false, cmdType, cmdText);
                DbDataReader dr = dbCommand.ExecuteReader(CommandBehavior.CloseConnection);
                dbCommand.Parameters.Clear();
                return dr;

            }
            catch (Exception ex)
            {
                CloseFactoryConnection();
                throw ex;
            }
            finally
            {
                if (null != dbCommand)
                    dbCommand.Dispose();
            }
        }

        #endregion

        #region OBJECT BASED PARAMETER ARRAY 

        /// <summary>
        ///Description	    :	This function is used to fetch data using Data Reader	
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	Data Reader
        ///Comments			:	
        /// </summary>
        public DbDataReader ExecuteReader(CommandType cmdType, string cmdText, object[,] cmdParameters)
        {

            // we use a try/catch here because if the method throws an exception we want to 
            // close the connection throw code, because no datareader will exist, hence the 
            // commandBehaviour.CloseConnection will not work

            try
            {

                EstablishFactoryConnection();                
                PrepareCommand(false, cmdType, cmdText, cmdParameters);
                DbDataReader dr = dbCommand.ExecuteReader(CommandBehavior.CloseConnection);
                dbCommand.Parameters.Clear();
                return dr;

            }
            catch (Exception ex)
            {
                CloseFactoryConnection();
                throw ex;
            }
            finally
            {
                if (null != dbCommand)
                    dbCommand.Dispose();
            }
        }

        #endregion

        #region STRUCTURE BASED PARAMETER ARRAY 
        
        /// <summary>
        ///Description	    :	This function is used to fetch data using Data Reader	
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, Parameter AStructure Array
        ///OutPut			:	Data Reader
        ///Comments			:	
        /// </summary>
        public DbDataReader ExecuteReader(CommandType cmdType, string cmdText, Parameters[] cmdParameters)
        {

            // we use a try/catch here because if the method throws an exception we want to 
            // close the connection throw code, because no datareader will exist, hence the 
            // commandBehaviour.CloseConnection will not work
            try
            {

                EstablishFactoryConnection();
                PrepareCommand(false, cmdType, cmdText, cmdParameters);
                return dbCommand.ExecuteReader(CommandBehavior.CloseConnection);

            }
            catch (Exception ex)
            {
                CloseFactoryConnection();
                throw ex;
            }
            finally
            {
                if (null != dbCommand)
                    dbCommand.Dispose();
            }
        }
               
        #endregion

        #endregion

        #region ADAPTER METHODS 

        #region PARAMETERLESS METHODS 
        
        /// <summary>
        ///Description	    :	This function is used to fetch data using Data Adapter	
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	Data Set
        ///Comments			:	
        ///                     Has to be changed/removed if object based array concept is removed.
        /// </summary>
        public DataSet DataAdapter(CommandType cmdType, string cmdText)
        {

            // we use a try/catch here because if the method throws an exception we want to 
            // close the connection throw code, because no datareader will exist, hence the 
            // commandBehaviour.CloseConnection will not work
            DbDataAdapter dda   = null;
            try
            {
                EstablishFactoryConnection();
                dda = dbFactory.CreateDataAdapter();
                PrepareCommand(false, cmdType, cmdText);

                dda.SelectCommand   = dbCommand;
                DataSet ds          = new DataSet();
                ds.Locale = CultureInfo.InvariantCulture;
                dda.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (null != dbCommand)
                    dbCommand.Dispose();
                CloseFactoryConnection();
            }
        }

        #endregion

        #region OBJECT BASED PARAMETER ARRAY 

        /// <summary>
        ///Description	    :	This function is used to fetch data using Data Adapter	
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	Data Set
        ///Comments			:	
        /// </summary>
        public DataSet DataAdapter(CommandType cmdType, string cmdText, object[,] cmdParameters)
        {

            // we use a try/catch here because if the method throws an exception we want to 
            // close the connection throw code, because no datareader will exist, hence the 
            // commandBehaviour.CloseConnection will not work
            DbDataAdapter dda = null;
            try
            {
                EstablishFactoryConnection();
                dda = dbFactory.CreateDataAdapter();
                PrepareCommand(false, cmdType, cmdText, cmdParameters);

                dda.SelectCommand   = dbCommand;
                DataSet ds          = new DataSet();
                ds.Locale = CultureInfo.InvariantCulture;
                dda.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (null != dbCommand)
                    dbCommand.Dispose();
                CloseFactoryConnection();
            }
        }

        #endregion

        #region STRUCTURE BASED PARAMETER ARRAY 
        
        /// <summary>
        ///Description	    :	This function is used to fetch data using Data Adapter	
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	Data Set
        ///Comments			:	
        /// </summary>
        public DataSet DataAdapter(CommandType cmdType, string cmdText, Parameters[] cmdParameters)
        {

            // we use a try/catch here because if the method throws an exception we want to 
            // close the connection throw code, because no datareader will exist, hence the 
            // commandBehaviour.CloseConnection will not work
            DbDataAdapter dda   = null;
            try
            {
                EstablishFactoryConnection();
                dda = dbFactory.CreateDataAdapter();
                PrepareCommand(false, cmdType, cmdText, cmdParameters);

                dda.SelectCommand   = dbCommand;
                DataSet ds          = new DataSet();
                ds.Locale = CultureInfo.InvariantCulture;
                dda.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if(null != dbCommand)
                    dbCommand.Dispose();
                CloseFactoryConnection();
            }
        }

        #endregion

        #endregion

        #region SCALAR METHODS 

        #region PARAMETERLESS METHODS 

        /// <summary>
        ///Description	    :	This function is used to invoke Execute Scalar Method	
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	Object
        ///Comments			:	
        /// </summary>
        public object ExecuteScalar(CommandType cmdType, string cmdText)
        {
            try
            {
                EstablishFactoryConnection();

                PrepareCommand(false, cmdType, cmdText);

                object val = dbCommand.ExecuteScalar();

                return val;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (null != dbCommand)
                    dbCommand.Dispose();
                CloseFactoryConnection();
            }
        }

        #endregion

        #region OBJECT BASED PARAMETER ARRAY

        /// <summary>
        ///Description	    :	This function is used to invoke Execute Scalar Method	
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	Object
        ///Comments			:	
        /// </summary>
        public object ExecuteScalar(CommandType cmdType, string cmdText, object[,] cmdParameters, bool blDisposeCommand)
        {
            try
            {

                EstablishFactoryConnection();
                PrepareCommand(false, cmdType, cmdText, cmdParameters);
                return dbCommand.ExecuteScalar();
            
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (blDisposeCommand && null != dbCommand)
                    dbCommand.Dispose();
                CloseFactoryConnection();
            }
        }

         /// <summary>
        ///Description	    :	This function is used to invoke Execute Scalar Method	
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	Object
        ///Comments			:	Overloaded Method. 
        /// </summary>
        public object ExecuteScalar(CommandType cmdType, string cmdText, object[,] cmdParameters)
        {
            return ExecuteScalar(cmdType, cmdText, cmdParameters, true);
        }

        /// <summary>
        ///Description	    :	This function is used to invoke Execute Scalar Method	
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	Object
        ///Comments			:	
        /// </summary>
        public object ExecuteScalar(bool blTransaction, CommandType cmdType, string cmdText, object[,] cmdParameters, bool blDisposeCommand)
        {
            try
            {

                PrepareCommand(blTransaction, cmdType, cmdText, cmdParameters);
                return dbCommand.ExecuteScalar();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (blDisposeCommand && null != dbCommand)
                    dbCommand.Dispose();
            }
        }

        /// <summary>
        ///Description	    :	This function is used to invoke Execute Scalar Method	
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	Object
        ///Comments			:	
        /// </summary>
        public object ExecuteScalar(bool blTransaction, CommandType cmdType, string cmdText, object[,] cmdParameters)
        {
            return ExecuteScalar(blTransaction, cmdType, cmdText, cmdParameters, true);
        }

        #endregion

        #region STRUCTURE BASED PARAMETER ARRAY 

        /// <summary>
        ///Description	    :	This function is used to invoke Execute Scalar Method	
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	Object
        ///Comments			:	
        /// </summary>
        public object ExecuteScalar(CommandType cmdType, string cmdText, Parameters[] cmdParameters, bool blDisposeCommand)
        {
            try
            {
                EstablishFactoryConnection();
                PrepareCommand(false, cmdType, cmdText, cmdParameters);
                return dbCommand.ExecuteScalar();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (blDisposeCommand && null != dbCommand)
                    dbCommand.Dispose();
                CloseFactoryConnection();
            }
        }

        /// <summary>
        ///Description	    :	This function is used to invoke Execute Scalar Method	
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	Object
        ///Comments			:	Overloaded Method. 
        /// </summary>
        public object ExecuteScalar(CommandType cmdType, string cmdText, Parameters[] cmdParameters)
        {
            return ExecuteScalar(cmdType, cmdText, cmdParameters, true);
        }

        /// <summary>
        ///Description	    :	This function is used to invoke Execute Scalar Method	
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	Object
        ///Comments			:	
        /// </summary>
        public object ExecuteScalar(bool blTransaction, CommandType cmdType, string cmdText, Parameters[] cmdParameters, bool blDisposeCommand)
        {
            try
            {

                PrepareCommand(blTransaction, cmdType, cmdText, cmdParameters);
                return dbCommand.ExecuteScalar();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (blDisposeCommand && null != dbCommand)
                    dbCommand.Dispose();
            }
        }

        /// <summary>
        ///Description	    :	This function is used to invoke Execute Scalar Method	
        ///Author			:	
        ///Date				:	1 July 2008
        ///Input			:	Command Type, Command Text, 2-Dimensional Parameter Array
        ///OutPut			:	Object
        ///Comments			:	
        /// </summary>
        public object ExecuteScalar(bool blTransaction, CommandType cmdType, string cmdText, Parameters[] cmdParameters)
        {
            return ExecuteScalar(blTransaction, cmdType, cmdText, cmdParameters, true);
        }

        #endregion

        #endregion

    }
}


