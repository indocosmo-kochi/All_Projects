using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Indocosmo.Framework.CommonBaseManagement
{
    public partial class BaseForm : Form,IFormAction
    {
        public ToolBarItemControl toolBarItemControls = new ToolBarItemControl();
        public BaseForm()
        {
            InitializeComponent();
        }

        public  virtual ToolBarItemControl ToolBarItemControls{
            get
            {
                return toolBarItemControls;
            }
        }

        #region IFormAction Members

        public virtual void iBtnSave()
        {
          //  throw new Exception("The method or operation is not implemented.");
        }

        public virtual void iBtnEdit()
        {
            //throw new Exception("The method or operation is not implemented.");
        }

        public virtual void iBtnDelete()
        {
            //throw new Exception("The method or operation is not implemented.");
        }

        public virtual void iBtnClose()
        {
            //throw new Exception("The method or operation is not implemented.");
        }

        public virtual void iBtnPrint()
        {
            //throw new Exception("The method or operation is not implemented.");
        }

        public virtual void iBtnClear()
        {
            //throw new Exception("The method or operation is not implemented.");
        }

        public virtual void iBtnAdd()
        {
            //throw new Exception("The method or operation is not implemented.");
        }


        public virtual void iBtnSearch()
        {
            //throw new Exception("The method or operation is not implemented.");
        }
        #endregion
    }
}