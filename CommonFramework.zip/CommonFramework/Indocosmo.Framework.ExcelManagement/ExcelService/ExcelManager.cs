using System;
using System.Collections.Generic;
using System.Text;
//using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;
using System.Collections;
using System.IO;
using System.Threading;
using System.Data;

namespace Indocosmo.Framework.ExcelManagement
{
    /// <summary>
    /// CLASS FOR EXPORTING DATA TO EXCEL/ FOR CREATNG EXCEL REPORTS
	///	THIS CLASS IS INDENTED FOR EXPORTING DATA TO EXCEL WORKSHEET.THE CLASS CONTAINS METHODS FOR OPENING EXISTING WORKSHEET 
	/// SETTING THE CURRENT WORKSHEET ,PUTTING DATA ON TO A SPECIFIED CELL BY SPECIFYING THE ROW NO AND COL NO.THE CLASS ALSO 
	/// CONTAINS METHODS FOR DELETING UNWANTED ROWS.
    /// </summary>
    public class ExcelManager
    {
        Excel.Application excel = null;
        Excel.Workbooks books = null;
        Excel.Workbook book = null;
        Excel.Sheets sheets = null;
        Excel.Worksheet sheet = null;
        Excel.Range cells = null;
        Object missing = System.Reflection.Missing.Value;
        int currentWorkSheet = 0;
        public ExcelManager()
        {
            currentWorkSheet = 0;
        }

        public bool CreateExcel(string reportName)
        {
            string file, template;
            try
            {
                file = AppDomain.CurrentDomain.BaseDirectory + @"\Reports\" + reportName + "(" + "1" + ").xls";
                file = file.Replace(@"\\", @"\");
                template = AppDomain.CurrentDomain.BaseDirectory + @"\Templates\" + reportName + ".xls";
                template = template.Replace(@"\\", @"\");

                File.Delete(file);  // used to check whether the file is open or not.if so ,generates an exception and return false.
                File.Copy(template, file, true);

                OpenExcel(file);

                book = books.get_Item(1);
                sheets = book.Worksheets;
                 SetSheet(1);
                return true;
            }
            catch
            {
                Close();
                return false;
            }
        }

        public void OpenExcel(string file)
        {
            System.Globalization.CultureInfo CurrentCI = System.Threading.Thread.CurrentThread.CurrentCulture;
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");
            excel = new Excel.Application();
            books = excel.Workbooks;
            //Excel 2000
            books.Open(file, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing, missing);
            //Excel 2003
            //books.Open(file, 0, true, 5, "", "", true, Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, false, false);
            excel.Visible = true;
            System.Threading.Thread.CurrentThread.CurrentCulture = CurrentCI;
        }

        public void PrintExcel()
        {
            book.PrintOut(1, 1, 1, false, missing, true, false, missing);
        }

        public void SetSheet(int sheetNumber)
        {
            try
            {
                sheet = null;
                sheet = (Excel.Worksheet)sheets.get_Item(sheetNumber);
                cells = sheet.Cells;
                currentWorkSheet = sheetNumber;
            }
            catch
            {
                Close();
            }
        }

        public void CopySheet(int sheetNumber)
        {
            try
            {
                sheet = null;
                sheet = (Excel.Worksheet)sheets.get_Item(sheetNumber);
                sheet.Copy(missing, sheet);
               
            }
            catch
            {
                Close();
            }
            
            
        }

        public void DeleteSheet(int sheetNumber)
        {
            try
            {
                sheet = null;
                sheet = (Excel.Worksheet)sheets.get_Item(sheetNumber);
                sheet.Delete();
                sheet = null;
            }
            catch
            {
                Close();
            }
        }

        public void SetCellValue(int row, int col, int value)
        {
            cells.Cells[row, col] = value;
        }

        public void SetCellValue(int row, int col, double value)
        {
            cells.Cells[row, col] = value;
        }

        public void SetCellValue(int row, int col, DateTime value)
        {
            cells.Cells[row, col] = value;
             
        }

        public void SetCellValue(int row, int col, string value)
        {
            if (value == null)
                return;
            else if (value.Trim() == "")
                return;
            cells.Cells[row, col] = value;
        }

        public void SetCellValue(string range, string value)
        {
            SetCellValue(range, range, value);
        }

        public void SetCellValue(string startCell, string endCell, string value)
        {
            if (value == null)
                return;
            if (value.Trim() == "")
                return;
            sheet.get_Range(startCell, endCell).Value2 = value;
        }

        public void MergeCells(int row, int startCol, int endCol)
        {
            Excel.Range range = sheet.get_Range(sheet.Cells[row, startCol], sheet.Cells[row, endCol]);
            range.Merge(missing);
        }

        public bool InsertRows(int insertRowAt)
        {
            return InsertRows(insertRowAt, 0);
        }

        public bool InsertRows(int insertRowAt, int noOfRows)
        {
            try
            {
                //Excel 2000
                sheet.get_Range(insertRowAt + ":" + (insertRowAt + noOfRows), missing).Insert(missing);
                //Excel 2003
                //sheet.get_Range(insertRowAt + ":" + (insertRowAt + noOfRows), missing).Insert(missing, missing);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public void CellClear(int row, int col)
        {
            cells.Cells[row, col] = "";
        }

        public bool CopyCell(int fromcellrow, int fromcellcol, int tocellrow, int tocellcol)
        {
            try
            {
                Excel.Range range = sheet.get_Range(sheet.Cells[fromcellrow, fromcellcol],sheet.Cells[fromcellrow, fromcellcol]);
                Excel.Range range1 = sheet.get_Range(sheet.Cells[tocellrow, tocellcol],sheet.Cells[tocellrow, tocellcol]);
                range.Copy(range1);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool CutCell(int fromcellrow, int fromcellcol, int tocellrow, int tocellcol)
        {
            try
            {
                Excel.Range range = sheet.get_Range(sheet.Cells[fromcellrow, fromcellcol], sheet.Cells[fromcellrow, fromcellcol]);
                Excel.Range range1 = sheet.get_Range(sheet.Cells[tocellrow, tocellcol], sheet.Cells[tocellrow, tocellcol]);
                range.Cut(range1);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public void CopyRow(int row, int startCol, int endCol)
        {
            Excel.Range range = sheet.get_Range(sheet.Cells[row, startCol], sheet.Cells[row, endCol]);
            Excel.Range range1 = sheet.get_Range(sheet.Cells[row + 1, startCol], sheet.Cells[row + 1, endCol]);
            range.Copy(range1);
             
        }

        public void CopyRow(int rowFrom,int rowTo, int startCol, int endCol)
        {
            Excel.Range range = sheet.get_Range(sheet.Cells[rowFrom, startCol], sheet.Cells[rowFrom, endCol]);
            Excel.Range range1 = sheet.get_Range(sheet.Cells[rowTo, startCol], sheet.Cells[rowTo, endCol]);
            range.Copy(range1);
        }
    
        public bool DeleteRows(int row)
        {
            return DeleteRows(row, row);
        }

        public bool DeleteRows(int startRow, int endRow)
        {
            try
            {
                sheet.get_Range(startRow + ":" + endRow, missing).Delete(0);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteRows(int startRow, int endRow, int sheetNo)
        {
            int previousWorkSheet = this.currentWorkSheet;
            try
            {
                this.SetSheet(sheetNo);
                this.DeleteRows(startRow, endRow);
                this.SetSheet(previousWorkSheet);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public void Save()
        {
            try
            {
                book.Save();
                book.Close(missing, missing, missing);
            }
            catch (Exception exception)
            {
                throw new Exception(exception.Message.ToString());
            }
            finally
            {
                Close();
            }
        }

        public void Save(string savePath, string password)
        {
            try
            {
                sheet = (Excel.Worksheet)sheets.get_Item(1);
                //Excel 2000
                sheet.Protect(password, true, true, true, missing);
                book.SaveAs(savePath, Excel.XlFileFormat.xlWorkbookNormal, missing, missing, missing, missing, Excel.XlSaveAsAccessMode.xlNoChange, missing, missing, missing, missing);
                //Excel 2003
                //sheet.Protect(password, true, true, true, missing, false, false, false, false, false, false, false, false, false, false, false);
                //book.SaveAs(savePath, Excel.XlFileFormat.xlWorkbookNormal, missing, missing, missing, missing, Excel.XlSaveAsAccessMode.xlNoChange, missing, missing, missing, missing, missing);
                book.Close(missing, missing, missing);
                Close();
            }
            catch (Exception exception)
            {
                Close();
                throw new Exception(exception.Message.ToString());
            }
        }

        private void Close()
        {
            try
            {
                if (excel.Workbooks != null)
                {
                    foreach (Excel.Workbook wb in excel.Workbooks)
                    {
                        foreach (Excel.Worksheet ws in wb.Worksheets)
                        {
                            System.Runtime.InteropServices.Marshal.ReleaseComObject(ws);
                        }
                        wb.Close(false, false, missing);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(wb);
                    }
                    excel.Workbooks.Close();
                }
                excel.DisplayAlerts = false;
                excel.Quit();
            }
            catch (Exception exception)
            {
                throw new Exception(exception.Message.ToString());
            }
            finally
            {
                if (cells != null)
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(cells);
                if (sheet != null)
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(sheet);
                if (sheets != null)
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(sheets);
                if (book != null)
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(book);
                if (books != null)
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(books);
                if (excel != null)
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(excel);
                cells = null;
                sheet = null; sheets = null;
                book = null; books = null;
                excel = null;
                System.GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        public void FillCellColor(int row, int startCol, int endCol)
        {
            sheet.get_Range(sheet.Cells[row, startCol], sheet.Cells[row, endCol]).Interior.Color = 0x008b0000;//0x00BEBEBE; 
        }
        
    }
}
