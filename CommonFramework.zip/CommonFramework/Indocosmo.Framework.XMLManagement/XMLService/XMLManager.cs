using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;
using System.Windows.Forms;
using System.Configuration;

namespace Indocosmo.Framework.XMLManagement
{
   public class XMLManager
    {
       private static readonly string language = Convert.ToString( ConfigurationManager.AppSettings["LANGUAGE"]);

        #region Get message from XML file

        /// <summary>
        /// Get Message based on culture settings
        /// </summary>
        /// <param name="msgCode">Message Code to get message </param>
        /// <returns>current culture based Message </returns>
       public static DialogResult ShowMessage(string messageCode)
       {
           return MessageBox.Show(GetMessage(messageCode));
       }

       public static DialogResult ShowMessage(IWin32Window owner, string messageCode)
       {
           return MessageBox.Show(owner, GetMessage(messageCode));
       }

       public static DialogResult ShowMessage(string messageCode,string caption)
       {
           return MessageBox.Show(GetMessage(messageCode), caption);
       }

       public static DialogResult ShowMessage(IWin32Window owner, string messageCode, string caption)
       {
           return MessageBox.Show(owner, GetMessage(messageCode), caption);
       }

       public static DialogResult ShowMessage(string messageCode, string caption,MessageBoxButtons buttons)
       {
           return MessageBox.Show(GetMessage(messageCode), caption, buttons);
       }

       public static DialogResult ShowMessage(IWin32Window owner, string messageCode, string caption, MessageBoxButtons buttons)
       {
           return MessageBox.Show(owner, GetMessage(messageCode), caption, buttons);
       }

       public static DialogResult ShowMessage(string messageCode, string caption, MessageBoxButtons buttons,MessageBoxIcon icon)
       {
           return MessageBox.Show(GetMessage(messageCode), caption, buttons, icon);
       }

       public static DialogResult ShowMessage(IWin32Window owner, string messageCode, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
       {
           return MessageBox.Show(owner, GetMessage(messageCode), caption, buttons, icon);
       }

       public static DialogResult ShowMessage(string messageCode, string caption, MessageBoxButtons buttons, MessageBoxIcon icon,MessageBoxDefaultButton defaultButton)
       {
           return MessageBox.Show(GetMessage(messageCode), caption, buttons, icon, defaultButton);
       }

       public static DialogResult ShowMessage(IWin32Window owner, string messageCode, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton)
       {
           return MessageBox.Show(owner, GetMessage(messageCode), caption, buttons, icon, defaultButton);
       }

       public static DialogResult ShowMessage(string messageCode, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton,MessageBoxOptions options)
       {
           return MessageBox.Show(GetMessage(messageCode), caption, buttons, icon, defaultButton, options);
       }

       public static DialogResult ShowMessage(IWin32Window owner, string messageCode, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options)
       {
           return MessageBox.Show(owner, GetMessage(messageCode), caption, buttons, icon, defaultButton, options);
       }

       public static DialogResult ShowMessage(string messageCode, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options,bool displayHelpButton)
       {
           return MessageBox.Show(GetMessage(messageCode), caption, buttons, icon, defaultButton, options, displayHelpButton);
       }

       public static DialogResult ShowMessage(string messageCode, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options,string helpFilePath)
       {
           return MessageBox.Show(GetMessage(messageCode), caption, buttons, icon, defaultButton, options, helpFilePath);
       }

       public static DialogResult ShowMessage(IWin32Window owner, string messageCode, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options,string helpFilePath)
       {
           return MessageBox.Show(owner, GetMessage(messageCode), caption, buttons, icon, defaultButton, options, helpFilePath);
       }

       public static DialogResult ShowMessage(string messageCode, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options, string helpFilePath,HelpNavigator navigator)
       {
           return MessageBox.Show(GetMessage(messageCode), caption, buttons, icon, defaultButton, options, helpFilePath, navigator);
       }

       public static DialogResult ShowMessage(IWin32Window owner, string messageCode, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options, string helpFilePath,HelpNavigator navigator)
       {
           return MessageBox.Show(owner, GetMessage(messageCode), caption, buttons, icon, defaultButton, options, helpFilePath, navigator);
       }

       public static DialogResult ShowMessage(string messageCode, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options, string helpFilePath, HelpNavigator navigator,string keyword)
       {
           return MessageBox.Show(GetMessage(messageCode), caption, buttons, icon, defaultButton, options, helpFilePath, navigator, keyword);
       }

       public static DialogResult ShowMessage(IWin32Window owner, string messageCode, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options, string helpFilePath, HelpNavigator navigator,string keyword)
       {
           return MessageBox.Show(owner, GetMessage(messageCode), caption, buttons, icon, defaultButton, options, helpFilePath, navigator, keyword);
       }

       public static DialogResult ShowMessage(string messageCode, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options, string helpFilePath, HelpNavigator navigator,object param)
       {
           return MessageBox.Show(GetMessage(messageCode), caption, buttons, icon, defaultButton, options, helpFilePath, navigator, param);
       }

       public static DialogResult ShowMessage(IWin32Window owner, string messageCode, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options, string helpFilePath, HelpNavigator navigator,object param)
       {
           return MessageBox.Show(owner, GetMessage(messageCode), caption, buttons, icon, defaultButton, options, helpFilePath, navigator, param);
       }


       private static string GetMessage(string messageCode)
       {
           // Instantiate an XmlDocument object.
           XmlDocument xmlDoc = new XmlDocument();

           string filePath;
           string message=string.Empty;
           filePath = AppDomain.CurrentDomain.BaseDirectory + "\\XmlFiles\\Message.xml";
           //TODO temporary 
           //  filePath = @"E:\Kuji\KujiManagement\XmlFiles\Message.xml";
           XmlReader xmlReader;
           XmlNode xmlNode;
           try
           {

               xmlReader = XmlReader.Create(new StreamReader(filePath, Encoding.Default));
               // Load Message.xml into the DOM.
               xmlDoc.Load(xmlReader);
               // Use the SelectSingleNode method to locate a specific title.
               xmlNode = xmlDoc.SelectSingleNode("//message/code[.='" + messageCode + "']");

               // Determine whether a matching node is located. 
               if (!(xmlNode == null))
               {
                   if (language == "en")
                   {
                       message = xmlNode.NextSibling.NextSibling.InnerText;
                       //return xmlNode.NextSibling.NextSibling.InnerText;
                   }
                   else
                   {
                       //return xmlNode.NextSibling.InnerText;
                       message = xmlNode.NextSibling.InnerText;
                   }
               }
           }
           catch( Exception ex)
           {
               MessageBox.Show(ex.Message);
           }
           finally
           {
               xmlReader = null;
               xmlNode = null;
           }
           return message;
       }

        /// <summary>
        /// Get Message based on culture settings
        /// </summary>
        /// <param name="msgCode">Message Code to get message </param>
        /// <returns>current culture based Message </returns>
        public static void MessageShow(string msgCode)
        {
            // Instantiate an XmlDocument object.
            XmlDocument xmlDoc = new XmlDocument();

            string filePath;
            filePath = AppDomain.CurrentDomain.BaseDirectory + "\\XmlFiles\\Message.xml";
            //TODO temporary 
          //  filePath = @"E:\Kuji\KujiManagement\XmlFiles\Message.xml";
            XmlReader xmlReader;
            XmlNode xmlNode;
            try
            {

                xmlReader = XmlReader.Create(new StreamReader(filePath, Encoding.Default));
                // Load Message.xml into the DOM.
                xmlDoc.Load(xmlReader);
                // Use the SelectSingleNode method to locate a specific title.
                xmlNode = xmlDoc.SelectSingleNode("//message/code[.='" + msgCode + "']");

                // Determine whether a matching node is located. 
                if (!(xmlNode == null))
                {
                    if (language == "en")
                    {
                        MessageBox.Show(xmlNode.NextSibling.NextSibling.InnerText);
                        //return xmlNode.NextSibling.NextSibling.InnerText;
                    }
                    else
                    {
                        //return xmlNode.NextSibling.InnerText;
                        MessageBox.Show(xmlNode.NextSibling.InnerText);
                    }
                }
            }
            catch ( Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                xmlReader = null;
                xmlNode = null;
            }
        }
       
        /// <summary>
        /// Get Message based on culture settings
        /// </summary>
        /// <param name="msgCode">Message Code to get message </param>
        /// <param name="msgBtn">Type of button to be displayed.Default button is OK </param>
        /// <returns>current culture based Message </returns>
        public static DialogResult MessageShow(string msgCode,MessageBoxButtons msgBtn)
        {
            DialogResult result=DialogResult.OK;
            // Instantiate an XmlDocument object.
            XmlDocument xmlDoc = new XmlDocument();

            string filePath;
            filePath = AppDomain.CurrentDomain.BaseDirectory + "\\XmlFiles\\Message.xml";
            //TODO temporary 
            //  filePath = @"E:\Kuji\KujiManagement\XmlFiles\Message.xml";
            XmlReader xmlReader;
            XmlNode xmlNode;
            try
            {

                xmlReader = XmlReader.Create(new StreamReader(filePath, Encoding.Default));
                // Load Message.xml into the DOM.
                xmlDoc.Load(xmlReader);
                // Use the SelectSingleNode method to locate a specific title.
                xmlNode = xmlDoc.SelectSingleNode("//message/code[.='" + msgCode + "']");

                // Determine whether a matching node is located. 
                if (!(xmlNode == null))
                {
                    if (language == "en")
                    {
                        result = MessageBox.Show(xmlNode.NextSibling.NextSibling.InnerText, "", msgBtn);
                        //return xmlNode.NextSibling.NextSibling.InnerText;
                    }
                    else
                    {
                      //return xmlNode.NextSibling.InnerText;
                      result = MessageBox.Show(xmlNode.NextSibling.InnerText, "", msgBtn);
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return result;
            }
            finally
            {
                xmlReader = null;
                xmlNode = null;
            }
        }
        #endregion
       
    }
}
