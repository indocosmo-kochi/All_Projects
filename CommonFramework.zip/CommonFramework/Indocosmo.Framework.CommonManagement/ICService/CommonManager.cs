using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.Common;

namespace Indocosmo.Framework.CommonManagement
{
    public class CommonManager
    {        

    #region Get current culture 

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static string GetLanguage()
        {
            string language = "";
            try
            {
                  language = ConfigurationManager.AppSettings["LANGUAGE"].ToString();
            }
            catch { 

            }
            finally
            {
                if (language != "en")
                    language = "ja";
            }
            return language;
        }
    #endregion

    #region String  converstions


        public static int Convert2Int(string expression)
        {
            if (expression.Length == 0)
                return (0);
            else
            {
                try
                {
                    expression = expression.Replace(",", "");
                    int val = int.Parse(expression);
                    return (val);
                }
                catch
                {
                    return (0);
                }
            }
        }

        public static bool Convert2Bool(string expression)
        {
            if (expression.Length == 0)
                return false;
            else
            {
                try
                {
                    expression = expression.Replace(",", "");
                    bool val = bool.Parse(expression);
                    return (val);
                }
                catch
                {
                    return false;
                }
            }
        }

        public static short Convert2Short(string expression)
        {
            if (expression.Length == 0)
                return (0);
            else
            {
                try
                {
                    short val = short.Parse(expression);
                    return (val);
                }
                catch
                {
                    return ((short)(0));
                }
            }
        }

        public static long Convert2Long(string expression)
        {
            if (expression.Length == 0)
                return (0);
            else
            {
                try
                {
                    long val = long.Parse(expression);
                    return (val);
                }
                catch
                {
                    return (0);
                }
            }
        }

        public static float Convert2Float(string expression)
        {
            if (expression.Length == 0)
                return (0);
            else
            {
                try
                {
                    float val = float.Parse(expression);
                    return (val);
                }
                catch
                {
                    return (0);
                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public static double Convert2Double(string expression)
        {
            if (expression.Length == 0)
                return (0);
            else
            {
                try
                {
                    expression = expression.Replace(",", "");
                    double val = double.Parse(expression);
                    return (val);


                }
                catch
                {
                    return (0);
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public static decimal Convert2Decimal(string expression)
        {
            if (expression.Length == 0)
                return (0);
            else
            {
                try
                {
                    expression = expression.Replace(",", "");
                    decimal val = decimal.Parse(expression);
                    return (val);


                }
                catch
                {
                    return (0);
                }
            }
        }

        /// <summary>
        /// Validate date
        /// </summary>
        /// <param name="date"> String date</param>
        /// <returns> True  - valid date 
        ///           False - Invalid date 
        /// </returns>
        public static bool IsDate(string date)
        {
            try
            {
                DateTime.Parse(date);
                return true;
            }
            catch
            {
                return false;
            }

        }


        /// <summary>
        /// Validate Integer
        /// </summary>
        /// <param name="date"> String Integer</param>
        /// <returns> True  - valid Integer 
        ///           False - Invalid Integer 
        /// </returns>
        public static bool IsInteger(string integer)
        {
            try
            {
                int.Parse(integer);
                return true;
            }
            catch
            {
                return false;
            }

        }

        /// <summary>
        /// Validate Double
        /// </summary>
        /// <param name="date"> String Double</param>
        /// <returns> True  - valid Double 
        ///           False - Invalid Double 
        /// </returns>
        public static bool IsDouble(string doublestring)
        {
            try
            {
                double.Parse(doublestring);
                return true;
            }
            catch
            {
                return false;
            }

        }

        /// <summary>
        /// Validate Decimal
        /// </summary>
        /// <param name="date"> String Decimal</param>
        /// <returns> True  - valid Decimal 
        ///           False - Invalid Decimal 
        /// </returns>
        public static bool IsDecimal(string decimalstring)
        {
            try
            {
                decimal.Parse(decimalstring);
                return true;
            }
            catch
            {
                return false;
            }

        }

        #endregion    
           

    #region KanjiforDayofWeek

        public static string GetDayKanji(string date)
        {
            return GetDayKanji(DateTime.Parse(date));
        }

        public static string GetDayKanji(DateTime date)
        {
            string dayKanji = "";
            switch (date.DayOfWeek)
            {
                case DayOfWeek.Monday: dayKanji = "��"; break;
                case DayOfWeek.Tuesday: dayKanji = "��"; break;
                case DayOfWeek.Wednesday: dayKanji = "��"; break;
                case DayOfWeek.Thursday: dayKanji = "��"; break;
                case DayOfWeek.Friday: dayKanji = "��"; break;
                case DayOfWeek.Saturday: dayKanji = "�y"; break;
                case DayOfWeek.Sunday: dayKanji = "��"; break;
            }

            return dayKanji;
        }

        #endregion
   
    #region Cursour function
       
        public static void Hourglass(bool Show)
        {
            if (Show == true)
            {
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;
            }
            else
            {
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
            }
            return;
        }

        #endregion

    }
}
