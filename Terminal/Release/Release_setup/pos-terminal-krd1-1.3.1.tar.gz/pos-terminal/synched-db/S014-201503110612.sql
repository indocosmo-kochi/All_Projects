insert into item_class_display_order(id,menu_id,sub_class_id,display_order,is_deleted) values ("36","5","69","2","0");
insert into item_class_display_order(id,menu_id,sub_class_id,display_order,is_deleted) values ("37","5","70","3","0");
insert into item_class_display_order(id,menu_id,sub_class_id,display_order,is_deleted) values ("38","5","67","5","0");
update item_class_display_order set id="25", menu_id="5", sub_class_id="37", display_order="1", is_deleted="0" where id=25 and is_deleted = 0 and is_synchable = 1;
