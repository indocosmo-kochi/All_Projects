update shop set is_deleted=1 where id =52;
