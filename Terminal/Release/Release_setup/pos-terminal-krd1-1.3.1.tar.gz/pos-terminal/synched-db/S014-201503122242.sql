insert into sale_item_display_order(id,menu_id,sub_class_id,sale_item_id,display_order,is_deleted) values ("571","5","70","436","1","0");
insert into sale_item_display_order(id,menu_id,sub_class_id,sale_item_id,display_order,is_deleted) values ("572","5","70","437","2","0");
insert into sale_item_display_order(id,menu_id,sub_class_id,sale_item_id,display_order,is_deleted) values ("573","5","70","438","3","0");
insert into sale_item_display_order(id,menu_id,sub_class_id,sale_item_id,display_order,is_deleted) values ("574","5","70","439","4","0");
insert into sale_item_display_order(id,menu_id,sub_class_id,sale_item_id,display_order,is_deleted) values ("575","5","70","440","5","0");
insert into sale_item_display_order(id,menu_id,sub_class_id,sale_item_id,display_order,is_deleted) values ("576","5","70","441","6","0");
