update users set is_deleted=1 where id =30;
update shop_users set is_deleted=1 where id =164;
