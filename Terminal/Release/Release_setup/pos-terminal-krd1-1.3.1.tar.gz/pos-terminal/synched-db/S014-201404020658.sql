update shop set is_deleted=1 where id =23;
update shop set is_deleted=1 where id =22;
update shop set is_deleted=1 where id =21;
