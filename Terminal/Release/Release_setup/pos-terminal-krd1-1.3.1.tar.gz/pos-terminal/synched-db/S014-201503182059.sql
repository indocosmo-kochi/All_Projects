update sale_item_display_order set id="510", menu_id="5", sub_class_id="37", sale_item_id="419", display_order="2", is_deleted="0" where id=510 and is_deleted = 0 and is_synchable = 1;
insert into sale_item_display_order(id,menu_id,sub_class_id,sale_item_id,display_order,is_deleted) values ("725","5","37","501","3","0");
insert into sale_item_display_order(id,menu_id,sub_class_id,sale_item_id,display_order,is_deleted) values ("726","5","37","502","6","0");
insert into sale_item_display_order(id,menu_id,sub_class_id,sale_item_id,display_order,is_deleted) values ("727","5","37","504","10","0");
insert into sale_item_display_order(id,menu_id,sub_class_id,sale_item_id,display_order,is_deleted) values ("728","5","37","505","13","0");
update sale_item_display_order set id="475", menu_id="5", sub_class_id="37", sale_item_id="51", display_order="1", is_deleted="0" where id=475 and is_deleted = 0 and is_synchable = 1;
