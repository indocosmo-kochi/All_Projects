insert into sale_item_discounts(id,discount_id,sale_item_id,price,is_deleted) values ("12","71","205","1.20","0");
insert into sale_item_discounts(id,discount_id,sale_item_id,price,is_deleted) values ("13","71","206","1.20","0");
insert into discounts(id,code,name,description,is_percentage,is_overridable,is_item_specific,permitted_for,is_promotion,is_system,price,account_code,grouping_quantity,allow_editing,is_valid,date_from,date_to,time_from,time_to,week_days,created_by,created_at,updated_by,updated_at,is_deleted) values ("71","KIDSPACK2","Kids Sushi 4 Piece Pack $2","Kids Sushi 4 Piece Pack $2","0","0","1","1","0","0",null,"","1","0","1","2018-10-23",null,null,null,null,"28","2018-10-23 12:55:36.0",null,null,"0");
insert into sale_item_discounts(id,discount_id,sale_item_id,price,is_deleted) values ("14","71","207","1.20","0");
insert into sale_item_discounts(id,discount_id,sale_item_id,price,is_deleted) values ("11","71","204","1.20","0");
insert into sale_item_discounts(id,discount_id,sale_item_id,price,is_deleted) values ("15","71","208","0.50","0");
