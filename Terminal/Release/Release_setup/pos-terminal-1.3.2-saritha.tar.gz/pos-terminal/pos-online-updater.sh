restart=""
while true
do
	java -jar ./pos-online-updater.jar $@ ${restart}
	ret=$?
	echo $ret
	if [ $ret -ne 5 ]; then
     	    exit 0
	fi
	restart="--restart"

done



