ALTER TABLE "main"."ui_settings" RENAME TO "_ui_settings_old_20191117";

CREATE TABLE "main"."ui_settings" (
"show_lightbox"  BOOL DEFAULT (1),
"use_coloreditem_buttons"  BOOL DEFAULT (1),
"show_alternative_titles"  BOOL DEFAULT (0),
"show_saleitem_details"  BOOL DEFAULT (0),
"use_singleline_billgrid"  BOOL DEFAULT (1),
"show_details_in_bill_summary"  BOOL DEFAULT (1),
"allow_attendance_entry"  BOOL DEFAULT 0,
"enable_second_cash_deposit"  BOOL DEFAULT 0,
"allow_daily_expense_entry"  bool DEFAULT 0,
"minimum_working_time"  INTEGER DEFAULT 60
)
;

INSERT INTO "main"."ui_settings" ("show_lightbox", "use_coloreditem_buttons", "show_alternative_titles", "show_saleitem_details", "use_singleline_billgrid", "show_details_in_bill_summary", "allow_attendance_entry", "enable_second_cash_deposit") SELECT "show_lightbox", "use_coloreditem_buttons", "show_alternative_titles", "show_saleitem_details", "use_singleline_billgrid", "show_details_in_bill_summary", "allow_attendance_entry", "enable_second_cash_deposit" FROM "_ui_settings_old_20191117";

update ui_settings  set allow_daily_expense_entry=1 where (select 1 from terminal where terminal_code in ('KRD1',	'PBY2',	'PBY2',	'GIN3',	'MTW2',	'APT2',	'HSN1',	'BBAY2',	'POS2',	'EST3',	'BTN1',	'MKU2',	'LAV1',	'LCN2',	'MTR1',	'TNI1',	'SLV1',	'TIRA3',	'SYM1',	'NWT2',	'CST1',	'LMLA',	'ULSA',	'TRP1',	'ANG1',	'BAY1',	'FRC1',	'CBLA2',	'QST1',	'LSQA2',	'QGA2',	'PTN2',	'SLK1',	'HSTA1',	'RCN2',	'SCS2',	'QTW1',	'BHM2',	'NLDA2',	'GRNA1',	'WSG1',	'CHMA2',	'WHAA1',	'CARA2',	'SYDA2',	'SYDB1',	'GOVA2',	'WMKA2',	'MJS1',	'AMOA1',	'CUSA2',	'OTH2',	'QTC1',	'PNMA1',	'MKR3',	'EATA1')) =1;
