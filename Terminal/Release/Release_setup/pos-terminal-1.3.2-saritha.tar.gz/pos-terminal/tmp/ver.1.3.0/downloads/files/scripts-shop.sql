delete from pos_system_functions where id in (15);
INSERT INTO   pos_system_functions  ( id ,  code ,  name ,  description ,  is_view_applicable ,  is_add_applicable ,  is_edit_applicable ,  is_delete_applicable ,  is_execute_applicable ,  is_publish_applicable ,  is_export_applicable ,  is_sync_to_pos ,  created_by ,  created_at ,  updated_by ,  updated_at ,  publish_status ,  is_deleted ,  is_synchable  ) 
VALUES (15, 'oo_cancel', 'Online Order Cancel', 'Online Order Cancel', 0, 0, 0, 0, 1, 0, 0, 1, 0, '2019-11-11 00:00:00.0', NULL, '2019-11-11 00:00:00.0', 0, 0, 1 );

ALTER TABLE "main"."shift_summary" RENAME TO "_shift_summary_old_20191119";

CREATE TABLE "main"."shift_summary" (
"auto_id"  INTEGER NOT NULL,
"station_code"  VARCHAR,
"station_id"  INTEGER DEFAULT 0,
"shop_code"  VARCHAR,
"shop_id"  INTEGER DEFAULT 0,
"shift_id"  INTEGER NOT NULL,
"shift_by"  INTEGER NOT NULL,
"opening_date"  DATETIME NOT NULL,
"opening_time"  DATETIME NOT NULL,
"closing_date"  DATETIME NOT NULL,
"closing_time"  DATETIME NOT NULL,
"opening_float"  DOUBLE DEFAULT (0),
"cash_receipts"  DOUBLE DEFAULT (0),
"card_receipts"  DOUBLE DEFAULT (0),
"voucher_receipts"  DOUBLE DEFAULT (0),
"accounts_receivable"  DOUBLE DEFAULT (0),
"cash_returned"  DOUBLE DEFAULT (0),
"online_receipts"  DOUBLE DEFAULT (0),
"voucher_balance"  DOUBLE DEFAULT (0),
"cash_out"  DOUBLE DEFAULT (0),
"cash_refund"  DOUBLE DEFAULT (0),
"card_refund"  DOUBLE DEFAULT (0),
"voucher_refund"  DOUBLE DEFAULT (0),
"accounts_refund"  DOUBLE DEFAULT (0),
"total_refund"  DOUBLE DEFAULT (0),
"sales"  DOUBLE DEFAULT (0),
"net_cash_received"  DOUBLE DEFAULT (0),
"voucher_balance_returned"  DOUBLE DEFAULT (0),
"closing_cash"  DOUBLE DEFAULT (0),
"actual_cash"  DOUBLE DEFAULT (0),
"cash_variance"  DOUBLE DEFAULT (0),
"cash_deposit"  DOUBLE DEFAULT (0),
"cash_remaining"  DOUBLE DEFAULT (0),
"referance_number"  VARCHAR DEFAULT (NULL),
"sync_status"  INTEGER DEFAULT (0),
"sync_message"  VARCHAR DEFAULT (NULL),
"cash_deposit_two"  DOUBLE DEFAULT 0,
"refference_number_two"  TEXT,
"actual_card"  DOUBLE DEFAULT 0,
"card_variance"  DOUBLE,
"total_expense"  DOUBLE,
PRIMARY KEY ("auto_id" ASC)
)
;

INSERT INTO "main"."shift_summary" ("auto_id", "station_code", "station_id", "shop_code", "shop_id", "shift_id", "shift_by", "opening_date", "opening_time", "closing_date", "closing_time", "opening_float", "cash_receipts", "card_receipts", "voucher_receipts", "accounts_receivable", "cash_returned", "online_receipts", "voucher_balance", "cash_out", "cash_refund", "card_refund", "voucher_refund", "accounts_refund", "total_refund", "sales", "net_cash_received", "voucher_balance_returned", "closing_cash", "actual_cash", "cash_variance", "cash_deposit", "cash_remaining", "referance_number", "sync_status", "sync_message", "cash_deposit_two", "refference_number_two", "actual_card", "card_variance") SELECT "auto_id", "station_code", "station_id", "shop_code", "shop_id", "shift_id", "shift_by", "opening_date", "opening_time", "closing_date", "closing_time", "opening_float", "cash_receipts", "card_receipts", "voucher_receipts", "accounts_receivable", "cash_returned", "online_receipts", "voucher_balance", "cash_out", "cash_refund", "card_refund", "voucher_refund", "accounts_refund", "total_refund", "sales", "net_cash_received", "voucher_balance_returned", "closing_cash", "actual_cash", "cash_variance", "cash_deposit", "cash_remaining", "referance_number", "sync_status", "sync_message", "cash_deposit_two", "refference_number_two", "actual_card", "card_variance" FROM "_shift_summary_old_20191119";

DROP TABLE IF EXISTS expense;
CREATE TABLE expense (
id  bigint(20) NOT NULL,
code  varchar(10) NOT NULL,
name  varchar(100) NOT NULL,
description  varchar(250) DEFAULT NULL,
expense_type  bigint(11) NOT NULL,
created_by  int(11) DEFAULT NULL,
created_at  datetime DEFAULT NULL,
updated_by  int(11) DEFAULT NULL,
updated_at  datetime DEFAULT NULL,
publish_status  tinyint(1) NOT NULL DEFAULT '0',
is_deleted  tinyint(1) NOT NULL DEFAULT '0',
is_synchable  tinyint(1) NOT NULL DEFAULT '1',
last_sync_at  timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY (id ASC)
);

DROP TABLE IF EXISTS expense_type;
CREATE TABLE expense_type (
id  bigint(20) NOT NULL,
code  varchar(10) NOT NULL,
name  varchar(100) NOT NULL,
short_name  varchar(100),
description  varchar(250) DEFAULT NULL,
gl_acc_code_global  varchar(50),
gl_acc_code_shop  varchar(50),
created_by  int(11) DEFAULT NULL,
created_at  datetime DEFAULT NULL,
updated_by  int(11) DEFAULT NULL,
updated_at  datetime DEFAULT NULL,
publish_status  tinyint(1) NOT NULL DEFAULT '0',
is_deleted  tinyint(1) NOT NULL DEFAULT '0',
is_synchable  tinyint(1) NOT NULL DEFAULT '1',
last_sync_at  timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY (id ASC)
);


DROP TABLE IF EXISTS txn_expense_dtl;
CREATE TABLE txn_expense_dtl (
id  INTEGER PRIMARY KEY AUTOINCREMENT,
shop_id  bigint(20) NOT NULL,
station_id  int(11) NOT NULL,
expense_hdr_id  bigint(60) NOT NULL,
expense_id  bigint(20) NOT NULL,
expense_name  varchar(100) DEFAULT NULL,
amount  decimal(8,2) NOT NULL,
is_deleted  tinyint(1) NOT NULL DEFAULT '0'
);


DROP TABLE IF EXISTS txn_expense_hdr;
CREATE TABLE "txn_expense_hdr" (
id  bigint(20) NOT NULL,
shop_id  bigint(20) NOT NULL,
station_id  int(11) NOT NULL,
user_id  int(11) NOT NULL,
shift_id  bigint(20) NOT NULL,
receipt_no  VARCHAR(100) NOT NULL,
cashout_date  date NOT NULL,
cashout_time  datetime NOT NULL,
amount  decimal(8,2) NOT NULL,
created_by  bigint(11) DEFAULT NULL,
created_at  datetime DEFAULT NULL,
updated_by  bigint(11) DEFAULT NULL,
updated_at  datetime DEFAULT NULL,
sync_message  varchar(1000) DEFAULT NULL,
sync_status  tinyint(4) DEFAULT '0',
is_deleted  tinyint(1) NOT NULL DEFAULT '0',
employee_id  INTEGER,
PRIMARY KEY (id , shop_id , station_id )
);

delete from sync_table_settings where id in (10,11,12,13);
insert into sync_table_settings ("id", "sync_order", "table_id", "table_name", "parent_table_id", "table_criteria", "order_by", "column_to_exclude", "web_param_value", "remarks") values ('10', NULL, '10', 'order_customer', '1', 'order_customer.order_id = order_hdrs.order_id', 'order_customer.order_id', NULL, NULL, 'For Order synchronization');
insert into sync_table_settings ("id", "sync_order", "table_id", "table_name", "parent_table_id", "table_criteria", "order_by", "column_to_exclude", "web_param_value", "remarks") values ('11', NULL, '11', 'order_hdr_ext', '1', 'order_hdr_ext.order_id = order_hdrs.order_id', 'order_hdr_ext.order_id', NULL, NULL, 'For Order synchronization');
insert into sync_table_settings ("id", "sync_order", "table_id", "table_name", "parent_table_id", "table_criteria", "order_by", "column_to_exclude", "web_param_value", "remarks") values ('12', '6', '12', 'txn_expense_hdr', '0', ' ', 'txn_expense_hdr.id', 'sync_status, sync_message', 'expense', 'For Expense Synchronization');
insert into sync_table_settings ("id", "sync_order", "table_id", "table_name", "parent_table_id", "table_criteria", "order_by", "column_to_exclude", "web_param_value", "remarks") values ('13', NULL, '13', 'txn_expense_dtl', '12', 'txn_expense_hdr.id=txn_expense_dtl.expense_hdr_id', 'txn_expense_dtl.id', NULL, 'expense', 'For Expense Synchronization');



