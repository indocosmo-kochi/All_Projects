update ui_settings set allow_attendance_entry=1;
