INSERT INTO "pos_system_functions" ("id", "code", "name", "description", "is_view_applicable", "is_add_applicable", "is_edit_applicable", "is_delete_applicable", "is_execute_applicable", "is_publish_applicable", "is_export_applicable", "is_sync_to_pos", "created_by", "created_at", "updated_by", "updated_at", "publish_status", "is_deleted", "is_synchable") VALUES (16, 'daily_expense', 'Edit Daily Expense', 'Allow edit daily expense', 0, 0, 0, 0, 1, 0, 0, 1, 0, '2019-11-11 00:00:00.0', NULL, '2019-11-11 00:00:00.0', 0, 0, 1);



ALTER TABLE "main"."discounts" RENAME TO "_discounts_old_20191204";

CREATE TABLE "main"."discounts" (
"id"  INTEGER NOT NULL,
"code"  VARCHAR NOT NULL,
"name"  VARCHAR NOT NULL,
"description"  VARCHAR,
"is_percentage"  BOOL NOT NULL DEFAULT (1),
"is_overridable"  BOOL DEFAULT (0),
"is_item_specific"  BOOL DEFAULT (0),
"permitted_for"  NUMBER NOT NULL DEFAULT (1),
"is_promotion"  BOOL NOT NULL DEFAULT (0),
"is_system"  BOOL NOT NULL DEFAULT (0),
"price"  DOUBLE DEFAULT (0),
"grouping_quantity"  INTEGER NOT NULL DEFAULT (0),
"allow_editing"  INTEGER NOT NULL DEFAULT (0),
"is_valid"  BOOL NOT NULL DEFAULT (1),
"date_from"  DATETIME,
"date_to"  DATETIME,
"time_from"  DATETIME,
"time_to"  DATETIME,
"week_days"  VARCHAR,
"created_by"  INTEGER,
"created_at"  DATETIME DEFAULT (CURRENT_TIMESTAMP),
"updated_by"  INTEGER,
"updated_at"  DATETIME,
"publish_status"  BOOL DEFAULT (0),
"is_deleted"  BOOL NOT NULL DEFAULT ('0'),
"is_synchable"  BOOL NOT NULL DEFAULT ('1'),
"account_code"  VARCHAR,
"fg_color"  VARCHAR,
"bg_color"  VARCHAR,
"display_order"  INTEGER,
PRIMARY KEY ("id" ASC)
)
;

INSERT INTO "main"."discounts" ("id", "code", "name", "description", "is_percentage", "is_overridable", "is_item_specific", "permitted_for", "is_promotion", "is_system", "price", "grouping_quantity", "allow_editing", "is_valid", "date_from", "date_to", "time_from", "time_to", "week_days", "created_by", "created_at", "updated_by", "updated_at", "publish_status", "is_deleted", "is_synchable", "account_code") SELECT "id", "code", "name", "description", "is_percentage", "is_overridable", "is_item_specific", "permitted_for", "is_promotion", "is_system", "price", "grouping_quantity", "allow_editing", "is_valid", "date_from", "date_to", "time_from", "time_to", "week_days", "created_by", "created_at", "updated_by", "updated_at", "publish_status", "is_deleted", "is_synchable", "account_code" FROM "_discounts_old_20191204";



DROP   VIEW  IF EXISTS v_discounts;
CREATE VIEW v_discounts AS
select * from discounts  where  (date_from is null or date(date_from)<=date()) and (date_to is null or date(date_to)>=date())  and is_valid=1 and is_promotion=0 and is_deleted=0 order by name;

DROP   VIEW  IF EXISTS v_sale_item_discounts;
CREATE VIEW v_sale_item_discounts AS
select 
vd.id,
vd.code,
vd.name,
vd.description,
vd.is_percentage,
vd.is_overridable,
vd.is_item_specific,
vd.permitted_for,
vd.is_promotion,
vd.is_system,
sid.price price,
vd.grouping_quantity,
vd.allow_editing,
vd.is_valid,
vd.date_from,
vd.date_to,
vd.time_from,
vd.time_to,
vd.week_days,
vd.created_by,
vd.created_at,
vd.updated_by,
vd.updated_at,
vd.publish_status,
vd.is_deleted,
vd.is_synchable,
sale_item_id ,
vd.display_order,
vd.bg_color,
vd.fg_color
from v_discounts as vd inner join  sale_item_discounts as sid on  sid.discount_id=vd.id where sid.is_deleted=0;
