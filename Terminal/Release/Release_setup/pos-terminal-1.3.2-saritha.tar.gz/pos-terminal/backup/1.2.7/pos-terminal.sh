#!/bin/bash

counter=0
ps -ax  | grep 'pos-terminal.sh' | grep  '/bin/bash' > proc
counter=$(grep -c 'pos-terminal'  proc) 

echo -e "\n\t`expr $counter - 1` instances found running."

if [ $counter -gt 1 ]
then
    echo -e "\tpos-terminal application already running.\n"
    exit 0
fi

while true
do
	java -jar ./pos-terminal.jar
	ret=$?
	echo $ret
	if [ $ret -eq 0 ]; then
		exit 0
		break;
	fi
	if [ $ret -eq 4 ]; then
		while true
		do
     	  		java -jar ./pos-online-updater.jar --restart
     	  		upret=$?
     	  	if [ $upret -eq 0 ]; then
     	  		break;
     	 	fi
     	done
	fi
done
 
