
while true
do
	java -jar ./pos-terminal.jar
	ret=$?
	echo $ret
	if [ $ret -eq 0 ]; then
		exit 0
		break;
	fi
	if [ $ret -eq 4 ]; then
		while true
		do
     	  		java -jar ./pos-online-updater.jar --restart
     	  		upret=$?
     	  	if [ $upret -eq 0 ]; then
     	  		break;
     	 	fi
     	done
	fi
	
done