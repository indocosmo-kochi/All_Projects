#!/bin/bash

BASEDIR=`dirname "${0}"`
cd $BASEDIR

java -jar ./pos-db-updater.jar $@
