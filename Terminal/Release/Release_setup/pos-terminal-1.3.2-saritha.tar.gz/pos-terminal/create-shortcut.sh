#!/bin/bash

SCRIPT_DIR=$(readlink -f "$0")
BASEDIR=$(dirname "$SCRIPT_DIR")
#echo "$BASEDIR"

cat <<END > ~/Desktop/MOCHI-POS.desktop
[Desktop Entry]
Name=MOCHI-POS
Encoding=UTF-8
Version=1.0
GenericName=MOCHI-POS
Exec=$BASEDIR/pos-terminal.sh
Terminal=false
Type=Application
Categories=System;
Path=$BASEDIR/
Icon=$BASEDIR/pos-icon.png
END
