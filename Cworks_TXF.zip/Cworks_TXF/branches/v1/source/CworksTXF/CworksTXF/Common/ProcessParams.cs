﻿namespace CWorksTXF.Common
{
    public  class ProcessParam
    {
        public string InputFileName { get; set; }
        public string OutputFileName { get; set; }
        public string PaperSize { get; set; }
        public string RotateAngle { get; set; }
        public string FontName { get; set; }
        public string AutoCADVersion { get; set; }
        public string Param1 { get; set; }
        public string Param2 { get; set; }
        public string Param3 { get; set; }

        public override string ToString()
        {
            return " Utility Parameters =>" + System.Environment.NewLine + 
                   "Input File :" + InputFileName + System.Environment.NewLine +
                   "Output File :" + OutputFileName + System.Environment.NewLine +
                   "PAPERSIZE :" + PaperSize + System.Environment.NewLine +
                   "ROTATE :" + RotateAngle + System.Environment.NewLine +
                   "FONT :" + FontName + System.Environment.NewLine +
                   "VERSION :" + AutoCADVersion;
        }
    }
}
