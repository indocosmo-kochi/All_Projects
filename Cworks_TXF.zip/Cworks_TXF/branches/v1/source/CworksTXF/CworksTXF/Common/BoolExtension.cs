﻿namespace CWorksTXF.Common
{
    public static class BoolExtension
    {
        public static string ToString(this bool value, int i)
        {
            return (value) ?  "1" : "0";
        }
    }
}
