﻿using System;

namespace CWorksTXF.Common
{
    public class CWorksTXFException : ApplicationException
    {
        public CWorksTXFException(String message) : base(message)
        {
        }
    }
}
