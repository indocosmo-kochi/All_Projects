﻿using CWorksTXF.Entities;
using System;
using System.Collections;
using System.Linq;
using System.Resources;

namespace CWorksTXF.Common
{
    public static class Resource
    {
        public static string GetTXFEntityTitle(string entityTypeName)
        {
            return GetResourceTitle<CwcEntityTitle>(entityTypeName);
        }
        static string GetResourceTitle<T>(string key)
        {
            ResourceManager rm = new ResourceManager(typeof(T));
            string someString = rm.GetString(key);
            return someString;
        }

        public static string GetTXFEntityTypeName(string entityTitle)
        {
            return GetResourceValue<CwcEntityTitle>(entityTitle);
        }

        static string GetResourceValue<T>(string value)
        {
            ResourceManager rm = new ResourceManager(typeof(T));
            
            var entry =
                rm.GetResourceSet(System.Threading.Thread.CurrentThread.CurrentCulture, true, true)
                  .OfType<DictionaryEntry>()
                  .FirstOrDefault(e => e.Value.ToString() == value);

            return entry.Key.ToString();

        }

    }
}