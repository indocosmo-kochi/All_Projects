﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CWorksTXF.Common
{
    public static class Enums
    {

        public enum MeasurementValue
        {
            English = 0,
            Metric = 1
        }


        public enum CurveType
        {
            EllipticalArc2d = 1,
            CircularArc2d = 2,
            LineSegment2d = 3,
            NurbCurve2d = 4
        }


        /// //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// Enum conversion sub routines
        /// //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// integer/enum String value to enum convertion 
        public static T ConvertStringToEnumValue<T>(string str) where T : struct, IConvertible
        {
            T val = ((T[])Enum.GetValues(typeof(T)))[0];

            if (!typeof(T).IsEnum)
            {
                Logger.RecordMessage(typeof(T).Name + " - is not an Enumeration type.", Logs.Log.MessageType.Exception);
            }
            try
            {
                val = (T)Enum.Parse(typeof(T), str);
            }
            catch (Exception)
            {
                Logger.RecordMessage(str + " - is not a valid value for the type : " + typeof(T).Name, Logs.Log.MessageType.Exception);
            }
            return val;
        }


        public static T ConvertEnumValueToString<T>(int intValue) where T : struct, IConvertible
        {
            if (!typeof(T).IsEnum)
            {
                throw new Exception("T must be an Enumeration type.");
            }
            T val = ((T[])Enum.GetValues(typeof(T)))[0];

            foreach (T enumValue in (T[])Enum.GetValues(typeof(T)))
            {
                if (Convert.ToInt32(enumValue).Equals(intValue))
                {
                    val = enumValue;
                    break;
                }
            }
            return val;
        }

    }
}
