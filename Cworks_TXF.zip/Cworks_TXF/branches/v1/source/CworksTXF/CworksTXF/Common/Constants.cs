﻿using System.IO;

namespace CWorksTXF.Common
{
    public static class CONST
    {
        public const string MODEL_SPACE = "*MODEL_SPACE";

        // Line Type file supplied along with the exe
        public const string ACAD_LINETYPES_FILE = "Acad/acadiso.lin";

    }
}
