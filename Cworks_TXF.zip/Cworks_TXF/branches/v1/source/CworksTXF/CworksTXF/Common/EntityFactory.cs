﻿using CWorksTXF.Txf.Reader;
using CWorksTXF.Txf.Writer;
using CWorksTXF.Dwg.Reader;
using CWorksTXF.Dwg.Writer;

namespace CWorksTXF.Common
{
    abstract class EntityFactory
    {
        public abstract IDwgEntityReader getDwgEntityReader(string typeName);
        public abstract ITxfEntityWriter getTxfEntityWriter(string typeName);

        public abstract ITxfEntityReader getTxfEntityReader(string typeName);
        public abstract IDwgEntityWriter getDwgEntityWriter(string typeName);
    }

    class EntityConcreteFactory : EntityFactory
    {
        public override IDwgEntityReader getDwgEntityReader(string typeName)
        {
            switch (typeName)
            {
                case "AlignedDimension": return new DwgAlignedDimensionReader();
                case "Arc": return new DwgArcReader();
                case "BlockTableRecord": return new DwgBlockReader();
                case "BlockReference": return new DwgBlockReferenceReader();
                case "Circle": return new DwgCircleReader();
                case "DBPoint": return new DwgDBPointReader();
                case "DBText": return new DwgDBTextReader();
                case "DimStyleTableRecord": return new DwgDimStyleReader();
                case "Ellipse": return new DwgEllipseReader();
                case "Face": return new DwgFaceReader();
                case "Hatch": return new DwgHatchReader();
                case "LayerTableRecord": return new DwgLayerReader();
                case "Leader": return new DwgLeaderReader();
                case "Line": return new DwgLineReader();
                case "MText": return new DwgMTextReader();
                case "OrdinateDimension": return new DwgOrdinateDimensionReader();
                case "Polyline": return new DwgPolylineReader();
                case "RotatedDimension": return new DwgRotatedDimensionReader();
                case "Spline": return new DwgSplineReader();
                case "TextStyleTableRecord": return new DwgTextStyleReader();
                case "ViewportTableRecord": return new DwgViewportReader();
                default:
                    {
                        Logger.RecordMessage(string.Format("DwgEntityReader for Entity type {0} not created.", typeName), Logs.Log.MessageType.Informational);
                        return null;
                    }
            }

        }

        public override ITxfEntityWriter getTxfEntityWriter(string typeName)
        {
            switch (typeName)
            {
                case "AlignedDimension": return new TxfAlignedDimensionWriter();
                case "Arc": return new TxfArcWriter();
                case "BlockTableRecord": return new TxfBlockWriter();
                case "BlockReference": return new TxfBlockReferenceWriter();
                case "Circle": return new TxfCircleWriter();
                case "DBPoint": return new TxfDBPointWriter();
                case "DBText": return new TxfDBTextWriter();
                case "DimStyleTableRecord": return new TxfDimStyleWriter();
                case "Ellipse": return new TxfEllipseWriter();
                case "Face": return new TxfFaceWriter();
                case "Hatch": return new TxfHatchWriter();
                case "LayerTableRecord": return new TxfLayerWriter();
                case "Leader": return new TxfLeaderWriter();
                case "Line": return new TxfLineWriter();
                case "MText": return new TxfMTextWriter();
                case "OrdinateDimension": return new TxfOrdinateDimensionWriter();
                case "Polyline": return new TxfPolylineWriter();
                case "RotatedDimension": return new TxfRotatedDimensionWriter();
                case "Spline": return new TxfSplineWriter();
                case "TextStyleTableRecord": return new TxfTextStyleWriter();
                case "ViewportTableRecord": return new TxfViewportWriter();
                default:
                    {
                        Logger.RecordMessage(string.Format("TxfEntityWriter for Entity type {0} not created.", typeName), Logs.Log.MessageType.Informational);
                        return null;
                    }
            }
        }

        public override ITxfEntityReader getTxfEntityReader(string typeName)
        {
            switch (typeName)
            {

                case "AlignedDimension": return new TxfAlignedDimensionReader();
                case "Arc": return new TxfArcReader();
                case "Block": return new TxfBlockReader();
                case "BlockReference": return new TxfBlockReferenceReader();
                case "Circle": return new TxfCircleReader();
                case "DBPoint": return new TxfDBPointReader();
                case "DBText": return new TxfDBTextReader();
                case "DimStyle": return new TxfDimStyleReader();
                case "Ellipse": return new TxfEllipseReader();
                case "Hatch": return new TxfHatchReader();
                case "Layer": return new TxfLayerReader();
                case "Leader": return new TxfLeaderReader();
                case "Line": return new TxfLineReader();
                case "MText": return new TxfMTextReader();
                case "OrdinateDimension": return new TxfOrdinateDimensionReader();
                case "Polyline": return new TxfPolyLineReader();
                case "RotatedDimension": return new TxfRotatedDimensionReader();
                case "Spline": return new TxfSplineReader();
                case "TextStyle": return new TxfTextStyleReader();
                case "Viewport": return new TxfViewportReader();
                default:
                    {
                        Logger.RecordMessage(string.Format("TxfEntityReader for Entity type {0} not created.", typeName), Logs.Log.MessageType.Informational);
                        return null;
                    }
            }
        }

        public override IDwgEntityWriter getDwgEntityWriter(string typeName)
        {
            switch (typeName)
            {
                case "AlignedDimension": return new DwgAlignedDimensionWriter();
                case "Arc": return new DwgArcWriter();
                case "Block": return new DwgBlockWriter();
                case "BlockReference": return new DwgBlockReferenceWriter();
                case "Circle": return new DwgCircleWriter();
                case "DBPoint": return new DwgDBPointWriter();
                case "DBText": return new DwgDBTextWriter();
                case "DimStyle": return new DwgDimStyleWriter(); 
                case "Ellipse": return new DwgEllipseWriter();
                case "Hatch": return new DwgHatchWriter();
                case "Layer": return new DwgLayerWriter();
                case "Leader": return new DwgLeaderWriter();
                case "Line": return new DwgLineWriter();
                case "MText": return new DwgMTextWriter();
                case "OrdinateDimension": return new DwgOrdinateDimensionWriter();
                case "Polyline": return new DwgPolyLineWriter();
                case "RotatedDimension": return new DwgRotatedDimensionWriter();
                case "Spline": return new DwgSplineWriter();
                case "TextStyle": return new DwgTextStyleWriter();
                case "Viewport": return new DwgViewportWriter();
                default:
                    {
                        Logger.RecordMessage(string.Format("DwgEntityWriter for Entity type {0} not created.", typeName), Logs.Log.MessageType.Informational);
                        return null;
                    }
            }


        }


    }
}
