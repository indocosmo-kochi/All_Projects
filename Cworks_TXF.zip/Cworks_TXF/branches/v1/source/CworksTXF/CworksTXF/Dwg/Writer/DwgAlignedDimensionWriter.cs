﻿using CWorksTXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksTXF.Dwg.Writer
{
    public class DwgAlignedDimensionWriter : DwgEntityWriter
    {

        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId entityId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable blockTbl = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable)
                {

                    // save the current line type for database into a temp variable
                    ObjectId current_linetypeId = db.Celtype;

                    CwcAlignedDimension entityObject = cwcDbObject as CwcAlignedDimension;

                    using (AlignedDimension alignedDimension = new AlignedDimension())
                    {

                        alignedDimension.XLine1Point = new Point3d(entityObject.XLine1Point.X, entityObject.XLine1Point.Y, entityObject.XLine1Point.Z);
                        alignedDimension.XLine2Point = new Point3d(entityObject.XLine2Point.X, entityObject.XLine2Point.Y, entityObject.XLine2Point.Z);
                        alignedDimension.DimLinePoint = new Point3d(entityObject.DimLinePoint.X, entityObject.DimLinePoint.Y, entityObject.DimLinePoint.Z);
                        alignedDimension.DimensionStyle = GetDwgObjectId(entityObject.DimStyleId.ToString());
                        //using (DimStyleTable dt = (DimStyleTable)db.DimStyleTableId.GetObject(OpenMode.ForRead))
                        //{
                        //    DimStyleTableRecord dtr1 = (DimStyleTableRecord)tm.GetObject(dt[entityObject.DimensionStyleId], OpenMode.ForRead);

                        //    ObjectId dimStyleId = dtr1.Id;
                        //    alignedDimension.DimensionStyle = dimStyleId;
                        //    if (entityObject.TextStyleId.Length > 0)
                        //    {
                        //        using (DimStyleTableRecord dtr = (DimStyleTableRecord)tm.GetObject(dimStyleId, OpenMode.ForWrite))
                        //        {
                        //            dtr.UpgradeOpen();
                        //            dtr.Dimtxsty = GetDwgObjectId(entityObject.TextStyleId);
                        //        }
                        //    }


                        //}

                        alignedDimension.SetDatabaseDefaults();

                        if (entityObject.LayerId.Length > 0)
                            alignedDimension.LayerId = GetDwgObjectId(entityObject.LayerId);

                        alignedDimension.Color = GetDwgColor(entityObject.Color);

                        if (entityObject.TextStyleId.Length > 0)
                        {
                            alignedDimension.TextStyleId = GetDwgObjectId(entityObject.TextStyleId);
                        }

                        alignedDimension.TextPosition = new Point3d(entityObject.TextPosition.X, entityObject.TextPosition.Y, entityObject.TextPosition.Z);
                        alignedDimension.TextRotation = entityObject.TextRotation;

                        alignedDimension.LinetypeId = GetLineTypeIdFromName(db, entityObject.Linetype);
                        alignedDimension.LinetypeScale = entityObject.LinetypeScale;

                        alignedDimension.LineWeight = entityObject.LineWeight;

                        ObjectId btrId;

                        // Open the Block table record for write
                        if (entityObject.BlockId == null)
                            btrId = blockTbl[BlockTableRecord.ModelSpace];
                        else
                            btrId = GetDwgObjectId(entityObject.BlockId);

                        using (BlockTableRecord btr = tr.GetObject(btrId, OpenMode.ForWrite) as BlockTableRecord)
                        {
                            // Add the new object to the block table record and the transaction
                            entityId = btr.AppendEntity(alignedDimension);
                            tm.AddNewlyCreatedDBObject(alignedDimension, true);
                        }

                    }


                    // restore the current line type for database from the temp variable
                    db.Celtype = current_linetypeId;
                }
                tr.Commit();
            }


            return entityId;
        }
    }
}
