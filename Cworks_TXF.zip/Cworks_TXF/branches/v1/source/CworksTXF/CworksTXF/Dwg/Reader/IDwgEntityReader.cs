﻿using CWorksTXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksTXF.Dwg.Reader
{
    interface IDwgEntityReader
    {
        CwcDbObject ReadEntityDetails(DBObject dbObject);
    }

}
