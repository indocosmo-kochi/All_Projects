﻿using CWorksTXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksTXF.Dwg.Writer
{
    public class DwgDimStyleWriter : DwgEntityWriter
    {
        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId dimstyleId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (DimStyleTable dst = (DimStyleTable)tm.GetObject(db.DimStyleTableId, OpenMode.ForRead))
                {

                    CwcDimStyle dimstyle = cwcDbObject as CwcDimStyle;

                    if (dst.Has(dimstyle.Name))
                    {
                        dimstyleId = dst[dimstyle.Name];
                        using (DimStyleTableRecord dstr = (DimStyleTableRecord)tm.GetObject(dimstyleId, OpenMode.ForWrite))
                        {
                            dst.UpgradeOpen();
                            SetDimStyleProperties(dstr, dimstyle);
                        }
                    }
                    else
                    {

                        using (DimStyleTableRecord dstr = new DimStyleTableRecord())
                        {
                            dst.UpgradeOpen();
                            dstr.Name = dimstyle.Name;
                            dimstyleId = dst.Add(dstr);
                            SetDimStyleProperties(dstr, dimstyle);
                            tm.AddNewlyCreatedDBObject(dstr, true);

                        }
                    }
                }
                tr.Commit();
            }
            return dimstyleId;
        }

        private void SetDimStyleProperties(DimStyleTableRecord dstr, CwcDimStyle dimstyle)
        {
            dstr.Dimadec = dimstyle.Dimadec;
            dstr.Dimalt = dimstyle.Dimalt;
            dstr.Dimaltd = dimstyle.Dimaltd;
            dstr.Dimaltf = dimstyle.Dimaltf;
            dstr.Dimaltrnd = dimstyle.Dimaltrnd;
            dstr.Dimalttd = dimstyle.Dimalttd;
            dstr.Dimalttz = dimstyle.Dimalttz;
            dstr.Dimaltu = dimstyle.Dimaltu;
            dstr.Dimaltz = dimstyle.Dimaltz;
            dstr.Dimapost = dimstyle.Dimapost;
            dstr.Dimarcsym = dimstyle.Dimarcsym;
            dstr.Dimasz = dimstyle.Dimasz;
            dstr.Dimatfit = dimstyle.Dimatfit;
            dstr.Dimaunit = dimstyle.Dimaunit;
            dstr.Dimazin = dimstyle.Dimazin;
            // If Dimsah is true, the arrowheads are formed by blocks set by the Dimblk1 and Dimblk2. If false, a block from Dimblk is used
            dstr.Dimsah = dimstyle.Dimsah;
            if (dimstyle.Dimsah)
            {
                dstr.Dimblk1s = dimstyle.Dimblk1s;
                dstr.Dimblk2s = dimstyle.Dimblk2s;
            }
            else
            {
                dstr.Dimblks = dimstyle.Dimblks;
            }
            dstr.Dimcen = dimstyle.Dimcen;
            dstr.Dimdec = dimstyle.Dimdec;
            dstr.Dimdle = dimstyle.Dimdle;
            dstr.Dimdli = dimstyle.Dimdli;
            dstr.Dimdsep = dimstyle.Dimdsep;
            dstr.Dimexe = dimstyle.Dimexe;
            dstr.Dimexo = dimstyle.Dimexo;
            dstr.Dimfrac = dimstyle.Dimfrac;
            dstr.Dimfxlen = dimstyle.Dimfxlen;
            dstr.DimfxlenOn = dimstyle.DimfxlenOn;
            dstr.Dimgap = dimstyle.Dimgap;
            dstr.Dimjogang = dimstyle.Dimjogang;
            dstr.Dimjust = dimstyle.Dimjust;
            dstr.Dimldrblks = dimstyle.Dimldrblks; 
            dstr.Dimlfac = dimstyle.Dimlfac;
            dstr.Dimlim = dimstyle.Dimlim;
            ////// Linetype Ext 1		
            dstr.Dimltex1 = GetDwgObjectId(dimstyle.Dimltex1);
            //////////////// Linetype Ext 2
            dstr.Dimltex2 = GetDwgObjectId(dimstyle.Dimltex2);
            /////////////////////////// Linetype
            dstr.Dimltype = GetDwgObjectId(dimstyle.Dimltype);
            // 1..6 values
            if ((dimstyle.Dimlunit >= 1) && (dimstyle.Dimlunit <= 6))
                dstr.Dimlunit = dimstyle.Dimlunit;
            ////////////////////// Lineweight
            dstr.Dimlwd = dimstyle.Dimlwd;
            /////////////////////// Lineweight
            dstr.Dimlwe = dimstyle.Dimlwe;
            dstr.Dimpost = dimstyle.Dimpost;
            dstr.Dimrnd = dimstyle.Dimrnd;
            dstr.Dimscale = dimstyle.Dimscale;
            dstr.Dimsd1 = dimstyle.Dimsd1;
            dstr.Dimsd2 = dimstyle.Dimsd2;
            dstr.Dimse1 = dimstyle.Dimse1;
            dstr.Dimse2 = dimstyle.Dimse2;
            dstr.Dimsoxd = dimstyle.Dimsoxd;
            dstr.Dimtad = dimstyle.Dimtad;
            dstr.Dimtdec = dimstyle.Dimtdec;
            dstr.Dimtfac = dimstyle.Dimtfac;
            dstr.Dimtfill = dimstyle.Dimtfill;
            dstr.Dimtih = dimstyle.Dimtih;
            dstr.Dimtix = dimstyle.Dimtix;
            dstr.Dimtm = dimstyle.Dimtm;
            dstr.Dimtmove = dimstyle.Dimtmove;
            dstr.Dimtofl = dimstyle.Dimtofl;
            dstr.Dimtoh = dimstyle.Dimtoh;
            dstr.Dimtol = dimstyle.Dimtol;
            dstr.Dimtolj = dimstyle.Dimtolj;
            dstr.Dimtp = dimstyle.Dimtp;
            dstr.Dimtsz = dimstyle.Dimtsz;
            dstr.Dimtvp = dimstyle.Dimtvp;
            // Dimtxsty -ObjectId of a TextStyleTableRecord object  
            dstr.Dimtxsty = GetDwgObjectId(dimstyle.Dimtxsty);
            dstr.Dimtxt = dimstyle.Dimtxt;
            dstr.Dimtzin = dimstyle.Dimtzin;
            dstr.Dimupt = dimstyle.Dimupt;
            dstr.Dimzin = dimstyle.Dimzin;

            dstr.Dimclrd = GetDwgColor(dimstyle.Dimclrd);
            dstr.Dimclre = GetDwgColor(dimstyle.Dimclre);
            dstr.Dimclrt = GetDwgColor(dimstyle.Dimclrt);
            dstr.Dimtfillclr = GetDwgColor(dimstyle.Dimtfillclr);

        }
    }
}
