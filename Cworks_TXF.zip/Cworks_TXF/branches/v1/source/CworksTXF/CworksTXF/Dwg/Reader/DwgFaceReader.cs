﻿using CWorksTXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksTXF.Dwg.Reader
{

    public class DwgFaceReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            // TO DO: Test & implement the scenario of handing a face with 3 vertices to assign null values to the 4th vertex, 
            // otherwise may return (0,0,0) a valid point for this non-existant 4th vertex 
            CwcFace face = new CwcFace();
            var entity = (dbObject as Face);
            face.Id = entity.Id.ToString();
            face.LayerId = entity.LayerId.ToString();
    //        face.LayerName = Layers[face.LayerId].Name;
            face.Vertex1 = entity.GetVertexAt(0);
            face.Vertex2 = entity.GetVertexAt(1);
            face.Vertex3 = entity.GetVertexAt(2);
            face.Vertex4 = entity.GetVertexAt(3);

            face.IsEdgeVisibleAtVertex1 = entity.IsEdgeVisibleAt(0);
            face.IsEdgeVisibleAtVertex2 = entity.IsEdgeVisibleAt(1);
            face.IsEdgeVisibleAtVertex3 = entity.IsEdgeVisibleAt(2);
            face.IsEdgeVisibleAtVertex4 = entity.IsEdgeVisibleAt(3);

            face.IsVisible = entity.Visible;
            face.Material = entity.Material;

            face.Linetype = entity.Linetype;
            face.BlockId = entity.BlockId.ToString();
            face.BlockName = entity.BlockName;

          //  face.LineWeight = entity.LineWeight.ToString();

            face.Color = GetDwgEntityColor(entity.Color, entity.LayerId.ToString());

            return face;
        }
    }


}

