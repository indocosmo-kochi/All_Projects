﻿using CWorksTXF.Common;
using CWorksTXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksTXF.Dwg.Reader
{
    public class DwgDBSettingsReader
    {
        public CwcDBSettings ReadDBSettings(Database db)
        {
            CwcDBSettings dbSettings = new CwcDBSettings();
            dbSettings.Pdmode = db.Pdmode;
            dbSettings.Pdsize = db.Pdsize;
            dbSettings.Ltscale = db.Ltscale;
            dbSettings.Measurement = ConvertDwgMeasurementToTxf(db.Measurement.ToString());

            return dbSettings;
        }

        private Enums.MeasurementValue ConvertDwgMeasurementToTxf(string dwgMeasurementValue)
        {
            return Enums.ConvertStringToEnumValue<Enums.MeasurementValue>(dwgMeasurementValue);
        }

    }
}
