﻿using CWorksTXF.Entities;
using System;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksTXF.Dwg.Writer
{
    public class DwgBlockReferenceWriter : DwgEntityWriter
    {

        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId btrId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable blockTbl = tr.GetObject(db.BlockTableId, OpenMode.ForWrite) as BlockTable)
                {

                    // save the current line type for database into a temp variable
                    ObjectId current_linetypeId = db.Celtype;

                    CwcBlockReference entityObject = cwcDbObject as CwcBlockReference;

                    btrId = blockTbl[entityObject.Name];
                    if (btrId.IsNull)
                    {
                        using (BlockTableRecord btr = new BlockTableRecord())
                        {
                            btr.Name = entityObject.Name;
                            btrId = blockTbl.Add(btr);
                            tm.AddNewlyCreatedDBObject(btr, true);
                        }

                        // To add the BlockRef for the Block
                        using (BlockReference blockRef = new BlockReference(new Point3d(entityObject.Position.X, entityObject.Position.Y, entityObject.Position.Z), btrId))
                        {
                            using (BlockTableRecord modelSpace = (BlockTableRecord)tm.GetObject(blockTbl[BlockTableRecord.ModelSpace], OpenMode.ForWrite))
                            {
                                modelSpace.AppendEntity(blockRef);
                                tm.AddNewlyCreatedDBObject(blockRef, true);
                            }
                            blockRef.ScaleFactors = new Scale3d(entityObject.ScaleFactors.X, entityObject.ScaleFactors.Y, entityObject.ScaleFactors.Z);

                            if (entityObject.LayerId.Length > 0)
                                blockRef.LayerId = GetDwgObjectId(entityObject.LayerId);

                            blockRef.Rotation = entityObject.Rotation;
                            blockRef.BlockUnit = entityObject.BlockUnit;

                            blockRef.Color = GetDwgColor(entityObject.Color);

                            SetupAttributeReference(blockTbl, blockRef, entityObject, btrId, tm);

                            blockRef.LinetypeId = GetLineTypeIdFromName(db, entityObject.Linetype);
                            blockRef.LinetypeScale = entityObject.LinetypeScale;

                            blockRef.LineWeight = entityObject.LineWeight;
                        }
                    }

                    // To setup another block as the parent for this block
                    if (!String.IsNullOrEmpty(entityObject.BlockName))
                    {

                        using (BlockReference blockRef = new BlockReference(new Point3d(entityObject.Position.X, entityObject.Position.Y, entityObject.Position.Z), btrId))
                        {
                            ObjectId parentBlockId = blockTbl[entityObject.BlockName];
                            using (BlockTableRecord parentBtr = (BlockTableRecord)tm.GetObject(parentBlockId, OpenMode.ForWrite))
                            {
                                parentBtr.AppendEntity(blockRef);
                                tm.AddNewlyCreatedDBObject(blockRef, true);
                            }
                            blockRef.ScaleFactors = new Scale3d(entityObject.ScaleFactors.X, entityObject.ScaleFactors.Y, entityObject.ScaleFactors.Z);

                            if (entityObject.LayerId.Length > 0)
                                blockRef.LayerId = GetDwgObjectId(entityObject.LayerId);

                            blockRef.Rotation = entityObject.Rotation;
                            blockRef.BlockUnit = entityObject.BlockUnit;

                            blockRef.Color = GetDwgColor(entityObject.Color);

                            SetupAttributeReference(blockTbl, blockRef, entityObject, btrId, tm);

                            blockRef.LinetypeId = GetLineTypeIdFromName(db, entityObject.Linetype);
                            blockRef.LinetypeScale = entityObject.LinetypeScale;

                            blockRef.LineWeight = entityObject.LineWeight;
                        }
                    }
                    // restore the current line type for database from the temp variable
                    db.Celtype = current_linetypeId;
                }
                tr.Commit();
            }


            return btrId;
        }

        private void SetupAttributeReference(BlockTable blockTbl, BlockReference blockRef, CwcBlockReference entityObject, ObjectId btrId, TransactionManager tm)
        {

            using (BlockTableRecord btr = (BlockTableRecord)tm.GetObject(btrId, OpenMode.ForRead))
            {
                if (btr.HasAttributeDefinitions)
                {
                    int iPosition = -1;
                    // Add attributes from the block table record
                    foreach (ObjectId objID in btr)
                    {
                        DBObject dbObj = tm.GetObject(objID, OpenMode.ForRead) as DBObject;

                        if (dbObj is AttributeDefinition)
                        {
                            AttributeDefinition attDef = dbObj as AttributeDefinition;

                            iPosition++;
                            if (!attDef.Constant)
                            {
                                using (AttributeReference attRef = new AttributeReference())
                                {
                                    attRef.SetAttributeFromBlock(attDef, blockRef.BlockTransform);
                                    attRef.Position = attDef.Position.TransformBy(blockRef.BlockTransform);

                                    attRef.TextString = GetTextStringFromAttributeRef(entityObject, attDef.Tag, attDef.TextString, iPosition);

                                    blockRef.AttributeCollection.AppendAttribute(attRef);

                                    tm.AddNewlyCreatedDBObject(attRef, true);
                                }
                            }
                        }

                    }
                }
            }

        }

        private string GetTextStringFromAttributeRef(CwcBlockReference entityObject, string tag, string textstring, int iPos)
        {
            for(int iCounter = 0; iCounter < entityObject.AttributeRefs.Count; iCounter++)
            {
                if (iCounter == iPos)
                    return entityObject.AttributeRefs[iCounter].TextString;
            }
            return textstring;
        }

    }
}
