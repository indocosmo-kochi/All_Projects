﻿using CWorksTXF.Entities;
using System.Text;
using Teigha.DatabaseServices;

namespace CWorksTXF.Dwg.Reader
{

    public class DwgMTextReader : DwgEnityReader, IDwgEntityReader
    {
        private StringBuilder m_sb = null;

        private string GetStrippedMtextContents(MText mt)
        {
            m_sb = new StringBuilder();
            mt.ExplodeFragments(new MTextFragmentCallback(FragmentCallback));
            return m_sb.ToString();
        }

        private MTextFragmentCallbackStatus FragmentCallback(MTextFragment fragment, object obj)
        {
            m_sb.Append(fragment.TrackingFactor.ToString() + "-"+ fragment.Text);
            return MTextFragmentCallbackStatus.Continue;
        }

        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {

            var entity = (dbObject as MText);
            CwcMText text = new CwcMText(entity.ColumnType, entity.ColumnAutoHeight, entity.ColumnCount);

            text.TextString = entity.Contents;
            text.Id = entity.Id.ToString();
            text.LayerId = entity.LayerId.ToString();

            text.Height  = entity.Height;
            text.Width = entity.Width;
            text.TextHeight = entity.TextHeight;

            text.Location = entity.Location;
            text.Attachment = entity.Attachment;

            text.BackgroundFill = entity.BackgroundFill;

            text.UseBackgroundColor = entity.UseBackgroundColor;

            if (text.BackgroundFill)
                text.BackgroundFillColor = entity.BackgroundFillColor;

            text.BackgroundScaleFactor = entity.BackgroundScaleFactor;

            text.ColumnAutoHeight = entity.ColumnAutoHeight;
            text.ColumnCount = entity.ColumnCount;
            text.ColumnFlowReversed = entity.ColumnFlowReversed;
            text.ColumnGutterWidth = entity.ColumnGutterWidth;
            text.ColumnType = entity.ColumnType;
            text.ColumnWidth = entity.ColumnWidth;

            if ((!entity.ColumnAutoHeight) && (entity.ColumnType == ColumnType.DynamicColumns))
            {
                for (int col = 0; col < entity.ColumnCount; col++)
                    text.ColumnHeight[col] = entity.GetColumnHeight(col);
            }

            text.Direction = entity.Direction;
            text.FlowDirection = entity.FlowDirection;
            text.LineSpaceDistance = entity.LineSpaceDistance;
            text.LineSpacingFactor = entity.LineSpacingFactor;
            text.LineSpacingStyle = entity.LineSpacingStyle;
            text.Normal = entity.Normal;
            text.Rotation = entity.Rotation;

            text.TextStyleId = entity.TextStyleId.ToString(); 

            text.BlockId = entity.BlockId.ToString();
            text.BlockName = entity.BlockName;
            text.Color = GetDwgEntityColor(entity.Color, entity.LayerId.ToString());

     //       text.LayerName = Layers[text.LayerId].Name;

            //string s = GetStrippedMtextContents((dbObject as MText));


            return text;
        }

     


    }
}
