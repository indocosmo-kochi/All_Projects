﻿using CWorksTXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksTXF.Dwg.Writer
{
    public class DwgTextStyleWriter : DwgEntityWriter
    {
        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId textstyleId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (TextStyleTable tst = (TextStyleTable)tm.GetObject(db.TextStyleTableId, OpenMode.ForRead))
                {

                    CwcTextStyle textstyle = cwcDbObject as CwcTextStyle;

                    if (tst.Has(textstyle.Name))
                    {
                        textstyleId = tst[textstyle.Name];
                        using (TextStyleTableRecord tstr = (TextStyleTableRecord)tm.GetObject(textstyleId, OpenMode.ForWrite))
                        {
                            tst.UpgradeOpen();
                            tstr.FileName = textstyle.FileName;
                            tstr.TextSize = textstyle.TextSize;
                            tstr.ObliquingAngle = textstyle.ObliquingAngle;
                            tstr.FlagBits = textstyle.FlagBits;
                            tstr.IsVertical = textstyle.IsVertical;

                            tstr.Annotative = textstyle.Annotative;
                            tstr.BigFontFileName = textstyle.BigFontFileName;
                            tstr.PriorSize = textstyle.PriorSize;
                            tstr.XScale = textstyle.XScale;

                            if (textstyle.FontName.Length > 0)
                                tstr.Font = new Teigha.GraphicsInterface.FontDescriptor(textstyle.FontName, textstyle.IsBold, textstyle.IsItallic, textstyle.Characters, textstyle.PitchAndFamily);

                        }
                    }
                    else
                    {

                        using (TextStyleTableRecord tstr = new TextStyleTableRecord())
                        {
                            tstr.FileName = textstyle.FileName;
                            tstr.Name = textstyle.Name;
                            tstr.TextSize = textstyle.TextSize;
                            tstr.ObliquingAngle = textstyle.ObliquingAngle;
                            tstr.FlagBits = textstyle.FlagBits;
                            tstr.IsVertical = textstyle.IsVertical;
                            tstr.Annotative = textstyle.Annotative;
                            tstr.BigFontFileName = textstyle.BigFontFileName;
                            tstr.PriorSize = textstyle.PriorSize;
                            tstr.XScale = textstyle.XScale;

                            if (textstyle.FontName.Length > 0)
                                tstr.Font = new Teigha.GraphicsInterface.FontDescriptor(textstyle.FontName, textstyle.IsBold, textstyle.IsItallic, textstyle.Characters, textstyle.PitchAndFamily);
                            tst.UpgradeOpen();
                            textstyleId = tst.Add(tstr);
                            tm.AddNewlyCreatedDBObject(tstr, true);

                        }
                    }
                }
                tr.Commit();
            }
            return textstyleId;
        }
    }
}
