﻿using CWorksTXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksTXF.Dwg.Reader
{

    public class DwgLineReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {

            CwcLine line = new CwcLine();
            var entity = (dbObject as Line);

            line.Id = entity.Id.ToString();
            line.LayerId = entity.LayerId.ToString();
            line.StartPoint = entity.StartPoint;

            line.EndPoint = entity.EndPoint;

            line.Linetype = entity.Linetype;

            line.LinetypeScale = entity.LinetypeScale;

            line.LineWeight = entity.LineWeight;

            //      line.LayerName = Layers[line.LayerId].Name;

            line.BlockId = entity.BlockId.ToString(); 

            line.BlockName = entity.BlockName;

            line.Color = GetDwgEntityColor(entity.Color, entity.LayerId.ToString());

            return line;
        }
    }


}
