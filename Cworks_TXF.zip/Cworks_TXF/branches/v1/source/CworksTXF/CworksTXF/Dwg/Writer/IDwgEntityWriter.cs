﻿using CWorksTXF.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Teigha.DatabaseServices;

namespace CWorksTXF.Dwg.Writer
{
    interface IDwgEntityWriter
    {
        ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject);
    }
}
