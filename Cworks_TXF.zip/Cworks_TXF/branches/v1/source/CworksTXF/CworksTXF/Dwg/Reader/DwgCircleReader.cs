﻿using CWorksTXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksTXF.Dwg.Reader
{
    public class DwgCircleReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            CwcCircle circle = new CwcCircle();
            var entity = (dbObject as Circle);
            circle.Id = entity.Id.ToString();
            circle.LayerId = entity.LayerId.ToString();
     //       circle.LayerName = Layers[circle.LayerId].Name;
            circle.Center = entity.Center;
            circle.Radius = entity.Radius;
            circle.LinetypeId = entity.LinetypeId.ToString();

            circle.Linetype = entity.Linetype;
            circle.LinetypeScale = entity.LinetypeScale;

            circle.LineWeight = entity.LineWeight;
            circle.BlockId = entity.BlockId.ToString();
            circle.BlockName = entity.BlockName;

            circle.Color = GetDwgEntityColor(entity.Color, entity.LayerId.ToString());


            return circle;
        }
    }
}
