﻿using CWorksTXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksTXF.Dwg.Writer
{
    public class DwgViewportWriter : DwgEntityWriter
    {
        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId viewportId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (ViewportTable vt = (ViewportTable)tm.GetObject(db.ViewportTableId, OpenMode.ForRead))
                {

                    CwcViewport viewport = cwcDbObject as CwcViewport;
                    ViewportTableRecord vtr;
                    if (vt.Has(viewport.Name))
                    {
                        viewportId = vt[viewport.Name];
                        using (vtr = (ViewportTableRecord)tm.GetObject(viewportId, OpenMode.ForWrite))
                        {
                            vt.UpgradeOpen();
                            vtr.CircleSides = viewport.CircleSides;
                            vtr.CenterPoint = new Point2d(viewport.CenterPoint.X, viewport.CenterPoint.Y);
                            vtr.GridEnabled = viewport.GridEnabled;
                            vtr.Height = viewport.Height;
                            vtr.Width = viewport.Width;
                        }
                    }
                    else
                    {

                        using (vtr = new ViewportTableRecord())
                        {
                            vtr.Name = viewport.Name;
                            vtr.CircleSides = viewport.CircleSides;
                            vtr.GridEnabled = viewport.GridEnabled;
                            vtr.CenterPoint = new Point2d(viewport.CenterPoint.X, viewport.CenterPoint.Y);
                            vtr.Height = viewport.Height;
                            vtr.Width = viewport.Width;

                            vt.UpgradeOpen();
                            viewportId = vt.Add(vtr);
                            tm.AddNewlyCreatedDBObject(vtr, true);
                        }
                    }
                }
                tr.Commit();
            }
            return viewportId;
        }
    }
}
