﻿using System;
using System.Collections.Generic;
using CWorksTXF.Entities;
using System.Text.RegularExpressions;
using CWorksTXF.Common;
using Teigha.DatabaseServices;
using Teigha.Colors;

namespace CWorksTXF.Txf.Reader
{
    public abstract class TxfEntityReader:ITxfEntityReader  
    {
        public string EntityTypeName { get; set; }
        public abstract CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord);

        protected bool ReadPropertyValue(Dictionary<string, string> entityRecord, string entityProperty, bool isRequired, out string value)
        {
            string errorMsg = "ERROR: Missing property VALUE '" + entityProperty + "' for Entity [" + EntityTypeName + "], TXF->DWG processing Aborted!!!.";
            return ReadPropertyValue(entityRecord, entityProperty, isRequired, out value, errorMsg);
        }

        protected bool ReadPropertyValue(Dictionary<string, string> entityRecord, string entityProperty, bool isRequired, out string value, string errorMsg)
        {
            if (entityRecord.ContainsKey(entityProperty))
            {
                value = entityRecord[entityProperty].Trim();
                if (isRequired && value.Length == 0)
                {
                    Logger.RecordMessage(errorMsg, Logs.Log.MessageType.Exception);
                    return false;
                }
                return true;
            }
            else
            {
                value = string.Empty;
                if (isRequired)
                {
                    Logger.RecordMessage(errorMsg, Logs.Log.MessageType.Exception);
                }
                return false;
            }
        }

        private byte?[] ConvertColorCsvStringToByte(string csvString)
        {
            string[] strValues = Regex.Match(csvString, @"\(([^)]*)\)").Groups[1].Value.Split(',');
            byte?[] byteValues = { null, null, null };
            if (strValues[0] != "-1")
            {
                byteValues[0] = ConvertTxfValue2Byte(strValues[0]);

                byteValues[1] = ConvertTxfValue2Byte(strValues[1]);

                byteValues[2] = ConvertTxfValue2Byte(strValues[2]);

            }

            return byteValues;
        }

        private Double[] ConvertPoint3dCsvStringToDouble(string csvString)
        {
            string[] strValues = Regex.Match(csvString, @"\(([^)]*)\)").Groups[1].Value.Split(',');
            Double[] doubleValues = { 0, 0, 0 };
            Double.TryParse(strValues[0], out doubleValues[0]);
            Double.TryParse(strValues[1], out doubleValues[1]);
            Double.TryParse(strValues[2], out doubleValues[2]);
            return doubleValues;
        }

        private double[] ConvertPoint2dCsvStringToDouble(string csvString)
        {
            string[] strValues = Regex.Match(csvString, @"\(([^)]*)\)").Groups[1].Value.Split(',');
            double[] doubleValues = { 0, 0};
            double.TryParse(strValues[0], out doubleValues[0]);
            double.TryParse(strValues[1], out doubleValues[1]);

            return doubleValues;
        }

        protected CwcColor ParseTxfColor(Dictionary<string, string> entityRecord, string colorProperty,
                                            string colorMethodProperty, string colorIndexProperty)
        {
            const short DEFAUTLT_COLOR_INDEX = 9;
            const byte DEFAUTLT_COLOR_RGB_VALUE = 255;

            // initialise with default value for color as ByLayer
            short colorIndex = DEFAUTLT_COLOR_INDEX;
            byte?[] colorValues = { DEFAUTLT_COLOR_RGB_VALUE, DEFAUTLT_COLOR_RGB_VALUE, DEFAUTLT_COLOR_RGB_VALUE };
            ColorMethod colorMethod = ColorMethod.None;

            // if value specified in the entity property, it will be overridden
            if (entityRecord.ContainsKey(colorProperty))
            {
                colorValues = ConvertColorCsvStringToByte(entityRecord[colorProperty]);
            }


            if (entityRecord.ContainsKey(colorMethodProperty))
            {
                int value;
                int.TryParse(entityRecord[colorMethodProperty], out value);
                colorMethod = ConvertTxfColorMethodToDwg(entityRecord[colorMethodProperty]);
            }

            if (entityRecord.ContainsKey(colorIndexProperty))
            {
                short.TryParse(entityRecord[colorIndexProperty], out colorIndex);
            }
            CwcColor cwcColor = new CwcColor(colorValues[0], colorValues[1], colorValues[2]);
            cwcColor.ColorMethod = colorMethod;
            cwcColor.ColorIndex = colorIndex;

      
            return cwcColor;
        }

        protected bool ParseTxfPoint3d(Dictionary<string, string> entityRecord, string entityProperty, bool isRequired, out CwcPoint3D point3d)
        {
            if (!entityRecord.ContainsKey(entityProperty))
            {
                point3d = new CwcPoint3D(0, 0, 0);
                if (isRequired)
                {
                    Logger.RecordMessage("ERROR: Missing property '" + entityProperty + "' for Entity [" + EntityTypeName + "], txf->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
                }
                return false;
            }
            else
            {
                double[] txfPoint3dValues = ConvertPoint3dCsvStringToDouble(entityRecord[entityProperty]);

                point3d = new CwcPoint3D(txfPoint3dValues[0], txfPoint3dValues[1], txfPoint3dValues[2]);
                return true;
            }

        }

        protected bool ParseTxfPoint2d(Dictionary<string, string> entityRecord, string entityProperty, bool isRequired, out CwcPoint2D point2d)
        {
            if (!entityRecord.ContainsKey(entityProperty))
            {
                point2d = new CwcPoint2D(0, 0);
                if (isRequired)
                {
                    Logger.RecordMessage("ERROR: Missing property '" + entityProperty + "' for Entity [" + EntityTypeName + "], TXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
                }
                return false;
            }
            else
            {
                double[] txfPoint2dValues = ConvertPoint2dCsvStringToDouble(entityRecord[entityProperty]);

                point2d = new CwcPoint2D(txfPoint2dValues[0], txfPoint2dValues[1]);
                return true;
            }

        }

        protected bool ParseTxfVector2d(Dictionary<string, string> entityRecord, string entityProperty, bool isRequired, out CwcVector2D vector2d)
        {
            if (!entityRecord.ContainsKey(entityProperty))
            {
                vector2d = new CwcVector2D(0, 0);
                if (isRequired)
                {
                    Logger.RecordMessage("ERROR: Missing property '" + entityProperty + "' for Entity [" + EntityTypeName + "], TXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
                }
                return false;
            }
            else
            {
                double[] txfVector2dValues = ConvertPoint2dCsvStringToDouble(entityRecord[entityProperty]);

                vector2d = new CwcVector2D(txfVector2dValues[0], txfVector2dValues[1]);
                return true;
            }

        }

        protected bool ParseTxfVector3d(Dictionary<string, string> entityRecord, string entityProperty, bool isRequired, out CwcVector3D vector3d)
        {
            if (!entityRecord.ContainsKey(entityProperty))
            {
                vector3d = new CwcVector3D(0, 0, 0);
                if (isRequired)
                {
                    Logger.RecordMessage("ERROR: Missing property '" + entityProperty + "' for Entity [" + EntityTypeName + "], TXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
                }
                return false;
            }
            else
            {
                double[] txfVector3dValues = ConvertPoint3dCsvStringToDouble(entityRecord[entityProperty]);

                vector3d = new CwcVector3D(txfVector3dValues[0], txfVector3dValues[1], txfVector3dValues[2]);
                return true;
            }

        }

        protected bool ConvertTxfValue2Bool(Dictionary<string, string> entityRecord, string entityProperty, bool isRequired, bool defaultValue)
        {
            if (entityRecord.ContainsKey(entityProperty))
            {
                return (entityRecord[entityProperty].Trim() == "1") ? true : false;
            }
            else
            {
                if (isRequired)
                {
                    Logger.RecordMessage("ERROR: Missing property '" + entityProperty + "' for Entity [" + EntityTypeName + "], TXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
                }
                return defaultValue;
            }
        }

        protected double ConvertTxfValue2Double(string value)
        {
            double dValue;

            if (!double.TryParse(value, out dValue))
            {
                Logger.RecordMessage("ERROR: String to Double Conversion, '" + value + "' cannot be converted. TXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
            }

            return dValue;
        }

        protected byte ConvertTxfValue2Byte(string value)
        {
            byte byteValue;

            if (!byte.TryParse(value, out byteValue))
            {
                Logger.RecordMessage("ERROR: String to Byte Conversion, '" + value + "' cannot be converted. TXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
            }

            return byteValue;
        }

        protected float ConvertTxfValue2float(string value)
        {
            float fValue;

            if (!float.TryParse(value, out fValue))
            {
                Logger.RecordMessage("ERROR: String to Float Conversion, '" + value + "' cannot be converted. TXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
            }

            return fValue;
        }

        protected int ConvertTxfValue2Integer(string value)
        {
            int intValue;

            if (!int.TryParse(value, out intValue))
            {
                Logger.RecordMessage("ERROR: String to Integer Conversion, '" + value + "' cannot be converted. TXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
            }

            return intValue;
        }
        protected short ConvertTxfValue2Short(string value)
        {
            short shortValue;

            if (!short.TryParse(value, out shortValue))
            {
                Logger.RecordMessage("ERROR: String to Short Conversion, '" + value + "' cannot be converted. TXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Exception);
            }

            return shortValue;
        }
        

        protected LineSpacingStyle ConvertTxfMTextLineSpacingStyleToDwg(string txfLineSpacingStyle)
        {
            return Enums.ConvertStringToEnumValue<LineSpacingStyle>(txfLineSpacingStyle);
        }

        protected FlowDirection ConvertTxfMTextFlowDirectionToDwg(string txfFlowDirection)
        {
            return Enums.ConvertStringToEnumValue<FlowDirection>(txfFlowDirection);
        }

        protected ColumnType ConvertTxfMTextColumnTypeToDwg(string txfColumnType)
        {
            return Enums.ConvertStringToEnumValue<ColumnType>(txfColumnType);
        }

        protected AttachmentPoint ConvertTxfMTextAttachmentToDwg(string txfAttachment)
        {
            return Enums.ConvertStringToEnumValue<AttachmentPoint>(txfAttachment);
        }

        protected TextVerticalMode ConvertTxfVerticalModeToDwg(string txfVerticalMode)
        {
            return Enums.ConvertStringToEnumValue<TextVerticalMode>(txfVerticalMode);
        }

        protected AttachmentPoint ConvertTxfTextJustifyToDwg(string txfTextJustify)
        {
            return Enums.ConvertStringToEnumValue<AttachmentPoint>(txfTextJustify);
        }

        protected TextHorizontalMode ConvertTxfHorizontalModeToDwg(string txfHorizontalMode)
        {
            return Enums.ConvertStringToEnumValue<TextHorizontalMode>(txfHorizontalMode);
        }

        
        protected AnnotationType ConvertTxfAnnotationTypeToDwg(string txfAnnotationType)
        {
            return Enums.ConvertStringToEnumValue<AnnotationType>(txfAnnotationType);
        }

        protected LineWeight ConvertTxfLineWeightToDwg(string txfLineWeight)
        {
            return Enums.ConvertStringToEnumValue<LineWeight>(txfLineWeight);
        }

        protected AnnotativeStates ConvertTxfAnnotativeStatesToDwg(string txfAnnotativeStates)
        {
            return Enums.ConvertStringToEnumValue<AnnotativeStates>(txfAnnotativeStates);
        }

        protected ColorMethod ConvertTxfColorMethodToDwg(string txfColorMethod)
        {
            return Enums.ConvertStringToEnumValue<ColorMethod>(txfColorMethod);
        }

        protected UnitsValue ConvertTxfBlockUnitToDwg(string txfBlockUnit)
        {
            return Enums.ConvertStringToEnumValue<UnitsValue>(txfBlockUnit);
        }

        protected void ReadDimensionValues(CwcDimension entity, Dictionary<string, string> entityRecord)
        {
            string value;

            if (ReadPropertyValue(entityRecord, "Dimadec", false, out value))
                entity.Dimadec = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimaltd", false, out value))
                entity.Dimaltd = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimalttd", false, out value))
                entity.Dimalttd = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimalttz", false, out value))
                entity.Dimalttz = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimaltu", false, out value))
                entity.Dimaltu = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimaltz", false, out value))
                entity.Dimaltz = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimaltf", false, out value))
                entity.Dimaltf = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimaltrnd", false, out value))
                entity.Dimaltrnd = ConvertTxfValue2Double(value);

            entity.Dimalt = ConvertTxfValue2Bool(entityRecord, "Dimalt", false, false);

            if (ReadPropertyValue(entityRecord, "Dimapost", false, out value))
                entity.Dimapost = value;

            if (ReadPropertyValue(entityRecord, "Dimasz", false, out value))
                entity.Dimasz = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimarcsym", false, out value))
                entity.Dimarcsym = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimatfit", false, out value))
                entity.Dimatfit = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimaunit", false, out value))
                entity.Dimaunit = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimazin", false, out value))
                entity.Dimazin = ConvertTxfValue2Integer(value);

            entity.Dimsah = ConvertTxfValue2Bool(entityRecord, "Dimsah", false, false);

            if (ReadPropertyValue(entityRecord, "Dimblk1s", false, out value))
                entity.Dimblk1s = value;

            if (ReadPropertyValue(entityRecord, "Dimblk2s", false, out value))
                entity.Dimblk2s = value;

            if (ReadPropertyValue(entityRecord, "Dimblks", false, out value))
                entity.Dimblks = value;

            if (ReadPropertyValue(entityRecord, "Dimcen", false, out value))
                entity.Dimcen = ConvertTxfValue2Double(value);

            entity.Dimclrd = ParseTxfColor(entityRecord, "Dimclrd", "Dimclrd_ColorMethod", "Dimclrd_ColorIndex");

            entity.Dimclre = ParseTxfColor(entityRecord, "Dimclre", "Dimclre_ColorMethod", "Dimclre_ColorIndex");

            entity.Dimclrt = ParseTxfColor(entityRecord, "Dimclrt", "Dimclrt_ColorMethod", "Dimclrt_ColorIndex");

            if (ReadPropertyValue(entityRecord, "Dimdec", false, out value))
                entity.Dimdec = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimfrac", false, out value))
                entity.Dimfrac = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimdle", false, out value))
                entity.Dimdle = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimdli", false, out value))
                entity.Dimdli = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimexe", false, out value))
                entity.Dimexe = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimexo", false, out value))
                entity.Dimexo = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimfxlen", false, out value))
                entity.Dimfxlen = ConvertTxfValue2Double(value);

            entity.DimfxlenOn = ConvertTxfValue2Bool(entityRecord, "DimfxlenOn", false, false);

            if (ReadPropertyValue(entityRecord, "Dimgap", false, out value))
                entity.Dimgap = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimjogang", false, out value))
                entity.Dimjogang = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimjust", false, out value))
                entity.Dimjust = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimdsep", false, out value))
            {
                if (value.Trim().Length > 0)
                {
                    entity.Dimdsep = value.Trim()[0];
                }
            }

            if (ReadPropertyValue(entityRecord, "Dimldrblks", false, out value))
                entity.Dimldrblks = value;

            if (ReadPropertyValue(entityRecord, "Dimlfac", false, out value))
                entity.Dimlfac = ConvertTxfValue2Double(value);

            entity.Dimlim = ConvertTxfValue2Bool(entityRecord, "Dimlim", false, false);

            if (ReadPropertyValue(entityRecord, "Dimltex1", false, out value))
                entity.Dimltex1 = value;

            if (ReadPropertyValue(entityRecord, "Dimltex2", false, out value))
                entity.Dimltex2 = value;

            if (ReadPropertyValue(entityRecord, "Dimltype", false, out value))
                entity.Dimltype = value;

            if (ReadPropertyValue(entityRecord, "Dimpost", false, out value))
                entity.Dimpost = value;

            if (ReadPropertyValue(entityRecord, "Dimrnd", false, out value))
                entity.Dimrnd = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimscale", false, out value))
                entity.Dimscale = ConvertTxfValue2Double(value);

            entity.Dimsd1 = ConvertTxfValue2Bool(entityRecord, "Dimsd1", false, false);

            entity.Dimsd2 = ConvertTxfValue2Bool(entityRecord, "Dimsd2", false, false);

            entity.Dimse1 = ConvertTxfValue2Bool(entityRecord, "Dimse1", false, false);

            entity.Dimse2 = ConvertTxfValue2Bool(entityRecord, "Dimse2", false, false);

            entity.Dimsoxd = ConvertTxfValue2Bool(entityRecord, "Dimsoxd", false, false);

            if (ReadPropertyValue(entityRecord, "Dimtad", false, out value))
                entity.Dimtad = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimtdec", false, out value))
                entity.Dimtdec = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimtfill", false, out value))
                entity.Dimtfill = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimtfac", false, out value))
                entity.Dimtfac = ConvertTxfValue2Double(value);

            entity.Dimtfillclr = ParseTxfColor(entityRecord, "Dimtfillclr", "Dimtfillclr_ColorMethod", "Dimtfillclr_ColorIndex");

            entity.Dimtih = ConvertTxfValue2Bool(entityRecord, "Dimtih", false, false);

            entity.Dimtix = ConvertTxfValue2Bool(entityRecord, "Dimtix", false, false);

            if (ReadPropertyValue(entityRecord, "Dimtm", false, out value))
                entity.Dimtm = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtmove", false, out value))
                entity.Dimtmove = ConvertTxfValue2Integer(value);

            entity.Dimtofl = ConvertTxfValue2Bool(entityRecord, "Dimtofl", false, false);

            entity.Dimtoh = ConvertTxfValue2Bool(entityRecord, "Dimtoh", false, false);

            entity.Dimtol = ConvertTxfValue2Bool(entityRecord, "Dimtol", false, false);

            if (ReadPropertyValue(entityRecord, "Dimtolj", false, out value))
                entity.Dimtolj = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimtp", false, out value))
                entity.Dimtp = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtsz", false, out value))
                entity.Dimtsz = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtvp", false, out value))
                entity.Dimtvp = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtxt", false, out value))
                entity.Dimtxt = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtzin", false, out value))
                entity.Dimtzin = ConvertTxfValue2Integer(value);

            entity.Dimupt = ConvertTxfValue2Bool(entityRecord, "Dimupt", false, false);

            if (ReadPropertyValue(entityRecord, "Dimzin", false, out value))
                entity.Dimzin = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimlwd", false, out value))
                entity.Dimlwd = ConvertTxfLineWeightToDwg(value);

            if (ReadPropertyValue(entityRecord, "Dimlwe", false, out value))
                entity.Dimlwe = ConvertTxfLineWeightToDwg(value);

        }

    }

}
