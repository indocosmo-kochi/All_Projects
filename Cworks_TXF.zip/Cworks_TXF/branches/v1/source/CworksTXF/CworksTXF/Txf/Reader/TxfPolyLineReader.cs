﻿using System.Collections.Generic;
using CWorksTXF.Entities;

namespace CWorksTXF.Txf.Reader
{
    public class TxfPolyLineReader : TxfEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            string value;
            int numberOfVertices = 0;
            if (ReadPropertyValue(entityRecord, "NumberOfVertices", true, out value))
                numberOfVertices = ConvertTxfValue2Integer(value);

            CwcPolyline entity = new CwcPolyline(numberOfVertices);

            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            CwcPoint3D point3d;
            for (int i = 0; i < numberOfVertices; i++)
            {
                if (ParseTxfPoint3d(entityRecord, string.Format("Vertex({0})", i), true, out point3d))
                    entity.Vertices[i] = point3d;
                if (ReadPropertyValue(entityRecord, string.Format("Bulge({0})", i), true, out value))
                    entity.Bulge[i] = ConvertTxfValue2Double(value);
                if (ReadPropertyValue(entityRecord, string.Format("StartWidth({0})", i), true, out value))
                    entity.StartWidth[i] = ConvertTxfValue2Double(value);
                if (ReadPropertyValue(entityRecord, string.Format("EndWidth({0})", i), true, out value))
                    entity.EndWidth[i] = ConvertTxfValue2Double(value);
            }

            entity.IsClosed = ConvertTxfValue2Bool(entityRecord, "IsClosed", true, true);

            entity.Color = ParseTxfColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            if (ReadPropertyValue(entityRecord, "Linetype", false, out value))
                entity.Linetype = value;

            if (ReadPropertyValue(entityRecord, "LinetypeScale", false, out value))
                entity.LinetypeScale = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                entity.LineWeight = ConvertTxfLineWeightToDwg(value);

            return entity;
        }

    }
}

