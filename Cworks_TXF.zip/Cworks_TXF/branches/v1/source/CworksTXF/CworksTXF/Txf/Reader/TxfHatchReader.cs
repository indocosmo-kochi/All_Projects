﻿using System.Collections.Generic;
using CWorksTXF.Entities;
using CWorksTXF.Common;
using System.Text.RegularExpressions;
using System;
using System.Linq;
using Teigha.DatabaseServices;

namespace CWorksTXF.Txf.Reader
{
    public class TxfHatchReader : TxfEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            string value;
            int numberOfLoops = 0;
            if (ReadPropertyValue(entityRecord, "NumberOfLoops", true, out value))
                numberOfLoops = ConvertTxfValue2Integer(value);

            CwcHatch entity = new CwcHatch(numberOfLoops);

            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            entity.IsHatch = ConvertTxfValue2Bool(entityRecord, "IsHatch", true, true);
         
            entity.IsGradient = ConvertTxfValue2Bool(entityRecord, "IsGradient", true, false);

            entity.IsSolidFill = ConvertTxfValue2Bool(entityRecord, "IsSolidFill", true, false);

            entity.Associative = ConvertTxfValue2Bool(entityRecord, "Associative", true, false);

            CwcPoint2D point2d;
            if (ParseTxfPoint2d(entityRecord, "Origin", true, out point2d))
                entity.Origin = point2d;

            if (entity.IsHatch)
            {
                if (ReadPropertyValue(entityRecord, "PatternName", true, out value))
                    entity.PatternName = value;
                if (ReadPropertyValue(entityRecord, "PatternType", false, out value))
                    entity.PatternType = ConvertTxfHatchPatternTypeToDwg(value);
                if (ReadPropertyValue(entityRecord, "PatternAngle", false, out value))
                    entity.PatternAngle = ConvertTxfValue2Double(value);
                if (ReadPropertyValue(entityRecord, "PatternSpace", false, out value))
                    entity.PatternSpace = ConvertTxfValue2Double(value);
                if (ReadPropertyValue(entityRecord, "HatchStyle", false, out value))
                    entity.HatchStyle = ConvertTxfHatchStyleToDwg(value);

                if (ReadPropertyValue(entityRecord, "PatternScale", false, out value))
                    entity.PatternScale = ConvertTxfValue2Double(value);

                entity.Color = ParseTxfColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

                entity.BackgroundColor = ParseTxfColor(entityRecord, "BackgroundColor", "BackgroundColorMethod", "BackgroundColorIndex");
            }
            else
            {
                if (ReadPropertyValue(entityRecord, "GradientName", true, out value))
                    entity.GradientName = value;
                if (ReadPropertyValue(entityRecord, "GradientType", true, out value))
                    entity.GradientType = ConvertTxfGradientPatternTypeToDwg(value);
                if (ReadPropertyValue(entityRecord, "GradientAngle", true, out value))
                    entity.GradientAngle = ConvertTxfValue2Double(value);
                if (ReadPropertyValue(entityRecord, "GradientShift", true, out value))
                    entity.GradientShift = ConvertTxfValue2float(value);

                CwcGradiantColor[] cwcGradiantColor = new CwcGradiantColor[2];
                if (ParseTxfGradientColor(entityRecord, "GradientColor(1)", true, out cwcGradiantColor[0]))
                    entity.GradientColor[0] = cwcGradiantColor[0];

                if (ParseTxfGradientColor(entityRecord, "GradientColor(2)", true, out cwcGradiantColor[1]))
                    entity.GradientColor[1] = cwcGradiantColor[1];

                entity.GradientOneColorMode = ConvertTxfValue2Bool(entityRecord, "GradientOneColorMode", false, true);

            }


            for (int i = 0; i < numberOfLoops; i++)
            {
                if (entity.Associative)
                {

                    int nofAssociativeIds = 0;

                    if (ReadPropertyValue(entityRecord, String.Format("NumberOfAssociativeIds({0})", i), true, out value))
                        nofAssociativeIds = ConvertTxfValue2Integer(value);

                    entity.Loops[i] = new CwcHatchLoop(nofAssociativeIds);

                    for (int j = 0; j < nofAssociativeIds; j++)
                    {
                        string id = string.Empty;
                        if (ReadPropertyValue(entityRecord, string.Format("AssociativeId({0},{1})", i, j), true, out id))
                            entity.Loops[i].AssociativeIds[j] = id;
                    }
                }
                else
                {

                    bool isPolyline = ConvertTxfValue2Bool(entityRecord, string.Format("IsPolyline({0})", i), true, true); 


                    if (isPolyline)
                    {
                        int noOfBulgeVertices = 0;

                        if (ReadPropertyValue(entityRecord, String.Format("NumberOfBulgeVertices({0})", i), true, out value))
                            noOfBulgeVertices = ConvertTxfValue2Integer(value);

                        entity.Loops[i] = new CwcHatchLoop(isPolyline, noOfBulgeVertices);

                        CwcPoint2D point2D;
                        for (int j = 0; j < entity.Loops[i].NumberOfBulgeVertices; j++)
                        {
                            double bulge = 0;
                            if (ReadPropertyValue(entityRecord, string.Format("Bulge({0},{1})", i, j), true, out value))
                                bulge = ConvertTxfValue2Double(value);

                            if (ParseTxfPoint2d(entityRecord, string.Format("Vertex({0},{1})", i, j), true, out point2D))
                                entity.Loops[i].BulgeVertices[j] = new CwcBulgeVertex(bulge, point2D);

                        }
                    }
                    else
                    {
                        ReadCurvesFromTXF(entityRecord, i, entity, isPolyline);
                    }
                }

                if (ReadPropertyValue(entityRecord, String.Format("LoopType({0})", i), true, out value))
                    entity.Loops[i].LoopType = ConvertTxfHatchLoopTypeToDwg(value);

            }

            if (ReadPropertyValue(entityRecord, "HatchObjectType", false, out value))
                entity.HatchObjectType = ConvertTxfHatchObjectTypeToDwg(value);

            if (ReadPropertyValue(entityRecord, "Annotative", false, out value))
                entity.Annotative = ConvertTxfAnnotativeStatesToDwg(value);

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            if (ReadPropertyValue(entityRecord, "Linetype", false, out value))
                entity.Linetype = value;

            if (ReadPropertyValue(entityRecord, "LinetypeScale", false, out value))
                entity.LinetypeScale = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                entity.LineWeight = ConvertTxfLineWeightToDwg(value);

            return entity;
        }

        private void ReadCurvesFromTXF(Dictionary<string, string> entityRecord, int hlCtr, CwcHatch entity, bool isPolyline=false)
        {
            string value = string.Empty;
            int noOfCurves = 0;

            if (ReadPropertyValue(entityRecord, String.Format("NumberOfCurves({0})", hlCtr), true, out value))
                noOfCurves = ConvertTxfValue2Integer(value);

            entity.Loops[hlCtr] = new CwcHatchLoop(isPolyline, noOfCurves);


            for (int curCtr = 0; curCtr < entity.Loops[hlCtr].NumberOfCurves; curCtr++)
            {

                Enums.CurveType curvetype = 0;

                if (ReadPropertyValue(entityRecord, String.Format("CurveType({0},{1})", hlCtr, curCtr), false, out value))
                    curvetype = ConvertTxfCurveTypeToDwg(value);

                CwcPoint2D point2d;

                switch (curvetype)
                {
                    case Common.Enums.CurveType.LineSegment2d:
                        CwcLineSegment2D linesegment = new CwcLineSegment2D(curvetype);

                        if (ParseTxfPoint2d(entityRecord, String.Format("StartPoint({0},{1})", hlCtr, curCtr), true, out point2d))
                            linesegment.StartPoint = point2d;

                        if (ParseTxfPoint2d(entityRecord, String.Format("EndPoint({0},{1})", hlCtr, curCtr), true, out point2d))
                            linesegment.EndPoint = point2d;

                        entity.Loops[hlCtr].Curve2DCollection[curCtr] = linesegment;
                        break;
                    case Common.Enums.CurveType.CircularArc2d:
                        CwcCircularArc2D circularArc = new CwcCircularArc2D(curvetype);

                        if (ParseTxfPoint2d(entityRecord, String.Format("Center({0},{1})", hlCtr, curCtr), true, out point2d))
                            circularArc.Center = point2d;

                        if (ReadPropertyValue(entityRecord, String.Format("Radius({0},{1})", hlCtr, curCtr), true, out value))
                            circularArc.Radius = ConvertTxfValue2Double(value);

                        if (ReadPropertyValue(entityRecord, String.Format("StartAngle({0},{1})", hlCtr, curCtr), false, out value))
                            circularArc.StartAngle = ConvertTxfValue2Double(value);

                        if (ReadPropertyValue(entityRecord, String.Format("EndAngle({0},{1})", hlCtr, curCtr), false, out value))
                            circularArc.EndAngle = ConvertTxfValue2Double(value);

                        circularArc.IsClockWise = ConvertTxfValue2Bool(entityRecord, String.Format("IsClockWise({0},{1})", hlCtr, curCtr), false, false);

                        CwcVector2D vector2d;
                        if (circularArc.IsClockWise) 
                        {
                            // Assumption : if IsClockWise then ReferenceVector is required for creating the circularArc2d 
                            if (ParseTxfVector2d(entityRecord, String.Format("ReferenceVector({0},{1})", hlCtr, curCtr), true, out vector2d))
                                circularArc.ReferenceVector = vector2d;
                        }
                        else
                        {
                            if (ParseTxfVector2d(entityRecord, String.Format("ReferenceVector({0},{1})", hlCtr, curCtr), false, out vector2d))
                                circularArc.ReferenceVector = vector2d;
                        }

                        entity.Loops[hlCtr].Curve2DCollection[curCtr] = circularArc;
                        break;
                    case Common.Enums.CurveType.EllipticalArc2d:
                        CwcEllipticalArc2D ellipticalArc = new CwcEllipticalArc2D(curvetype);

                        if (ParseTxfPoint2d(entityRecord, String.Format("Center({0},{1})", hlCtr, curCtr), true, out point2d))
                            ellipticalArc.Center = point2d;

                        if (ReadPropertyValue(entityRecord, String.Format("MajorRadius({0},{1})", hlCtr, curCtr), true, out value))
                            ellipticalArc.MajorRadius = ConvertTxfValue2Double(value);

                        if (ReadPropertyValue(entityRecord, String.Format("MinorRadius({0},{1})", hlCtr, curCtr), true, out value))
                            ellipticalArc.MinorRadius = ConvertTxfValue2Double(value);

                        if (ParseTxfVector2d(entityRecord, String.Format("MajorAxis({0},{1})", hlCtr, curCtr), true, out vector2d))
                            ellipticalArc.MajorAxis = vector2d;

                        if (ParseTxfVector2d(entityRecord, String.Format("MinorAxis({0},{1})", hlCtr, curCtr), true, out vector2d))
                            ellipticalArc.MinorAxis = vector2d;

                        if (ReadPropertyValue(entityRecord, String.Format("StartAngle({0},{1})", hlCtr, curCtr), false, out value))
                            ellipticalArc.StartAngle = ConvertTxfValue2Double(value);

                        if (ReadPropertyValue(entityRecord, String.Format("EndAngle({0},{1})", hlCtr, curCtr), false, out value))
                            ellipticalArc.EndAngle = ConvertTxfValue2Double(value);

                        entity.Loops[hlCtr].Curve2DCollection[curCtr] = ellipticalArc;

                        break;
                    case Common.Enums.CurveType.NurbCurve2d:

                        CwcNurbCurve2D nurbCurve2d = null;

                        bool hasFitData = ConvertTxfValue2Bool(entityRecord, String.Format("HasFitData({0},{1})", hlCtr, curCtr), false, false);
                        if (hasFitData)
                        {
                            int noOfFitPoints = 0;

                            if (ReadPropertyValue(entityRecord, String.Format("NumFitPoints({0},{1})", hlCtr, curCtr), true, out value))
                                noOfFitPoints = ConvertTxfValue2Integer(value);

                            nurbCurve2d = new CwcNurbCurve2D(noOfFitPoints, curvetype);

                            if (ReadPropertyValue(entityRecord, String.Format("Degree({0},{1})", hlCtr, curCtr), false, out value))
                                nurbCurve2d.Degree = ConvertTxfValue2Integer(value);

                            nurbCurve2d.FitKnotParameterization = ConvertTxfKnotParameterizationToDwg(String.Format("FitKnotParameterization({0},{1})", hlCtr, curCtr));

                            if (ReadPropertyValue(entityRecord, String.Format("FitTolerance_EqualPoint({0},{1})", hlCtr, curCtr), false, out value))
                                nurbCurve2d.FitTolerance_EqualPoint = ConvertTxfValue2Double(value);

                            if (ReadPropertyValue(entityRecord, String.Format("FitTolerance_EqualVector({0},{1})", hlCtr, curCtr), false, out value))
                                nurbCurve2d.FitTolerance_EqualVector = ConvertTxfValue2Double(value);

                            nurbCurve2d.Fit_TangentsExist = ConvertTxfValue2Bool(entityRecord, String.Format("Fit_TangentsExist({0},{1})", hlCtr, curCtr), false, false);
                            if (nurbCurve2d.Fit_TangentsExist)
                            {
                                if (ParseTxfVector2d(entityRecord, String.Format("Fit_StartTangent({0},{1})", hlCtr, curCtr), true, out vector2d))
                                    nurbCurve2d.Fit_StartTangent = vector2d;

                                if (ParseTxfVector2d(entityRecord, String.Format("Fit_EndTangent({0},{1})", hlCtr, curCtr), true, out vector2d))
                                    nurbCurve2d.Fit_EndTangent = vector2d;
                            }
                            for (int fp = 0; fp < nurbCurve2d.NumFitPoints; fp++)
                            {
                                if (ParseTxfPoint2d(entityRecord, String.Format("FitPoints({0},{1},{2})", hlCtr, curCtr, fp), true, out point2d))
                                    nurbCurve2d.FitPoints[fp] = point2d;
                            }
                        }
                        else
                        {

                            int noOfControlPoints = 0;

                            if (ReadPropertyValue(entityRecord, String.Format("NumControlPoints({0},{1})", hlCtr, curCtr), true, out value))
                                noOfControlPoints = ConvertTxfValue2Integer(value);

                            int noOfNumKnots = 0;

                            if (ReadPropertyValue(entityRecord, String.Format("NumKnots({0},{1})", hlCtr, curCtr), true, out value))
                                noOfNumKnots = ConvertTxfValue2Integer(value);

                            int noOfNumWeights = 0;

                            if (ReadPropertyValue(entityRecord, String.Format("NumWeights({0},{1})", hlCtr, curCtr), true, out value))
                                noOfNumWeights = ConvertTxfValue2Integer(value);

                            nurbCurve2d = new CwcNurbCurve2D(noOfControlPoints, noOfNumKnots, noOfNumWeights, curvetype);

                            if (ReadPropertyValue(entityRecord, String.Format("Degree({0},{1})", hlCtr, curCtr), true, out value))
                                nurbCurve2d.Degree = ConvertTxfValue2Integer(value);

                            nurbCurve2d.Periodic = ConvertTxfValue2Bool(entityRecord, String.Format("HasFitData({0},{1})", hlCtr, curCtr), false, false);

                            for (int cp = 0; cp < noOfControlPoints; cp++)
                            {
                                if (ParseTxfPoint2d(entityRecord, String.Format("ControlPoints({0},{1},{2})", hlCtr, curCtr, cp), true, out point2d))
                                    nurbCurve2d.ControlPoints[cp] = point2d;
                            }
                            for (int knt = 0; knt < noOfNumKnots; knt++)
                            {
                                if (ReadPropertyValue(entityRecord, String.Format("Knots({0},{1},{2})", hlCtr, curCtr, knt), false, out value))
                                    nurbCurve2d.Knots[knt] = ConvertTxfValue2Double(value);
                            }
                            for (int wt = 0; wt < noOfNumWeights; wt++)
                            {
                                if (ReadPropertyValue(entityRecord, String.Format("Weights({0},{1},{2})", hlCtr, curCtr, wt), false, out value))
                                    nurbCurve2d.Weights[wt] = ConvertTxfValue2Double(value);
                            }

                        }
                        entity.Loops[hlCtr].Curve2DCollection[curCtr] = nurbCurve2d;

                        break;

                    }

                  
                } // switch

            } // 


        public Teigha.Geometry.KnotParameterizationEnum ConvertTxfKnotParameterizationToDwg(string txfKnotParameterization)
        {
            return Enums.ConvertStringToEnumValue<Teigha.Geometry.KnotParameterizationEnum>(txfKnotParameterization);
        }

        public Enums.CurveType ConvertTxfCurveTypeToDwg(string txfCurveType)
        {
            return Enums.ConvertStringToEnumValue<Enums.CurveType>(txfCurveType);
        }

        public HatchPatternType ConvertTxfHatchPatternTypeToDwg(string txfHatchPatternType)
        {
            return Enums.ConvertStringToEnumValue<HatchPatternType>(txfHatchPatternType);
        }
        private HatchObjectType ConvertTxfHatchObjectTypeToDwg(string txfHatchObjectType)
        {
            return Enums.ConvertStringToEnumValue<HatchObjectType>(txfHatchObjectType);
        }
        private HatchStyle ConvertTxfHatchStyleToDwg(string txfHatchStyle)
        {
            return Enums.ConvertStringToEnumValue<HatchStyle>(txfHatchStyle);
        }
        private GradientPatternType ConvertTxfGradientPatternTypeToDwg(string txfGradientPatternType)
        {
            return Enums.ConvertStringToEnumValue<GradientPatternType>(txfGradientPatternType);
        }

        private HatchLoopTypes ConvertTxfHatchLoopTypeToDwg(string txfHatchLoopType)
        {
            return Enums.ConvertStringToEnumValue<HatchLoopTypes>(txfHatchLoopType);
        }


        private CwcGradiantColor ConvertCsvStringToGradiantColor(string csvString)
        {
            string[] strValues = Regex.Match(csvString, @"\(([^)]*)\)").Groups[1].Value.Split(',');

            CwcGradiantColor cwcGradiantColor = new CwcGradiantColor();
            byte bvalue;
            byte.TryParse(strValues[0], out bvalue);
            cwcGradiantColor.Red = bvalue;
            byte.TryParse(strValues[1], out bvalue);
            cwcGradiantColor.Green = bvalue;
            byte.TryParse(strValues[2], out bvalue);
            cwcGradiantColor.Blue = bvalue;
            float fvalue;
            float.TryParse(strValues[3], out fvalue);
            cwcGradiantColor.Value = fvalue;

            return cwcGradiantColor;
        }

        private bool ParseTxfGradientColor(Dictionary<string, string> entityRecord, string entityProperty, bool isRequired, out CwcGradiantColor cwcGradiantColor)
        {
            if (entityRecord.ContainsKey("GradientColor(1)") && entityRecord.ContainsKey("GradientColor(2)"))
            {
                cwcGradiantColor = ConvertCsvStringToGradiantColor(entityRecord[entityProperty]);
                return true;
            }
            else
            {
                if (isRequired)
                {
                    Logger.RecordMessage("ERROR: Missing property '" + entityProperty + "' for Entity [" + EntityTypeName + "], TXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Error);
                    Environment.Exit(1);
                }
                cwcGradiantColor = new CwcGradiantColor(0,0,0,0);
                return false;
            }

        }


    }
}

