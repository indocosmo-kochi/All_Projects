﻿using System;
using System.Text;
using CWorksTXF.Entities;
using CWorksTXF.Common;

namespace CWorksTXF.Txf.Writer
{

    public class TxfDBTextWriter : TxfEntityWriter
    {
        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcDBText);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetTXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("TextString={0}", entity.TextString))
                    .AppendLine(String.Format("Position={0}", entity.Position.ToString()))
                    .AppendLine(String.Format("Height={0}", entity.Height.ToString()))
                    .AppendLine(String.Format("IsDefaultAlignment={0}", entity.IsDefaultAlignment.ToString(1)))
                    .AppendLine(String.Format("HorizontalMode={0}", entity.HorizontalMode.ToString("D")))
                    .AppendLine(String.Format("VerticalMode={0}", entity.VerticalMode.ToString("D")))
                    .AppendLine(String.Format("Justify={0}", entity.Justify.ToString("D")))
                    .AppendLine(String.Format("Normal={0}", entity.Normal.ToString()))
                    .AppendLine(String.Format("Oblique={0}", entity.Oblique.ToString()))
                    .AppendLine(String.Format("Rotation={0}", entity.Rotation.ToString()))
                    .AppendLine(String.Format("IsMirroredInX={0}", entity.IsMirroredInX.ToString(1)))
                    .AppendLine(String.Format("IsMirroredInY={0}", entity.IsMirroredInY.ToString(1)))
                    .AppendLine(String.Format("Thickness={0}", entity.Thickness.ToString()))
                    .AppendLine(String.Format("WidthFactor={0}", entity.WidthFactor.ToString()))
                    .AppendLine(String.Format("Color={0}", entity.Color.ToString()))
                    .AppendLine(String.Format("ColorMethod={0}", entity.Color.ColorMethod.ToString("D")))
                    .AppendLine(String.Format("ColorIndex={0}", entity.Color.ColorIndex.ToString()))
                    .AppendLine(String.Format("TextStyleId={0}", entity.TextStyleId))
                    .AppendLine(String.Format("LayerId={0}", entity.LayerId))
                    ;

            if (!entity.IsDefaultAlignment)
                strBuilder.AppendLine(String.Format("AlignmentPoint={0}", entity.AlignmentPoint.ToString()));

            if (entity.BlockName.Trim().ToUpper() != CONST.MODEL_SPACE)
                strBuilder.AppendLine(String.Format("BlockId={0}", entity.BlockId));
            return strBuilder.ToString();
        }
    }
}
