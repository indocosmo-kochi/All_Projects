﻿using System.Collections.Generic;
using CWorksTXF.Entities;

namespace CWorksTXF.Txf.Reader
{
    public class TxfRotatedDimensionReader : TxfEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcRotatedDimension entity = new CwcRotatedDimension();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            ReadDimensionValues(entity, entityRecord);

            CwcPoint3D point3d;
            if (ParseTxfPoint3d(entityRecord, "XLine1Point", true, out point3d))
                entity.XLine1Point = point3d;

            if (ParseTxfPoint3d(entityRecord, "XLine2Point", true, out point3d))
                entity.XLine2Point = point3d;

            if (ParseTxfPoint3d(entityRecord, "DimLinePoint", true, out point3d))
                entity.DimLinePoint = point3d;

            if (ReadPropertyValue(entityRecord, "Rotation", false, out value))
                entity.Rotation = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "DimStyleId", false, out value))
                entity.DimStyleId = value;

            entity.Color = ParseTxfColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            if (ReadPropertyValue(entityRecord, "TextStyleId", true, out value))
                entity.TextStyleId = value;

            if (ParseTxfPoint3d(entityRecord, "TextPosition", true, out point3d))
                entity.TextPosition = point3d;

            if (ReadPropertyValue(entityRecord, "TextRotation", false, out value))
                entity.TextRotation = ConvertTxfValue2Double(value);
            
            if (ReadPropertyValue(entityRecord, "DimBlockId", false, out value))
                entity.DimBlockId = value;
            
            if (ReadPropertyValue(entityRecord, "DimensionText", false, out value))
                entity.DimensionText = value;

            entity.DynamicDimension = ConvertTxfValue2Bool(entityRecord, "DynamicDimension", false, false);

            if (ReadPropertyValue(entityRecord, "Elevation", false, out value))
                entity.Elevation = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "HorizontalRotation", false, out value))
                entity.HorizontalRotation = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "AlternatePrefix", false, out value))
                entity.AlternatePrefix = value;

            if (ReadPropertyValue(entityRecord, "AlternateSuffix", false, out value))
                entity.AlternateSuffix = value;

            if (ReadPropertyValue(entityRecord, "Prefix", false, out value))
                entity.Prefix = value;

            if (ReadPropertyValue(entityRecord, "Suffix", false, out value))
                entity.Suffix = value;

            entity.AltSuppressLeadingZeros = ConvertTxfValue2Bool(entityRecord, "AltSuppressLeadingZeros", false, false);
            entity.AltSuppressTrailingZeros = ConvertTxfValue2Bool(entityRecord, "AltSuppressTrailingZeros", false, false);
            entity.AltSuppressZeroFeet = ConvertTxfValue2Bool(entityRecord, "AltSuppressZeroFeet", false, false);
            entity.AltSuppressZeroInches = ConvertTxfValue2Bool(entityRecord, "AltSuppressZeroInches", false, false);
            entity.AltToleranceSuppressLeadingZeros = ConvertTxfValue2Bool(entityRecord, "AltToleranceSuppressLeadingZeros", false, false);
            entity.AltToleranceSuppressTrailingZeros = ConvertTxfValue2Bool(entityRecord, "AltToleranceSuppressTrailingZeros", false, false);
            entity.AltToleranceSuppressZeroFeet = ConvertTxfValue2Bool(entityRecord, "AltToleranceSuppressZeroFeet", false, false);
            entity.AltToleranceSuppressZeroInches = ConvertTxfValue2Bool(entityRecord, "AltToleranceSuppressZeroInches", false, false);

            entity.SuppressAngularLeadingZeros = ConvertTxfValue2Bool(entityRecord, "SuppressAngularLeadingZeros", false, false);
            entity.SuppressAngularTrailingZeros = ConvertTxfValue2Bool(entityRecord, "SuppressAngularTrailingZeros", false, false);
            entity.SuppressLeadingZeros = ConvertTxfValue2Bool(entityRecord, "SuppressLeadingZeros", false, false);
            entity.SuppressTrailingZeros = ConvertTxfValue2Bool(entityRecord, "SuppressTrailingZeros", false, false);
            entity.SuppressZeroFeet = ConvertTxfValue2Bool(entityRecord, "SuppressZeroFeet", false, false);
            entity.SuppressZeroInches = ConvertTxfValue2Bool(entityRecord, "SuppressZeroInches", false, false);

            entity.ToleranceSuppressLeadingZeros = ConvertTxfValue2Bool(entityRecord, "ToleranceSuppressLeadingZeros", false, false);
            entity.ToleranceSuppressTrailingZeros = ConvertTxfValue2Bool(entityRecord, "ToleranceSuppressTrailingZeros", false, false);
            entity.ToleranceSuppressZeroFeet = ConvertTxfValue2Bool(entityRecord, "ToleranceSuppressZeroFeet", false, false);
            entity.ToleranceSuppressZeroInches = ConvertTxfValue2Bool(entityRecord, "ToleranceSuppressZeroInches", false, false);
            entity.UsingDefaultTextPosition = ConvertTxfValue2Bool(entityRecord, "UsingDefaultTextPosition", false, false);

            if (ReadPropertyValue(entityRecord, "TextLineSpacingFactor", false, out value))
                entity.TextLineSpacingFactor = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "TextAttachment", true, out value))
                entity.TextAttachment = ConvertTxfTextJustifyToDwg(value);

            if (ReadPropertyValue(entityRecord, "TextLineSpacingStyle", false, out value))
                entity.TextLineSpacingStyle = ConvertTxfMTextLineSpacingStyleToDwg(value);

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            if (ReadPropertyValue(entityRecord, "Linetype", false, out value))
                entity.Linetype = value;

            if (ReadPropertyValue(entityRecord, "LinetypeScale", false, out value))
                entity.LinetypeScale = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                entity.LineWeight = ConvertTxfLineWeightToDwg(value);

            return entity;
        }

    }
}
