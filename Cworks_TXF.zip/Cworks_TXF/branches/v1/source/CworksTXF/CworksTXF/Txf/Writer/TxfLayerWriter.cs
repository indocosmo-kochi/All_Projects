﻿using System;
using System.Text;
using CWorksTXF.Entities;
using CWorksTXF.Common;

namespace CWorksTXF.Txf.Writer
{
    public class TxfLayerWriter : TxfEntityWriter
    {
        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcLayer);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetTXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))

                    .AppendLine(String.Format("Name={0}", entity.Name))
                    .AppendLine(String.Format("Color={0}", entity.Color.ToString()))
                    .AppendLine(String.Format("ColorMethod={0}", entity.Color.ColorMethod.ToString("D")))
                    .AppendLine(String.Format("ColorIndex={0}", entity.Color.ColorIndex.ToString()))
                    .AppendLine(String.Format("LineType={0}", entity.LineType))

                    .AppendLine(String.Format("LineWeight={0}", entity.LineWeight.ToString("D")))
                    .AppendLine(String.Format("IsOff={0}", entity.IsOff.ToString(1)))
                    .AppendLine(String.Format("IsHidden={0}", entity.IsHidden.ToString(1)))
                    .AppendLine(String.Format("IsPlottable={0} ", entity.IsPlottable.ToString(1)))
                    .AppendLine(String.Format("IsLocked={0}", entity.IsLocked.ToString(1)))
            ;
            return strBuilder.ToString();
        }
    }
}
