﻿using System;
using System.Text;
using CWorksTXF.Entities;
using System.IO;

namespace CWorksTXF.Txf.Writer
{
    public class TxfDBSettingsWriter
    {
        public void WriteDBSettings(CwcDBSettings item, StreamWriter outfile)
        {
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine("[DBSETTINGS]")
                    .AppendLine(String.Format("Pdmode={0}", item.Pdmode.ToString()))
                    .AppendLine(String.Format("Pdsize={0}", item.Pdsize.ToString()))
                    .AppendLine(String.Format("Ltscale={0}", item.Ltscale.ToString()))
                    .AppendLine(String.Format("Measurement={0}", (int)item.Measurement))
            ;
            outfile.WriteLine(strBuilder.ToString());

        }
    }
}

