﻿using CWorksTXF.Entities;
using System.Collections.Generic;

namespace CWorksTXF.Txf.Reader
{
    interface ITxfEntityReader
    {
        CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord);
    }
}
