﻿using System;
using System.Collections.Generic;
using CWorksTXF.Entities;
using CWorksTXF.Common;

namespace CWorksTXF.Txf.Reader
{
    public class TxfDBSettingsReader : TxfEntityReader
    {
        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            throw new NotImplementedException();
        }

        public CwcDBSettings ReadAndParseDBSettings(Dictionary<string, string> entityRecord)
        {
            CwcDBSettings dbSettings = new CwcDBSettings();
            string value;

            if (ReadPropertyValue(entityRecord, "Pdmode", false, out value))
                dbSettings.Pdmode = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Pdsize", false, out value))
                dbSettings.Pdsize = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Ltscale", false, out value))
                dbSettings.Ltscale = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Measurement", false, out value))
                dbSettings.Measurement = ConvertTxfMeasurementToDwg(value);


            return dbSettings;
        }


        private Enums.MeasurementValue ConvertTxfMeasurementToDwg(string txfMeasurement)
        {
            int intValue = ConvertTxfValue2Integer(txfMeasurement);

            return Enums.ConvertEnumValueToString<Enums.MeasurementValue>(intValue);
        }

    }
}
