﻿using System.Collections.Generic;
using CWorksTXF.Entities;

namespace CWorksTXF.Txf.Reader
{
    public class TxfBlockReader : TxfEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcBlock entity = new CwcBlock();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            if (ReadPropertyValue(entityRecord, "Name", true, out value))
                entity.Name = value;

            if (ReadPropertyValue(entityRecord, "NumberAttributeDefs", true, out value))
                entity.NumberAttributeDefs = ConvertTxfValue2Integer(value);

            for (int i = 0; i < entity.NumberAttributeDefs; i++)
            {
                CwcAttributeDefinition attdef = new CwcAttributeDefinition();

                CwcPoint3D point3d;
                if (ParseTxfPoint3d(entityRecord, string.Format("Position({0})", i), true, out point3d))
                    attdef.Position = point3d;

                if (ParseTxfPoint3d(entityRecord, string.Format("AlignmentPoint({0})", i), true, out point3d))
                    attdef.AlignmentPoint = point3d;

                if (ReadPropertyValue(entityRecord, string.Format("Tag({0})", i), true, out value))
                    attdef.Tag = value;
                
                if (ReadPropertyValue(entityRecord, string.Format("TextString({0})", i), false, out value))
                    attdef.TextString = value;

                if (ReadPropertyValue(entityRecord, string.Format("FieldLength({0})", i), true, out value))
                    attdef.FieldLength = ConvertTxfValue2Integer(value);

                if (ReadPropertyValue(entityRecord, string.Format("Height({0})", i), true, out value))
                    attdef.Height = ConvertTxfValue2Double(value);

                if (ReadPropertyValue(entityRecord, string.Format("Oblique({0})", i), true, out value))
                    attdef.Oblique = ConvertTxfValue2Double(value);

                if (ReadPropertyValue(entityRecord, string.Format("Rotation({0})", i), true, out value))
                    attdef.Rotation = ConvertTxfValue2Double(value);

                if (ReadPropertyValue(entityRecord, string.Format("WidthFactor({0})", i), true, out value))
                    attdef.WidthFactor = ConvertTxfValue2Double(value);

                if (ReadPropertyValue(entityRecord, string.Format("Annotative({0})", i), true, out value))
                    attdef.Annotative = ConvertTxfAnnotativeStatesToDwg(value);

                if (ReadPropertyValue(entityRecord, string.Format("Justify({0})", i), true, out value))
                    attdef.Justify = ConvertTxfTextJustifyToDwg(value);
                
                attdef.IsMirroredInX = ConvertTxfValue2Bool(entityRecord, string.Format("IsMirroredInX({0})", i), true, false);
                attdef.IsMirroredInY = ConvertTxfValue2Bool(entityRecord, string.Format("IsMirroredInY({0})", i), true, false);
                attdef.Constant = ConvertTxfValue2Bool(entityRecord, string.Format("Constant({0})", i), true, false);
                attdef.IsMTextAttributeDefinition = ConvertTxfValue2Bool(entityRecord, string.Format("IsMTextAttributeDefinition({0})", i), true, false);
                attdef.Invisible = ConvertTxfValue2Bool(entityRecord, string.Format("Invisible({0})", i), false, false);
                attdef.LockPositionInBlock = ConvertTxfValue2Bool(entityRecord, string.Format("LockPositionInBlock({0})", i), false, false);

                if (!attdef.Constant)
                {
                    if (ReadPropertyValue(entityRecord, string.Format("Prompt({0})", i), false, out value))
                        attdef.Prompt = value;
                    attdef.Verifiable = ConvertTxfValue2Bool(entityRecord, string.Format("Verifiable({0})", i), false, false);
                    attdef.Preset = ConvertTxfValue2Bool(entityRecord, string.Format("Preset({0})", i), false, false);
                }
                if (attdef.IsMTextAttributeDefinition)
                {
                    if (ReadPropertyValue(entityRecord, string.Format("MTextWidth({0})", i), true, out value))
                        attdef.MTextWidth = ConvertTxfValue2Double(value);

                    if (ReadPropertyValue(entityRecord, string.Format("MTextContents({0})", i), true, out value))
                        attdef.MTextContents = value;
                    
                }
                attdef.Color = ParseTxfColor(entityRecord, string.Format("Color({0})", i), string.Format("ColorMethod({0})", i), string.Format("ColorIndex({0})", i));

                if (ReadPropertyValue(entityRecord, string.Format("TextStyleId({0})", i), false, out value))
                    attdef.TextStyleId = value;

                if (ReadPropertyValue(entityRecord, string.Format("LayerId({0})", i), false, out value))
                    attdef.LayerId = value;

                entity.AttributeDefs.Add(attdef);
            }

            return entity;
        }

    }
}
