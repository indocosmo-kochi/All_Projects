﻿using CWorksTXF.Entities;
using System.IO;

namespace CWorksTXF.Txf.Writer
{
    public interface ITxfEntityWriter
    {
        void WriteEnityDetails(CwcDbObject item, StreamWriter outfile);
    }
}
