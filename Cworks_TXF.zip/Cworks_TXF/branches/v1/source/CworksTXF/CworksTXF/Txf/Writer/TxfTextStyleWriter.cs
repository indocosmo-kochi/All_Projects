﻿using System;
using System.Text;
using CWorksTXF.Entities;
using CWorksTXF.Common;

namespace CWorksTXF.Txf.Writer
{
    public class TxfTextStyleWriter : TxfEntityWriter
    {
        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcTextStyle);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetTXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("Name={0}", entity.Name))
                    .AppendLine(String.Format("FontName={0}", entity.FontName))
                    .AppendLine(String.Format("TextSize={0}", entity.TextSize.ToString()))
                    .AppendLine(String.Format("FlagBits={0}", entity.FlagBits.ToString()))
                    .AppendLine(String.Format("ObliquingAngle={0}", entity.ObliquingAngle.ToString()))
                    .AppendLine(String.Format("IsVertical={0}", entity.IsVertical.ToString(1)))
                    .AppendLine(String.Format("IsBold={0}", entity.IsBold.ToString(1)))
                    .AppendLine(String.Format("IsItallic={0}", entity.IsItallic.ToString(1)))
                    .AppendLine(String.Format("Characters={0}", entity.Characters.ToString()))
                    .AppendLine(String.Format("PitchAndFamily={0}", entity.PitchAndFamily.ToString()))
                    .AppendLine(String.Format("FileName={0}", entity.FileName))
                    .AppendLine(String.Format("Annotative={0}", entity.Annotative.ToString("D")))
                    .AppendLine(String.Format("BigFontFileName={0}", entity.BigFontFileName))
                    .AppendLine(String.Format("PriorSize={0}", entity.PriorSize.ToString()))
                    .AppendLine(String.Format("XScale={0}", entity.XScale.ToString()))
            ;
            return strBuilder.ToString();
        }
    }
}
