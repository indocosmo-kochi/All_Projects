﻿using System;
using System.Text;
using CWorksTXF.Entities;
using CWorksTXF.Common;

namespace CWorksTXF.Txf.Writer
{

    public class TxfArcWriter : TxfEntityWriter
    {
        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcArc);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetTXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("Center={0} ", entity.Center.ToString()))
                    .AppendLine(String.Format("Radius={0}", entity.Radius.ToString()))
                    .AppendLine(String.Format("StartPoint={0} ", entity.StartPoint.ToString()))
                    .AppendLine(String.Format("EndPoint={0} ", entity.EndPoint.ToString()))

                    .AppendLine(String.Format("Normal={0} ", entity.Normal.ToString()))

                    .AppendLine(String.Format("StartAngle={0}", entity.StartAngle.ToString()))
                    .AppendLine(String.Format("EndAngle={0}", entity.EndAngle.ToString()))

                    .AppendLine(String.Format("Color={0}", entity.Color.ToString()))
                    .AppendLine(String.Format("ColorMethod={0}", entity.Color.ColorMethod.ToString("D")))
                    .AppendLine(String.Format("ColorIndex={0}", entity.Color.ColorIndex.ToString()))
                    .AppendLine(String.Format("Linetype={0} ", entity.Linetype))
                    .AppendLine(String.Format("LinetypeScale={0}", entity.LinetypeScale))
                    .AppendLine(String.Format("LayerId={0}", entity.LayerId))
                    .AppendLine(String.Format("LineWeight={0}", entity.LineWeight.ToString("D")))
                    ;
            if (entity.BlockName.Trim().ToUpper() != CONST.MODEL_SPACE)
                strBuilder.AppendLine(String.Format("BlockId={0}", entity.BlockId));
            return strBuilder.ToString();
        }
    }
}

