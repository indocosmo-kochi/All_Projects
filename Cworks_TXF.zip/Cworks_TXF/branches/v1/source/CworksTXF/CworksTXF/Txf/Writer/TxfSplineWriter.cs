﻿using System;
using System.Text;
using CWorksTXF.Entities;
using CWorksTXF.Common;

namespace CWorksTXF.Txf.Writer
{
    public class TxfSplineWriter : TxfEntityWriter
    {

        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcSpline);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetTXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("HasFitData={0}", entity.HasFitData.ToString(1)))
                    ;

            if (entity.HasFitData)
            {
                if (entity.FitTangentsExist)
                {
                    strBuilder.AppendLine(String.Format("StartFitTangent={0}", entity.StartFitTangent.ToString()))
                            .AppendLine(String.Format("EndFitTangent={0}", entity.EndFitTangent.ToString()));
                }

                strBuilder.AppendLine(String.Format("FitTangentsExist={0}", entity.FitTangentsExist.ToString(1)))
                        .AppendLine(String.Format("NumFitPoints={0}", entity.NumFitPoints.ToString()))
                        .AppendLine(String.Format("Order={0}", entity.Order.ToString()))
                        .AppendLine(String.Format("FitTolerance={0}", entity.FitTolerance.ToString()))
                        ;


                for (int fp = 0; fp < entity.NumFitPoints; fp++)
                {
                    strBuilder.AppendLine(String.Format("FitPoints({0})={1}", fp, entity.FitPoints[fp].ToString()));
                }
            }
            else
            {
                strBuilder.AppendLine(String.Format("NumControlPoints={0}", entity.NumControlPoints.ToString()))
                        .AppendLine(String.Format("NumKnots={0}", entity.NurbsData.NumKnots.ToString()))
                        .AppendLine(String.Format("NumWeights={0}", entity.NurbsData.NumWeights.ToString()))
                        .AppendLine(String.Format("Closed={0}", entity.NurbsData.Closed.ToString(1)))
                        .AppendLine(String.Format("ControlPointTolerance={0}", entity.NurbsData.ControlPointTolerance.ToString()))
                        .AppendLine(String.Format("Degree={0}", entity.NurbsData.Degree.ToString()))
                        .AppendLine(String.Format("KnotTolerance={0}", entity.NurbsData.KnotTolerance.ToString()))
                        .AppendLine(String.Format("Periodic={0}", entity.NurbsData.Periodic.ToString(1)))
                        .AppendLine(String.Format("Rational={0}", entity.NurbsData.Rational.ToString(1)))
                        ;

                for (int cp = 0; cp < entity.NumControlPoints; cp++)
                {
                    strBuilder.AppendLine(String.Format("ControlPoints({0})={1}", cp, entity.ControlPoints[cp].ToString()));
                }

                for (int knt = 0; knt < entity.NurbsData.NumKnots; knt++)
                {
                    strBuilder.AppendLine(String.Format("Knots({0})={1}", knt, entity.NurbsData.Knots[knt].ToString()));
                }

                for (int wt = 0; wt < entity.NurbsData.NumWeights; wt++)
                {
                    strBuilder.AppendLine(String.Format("Weights({0})={1}", wt, entity.NurbsData.Weights[wt].ToString()));
                }

            }

            strBuilder.AppendLine(String.Format("Color={0}", entity.Color.ToString()))
                   .AppendLine(String.Format("ColorMethod={0}", entity.Color.ColorMethod.ToString("D")))
                   .AppendLine(String.Format("ColorIndex={0}", entity.Color.ColorIndex.ToString()))
                   .AppendLine(String.Format("Linetype={0}", entity.Linetype))
                   .AppendLine(String.Format("LinetypeScale={0}", entity.LinetypeScale))
                   .AppendLine(String.Format("LayerId={0}", entity.LayerId))
                   .AppendLine(String.Format("LineWeight={0}", entity.LineWeight.ToString("D")))
                   ;
            if (entity.BlockName.Trim().ToUpper() != CONST.MODEL_SPACE)
                strBuilder.AppendLine(String.Format("BlockId={0}", entity.BlockId));
            return strBuilder.ToString();
        }

    }
}
