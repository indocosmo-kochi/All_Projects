﻿using System;
using System.Collections.Generic;
using Teigha.DatabaseServices;
using CWorksTXF.Entities;

namespace CWorksTXF.Txf.Reader
{
    public class TxfMTextReader : TxfEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {

            string value;
            int colCount = 0;
            ColumnType colType = ColumnType.NoColumns;
            if (ReadPropertyValue(entityRecord, "ColumnCount", false, out value))
                colCount = ConvertTxfValue2Integer(value);

            bool colAutoHeight = ConvertTxfValue2Bool(entityRecord, "ColumnAutoHeight", true, false);

            if (ReadPropertyValue(entityRecord, "ColumnType", true, out value))
                colType = ConvertTxfMTextColumnTypeToDwg(value);

            CwcMText entity = new CwcMText(colType, colAutoHeight, colCount);

            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            if (ReadPropertyValue(entityRecord, "TextString", false, out value))
                entity.TextString = value;

            CwcPoint3D point3d;
            if (ParseTxfPoint3d(entityRecord, "Location", true, out point3d))
                entity.Location = point3d;

            if (ReadPropertyValue(entityRecord, "Height", false, out value))
                entity.Height = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Width", false, out value))
                entity.Width = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "TextHeight", false, out value))
                entity.TextHeight = ConvertTxfValue2Double(value);

            CwcVector3D vector3d;
            if (ParseTxfVector3d(entityRecord, "Normal", true, out vector3d))
                entity.Normal = vector3d;

            if (ReadPropertyValue(entityRecord, "Attachment", false, out value))
                entity.Attachment = ConvertTxfMTextAttachmentToDwg(value);

            if (ParseTxfVector3d(entityRecord, "Direction", true, out vector3d))
                entity.Direction = vector3d;

            if (ReadPropertyValue(entityRecord, "FlowDirection", false, out value))
                entity.FlowDirection = ConvertTxfMTextFlowDirectionToDwg(value);

            if (ReadPropertyValue(entityRecord, "BackgroundScaleFactor", false, out value))
                entity.BackgroundScaleFactor = ConvertTxfValue2Double(value);

            entity.ColumnFlowReversed = ConvertTxfValue2Bool(entityRecord, "ColumnFlowReversed", false, false);

            if (entity.ColumnType != ColumnType.NoColumns)
            {
                if (ReadPropertyValue(entityRecord, "ColumnGutterWidth", false, out value))
                    entity.ColumnGutterWidth = ConvertTxfValue2Double(value);

                if (ReadPropertyValue(entityRecord, "ColumnWidth", false, out value))
                    entity.ColumnWidth = ConvertTxfValue2Double(value);
            }

            if ((!entity.ColumnAutoHeight) && (entity.ColumnType == ColumnType.DynamicColumns))
            {
                for (int col = 0; col < entity.ColumnCount; col++)
                {
                    if (ReadPropertyValue(entityRecord, String.Format("ColumnHeight[{0}]", col), false, out value))
                        entity.ColumnWidth = ConvertTxfValue2Double(value);
                }
            }


            if (ReadPropertyValue(entityRecord, "LineSpaceDistance", false, out value))
                entity.LineSpaceDistance = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineSpacingFactor", false, out value))
                entity.LineSpacingFactor = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineSpacingStyle", false, out value))
                entity.LineSpacingStyle = ConvertTxfMTextLineSpacingStyleToDwg(value);

            if (ReadPropertyValue(entityRecord, "Rotation", false, out value))
                entity.Rotation = ConvertTxfValue2Double(value);


            //if (ReadPropertyValue(entityRecord, "Font", false, out value))
            //    entity.Font = value;

            entity.BackgroundFill = ConvertTxfValue2Bool(entityRecord, "BackgroundFill", true, false);
            entity.UseBackgroundColor = ConvertTxfValue2Bool(entityRecord, "UseBackgroundColor", false, false);

            if (entity.BackgroundFill)
                entity.BackgroundFillColor = ParseTxfColor(entityRecord, "BackgroundFillColor", "BackgroundFillColorMethod", "BackgroundFillColorIndex");


            if (ReadPropertyValue(entityRecord, "TextStyleId", false, out value))
                entity.TextStyleId = value;

            entity.Color = ParseTxfColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            return entity;
        }

    }
}
