﻿using System.Collections.Generic;
using CWorksTXF.Entities;

namespace CWorksTXF.Txf.Reader
{
    public class TxfSplineReader : TxfEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            string value;

            bool hasFitData = ConvertTxfValue2Bool(entityRecord, "HasFitData", true, true);

            int numberOfFitPoints = 0;
            int numberOfControlPoints = 0;
            int numberOfKnots = 0;
            int numberOfWeights = 0;
            CwcSpline entity;
            CwcPoint3D point3d;

            if (hasFitData)
            {

                bool fitTangentsExist = ConvertTxfValue2Bool(entityRecord, "FitTangentsExist", true, true);

                if (ReadPropertyValue(entityRecord, "NumFitPoints", true, out value))
                    numberOfFitPoints = ConvertTxfValue2Integer(value);

                entity = new CwcSpline(hasFitData, numberOfFitPoints);

                entity.FitTangentsExist = fitTangentsExist;

                for (int i = 0; i < numberOfFitPoints; i++)
                {
                    if (ParseTxfPoint3d(entityRecord, string.Format("FitPoints({0})", i), true, out point3d))
                        entity.FitPoints[i] = point3d;
                }

                CwcVector3D vector3d;

                if (fitTangentsExist)
                {
                    if (ParseTxfVector3d(entityRecord, "StartFitTangent", true, out vector3d))
                        entity.StartFitTangent = vector3d;

                    if (ParseTxfVector3d(entityRecord, "EndFitTangent", true, out vector3d))
                        entity.EndFitTangent = vector3d;
                }

                if (ReadPropertyValue(entityRecord, "FitTolerance", false, out value))
                    entity.FitTolerance = ConvertTxfValue2Double(value);

                if (ReadPropertyValue(entityRecord, "Order", false, out value))
                    entity.Order = ConvertTxfValue2Integer(value);

            }
            else
            {
                if (ReadPropertyValue(entityRecord, "NumControlPoints", true, out value))
                    numberOfControlPoints = ConvertTxfValue2Integer(value);

                if (ReadPropertyValue(entityRecord, "NumKnots", true, out value))
                    numberOfKnots = ConvertTxfValue2Integer(value);

                if (ReadPropertyValue(entityRecord, "NumWeights", true, out value))
                    numberOfWeights = ConvertTxfValue2Integer(value);

                entity = new CwcSpline(hasFitData, numberOfControlPoints, numberOfKnots, numberOfWeights);

                for (int cp = 0; cp < numberOfControlPoints; cp++)
                {
                    if (ParseTxfPoint3d(entityRecord, string.Format("ControlPoints({0})", cp), true, out point3d))
                        entity.ControlPoints[cp] = point3d;
                }

                for (int knt = 0; knt < numberOfKnots; knt++)
                {
                    if (ReadPropertyValue(entityRecord, string.Format("Knots({0})", knt), true, out value))
                        entity.NurbsData.Knots[knt] = ConvertTxfValue2Double(value);
                }

                for (int wt = 0; wt < numberOfWeights; wt++)
                {
                    if (ReadPropertyValue(entityRecord, string.Format("Weights({0})", wt), true, out value))
                        entity.NurbsData.Weights[wt] = ConvertTxfValue2Double(value);
                }

                entity.NurbsData.Closed = ConvertTxfValue2Bool(entityRecord, "Closed", false, false);

                if (ReadPropertyValue(entityRecord, "Degree", false, out value))
                    entity.NurbsData.Degree = ConvertTxfValue2Integer(value);

                if (ReadPropertyValue(entityRecord, "ControlPointTolerance", false, out value))
                    entity.NurbsData.ControlPointTolerance = ConvertTxfValue2Double(value);

                if (ReadPropertyValue(entityRecord, "KnotTolerance", false, out value))
                    entity.NurbsData.KnotTolerance = ConvertTxfValue2Double(value);

                entity.NurbsData.Periodic = ConvertTxfValue2Bool(entityRecord, "Periodic", false, false);
                entity.NurbsData.Rational = ConvertTxfValue2Bool(entityRecord, "Rational", false, false);

            }

            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            entity.Color = ParseTxfColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            if (ReadPropertyValue(entityRecord, "Linetype", false, out value))
                entity.Linetype = value;

            if (ReadPropertyValue(entityRecord, "LinetypeScale", false, out value))
                entity.LinetypeScale = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                entity.LineWeight = ConvertTxfLineWeightToDwg(value);

            return entity;
        }

    }
}
