﻿using System.Collections.Generic;
using CWorksTXF.Entities;

namespace CWorksTXF.Txf.Reader
{
    public class TxfEllipseReader : TxfEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcEllipse entity = new CwcEllipse();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            CwcPoint3D point3d;
            if (ParseTxfPoint3d(entityRecord, "Center", true, out point3d))
                entity.Center = point3d;

            CwcVector3D vector3d;
            if (ParseTxfVector3d(entityRecord, "UnitNormal", true, out vector3d))
                entity.UnitNormal = vector3d;

            if (ParseTxfVector3d(entityRecord, "MajorAxis", true, out vector3d))
                entity.MajorAxis = vector3d;

            if (ReadPropertyValue(entityRecord, "RadiusRatio", false, out value))
                entity.RadiusRatio = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "StartAngle", false, out value))
                entity.StartAngle = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "EndAngle", false, out value))
                entity.EndAngle = ConvertTxfValue2Double(value);

            entity.Color = ParseTxfColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            if (ReadPropertyValue(entityRecord, "Linetype", false, out value))
                entity.Linetype = value;

            if (ReadPropertyValue(entityRecord, "LinetypeScale", false, out value))
                entity.LinetypeScale = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                entity.LineWeight = ConvertTxfLineWeightToDwg(value);

            return entity;
        }

    }
}

