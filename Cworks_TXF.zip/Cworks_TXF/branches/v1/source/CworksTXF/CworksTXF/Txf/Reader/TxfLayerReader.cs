﻿using System.Collections.Generic;
using CWorksTXF.Entities;

namespace CWorksTXF.Txf.Reader
{
    public class TxfLayerReader : TxfEntityReader
    {
        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcLayer cwcLayer = new CwcLayer();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                cwcLayer.Id = value;

            if (ReadPropertyValue(entityRecord, "Name", true, out value))
                cwcLayer.Name = value;

            cwcLayer.Color = ParseTxfColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            cwcLayer.IsOff = ConvertTxfValue2Bool(entityRecord, "IsOff", false, false);
            cwcLayer.IsHidden = ConvertTxfValue2Bool(entityRecord, "IsHidden", false, false);
            cwcLayer.IsPlottable = ConvertTxfValue2Bool(entityRecord, "IsPlottable", false, true);
            cwcLayer.IsLocked = ConvertTxfValue2Bool(entityRecord, "IsLocked", false, false);

            if (ReadPropertyValue(entityRecord, "LineType", false, out value))
                cwcLayer.LineType = value;
            //if (ReadPropertyValue(entityRecord, "LineType", false, out value))
            //    cwcLayer.LineType = ConvertCxfLineTypeToDwg(value); 
            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                cwcLayer.LineWeight = ConvertTxfLineWeightToDwg(value);

            return cwcLayer;

        }
    }
}
