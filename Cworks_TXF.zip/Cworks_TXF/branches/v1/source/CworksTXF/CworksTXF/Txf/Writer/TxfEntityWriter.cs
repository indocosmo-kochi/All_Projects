﻿using System.IO;
using System;
using System.Text;
using CWorksTXF.Entities;
using CWorksTXF.Common;

namespace CWorksTXF.Txf.Writer
{
    public abstract class TxfEntityWriter : ITxfEntityWriter
    {

        public virtual string getEntityDetails(CwcDbObject item)
        {
            return string.Empty;
        }

        public void WriteEnityDetails(CwcDbObject item, StreamWriter outfile)
        {
            outfile.WriteLine(getEntityDetails(item));
        }

        protected string WriteDimensionValues(CwcDimension entity)
        {
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(String.Format("Dimadec={0}", entity.Dimadec.ToString()))
                    .AppendLine(String.Format("Dimalt={0}", entity.Dimalt.ToString(1)))
                    .AppendLine(String.Format("Dimaltd={0}", entity.Dimaltd.ToString()))
                    .AppendLine(String.Format("Dimaltf={0}", entity.Dimaltf.ToString()))
                    .AppendLine(String.Format("Dimaltrnd={0}", entity.Dimaltrnd.ToString()))
                    .AppendLine(String.Format("Dimalttd={0}", entity.Dimalttd.ToString()))
                    .AppendLine(String.Format("Dimalttz={0}", entity.Dimalttz.ToString()))
                    .AppendLine(String.Format("Dimaltu={0}", entity.Dimaltu.ToString()))
                    .AppendLine(String.Format("Dimaltz={0}", entity.Dimaltz.ToString()))
                    .AppendLine(String.Format("Dimapost={0}", entity.Dimapost))
                    .AppendLine(String.Format("Dimarcsym={0}", entity.Dimarcsym.ToString()))
                    .AppendLine(String.Format("Dimasz={0}", entity.Dimasz.ToString()))
                    .AppendLine(String.Format("Dimatfit={0}", entity.Dimatfit.ToString()))
                    .AppendLine(String.Format("Dimaunit={0}", entity.Dimaunit.ToString()))
                    .AppendLine(String.Format("Dimazin={0}", entity.Dimazin.ToString()))
                    .AppendLine(String.Format("Dimsah={0}", entity.Dimsah.ToString(1)))
                    .AppendLine(String.Format("Dimblk1s={0}", entity.Dimblk1s))
                    .AppendLine(String.Format("Dimblk2s={0}", entity.Dimblk2s))
                    .AppendLine(String.Format("Dimblks={0}", entity.Dimblks))
                    .AppendLine(String.Format("Dimcen={0}", entity.Dimcen.ToString()))

                    .AppendLine(String.Format("Dimdec={0}", entity.Dimdec.ToString()))
                    .AppendLine(String.Format("Dimdle={0}", entity.Dimdle.ToString()))
                    .AppendLine(String.Format("Dimdli={0}", entity.Dimdli.ToString()))
                    .AppendLine(String.Format("Dimdsep={0}", entity.Dimdsep))
                    .AppendLine(String.Format("Dimexe={0}", entity.Dimexe.ToString()))
                    .AppendLine(String.Format("Dimexo={0}", entity.Dimexo.ToString()))
                    .AppendLine(String.Format("Dimfrac={0}", entity.Dimfrac.ToString()))
                    .AppendLine(String.Format("Dimfxlen={0}", entity.Dimfxlen.ToString()))
                    .AppendLine(String.Format("DimfxlenOn={0}", entity.DimfxlenOn.ToString(1)))
                    .AppendLine(String.Format("Dimgap={0}", entity.Dimgap.ToString()))
                    .AppendLine(String.Format("Dimjogang={0}", entity.Dimjogang.ToString()))
                    .AppendLine(String.Format("Dimjust={0}", entity.Dimjust.ToString()))
                    .AppendLine(String.Format("Dimldrblks={0}", entity.Dimldrblks))
                    .AppendLine(String.Format("Dimlfac={0}", entity.Dimlfac.ToString()))
                    .AppendLine(String.Format("Dimlim={0}", entity.Dimlim.ToString(1)))
                    .AppendLine(String.Format("Dimltex1={0}", entity.Dimltex1.ToString()))
                    .AppendLine(String.Format("Dimltex2={0}", entity.Dimltex2.ToString()))
                    .AppendLine(String.Format("Dimltype={0}", entity.Dimltype.ToString()))
                    .AppendLine(String.Format("Dimlunit={0}", entity.Dimlunit.ToString()))
                    .AppendLine(String.Format("Dimlwd={0}", entity.Dimlwd.ToString("D")))
                    .AppendLine(String.Format("Dimlwe={0}", entity.Dimlwe.ToString("D")))
                    .AppendLine(String.Format("Dimpost={0}", entity.Dimpost))
                    .AppendLine(String.Format("Dimrnd={0}", entity.Dimrnd.ToString()))
                    .AppendLine(String.Format("Dimscale={0}", entity.Dimscale.ToString()))
                    .AppendLine(String.Format("Dimsd1={0}", entity.Dimsd1.ToString(1)))
                    .AppendLine(String.Format("Dimsd2={0}", entity.Dimsd2.ToString(1)))
                    .AppendLine(String.Format("Dimse1={0}", entity.Dimse1.ToString(1)))
                    .AppendLine(String.Format("Dimse2={0}", entity.Dimse2.ToString(1)))
                    .AppendLine(String.Format("Dimsoxd={0}", entity.Dimsoxd.ToString(1)))
                    .AppendLine(String.Format("Dimtad={0}", entity.Dimtad.ToString()))
                    .AppendLine(String.Format("Dimtdec={0}", entity.Dimtdec.ToString()))
                    .AppendLine(String.Format("Dimtfac={0}", entity.Dimtfac.ToString()))
                    .AppendLine(String.Format("Dimtfill={0}", entity.Dimtfill.ToString()))
                    .AppendLine(String.Format("Dimtih={0}", entity.Dimtih.ToString(1)))
                    .AppendLine(String.Format("Dimtix={0}", entity.Dimtix.ToString(1)))
                    .AppendLine(String.Format("Dimtm={0}", entity.Dimtm.ToString()))
                    .AppendLine(String.Format("Dimtmove={0}", entity.Dimtmove.ToString()))
                    .AppendLine(String.Format("Dimtofl={0}", entity.Dimtofl.ToString(1)))
                    .AppendLine(String.Format("Dimtoh={0}", entity.Dimtoh.ToString(1)))
                    .AppendLine(String.Format("Dimtol={0}", entity.Dimtol.ToString(1)))
                    .AppendLine(String.Format("Dimtolj={0}", entity.Dimtolj.ToString()))
                    .AppendLine(String.Format("Dimtp={0}", entity.Dimtp.ToString()))
                    .AppendLine(String.Format("Dimtsz={0}", entity.Dimtsz.ToString()))
                    .AppendLine(String.Format("Dimtvp={0}", entity.Dimtvp.ToString()))
                    .AppendLine(String.Format("Dimtxt={0}", entity.Dimtxt.ToString()))
                    .AppendLine(String.Format("Dimtzin={0}", entity.Dimtzin.ToString()))
                    .AppendLine(String.Format("Dimupt={0}", entity.Dimupt.ToString(1)))
                    .AppendLine(String.Format("Dimzin={0}", entity.Dimzin.ToString()))
            ;

            if (entity.Dimtfillclr != null)
            {
                strBuilder.AppendLine(String.Format("Dimtfillclr={0}", entity.Dimtfillclr.ToString()))
                    .AppendLine(String.Format("Dimtfillclr_ColorMethod={0}", entity.Dimtfillclr.ColorMethod.ToString("D")))
                    .AppendLine(String.Format("Dimtfillclr_ColorIndex={0}", entity.Dimtfillclr.ColorIndex.ToString()));
            }

            if (entity.Dimclrd != null)
            {
                strBuilder.AppendLine(String.Format("Dimclrd={0}", entity.Dimclrd.ToString()))
                    .AppendLine(String.Format("Dimclrd_ColorMethod={0}", entity.Dimclrd.ColorMethod.ToString("D")))
                    .AppendLine(String.Format("Dimclrd_ColorIndex={0}", entity.Dimclrd.ColorIndex.ToString()));
            }

            if (entity.Dimclre != null)
            {
                strBuilder.AppendLine(String.Format("Dimclre={0}", entity.Dimclre.ToString()))
                    .AppendLine(String.Format("Dimclre_ColorMethod={0}", entity.Dimclre.ColorMethod.ToString("D")))
                    .AppendLine(String.Format("Dimclre_ColorIndex={0}", entity.Dimclre.ColorIndex.ToString()));
            }

            if (entity.Dimclrt != null)
            {
                strBuilder.AppendLine(String.Format("Dimclrt={0}", entity.Dimclrt.ToString()))
                    .AppendLine(String.Format("Dimclrt_ColorMethod={0}", entity.Dimclrt.ColorMethod.ToString("D")))
                    .AppendLine(String.Format("Dimclrt_ColorIndex={0}", entity.Dimclrt.ColorIndex.ToString()));
            }
            return strBuilder.ToString();
        }
    }
}
