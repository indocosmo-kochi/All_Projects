﻿using System.Collections.Generic;
using CWorksTXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksTXF.Txf.Reader
{
    public class TxfLeaderReader : TxfEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {            
            int numberOfVertices = 0;
            string value;
            if (ReadPropertyValue(entityRecord, "NumVertices", true, out value))
                numberOfVertices = ConvertTxfValue2Integer(value);

            CwcLeader entity = new CwcLeader(numberOfVertices);

            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            CwcPoint3D point3d;
            for (int i = 0; i < numberOfVertices; i++)
            {
                if (ParseTxfPoint3d(entityRecord, string.Format("Vertex({0})", i), true, out point3d))
                    entity.Vertices[i] = point3d;
            }
            entity.HasArrowHead = ConvertTxfValue2Bool(entityRecord, "HasArrowHead", true, false);
            entity.IsSplined = ConvertTxfValue2Bool(entityRecord, "IsSplined", true, false);   
                     
            if (ReadPropertyValue(entityRecord, "TextStyleId", false, out value))
                entity.TextStyleId = value;

            entity.Dimclrd = ParseTxfColor(entityRecord, "Dimclrd", "Dimclrd_ColorMethod", "Dimclrd_ColorIndex");

            if (ReadPropertyValue(entityRecord, "Dimasz", true, out value))
                entity.Dimasz = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimgap", true, out value))
                entity.Dimgap = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimscale", true, out value))
                entity.Dimscale = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtxt", true, out value))
                entity.Dimtxt = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtad", true, out value))
                entity.Dimtad = ConvertTxfValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimblks", false, out value))
                entity.Dimblks = value;

            if (ReadPropertyValue(entityRecord, "AnnoType", true, out value))
                entity.AnnoType = ConvertTxfAnnotationTypeToDwg(value);

            if (ReadPropertyValue(entityRecord, "Dimlwd", false, out value))
                entity.Dimlwd = ConvertTxfLineWeightToDwg(value);

            if (ReadPropertyValue(entityRecord, "DimensionStyle", true, out value))
                entity.DimensionStyle = value;

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            if (ReadPropertyValue(entityRecord, "Linetype", false, out value))
                entity.Linetype = value;

            if (ReadPropertyValue(entityRecord, "LinetypeScale", false, out value))
                entity.LinetypeScale = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                entity.LineWeight = ConvertTxfLineWeightToDwg(value);

            if (entity.AnnoType == AnnotationType.MText)
            {
                if (ReadPropertyValue(entityRecord, "Annotation", false, out value))
                    entity.Annotation = value;
            }

            return entity;
        }

    }
}
