﻿using System.Collections.Generic;
using CWorksTXF.Entities;

namespace CWorksTXF.Txf.Reader
{
    public class TxfViewportReader : TxfEntityReader
    {
        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcViewport cwcViewport = new CwcViewport();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                cwcViewport.Id = value;

            if (ReadPropertyValue(entityRecord, "Name", true, out value))
                cwcViewport.Name = value;

            if (ReadPropertyValue(entityRecord, "CircleSides", false, out value))
                cwcViewport.CircleSides = ConvertTxfValue2Short(value);

            cwcViewport.GridEnabled = ConvertTxfValue2Bool(entityRecord, "GridEnabled", false, true);

            CwcPoint2D point2d;
            if (ParseTxfPoint2d(entityRecord, "CenterPoint", true, out point2d))
                cwcViewport.CenterPoint = point2d;

            if (ReadPropertyValue(entityRecord, "Height", false, out value))
                cwcViewport.Height = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Width", false, out value))
                cwcViewport.Width = ConvertTxfValue2Double(value);

            return cwcViewport;

        }
    }
}
