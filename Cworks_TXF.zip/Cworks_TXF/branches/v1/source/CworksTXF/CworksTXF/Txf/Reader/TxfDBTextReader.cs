﻿using System.Collections.Generic;
using CWorksTXF.Entities;

namespace CWorksTXF.Txf.Reader
{
    public class TxfDBTextReader : TxfEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcDBText entity = new CwcDBText();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            if (ReadPropertyValue(entityRecord, "TextString", false, out value))
                entity.TextString = value;

            CwcPoint3D point3d;
            if (ParseTxfPoint3d(entityRecord, "Position", true, out point3d))
                entity.Position = point3d;

            CwcVector3D vector3d;
            if (ParseTxfVector3d(entityRecord, "Normal", true, out vector3d))
                entity.Normal = vector3d;

            if (ReadPropertyValue(entityRecord, "Height", false, out value))
                entity.Height = ConvertTxfValue2Double(value);

            entity.IsDefaultAlignment = ConvertTxfValue2Bool(entityRecord, "IsDefaultAlignment", true, true);
            entity.IsMirroredInX = ConvertTxfValue2Bool(entityRecord, "IsMirroredInX", true, true);
            entity.IsMirroredInY = ConvertTxfValue2Bool(entityRecord, "IsMirroredInY", true, true);

            if (!entity.IsDefaultAlignment)
            {
                if (ParseTxfPoint3d(entityRecord, "AlignmentPoint", true, out point3d))
                    entity.AlignmentPoint = point3d;
            }

            if (ReadPropertyValue(entityRecord, "HorizontalMode", false, out value))
                entity.HorizontalMode = ConvertTxfHorizontalModeToDwg(value);

            if (ReadPropertyValue(entityRecord, "VerticalMode", false, out value))
                entity.VerticalMode = ConvertTxfVerticalModeToDwg(value);

            if (ReadPropertyValue(entityRecord, "Justify", false, out value))
                entity.Justify = ConvertTxfTextJustifyToDwg(value);

            if (ReadPropertyValue(entityRecord, "Oblique", false, out value))
                entity.Oblique = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Rotation", false, out value))
                entity.Rotation = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Thickness", false, out value))
                entity.Thickness = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "WidthFactor", false, out value))
                entity.WidthFactor = ConvertTxfValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Font", false, out value))
                entity.Font = value;

            if (ReadPropertyValue(entityRecord, "TextStyleId", false, out value))
                entity.TextStyleId = value;

            entity.Color = ParseTxfColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            return entity;
        }

    }
}

