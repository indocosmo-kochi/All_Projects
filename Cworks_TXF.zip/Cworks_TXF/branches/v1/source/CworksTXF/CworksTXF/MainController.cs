﻿using CWorksTXF.Common;
using System;
using System.Collections.Generic;
using System.IO;

namespace CWorksTXF
{

    public enum ConversionType
    {
        DWG_to_TXF,
        DXF_to_TXF,
        TXF_to_DWG,
        TXF_to_DXF
    };

    public class MainController
    {

        ConversionType conversionType;

        public bool processFile(ProcessParam processParam)
        {
            bool result=false;
            if (isValidConvertionType(processParam))
            {
                Logger.RecordMessage(conversionType.ToString(), Logs.Log.MessageType.Informational);
                // Ensure the output folder exist
                if (IsOutputFolderExists(processParam.OutputFileName))
                {
                    switch (conversionType)
                    {
                        case ConversionType.DWG_to_TXF:
                        case ConversionType.DXF_to_TXF:
                            {
                                DwgToTxfController dwgToTxfController = new DwgToTxfController();
                                result = dwgToTxfController.convert_DWG_to_TXF(processParam);
                                if (result)
                                {
                                    Logger.RecordMessage("TXF file created succesfully.", Logs.Log.MessageType.Informational);
                                    Console.WriteLine("TXF file created succesfully.");
                                }
                                break;
                            }
                        case ConversionType.TXF_to_DWG:
                            {
                                TxfToDwgController txfToDwgController = new TxfToDwgController();
                                result = txfToDwgController.convert_TXF_to_DWG(processParam);
                                if (result)
                                {
                                    Logger.RecordMessage("DWG file created succesfully.", Logs.Log.MessageType.Informational);
                                    Console.WriteLine("DWG file created succesfully.");
                                }
                                break;
                            }

                        case ConversionType.TXF_to_DXF:
                            convert_TXF_to_DXF(processParam);
                            break;
                    }
                    result = true;
                }
            }

            return result;

        }

        private void convert_TXF_to_DXF(ProcessParam processParam)
        {
            Logger.RecordMessage("TXF=>DXF Not yet implemented", Logs.Log.MessageType.Error);
            Console.WriteLine("TXF=>DXF Not yet implemented");
        }

        private bool IsOutputFolderExists(string outputFileName)
        {
            bool result = false;
            try
            {
                string outputPath = Path.GetDirectoryName(outputFileName);
                if (outputPath.Length == 0)
                {
                    Logger.RecordMessage("Invalid Output file path", Logs.Log.MessageType.Error);
                    Console.WriteLine("Invalid Output file path");
                }
                else
                {
                    Directory.CreateDirectory(outputPath);
                    result = true;
                }
            }
            catch (System.Exception)
            {
                Logger.RecordMessage("Invalid Output file path", Logs.Log.MessageType.Error);
                Console.WriteLine("Invalid Output file path");
            }
            return result;
        }

        private bool isValidConvertionType(ProcessParam processParam)
        {
            bool isValid = false;
            if (!File.Exists(processParam.InputFileName))
            {
                Logger.RecordMessage("Input file not found", Logs.Log.MessageType.Error);
                Console.WriteLine("Input file not found");
            }
            else
            {

                List<string> fileExtension = new List<string> { ".DWG", ".DXF", ".TXF" };

                string inputFileType = Path.GetExtension(processParam.InputFileName).ToUpper();
                string outputFileType = Path.GetExtension(processParam.OutputFileName).ToUpper();

                if ((inputFileType.Length == 0) || (!fileExtension.Contains(inputFileType)))
                {
                    Logger.RecordMessage("Invalid Input filetype", Logs.Log.MessageType.Error);
                    Console.WriteLine("Invalid Input filetype");
                }
                else if ((outputFileType.Length == 0) || (!fileExtension.Contains(outputFileType)))
                {
                    Logger.RecordMessage("Invalid Output filetype", Logs.Log.MessageType.Error);
                    Console.WriteLine("Invalid Output filetype");
                }
                else if (inputFileType == outputFileType)
                {
                    Logger.RecordMessage("Input file type and output file types are same.", Logs.Log.MessageType.Error);
                    Console.WriteLine("Input file type and output file types are same.");
                }
                else
                {
                    conversionType = (inputFileType == ".DWG") ? ConversionType.DWG_to_TXF :
                                                (inputFileType == ".DXF") ? ConversionType.DXF_to_TXF :
                                                     (outputFileType == ".DWG") ? ConversionType.TXF_to_DWG : ConversionType.TXF_to_DXF;

                    if ((conversionType == ConversionType.DWG_to_TXF) || (conversionType == ConversionType.DXF_to_TXF))
                    {
                        if (outputFileType != ".TXF")
                        {
                            Logger.RecordMessage(inputFileType + " to " + outputFileType + " Conversion not supported", Logs.Log.MessageType.Error);
                            Console.WriteLine(inputFileType + " to " + outputFileType + " Conversion not supported");
                            Console.WriteLine("DWG => TXF  or DXF => TXF only supported. ");
                            return false;
                        }
                    }
                    else if ((conversionType == ConversionType.TXF_to_DWG) || (conversionType == ConversionType.TXF_to_DXF))
                    {
                        if (inputFileType != ".TXF")
                        {
                            Logger.RecordMessage(inputFileType + " to " + outputFileType + " Conversion not supported", Logs.Log.MessageType.Error);
                            Console.WriteLine(inputFileType + " to " + outputFileType + " Conversion not supported");
                            Console.WriteLine("TXF => DWG  or TXF => DXF only supported. ");
                            return false;
                        }
                    }

                    isValid = true;
                }
            }
            return isValid;
        }



    }
}
