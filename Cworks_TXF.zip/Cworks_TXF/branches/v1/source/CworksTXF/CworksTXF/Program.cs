﻿using CWorksTXF.Common;
using System;


namespace CWorksTXF
{
    static class Program
    {

        static void Main(string[] args)
        {
            Logger.LogType = Logger.LogTypes.File;

            if ( (args == null) || (args.Length < 2) )
            {
                Logger.RecordMessage("ERROR: Parameters missing.", Logs.Log.MessageType.Error);
                Console.WriteLine("ERROR: Parameters missing.");
                string appName = System.Diagnostics.Process.GetCurrentProcess().ProcessName;
                Console.WriteLine("USAGE : " + appName + " {input_file} {output_file} [PAPERSIZE {:paper_size}] [ROTATE {:angle}] [FONT {:font_name}]] [VERSION {:version_no}] [<PARAM_1> {:value_1}] [<PARAM_2> {:value_2}] [<PARAM_3> {:value_3}]");
            }
            else
            {
                ProcessParam processParams = new ProcessParam();
                processParams.InputFileName = args[0];
                processParams.OutputFileName = args[1];
                for (int i = 2; i < args.Length; i++)
                {
                    processParams.PaperSize = (args[i].ToUpper() == "PAPERSIZE") ? args[i + 1].ToUpper().Substring(1) : processParams.PaperSize;
                    processParams.RotateAngle = (args[i].ToUpper() == "ROTATE") ? args[i + 1].ToUpper().Substring(1) : processParams.RotateAngle;
                    processParams.FontName = (args[i].ToUpper() == "FONT") ? args[i + 1].ToUpper().Substring(1) : processParams.FontName;
                    processParams.AutoCADVersion = (args[i].ToUpper() == "VERSION") ? args[i + 1].ToUpper().Substring(1) : processParams.AutoCADVersion;
                }

                Logger.RecordMessage(processParams.ToString(), Logs.Log.MessageType.Informational);

                MainController mainController = new MainController();
                mainController.processFile(processParams);
            }

        }
    }
}
