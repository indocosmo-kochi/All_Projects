///////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2002-2017, Open Design Alliance (the "Alliance").
// All rights reserved.
//
// This software and its documentation and related materials are owned by
// the Alliance. The software may only be incorporated into application
// programs owned by members of the Alliance, subject to a signed
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable
// trade secrets of the Alliance and its suppliers. The software is also
// protected by copyright law and international treaty provisions. Application
// programs incorporating this software must include the following statement
// with their copyright notices:
//
//   This application incorporates Teigha(R) software pursuant to a license
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2017 by Open Design Alliance.
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////
using System;
#pragma warning disable 618

public sealed class ActivationData
{
public const string userInfo = "Q1dPUktTIENvIEx0ZA==";
public const string userSignature = "niXiriGiAcvBUKhfh9uq3aZjSEZD9uSPs+X2voZLCSec/qDGeeTLd6MU+scKuIT7+SFrWLzX1bQzyJPX8kwidJadUxljqNxusA4+/59DF00Cg0d1CtmKIbCi0TFjqdXLwBFBYHS3/QJOPtrkMSWnT5IMXD3TvJuuPQObwepXyNVZn5saqw1OODqgBS6izf1vbEOoKvyiNL3tXHlvJ5A5hSgxM662iBrhlzJ/YyU5pnkfkvvhl0JoIx7a0xDsxVBxduEaWS3Y9/sVUtS+/Gnz+0UfDHhhh1Hj8bs6nLQBBtG2tO2L0wOu/Obec8SJe8vt+grZwaKjiv1zfL2fZF0n9q+8bpNuGShibfikuLW8It2nelExvI7Z8u+lUjqZPtw015qS3iTkjdqWTqokioz70ZdN65hE1C/7J5ATIVklh1Xek+mcQBiwLPavCs6Np62QOurMwzQSv32EQ0XYbQRmJhCtZ8iiQ5sh5BHce6HNcZzyNy2KF76lX4jxnFvut/OCUefRGq6sdddGV3NaEvUHs1Ze/HQxC4ax9ETTcPnP77kbxsDQ/VeXEk0PZ9BR18pedW4B33anxh/u68LxaKA7zwpngkV5onSsWo1/9E3UhniyrVBFAoyw7TP8FJNh1gEMZawnYLntfbXrhY8plF6oXIFlXs/Eng6E9zEm8jVoUkM=";
};
