﻿using System;
using System.Diagnostics;
using System.Text;

namespace CWorksTXF.Logs
{
    public class EventLog : Log
    {


        // Internal EventLogName destination value   
        private string _EventLogName = "";
        public string EventLogName
        {
            get
            {
                return this._EventLogName;
            }
            set
            {
                this._EventLogName = value;
            }
        }
        // Internal EventLogSource value   
        private string _EventLogSource;
        public string EventLogSource
        {
            get
            {
                return this._EventLogSource;
            }
            set
            {
                this._EventLogSource = value;
            }
        }
        // Internal MachineName value   
        private string _MachineName = "";
        public string MachineName
        {
            get
            {
                return this._MachineName;
            }
            set
            {
                this._MachineName = value;
            }
        }
        public EventLog()
        {
            this.MachineName = ".";
            this.EventLogName = "CWorksEventLog";
            this.EventLogSource = "CFXConversion";
        }
        public override void RecordMessage(Exception Message, Log.MessageType Severity)
        {
            this.RecordMessage(Message.Message, Severity);
        }

        public override void RecordMessage(string Message, Log.MessageType Severity)
        {
            StringBuilder message = new StringBuilder();
            System.Diagnostics.EventLog eventLog = new System.Diagnostics.EventLog();
            // Create the source if it does not already exist     
            if ( !System.Diagnostics.EventLog.SourceExists(this._EventLogSource) )
            {
                System.Diagnostics.EventLog.CreateEventSource( this._EventLogSource, this._EventLogName);
            }
            eventLog.Source = this._EventLogSource;
            eventLog.MachineName = this._MachineName;
            // Determine what the EventLogEventType should be      
            // based on the LogSeverity passed in     
            EventLogEntryType type = EventLogEntryType.Information;
            switch (Severity.ToString().ToUpper())
            {
                case "INFORMATIONAL":
                    type = EventLogEntryType.Information;
                    break;
                case "FAILURE":
                    type = EventLogEntryType.FailureAudit;
                    break;
                case "WARNING":
                    type = EventLogEntryType.Warning;
                    break;
                case "ERROR":
                    type = EventLogEntryType.Error;
                    break;
            }
            message.Append(Severity.ToString()).Append(",").Append(System.DateTime.Now).Append(",").Append(Message);
            eventLog.WriteEntry(message.ToString(), type);
        }
    }
}

