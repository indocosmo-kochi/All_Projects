﻿using CWorksTXF.Common;
using CWorksTXF.Txf.Reader;
using CWorksTXF.Dwg.Writer;
using CWorksTXF.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using Teigha.DatabaseServices;
using Teigha.Runtime;
//using System.Linq;  // used in DictToFile - For Debug


namespace CWorksTXF
{
    class TxfToDwgController
    {

        readonly EntityConcreteFactory factory = new EntityConcreteFactory();
        readonly Dictionary<string, ObjectId> objectIdMapperList = new Dictionary<string, ObjectId>();
        public bool convert_TXF_to_DWG(ProcessParam processParam)
        {
            bool result = false;    
            Services.odActivate(ActivationData.userInfo, ActivationData.userSignature);
            using (Services svcs = new Services())
            {
                using (Database db = new Database(true, true))
                {

                    try
                    {
                        using (StreamReader streamRdr = File.OpenText(processParam.InputFileName))
                        {
                            string txtline = String.Empty;
                            string entityTypeName = String.Empty;
                            Dictionary<string, string> txfEntityRecord = new Dictionary<string, string>();

                            while ((txtline = streamRdr.ReadLine()) != null)
                            {
                                // check if this is NOT an empty line
                                if (txtline.Trim().Length > 0)
                                {
                                    // check if this is a valid cfx entity title
                                    if ((txtline.Trim()[0] == '[') && (txtline.Trim()[txtline.Trim().Length - 1] == ']'))
                                    {
                                        entityTypeName = Resource.GetTXFEntityTypeName(txtline.Trim());
                                        if (entityTypeName.Length > 0)
                                        {
                                            //add the entity typename into list
                                            txfEntityRecord.Clear();
                                        }
                                    }
                                    // read each line and add into list until a blank row (end of title rec) found
                                    else
                                    {
                                        string[] keyValue = new string[2];
                                        int posOfEqual = txtline.IndexOf("=");
                                        keyValue[0] = txtline.Substring(0, posOfEqual);
                                        int posOfValue = posOfEqual + 1;
                                        keyValue[1] = txtline.Substring(posOfValue, txtline.Length- posOfValue);

                                        txfEntityRecord.Add(keyValue[0], keyValue[1]);
                                    }
                                }
                                else // if the "txtline" is BLANK Line after entity ppty values
                                {
                                   
                                    WriteDwgEntity(db, txfEntityRecord, entityTypeName);
                                    entityTypeName = "";
                                }

                            }
                            // to process the last entry if there is no blank line after 
                            WriteDwgEntity(db, txfEntityRecord, entityTypeName);
                        }
                        MoveHatchtoBack(db);
                        db.SaveAs(processParam.OutputFileName, DwgVersion.AC1024);
                        result = true;
                    }
                    catch (System.Exception ex)
                    {
                        Logger.RecordMessage(ex.Message, Logs.Log.MessageType.Error);
                    }

                }
            }
            return result;
        }

        private bool IsValidDBEntity(Database db,
                                    Dictionary<string, string> txfEntityRecord, string entityTypeName)
        {
            if (entityTypeName.Length > 0)
            {
                if (entityTypeName.ToUpper() != "DBSETTINGS")
                {
                    return true;
                }
                TxfDBSettingsReader txfDBSettingsReader = new TxfDBSettingsReader();
                DwgDBSettingsWriter dwgDBSettingsWriter = new DwgDBSettingsWriter();
                CwcDBSettings cwcDBSettings = txfDBSettingsReader.ReadAndParseDBSettings(txfEntityRecord);
                dwgDBSettingsWriter.SetDBSettings(db, cwcDBSettings);
                return false;
            }
            return false;
        }

        private void WriteDwgEntity(Database db,  
                                    Dictionary<string, string> txfEntityRecord, string entityTypeName)
        {
            if (IsValidDBEntity(db, txfEntityRecord, entityTypeName))
            {

                // send this list into the TXFReader of the type of entity we read
                // create the entity type, call the DWGWriter to create the entity in DWG file

                IDwgEntityWriter dwgEntity = factory.getDwgEntityWriter(entityTypeName);

                ITxfEntityReader txfEntity = factory.getTxfEntityReader(entityTypeName);

                if (txfEntity != null)
                {

                    ((TxfEntityReader)txfEntity).EntityTypeName = entityTypeName;

                    CwcDbObject cwcDbObject = txfEntity.ReadAndParse(txfEntityRecord);

                    Logger.RecordMessage(string.Format("Processing Entity {0} (Id:{1})", entityTypeName, cwcDbObject.Id.ToString()), Logs.Log.MessageType.Informational);

                    ((DwgEntityWriter)dwgEntity).ObjectIdMapperList = objectIdMapperList;

                    ObjectId dwgObjectId = dwgEntity.CreateDwgEntity(db, cwcDbObject);
                    
                    if (!objectIdMapperList.ContainsKey(cwcDbObject.Id))
                        objectIdMapperList.Add(cwcDbObject.Id, dwgObjectId);

                }
            }
        }



        private void MoveHatchtoBack(Database database)
        {

            TransactionManager tm = database.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable bt = (BlockTable)tm.GetObject(database.BlockTableId, OpenMode.ForRead))
                {
                    using (BlockTableRecord btr = (BlockTableRecord)tm.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForRead))
                    {

                        using (DrawOrderTable drawOrder = (DrawOrderTable)tm.GetObject(btr.DrawOrderTableId, OpenMode.ForRead))
                        {

                            ObjectIdCollection hatchids = new ObjectIdCollection();
                            BlockTableRecordEnumerator iterator = btr.GetEnumerator();

                            ObjectId dbObject_Id;
                            DBObject dbObject;
                            string typeName;
                            while (iterator.MoveNext())
                            {
                                dbObject_Id = (ObjectId)iterator.Current;
                                using (dbObject = tm.GetObject(dbObject_Id, OpenMode.ForRead))
                                {

                                    typeName = dbObject.GetType().Name;

                                    if (typeName.ToUpper() == "HATCH")
                                    {
                                        hatchids.Add(dbObject_Id);
                                    }
                                    else if (typeName == "BlockReference")
                                    {

                                        using (BlockTableRecord bDef = (BlockTableRecord)(((BlockReference)dbObject).BlockTableRecord.GetObject(OpenMode.ForRead)))
                                        {

                                            using (DrawOrderTable blkdrawOrder = (DrawOrderTable)tm.GetObject(bDef.DrawOrderTableId, OpenMode.ForRead))
                                            {

                                                ObjectIdCollection blkhatchids = new ObjectIdCollection();

                                                BlockTableRecordEnumerator iterator_block = bDef.GetEnumerator();

                                                DBObject dbObject_block;

                                                while (iterator_block.MoveNext())
                                                {
                                                    ObjectId id = (ObjectId)iterator_block.Current;
                                                    using (dbObject_block = tm.GetObject(id, OpenMode.ForRead))
                                                    {
                                                        typeName = dbObject_block.GetType().Name;
                                                        if (typeName.ToUpper() == "HATCH")
                                                        {
                                                            blkhatchids.Add(id);
                                                        }
                                                    }
                                                }
                                                if (blkhatchids.Count > 0)
                                                {
                                                    blkdrawOrder.UpgradeOpen();
                                                    blkdrawOrder.MoveToBottom(blkhatchids);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if (hatchids.Count > 0)
                            {
                                drawOrder.UpgradeOpen();
                                drawOrder.MoveToBottom(hatchids);
                            }
                        }
                    }
                }

                tr.Commit();
            }
        }


    }

    //For Debug - objectIdMapperList
    //public static class DictToFile
    //{
    //    public static string ToString(this System.Collections.Generic.Dictionary<string, ObjectId> source, string keyValueSeparator = "=", string sequenceSeparator = "|")
    //    {
    //        return source == null ? "" : string.Join(sequenceSeparator, source.Keys.Zip(source.Values, (k, v) => k + keyValueSeparator + v));
    //    }

    //}


}


