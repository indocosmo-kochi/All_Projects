/**
 * @author Jeswin Chacko P A
 *
 * @version 0.0.1 Feb 29, 2020
 *
 *
 */
package com.indocosmo.hrmis.bean;

public class EducationBean {

	private int education_id,education_id_array[];
	private String qualification_array[],board_or_university_array[],education_year_array[];
	private double marks_array[];
	private String qualification,board_or_university,education_year;
	private double marks;
	
	public String[] getQualification_array() {
		return qualification_array;
	}
	public void setQualification_array(String[] qualification_array) {
		this.qualification_array = qualification_array;
	}
	public String[] getBoard_or_university_array() {
		return board_or_university_array;
	}
	public void setBoard_or_university_array(String[] board_or_university_array) {
		this.board_or_university_array = board_or_university_array;
	}
	public String[] getEducation_year_array() {
		return education_year_array;
	}
	public void setEducation_year_array(String[] education_year_array) {
		this.education_year_array = education_year_array;
	}
	public double[] getMarks_array() {
		return marks_array;
	}
	public void setMarks_array(double[] marks_array) {
		this.marks_array = marks_array;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getBoard_or_university() {
		return board_or_university;
	}
	public void setBoard_or_university(String board_or_university) {
		this.board_or_university = board_or_university;
	}
	public String getEducation_year() {
		return education_year;
	}
	public void setEducation_year(String education_year) {
		this.education_year = education_year;
	}
	public double getMarks() {
		return marks;
	}
	public void setMarks(double marks) {
		this.marks = marks;
	}
	public int getEducation_id() {
		return education_id;
	}
	public void setEducation_id(int education_id) {
		this.education_id = education_id;
	}
	public int[] getEducation_id_array() {
		return education_id_array;
	}
	public void setEducation_id_array(int education_id_array[]) {
		this.education_id_array = education_id_array;
	}
}
