package com.indocosmo.hrmis.bean;

import java.sql.Date;

/**
 * @author Anandhapadmanabhan
 *
 * @version 0.0.1 Feb 29, 2020
 */

public class AnnouncementBean {
	
	int announcement_tbl_id;
	String announcement_tbl_name,announcement_tbl_status,announcement_tbl_description;
	public String getAnnouncement_tbl_description() {
		return announcement_tbl_description;
	}
	public void setAnnouncement_tbl_description(String announcement_tbl_description) {
		this.announcement_tbl_description = announcement_tbl_description;
	}
	Date announcement_tbl_start_date,announcement_tbl_end_date;
	public int getAnnouncement_tbl_id() {
		return announcement_tbl_id;
	}
	public void setAnnouncement_tbl_id(int announcement_tbl_id) {
		this.announcement_tbl_id = announcement_tbl_id;
	}
	public String getAnnouncement_tbl_name() {
		return announcement_tbl_name;
	}
	public void setAnnouncement_tbl_name(String announcement_tbl_name) {
		this.announcement_tbl_name = announcement_tbl_name;
	}
	public String getAnnouncement_tbl_status() {
		return announcement_tbl_status;
	}
	public void setAnnouncement_tbl_status(String announcement_tbl_status) {
		this.announcement_tbl_status = announcement_tbl_status;
	}
	public Date getAnnouncement_tbl_start_date() {
		return announcement_tbl_start_date;
	}
	public void setAnnouncement_tbl_start_date(Date announcement_tbl_start_date) {
		this.announcement_tbl_start_date = announcement_tbl_start_date;
	}
	public Date getAnnouncement_tbl_end_date() {
		return announcement_tbl_end_date;
	}
	public void setAnnouncement_tbl_end_date(Date announcement_tbl_end_date) {
		this.announcement_tbl_end_date = announcement_tbl_end_date;
	}
	

}
