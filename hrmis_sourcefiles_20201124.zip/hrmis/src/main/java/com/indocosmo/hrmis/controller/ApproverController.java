/**
 * @author Jeswin Chacko P A
 *
 * @version 0.0.1 May 15, 2020
 *
 *
 */
package com.indocosmo.hrmis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.indocosmo.hrmis.bean.ApproverBean;
import com.indocosmo.hrmis.bean.EmployeeBean;
import com.indocosmo.hrmis.dao.ApproverDAO;
import com.indocosmo.hrmis.dao.EmployeeDAO;

@Controller
public class ApproverController {
	
	@Autowired
	EmployeeDAO employee_dao_object;
	
	@Autowired
	ApproverDAO approver_dao_object;
	
	@RequestMapping(value = "/addApprover/{employee_id}")
	public String addLocation(@PathVariable int employee_id, Model model_object) {
		model_object.addAttribute("employee_id", employee_id);
		List<EmployeeBean> approvers_for_list = employee_dao_object.getApproverForList(employee_id);
		model_object.addAttribute("approvers_for_list", approvers_for_list);
		int current_approver_level = approver_dao_object.getNextApproverLevel(employee_id);
		int next_approver_level = current_approver_level + 1;
		model_object.addAttribute("next_approver_level",next_approver_level);
		return "admin/employee/add_approver";
	}

	@RequestMapping(value = "/addApproverSave", method = RequestMethod.POST)
	public String addApproverSave(@ModelAttribute("approver_bean_object") ApproverBean approver_bean_object) {
		approver_dao_object.insertApprover(approver_bean_object);
		return "redirect:/editEmployeeView/"+approver_bean_object.getEmployee_id();
	}

	@RequestMapping(value = "/deleteApprover/{approver_id}")
	public String deleteApprover(@PathVariable int approver_id, Model model_object) {
		ApproverBean approver_bean_object = approver_dao_object.getApproverById(approver_id);
		int approver_delete_status = approver_dao_object.deleteApprover(approver_id);
		model_object.addAttribute("approver_delete_status", approver_delete_status);
		return "redirect:/editEmployeeView/"+approver_bean_object.getEmployee_id();
	}
	
	@RequestMapping(value = "/editApproverView/{approver_id}")
	public String editApproverView(@PathVariable int approver_id, Model model_object) {
		ApproverBean approver_bean_object = approver_dao_object.getApproverById(approver_id);
		model_object.addAttribute("approver", approver_bean_object);
		int employee_id = approver_bean_object.getEmployee_id();
		List<EmployeeBean> approvers_for_list = employee_dao_object.getApproverForList(employee_id);
		model_object.addAttribute("approvers_for_list", approvers_for_list);
		int current_approver_level = approver_dao_object.getNextApproverLevel(employee_id);
		int next_approver_level = current_approver_level + 1;
		model_object.addAttribute("next_approver_level",next_approver_level);
		return "admin/employee/edit_approver";
	}
	
	@RequestMapping(value = "/editApproverSave", method = RequestMethod.POST)
	public String editApproverSave(@ModelAttribute("approver_bean_object") ApproverBean approver_bean_object, Model model_object) {
		int check = approver_dao_object.checkApproverLevel(approver_bean_object);
		if(check==0) {
			approver_dao_object.editApprover(approver_bean_object);
			return "redirect:/editEmployeeView/"+approver_bean_object.getEmployee_id();
		}
		else {
			model_object.addAttribute("check_level",check);
			return "redirect:/editApproverView/"+approver_bean_object.getApprover_tbl_id();
		}
	}
}
