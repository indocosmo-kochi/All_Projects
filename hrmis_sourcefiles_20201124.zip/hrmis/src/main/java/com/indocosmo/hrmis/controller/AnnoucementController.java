/**
 * 
 */
package com.indocosmo.hrmis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.indocosmo.hrmis.bean.AnnouncementBean;
import com.indocosmo.hrmis.dao.AnnouncementDAO;

/**
 * @author Anandhapadmanabhan
 * 
 * @version 0.0.1 
 *
 */
@Controller
public class AnnoucementController {
	
	
	@RequestMapping("/AddAnnouncement")    
	public String showform1(Model m){    
	    m.addAttribute("command", new AnnouncementBean());  
	    return "admin/employee/AddAnnouncement";   
	}
	
	
	@Autowired
	AnnouncementDAO announcementdaoobject;
	
	@RequestMapping(value="/save1",method = RequestMethod.POST)    
	public String save1(@ModelAttribute("announcementobject") AnnouncementBean announcementobject){ 
		announcementdaoobject.save1(announcementobject);   
	    return "redirect:/ViewAnnouncement";   
	}
	@RequestMapping("/ViewAnnouncement")    
	public String viewannouncement(Model m){    
	    List<AnnouncementBean> list=announcementdaoobject.getAnnouncement();
	    m.addAttribute("list",list);  
	    return "admin/employee/ViewAnnouncement";    
	}
	@RequestMapping(value="/EditAnnouncement/{announcement_tbl_id}")    
	public String edit1(@PathVariable int announcement_tbl_id, Model m){  
		AnnouncementBean announcementobject=announcementdaoobject.getAnnouncementById(announcement_tbl_id); 
	    m.addAttribute("command",announcementobject);  
	    return "admin/employee/EditAnnouncement";    
	}    

	@RequestMapping(value="/editsave1",method = RequestMethod.POST)    
	public String editsave1(@ModelAttribute("announcementobject") AnnouncementBean announcementobject){  
		announcementdaoobject.update1(announcementobject);
	    return "redirect:/ViewAnnouncement";    
	}    

	@RequestMapping(value="/deleteannouncement/{announcement_tbl_id}",method = RequestMethod.GET)    
	public String delete1(@PathVariable int announcement_tbl_id){    
		announcementdaoobject.delete1(announcement_tbl_id);    
	    return "redirect:/ViewAnnouncement";    
	}
	@RequestMapping(value="/SendMail/{announcement_tbl_id}")    
	public String sendmail(@PathVariable int announcement_tbl_id, Model m){  
		AnnouncementBean announcementobject= announcementdaoobject.getAnnouncementById(announcement_tbl_id);
	    m.addAttribute("command",announcementobject);  
	    return "admin/employee/SendMail";    
	}
}
