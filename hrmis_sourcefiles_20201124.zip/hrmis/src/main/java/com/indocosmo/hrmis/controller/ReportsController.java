/**
 * 
 */
package com.indocosmo.hrmis.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.indocosmo.hrmis.bean.EmployeeLeaveBean;
import com.indocosmo.hrmis.dao.EmployeeLeaveDAO;

/**
 * @author Ayana P Dharman
 * 
 * @version 0.0.1 27 April 2020
 * 
 *
 */
@Controller
public class ReportsController {

	@Autowired
	EmployeeLeaveDAO emp_leavedao_object;
	
	@RequestMapping("reports")
	public String reportsview(Model m,HttpSession session) {
		int employee_id = (Integer) session.getAttribute("employee_id");
		List<EmployeeLeaveBean> leave_employees = emp_leavedao_object.getLeaveEmployees(1,employee_id);
		m.addAttribute("leave_employees", leave_employees);
		return "admin/reports/leave_report";
	}

	@RequestMapping(value="loadLeaveReport",method = RequestMethod.POST)
	public String loadLeaveReport(@ModelAttribute("EmployeeLeaveBeanobject") EmployeeLeaveBean EmployeeLeaveBeanobject,
			Model m,HttpSession session) {
		int employee_id = (Integer) session.getAttribute("employee_id");
		List<EmployeeLeaveBean> leave_employees = emp_leavedao_object.getLeaveEmployees(1,employee_id);
		m.addAttribute("leave_employees", leave_employees);
		List<EmployeeLeaveBean> leave_report = emp_leavedao_object.getLoadLeaveReport(EmployeeLeaveBeanobject);
		System.out.println(leave_report.size());
		m.addAttribute("leave_report", leave_report);
		return "admin/reports/leave_report";
	}
	
	@RequestMapping("workreport")
	public String reportswork() {
		return "admin/reports/work_reports";
	}
}
