/**
 * @author Jeswin Chacko P A
 *
 * @version 0.0.1 May 15, 2020
 *
 *
 */
package com.indocosmo.hrmis.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;

import com.indocosmo.hrmis.bean.ApproverBean;

public class ApproverDAO {

	JdbcTemplate jdbc_template;

	public void setTemplate(JdbcTemplate jdbc_template) {
		this.jdbc_template = jdbc_template;
	}

	public int insertApprover(final ApproverBean approver_bean_object) {
		String sql = "INSERT INTO approver_tbl (approver_level,approver_emp_id,is_mail,employee_id) VALUES (?,?,?,?)";
		return jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setInt(1, approver_bean_object.getApprover_level());
				prepared_statement_object.setInt(2, approver_bean_object.getApprover_emp_id());
				prepared_statement_object.setInt(3, approver_bean_object.getIs_mail());
				prepared_statement_object.setInt(4, approver_bean_object.getEmployee_id());
				return prepared_statement_object.executeUpdate();
			}
		});
	}

	public List<ApproverBean> getApprovers(int employee_id) {
		return jdbc_template.query("call hrmis.getApprovers(" + employee_id + ")", new RowMapper<ApproverBean>() {
			public ApproverBean mapRow(ResultSet rs, int row) throws SQLException {
				ApproverBean approver_bean_object = new ApproverBean();
				approver_bean_object.setApprover_tbl_id(rs.getInt(1));
				approver_bean_object.setApprover_level(rs.getInt(2));
				approver_bean_object.setApprover_emp_id(rs.getInt(3));
				approver_bean_object.setEmployee_name(rs.getString(4));
				approver_bean_object.setIs_mail(rs.getInt(5));
				approver_bean_object.setCreated_by(rs.getString(6));
				approver_bean_object.setUpdated_by(rs.getString(7));
				approver_bean_object.setCreated_date(rs.getDate(8));
				approver_bean_object.setUpdated_date(rs.getDate(9));
				approver_bean_object.setEmployee_id(rs.getInt(10));
				return approver_bean_object;
			}
		});
	}

	public ApproverBean getApproverById(int approver_id) {
		String sql = "call hrmis.getApproverById(?)";
		return jdbc_template.queryForObject(sql, new Object[] { approver_id },
				new BeanPropertyRowMapper<ApproverBean>(ApproverBean.class));
	}

	public int editApprover(final ApproverBean approver_bean_object) {
		String sql = "UPDATE approver_tbl SET approver_level=?,approver_emp_id=?,is_mail=? WHERE approver_tbl_id=?";
		return jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setInt(1, approver_bean_object.getApprover_level());
				prepared_statement_object.setInt(2, approver_bean_object.getApprover_emp_id());
				prepared_statement_object.setInt(3, approver_bean_object.getIs_mail());
				prepared_statement_object.setInt(4, approver_bean_object.getApprover_tbl_id());
				return prepared_statement_object.executeUpdate();
			}
		});
	}

	public int deleteApprover(int approver_tbl_id) {
		String sql = "UPDATE approver_tbl SET approver_isdeleted=1 WHERE approver_tbl_id=" + approver_tbl_id;
		return jdbc_template.update(sql);
	}

	public int getNextApproverLevel(int employee_id) {
		String sql = "call hrmis.getApproverLevel(?);";
		int level = jdbc_template.queryForObject(sql, new Object[] { employee_id }, Integer.class);
		return level;
	}

	public int checkApproverLevel(ApproverBean approver_bean_object) {
		int check=0;
		int employee_id = approver_bean_object.getEmployee_id();
		int level = approver_bean_object.getApprover_level();
		String sql2 = "SELECT COUNT(approver_tbl_id) FROM approver_tbl "
				+ "WHERE employee_id=? AND approver_level=? AND approver_isdeleted=0";
		check = jdbc_template.queryForObject(sql2, new Object[] { employee_id,level }, Integer.class);
		return check;
	}
}
