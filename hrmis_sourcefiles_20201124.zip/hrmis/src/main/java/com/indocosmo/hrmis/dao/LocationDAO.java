/**
 * @author Ayana P Dharman
 *
 * @version 0.0.1 Mar 11, 2020
 *
 *
 */
package com.indocosmo.hrmis.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;

import com.indocosmo.hrmis.bean.LocationBean;
import com.indocosmo.hrmis.common.CommonQueries;

public class LocationDAO {

	CommonQueries sql_object;
	JdbcTemplate jdbc_template;

	public void setTemplate(JdbcTemplate jdbc_template) {
		this.jdbc_template = jdbc_template;
	}

	public List<LocationBean> getLocations() {
		return jdbc_template.query("SELECT * FROM location WHERE is_deleted=0", new RowMapper<LocationBean>() {
			public LocationBean mapRow(ResultSet rs, int row) throws SQLException {
				LocationBean location_bean_object = new LocationBean();
				location_bean_object.setLocation_id(rs.getInt(1));
				location_bean_object.setLocation_name(rs.getString(2));
				return location_bean_object;
			}
		});
	}

	public int insertLocation(final LocationBean location_bean_object) {
		String sql = "INSERT INTO location (location_id,location_name) VALUES (?,?)";
		return jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setInt(1, location_bean_object.getLocation_id());
				prepared_statement_object.setString(2, location_bean_object.getLocation_name());
				return prepared_statement_object.executeUpdate();
			}
		});
	}

	public LocationBean getLocationById(String location_id) { // To get an item by id(used in editing form)
		String sql = "SELECT * FROM location WHERE location_id=?";
		return jdbc_template.queryForObject(sql, new Object[] { location_id },
				new BeanPropertyRowMapper<LocationBean>(LocationBean.class));
	}

	public int editLocation(final LocationBean location_bean_object) {
		String sql = "UPDATE location SET location_name=? WHERE location_id=?";
		return jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setString(1, location_bean_object.getLocation_name());
				prepared_statement_object.setInt(2, location_bean_object.getLocation_id());
				return prepared_statement_object.executeUpdate();
			}
		});
	}

	public int deleteLocation(String location_id) {
		String sql = "UPDATE location SET is_deleted=1 WHERE location_id='"+location_id+"'";
		return jdbc_template.update(sql);
	}
}
