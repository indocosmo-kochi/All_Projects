package com.indocosmo.hrmis.controller;

import java.sql.Date;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.indocosmo.hrmis.bean.EmployeeBean;
import com.indocosmo.hrmis.bean.EmployeeLeaveBean;
import com.indocosmo.hrmis.bean.LeaveAllocationBean;
import com.indocosmo.hrmis.dao.EmailDAO;
import com.indocosmo.hrmis.dao.EmployeeDAO;
import com.indocosmo.hrmis.dao.EmployeeLeaveDAO;
import com.indocosmo.hrmis.dao.HolidayDAO;

@Controller
public class LeaveRequestController {
	
	@Autowired
	HolidayDAO holiday_dao_object;
	@Autowired
	EmployeeLeaveDAO emp_leavedao_object;
	@Autowired
	EmployeeDAO emp_dao_object;
	@Autowired
	private JavaMailSender mailSenderObj;
	
	@RequestMapping("/EmpLeaveApplication")    
	public String showform2(Model m,HttpSession session){
		int employee_id = (Integer) session.getAttribute("employee_id");
		List<LeaveAllocationBean> leavetype_list = emp_leavedao_object.getleavetype(employee_id);
		m.addAttribute("leave_type", leavetype_list);
	    return "employee/leaveRequest/EmpLeaveApplication";  	
	}
	
	@RequestMapping(value="/getAvailableLeaves")
	public String getAvailableLeaves(@RequestParam("type") int leave_type_id,@RequestParam("from_date") String from_date_str, 
			Model m,HttpSession session) {
		int employee_id = (Integer) session.getAttribute("employee_id");
		Date from_date = Date.valueOf(from_date_str);
		Calendar cal = Calendar.getInstance();
		cal.setTime(from_date);
		int year_int = cal.get(Calendar.YEAR);
		String year = String.valueOf(year_int);
		int available_leaves = emp_leavedao_object.getAvailableLeaves(employee_id,leave_type_id,year);
		m.addAttribute("available_leaves",available_leaves);
	    return "employee/leaveRequest/available_leaves"; 
	}
	
	@RequestMapping(value="/leaveApplicationSave",method = RequestMethod.POST)    
	public String save2(@ModelAttribute("EmployeeLeaveBean_object") EmployeeLeaveBean EmployeeLeaveBean_object,HttpSession session,
						Model m){ 
		int employee_id = (Integer) session.getAttribute("employee_id");
		Date from_date = EmployeeLeaveBean_object.getLeave_app_tbl_from_date();
		Date to_date = EmployeeLeaveBean_object.getLeave_app_tbl_to_date();
		String reason = EmployeeLeaveBean_object.getLeave_app_tbl_reason();
		if(EmployeeLeaveBean_object.getLeave_app_tbl_leave_type() != 0) {
			int leave_type = EmployeeLeaveBean_object.getLeave_app_tbl_leave_type();
			Calendar cal = Calendar.getInstance();
			cal.setTime(from_date);
			int year_int = cal.get(Calendar.YEAR);
			String year = String.valueOf(year_int);
			int available_leaves = emp_leavedao_object.getAvailableLeaves(employee_id,leave_type,year);
			if(available_leaves == 0) {
				m.addAttribute("error",3);
			}
			else {
				int leaveapplication = emp_leavedao_object.leaveApplicationSave(EmployeeLeaveBean_object,employee_id);
				if(leaveapplication == 0) {
					m.addAttribute("error",0);
				}
				else if(leaveapplication == 2) {
					m.addAttribute("error",2);
				}
				else {
					int leavehistory = emp_leavedao_object.leaveHistorySave(EmployeeLeaveBean_object,employee_id,1);
					if(leavehistory == 0) {
						m.addAttribute("error",0);
					}
					else {
						m.addAttribute("error",1);
						int approver_id = emp_leavedao_object.getApproverinAnyLevel(employee_id, 1);
						EmployeeBean approver = emp_dao_object.getEmployeeById(approver_id);
						String to = approver.getEmail_id_official();
						EmployeeBean employee = emp_dao_object.getEmployeeById(employee_id);
						String employee_name = employee.getEmployee_name();
						String employee_code = employee.getEmployee_code();
						String subject = "Leave Application By "+employee_name+"("+employee_code+") From "+from_date+" to "+to_date;
						String message = "Dear Sir/Madam \n"
										+ "The employee "+employee_name+"("+employee_code+") has forwarded a leave application \n"
										+ "Following are the details regarding leave \n"
										+ "From Date : "+from_date+"\n"
										+ "To Date : "+to_date+"\n"
										+ "Reason : "+reason+"\n"
										+ "Thanks & Regards \n"
										+ "Indocosmo Systems";
						System.out.println(message);
						EmailDAO.sendEmail(to,subject,message, null, mailSenderObj);
					}
				}
			}
		}
		else {
			int leaveapplication = emp_leavedao_object.leaveApplicationSave(EmployeeLeaveBean_object,employee_id);
			if(leaveapplication == 0) {
				m.addAttribute("error",0);
			}
			else if(leaveapplication == 2) {
				m.addAttribute("error",2);
			}
			else {
				int leavehistory = emp_leavedao_object.leaveHistorySave(EmployeeLeaveBean_object,employee_id,1);
				if(leavehistory == 0) {
					m.addAttribute("error",0);
				}
				else {
					m.addAttribute("error",1);
					int approver_id = emp_leavedao_object.getApproverinAnyLevel(employee_id, 1);
					EmployeeBean approver = emp_dao_object.getEmployeeById(approver_id);
					String to = approver.getEmail_id_official();
					EmployeeBean employee = emp_dao_object.getEmployeeById(employee_id);
					String employee_name = employee.getEmployee_name();
					String employee_code = employee.getEmployee_code();
					String subject = "Leave Application By "+employee_name+"("+employee_code+") From "+from_date+" to "+to_date;
					String message = "Dear Sir/Madam \n"
									+ "The employee "+employee_name+"("+employee_code+") has forwarded a leave application \n"
									+ "Following are the details regarding leave \n"
									+ "From Date : "+from_date+"\n"
									+ "To Date : "+to_date+"\n"
									+ "Reason : "+reason+"\n"
									+ "Thanks & Regards \n"
									+ "Indocosmo Systems";
					EmailDAO.sendEmail(to,subject,message, null, mailSenderObj);
				}
			}
		}
		return "redirect:/EmpLeaveApplication";
	}
	@RequestMapping(value="/Admin_requestEdit/{leave_app_tbl_id}")    
	public String adminrequestedit(@PathVariable int leave_app_tbl_id, Model m,HttpSession session){
		EmployeeLeaveBean EmployeeLeaveBeanobject=emp_leavedao_object.getEmpLeaveById(leave_app_tbl_id);
	    m.addAttribute("command1",EmployeeLeaveBeanobject);
	    int employee_id = EmployeeLeaveBeanobject.getLeave_app_tbl_emp_id();
	    int leave_type_id = EmployeeLeaveBeanobject.getLeave_app_tbl_leave_type();
	    java.sql.Date from_date = EmployeeLeaveBeanobject.getLeave_app_tbl_from_date();
	    Calendar cal = Calendar.getInstance();
		cal.setTime(from_date);
		int year_int = cal.get(Calendar.YEAR);
		String year = String.valueOf(year_int);
	    if(leave_type_id != 0) {
			int available_leaves = emp_leavedao_object.getAvailableLeaves(employee_id,leave_type_id,year);
			m.addAttribute("available_leaves",available_leaves);
	    }
	    List<EmployeeLeaveBean> approve_history=emp_leavedao_object.getApproveHistory(leave_app_tbl_id);
	    m.addAttribute("approve_history",approve_history);
	    return "employee/leaveRequest/RequestEdit";

	}
	@RequestMapping(value="AdminEditApprove",method = RequestMethod.GET)
	public String AdminEditapprove(@ModelAttribute("EmployeeLeaveBeanobject") EmployeeLeaveBean EmployeeLeaveBeanobject,HttpSession session)
	{
		int user_id = (Integer) session.getAttribute("employee_id");
		int employee_id = EmployeeLeaveBeanobject.getLeave_app_tbl_emp_id();
		Date from_date = EmployeeLeaveBeanobject.getLeave_app_tbl_from_date();
		Date to_date = EmployeeLeaveBeanobject.getLeave_app_tbl_to_date();
		String reason = EmployeeLeaveBeanobject.getLeave_app_tbl_reason();
		int approver_level = EmployeeLeaveBeanobject.getLeave_application_tbl_appr_lvl();
		int next_approver_level = approver_level+1;
		int flag = emp_leavedao_object.approveLeave(EmployeeLeaveBeanobject,user_id);
		if(flag == 1) {
			EmployeeBean approver = emp_dao_object.getEmployeeById(employee_id);
			String to = approver.getEmail_id_official();
			EmployeeBean employee = emp_dao_object.getEmployeeById(employee_id);
			String employee_name = employee.getEmployee_name();
			String employee_code = employee.getEmployee_code();
			String subject = "Leave Application By "+employee_name+"("+employee_code+") From "+from_date+" to "+to_date;
			String message = "Dear "+employee_name+" \n"
							+ "Your leave application is approved \n"
							+ "Following are the details regarding leave \n"
							+ "From Date : "+from_date+"\n"
							+ "To Date : "+to_date+"\n"
							+ "Reason : "+reason+"\n"
							+ "Thanks & Regards \n"
							+ "Indocosmo Systems";
			EmailDAO.sendEmail(to,subject,message, null, mailSenderObj);
		}
		else if(flag == 2) {
			int approver_id = emp_leavedao_object.getApproverinAnyLevel(employee_id, next_approver_level);
			EmployeeBean approver = emp_dao_object.getEmployeeById(approver_id);
			String to = approver.getEmail_id_official();
			EmployeeBean employee = emp_dao_object.getEmployeeById(employee_id);
			String employee_name = employee.getEmployee_name();
			String employee_code = employee.getEmployee_code();
			String subject = "Leave Application By "+employee_name+"("+employee_code+") From "+from_date+" to "+to_date;
			String message = "Dear Sir/Madam \n"
							+ "The employee "+employee_name+"("+employee_code+") has forwarded a leave application \n"
							+ "Following are the details regarding leave \n"
							+ "From Date : "+from_date+"\n"
							+ "To Date : "+to_date+"\n"
							+ "Reason : "+reason+"\n"
							+ "Thanks & Regards \n"
							+ "Indocosmo Systems";
			EmailDAO.sendEmail(to,subject,message, null, mailSenderObj);
		}
		return "redirect:/dashboard";
	}
	
	@RequestMapping(value="AdminEditReject",method = RequestMethod.GET)
	public String AdminEditReject(@ModelAttribute("EmployeeLeaveBeanobject") EmployeeLeaveBean EmployeeLeaveBeanobject,HttpSession session)
	{
		int user_id = (Integer) session.getAttribute("employee_id");
		int employee_id = EmployeeLeaveBeanobject.getLeave_app_tbl_emp_id();
		Date from_date = EmployeeLeaveBeanobject.getLeave_app_tbl_from_date();
		Date to_date = EmployeeLeaveBeanobject.getLeave_app_tbl_to_date();
		String reason = EmployeeLeaveBeanobject.getLeave_app_tbl_reason();
		emp_leavedao_object.rejectLeave(EmployeeLeaveBeanobject,user_id);
		EmployeeBean approver = emp_dao_object.getEmployeeById(employee_id);
		String to = approver.getEmail_id_official();
		EmployeeBean employee = emp_dao_object.getEmployeeById(employee_id);
		String employee_name = employee.getEmployee_name();
		String employee_code = employee.getEmployee_code();
		String subject = "Leave Application By "+employee_name+"("+employee_code+") From "+from_date+" to "+to_date;
		String message = "Dear "+employee_name+" \n"
						+ "Your leave application is rejected \n"
						+ "Following are the details regarding leave \n"
						+ "From Date : "+from_date+"\n"
						+ "To Date : "+to_date+"\n"
						+ "Reason : "+reason+"\n"
						+ "Thanks & Regards \n"
						+ "Indocosmo Systems";
		EmailDAO.sendEmail(to,subject,message, null, mailSenderObj);
		return "redirect:/dashboard";
	}
	
	@RequestMapping(value="cancelLeave/{leave_app_tbl_id}")
	public String cancelLeave(@PathVariable int leave_app_tbl_id, Model m,HttpSession session)
	{
		int user_id = (Integer) session.getAttribute("employee_id");
		EmployeeLeaveBean EmployeeLeaveBeanobject=emp_leavedao_object.getEmpLeaveById(leave_app_tbl_id);
		int leave_status = EmployeeLeaveBeanobject.getLeave_status();
		int employee_id = EmployeeLeaveBeanobject.getLeave_app_tbl_emp_id();
		Date from_date = EmployeeLeaveBeanobject.getLeave_app_tbl_from_date();
		Date to_date = EmployeeLeaveBeanobject.getLeave_app_tbl_to_date();
		String reason = EmployeeLeaveBeanobject.getLeave_app_tbl_reason();
		emp_leavedao_object.cancelLeave(EmployeeLeaveBeanobject,user_id);
		if(leave_status == 3) {
			EmployeeBean employee = emp_dao_object.getEmployeeById(employee_id);
			String employee_name = employee.getEmployee_name();
			String employee_code = employee.getEmployee_code();
			String subject = "Leave Application By "+employee_name+"("+employee_code+") From "+from_date+" to "+to_date;
			String message = "Dear Sir/Madam \n"
					+ "The employee "+employee_name+"("+employee_code+") has cancelled an approved leave application \n"
					+ "Following are the details regarding leave \n"
					+ "From Date : "+from_date+"\n"
					+ "To Date : "+to_date+"\n"
					+ "Reason : "+reason+"\n"
					+ "Thanks & Regards \n"
					+ "Indocosmo Systems";
			List<EmployeeLeaveBean> approve_history=emp_leavedao_object.getApproveHistory(leave_app_tbl_id);
			for(int i = 0; i<approve_history.size(); i++) {
				int approver_id = approve_history.get(i).getLeave_app_tbl_approver_id();
				EmployeeBean approver = emp_dao_object.getEmployeeById(approver_id);
				String to = approver.getEmail_id_official();
				EmailDAO.sendEmail(to,subject,message, null, mailSenderObj);
			}
		}
		return "redirect:/dashboard";
	}

	@RequestMapping("leavehistory")
	public String leavehistorylist(Model m,HttpSession session) {
		int is_approver = (Integer) session.getAttribute("is_approver");
		String designation = (String) session.getAttribute("designation_name");
		int employee_id = (Integer) session.getAttribute("employee_id");
		if(designation.equalsIgnoreCase("HR Manager")) {
			List<EmployeeLeaveBean> leave_employees = emp_leavedao_object.getLeaveEmployees(1,employee_id);
			m.addAttribute("leave_employees", leave_employees);
		}
		else if(is_approver == 1) {
			List<EmployeeLeaveBean> leave_employees = emp_leavedao_object.getLeaveEmployees(2,employee_id);
			m.addAttribute("leave_employees", leave_employees);
		}
		else {
			List<EmployeeLeaveBean> leave_employees = emp_leavedao_object.getLeaveEmployees(3,employee_id);
			m.addAttribute("leave_employees", leave_employees);
		}
		return "admin/leave/leave_historys";
	}

	@RequestMapping(value="loadLeaveHistory",method = RequestMethod.POST)
	public String loadLeaveHistory(@ModelAttribute("EmployeeLeaveBeanobject") EmployeeLeaveBean EmployeeLeaveBeanobject,
			Model m,HttpSession session) {
			int is_approver = (Integer) session.getAttribute("is_approver");
			String designation = (String) session.getAttribute("designation_name");
			int employee_id = (Integer) session.getAttribute("employee_id");
			if(designation.equalsIgnoreCase("HR Manager")) {
				List<EmployeeLeaveBean> leave_employees = emp_leavedao_object.getLeaveEmployees(1,employee_id);
				m.addAttribute("leave_employees", leave_employees);
			}
			else if(is_approver == 1) {
				List<EmployeeLeaveBean> leave_employees = emp_leavedao_object.getLeaveEmployees(2,employee_id);
				m.addAttribute("leave_employees", leave_employees);
			}
			else {
				List<EmployeeLeaveBean> leave_employees = emp_leavedao_object.getLeaveEmployees(3,employee_id);
				m.addAttribute("leave_employees", leave_employees);
			}
		List<EmployeeLeaveBean> leave_history = emp_leavedao_object.getLoadLeaveHistory(EmployeeLeaveBeanobject);
		m.addAttribute("leave_history", leave_history);
		return "admin/leave/leave_historys";
	}

	@RequestMapping(value="/viewLeave/{leave_app_tbl_id}")    
	public String viewLeave(@PathVariable int leave_app_tbl_id, Model m,HttpSession session){
		EmployeeLeaveBean EmployeeLeaveBeanobject=emp_leavedao_object.getEmpLeaveById(leave_app_tbl_id);
	    m.addAttribute("command1",EmployeeLeaveBeanobject);
	    List<EmployeeLeaveBean> approve_history=emp_leavedao_object.getApproveHistory(leave_app_tbl_id);
	    m.addAttribute("approve_history",approve_history);
	    return "employee/leaveRequest/view_leave";

	}
	
	@RequestMapping("requestsForOthersByHR")
	public String requestsForOthersByHR (Model m,HttpSession session) {
		int employee_id = (Integer) session.getAttribute("employee_id");
		List<EmployeeLeaveBean> approve_list = emp_leavedao_object.getApproveListForHr(employee_id);
		m.addAttribute("approve_list", approve_list);
		return "employee/leaveRequest/hr_other_requests";
	}
}
