/**
  * @author Ayana P Dharman
 *
 * @version 0.0.1 Mar 11, 2020
 *
 *
 */
package com.indocosmo.hrmis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.indocosmo.hrmis.bean.LocationBean;
import com.indocosmo.hrmis.dao.LocationDAO;

@Controller
public class LocationController {

	@Autowired
	LocationDAO location_dao_object;
	
	@RequestMapping("viewLocation")
	public String viewLocation(Model model_object) {
		List<LocationBean> location_list = location_dao_object.getLocations();
		model_object.addAttribute("location_list", location_list);
		return "admin/employee/view_location";
	}

	@RequestMapping("addLocation")
	public String addLocation() {
		return "admin/employee/add_location";
	}
	
	@RequestMapping(value = "/addLocationSave", method = RequestMethod.POST)
	public String addLocationSave(@ModelAttribute("location_bean_object") LocationBean location_bean_object) {
		location_dao_object.insertLocation(location_bean_object);
		return "redirect:/viewLocation";
	}
	
	@RequestMapping(value = "/editLocationView/{location_id}")
	public String editLocationView(@PathVariable String location_id, Model model_object) {
		
		LocationBean location_bean_object = location_dao_object.getLocationById(location_id);
		
		System.out.println(location_bean_object.getLocation_id());
		
		model_object.addAttribute("location", location_bean_object);
		return "admin/employee/edit_location";
	}
	
	@RequestMapping(value = "/editLocationSave", method = RequestMethod.POST)
	public String editLocationSave(@ModelAttribute("location_bean_object") LocationBean location_bean_object) {
		
		System.out.println(location_bean_object.getLocation_id()+""+location_bean_object.getLocation_name());
		
		location_dao_object.editLocation(location_bean_object);
		return "redirect:/viewLocation";
	}
	
	@RequestMapping(value = "/deleteLocation/{location_id}")
	public String deleteLocation(@PathVariable String location_id, Model model_object) {
		int location_bean_object = location_dao_object.deleteLocation(location_id);
		model_object.addAttribute("location", location_bean_object);
		return "redirect:/viewLocation";
	}
}
