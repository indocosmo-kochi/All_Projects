/**
 * @author Jeswin Chacko P A
 *
 * @version 0.0.1 Mar 5, 2020
 *
 *
 */
package com.indocosmo.hrmis.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.indocosmo.hrmis.bean.PersonalBean;
import com.indocosmo.hrmis.dao.PersonalDAO;

@Controller
public class PersonalController {

	@Autowired
	PersonalDAO personal_dao_object;
	
	@RequestMapping("personalDetails")
	public String personalDetails(Model model_object,HttpSession session) {
		String employee_id = (String) session.getAttribute("userid");
		int check = personal_dao_object.check(employee_id);
		if(check == 0) {
			return "employee/personalInformation/personal_details_empty";
		}
		PersonalBean personal_bean_object = personal_dao_object.getPersonal(employee_id);
		List<PersonalBean> sibling_list = personal_dao_object.getSibling(employee_id);
		List<PersonalBean> child_list = personal_dao_object.getChild(employee_id);
		model_object.addAttribute("personal", personal_bean_object);
		model_object.addAttribute("sibling_list", sibling_list);
		model_object.addAttribute("child_list", child_list);
		return "employee/personalInformation/personal_details_view";
	}
	
	@RequestMapping(value = "/addPersonalSave", method = RequestMethod.POST)
	public String savePersonal(@ModelAttribute("personal_bean_object") PersonalBean personal_bean_object,HttpSession session) {
		String employee_id = (String) session.getAttribute("userid");
		personal_dao_object.insertPersonal(personal_bean_object,employee_id);
		return "redirect:/personalDetails";
	}
	
	@RequestMapping(value = "/editPersonalSave", method = RequestMethod.POST)
	public String editPersonalSave(@ModelAttribute("personal_bean_object") PersonalBean personal_bean_object,HttpSession session) {
		String employee_id = (String) session.getAttribute("userid");
		personal_dao_object.editPersonal(personal_bean_object,employee_id);
		return "redirect:/personalDetails";
	}
	
	@RequestMapping("addPersonal")
	public String addPersonal() {
		return "employee/personalInformation/personal_details_add";
	}
}
