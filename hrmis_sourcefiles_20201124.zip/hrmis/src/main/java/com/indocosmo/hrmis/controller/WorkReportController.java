/**
 * 
 */
package com.indocosmo.hrmis.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.fileupload.FileItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.indocosmo.hrmis.bean.AnnouncementBean;
import com.indocosmo.hrmis.bean.EmployeeBean;
import com.indocosmo.hrmis.bean.EmployeeLeaveBean;
import com.indocosmo.hrmis.bean.LeaveAllocationBean;
import com.indocosmo.hrmis.bean.LocationBean;
import com.indocosmo.hrmis.bean.WorkReportBean;
import com.indocosmo.hrmis.dao.EmployeeDAO;
import com.indocosmo.hrmis.dao.WorkReportDAO;

/**
 * @author Ayana P Dharman
 * 
 * @version 0.0.1 22 June 2020
 *
 */
@Controller
public class WorkReportController {

	@Autowired
	ServletContext context;

	@Autowired
	WorkReportDAO workreport_dao_object;

	@Autowired
	EmployeeDAO employee_dao_object;

	private static final String FILE_PATH = "e:/INDOCOSMOHRMIS/HRMIS/src/main/webapp/resources/workreports/employeeid/";

	@RequestMapping("Workreportuploademp")
	public String workreport(Model model_object, HttpSession session) {
		String employee_code = (String) session.getAttribute("userid");
		EmployeeBean employee_bean_object = employee_dao_object.getEmployeeByCode(employee_code);
		model_object.addAttribute("employee", employee_bean_object);
		return "employee/workreport/workreportupload";
	}
	
	@RequestMapping("hrworkreportshistory")
	public String reportsview(Model m,HttpSession session) {
		int employee_id = (Integer) session.getAttribute("employee_id");
		List<EmployeeBean> employee_list = workreport_dao_object.getEmployeeByCodeHr();
		m.addAttribute("employee_list", employee_list);
		List<WorkReportBean> reportlist = workreport_dao_object.getworkreporthistory();
		m.addAttribute("reportlist", reportlist);
		
		return "admin/reports/work_reports";
	}
	
	@RequestMapping("WorkReporthistoryemp")
	public String reportsviewemployee(Model m,HttpSession session) {
		int employee_id =(Integer) session.getAttribute("employee_id");
		List<WorkReportBean> reportlistemp = workreport_dao_object.getworkreporthistorybyuser(employee_id);
		m.addAttribute("reportlistemp", reportlistemp);
		
		return "employee/workreport/work_report_history";
	}
	
	
	
	@RequestMapping(value="loadWorkReport",method = RequestMethod.POST)
	public String loadLeaveReport(@ModelAttribute("Workreport_bean_object") WorkReportBean Workreport_bean_object,
			Model m,HttpSession session) {
		int employee_id = (Integer) session.getAttribute("employee_id");
		List<EmployeeBean> employee_list = workreport_dao_object.getEmployeeByCodeHr();
		m.addAttribute("employee_list", employee_list);
		String fromdate = Workreport_bean_object.getFrom_month();
		String todate = Workreport_bean_object.getTo_month();
		int empid = Workreport_bean_object.getEmployee_id();
		System.out.println(fromdate +" " +todate +" "+ empid);

		List<WorkReportBean> reportlist = workreport_dao_object.getreporthistoryByid(fromdate,todate,empid);
		m.addAttribute("reportlist", reportlist);
		return "admin/reports/work_reports";
	}
	
	
	@RequestMapping("WorkReportUploadhr")
	public String workuploadbyHr(Model model_object,HttpSession session) {
		
		List<EmployeeBean> employee_list = workreport_dao_object.getEmployeeByCodeHr();
		model_object.addAttribute("employee_list", employee_list);
		
		System.out.println("size"+employee_list.size());
		
		List<LocationBean> location_list = workreport_dao_object.getLocations();
		model_object.addAttribute("location_list", location_list);
		
		return "employee/workreport/WorkUpload";
	}

	@RequestMapping(value = "/workreportsave", method = RequestMethod.POST)
	public String upload(@ModelAttribute("workreport_bean_object") WorkReportBean workreport_bean_object,
			@Validated WorkReportBean file, BindingResult result, ModelMap model,
			@RequestParam CommonsMultipartFile uploadfile,HttpSession session) {
		
		
		String path = session.getServletContext().getRealPath("/");
		String filename = uploadfile.getOriginalFilename();
		workreport_bean_object.setFilename(filename);
		String employee_name = workreport_dao_object.getemployeeName(workreport_bean_object.getEmployee_id());
		workreport_dao_object.uploadfilesave(workreport_bean_object,employee_name);
		System.out.println(path + " " + filename);
		try {
			byte barr[] = uploadfile.getBytes();

			BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(path + "/" + filename));
			bout.write(barr);
			bout.flush();
			bout.close();

		} catch (Exception e) {
			System.out.println(e);
		}
		return "redirect:/dashboard";
	}
	
	
	@RequestMapping(value = "/workreportsaveemp", method = RequestMethod.POST)
	public String uploademp(@ModelAttribute("workreport_bean_object") WorkReportBean workreport_bean_object,
			@Validated WorkReportBean file, BindingResult result, ModelMap model,
			@RequestParam CommonsMultipartFile uploadfile,HttpSession session) {
		
		
		String path = session.getServletContext().getRealPath("/");
		String filename = uploadfile.getOriginalFilename();
		workreport_bean_object.setFilename(filename);
		String employee_name = workreport_dao_object.getemployeeName(workreport_bean_object.getEmployee_id());
		workreport_dao_object.uploadfilesave(workreport_bean_object,employee_name);
		System.out.println(path + " " + filename);
		try {
			byte barr[] = uploadfile.getBytes();

			BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(path + "/" + filename));
			bout.write(barr);
			bout.flush();
			bout.close();

		} catch (Exception e) {
			System.out.println(e);
		}
		return "redirect:/WorkReporthistoryemp";
	}

	private static final int BUFFER_SIZE = 4096;

	//private String filePath = "/workreports/employeeid/";

	@RequestMapping(value = "/downloadreport/{filename}", method = RequestMethod.GET)
	public void doDownload(HttpServletRequest request, HttpServletResponse response,
			@PathVariable("filename") String filename) throws IOException {

		System.out.println(filename);
		// get absolute path of the application
		ServletContext context = request.getServletContext();
		String appPath = context.getRealPath("");
		System.out.println("appPath = " + filename);

		// construct the complete absolute path of the file
		String fullPath = appPath+ filename+".xlsx";
		System.out.println(fullPath);
		File downloadFile = new File(fullPath);
		FileInputStream inputStream = new FileInputStream(downloadFile);

		// get MIME type of the file
		String mimeType = context.getMimeType(fullPath);
		if (mimeType == null) {
			// set to binary type if MIME mapping not found
			mimeType = "application/octet-stream";
		}
		System.out.println("MIME type: " + mimeType);

		// set content attributes for the response
		response.setContentType(mimeType);
		response.setContentLength((int) downloadFile.length());

		// set headers for the response
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"", downloadFile.getName());
		response.setHeader(headerKey, headerValue);

		// get output stream of the response
		OutputStream outStream = response.getOutputStream();

		byte[] buffer = new byte[BUFFER_SIZE];
		int bytesRead = -1;

		// write bytes read from the input stream into the output stream
		while ((bytesRead = inputStream.read(buffer)) != -1) {
			outStream.write(buffer, 0, bytesRead);
		}

		inputStream.close();
		outStream.close();

	}

	@RequestMapping(value = "/ReportApproval/{work_report_id}", method = RequestMethod.GET)
	public String approval(@PathVariable int work_report_id,Model m, HttpSession session) {
		int employee_id = (Integer) session.getAttribute("employee_id");
		 workreport_dao_object.reportapproval(work_report_id);
		//System.out.println("approved status" + approvereport);
		/*
		 * if (approvereport == 1) { m.addAttribute("status",1); List<WorkReportBean>
		 * report_status = workreport_dao_object.getreportstatus(employee_id);
		 * m.addAttribute("report_status", report_status);
		 * System.out.println(report_status.size()); } else {
		 * m.addAttribute("status",0); }
		 */
			
		return "redirect:/dashboard";
	}
	
	@RequestMapping(value = "/ReportReject/{work_report_id}", method = RequestMethod.GET)
	public String reject(@PathVariable int work_report_id,Model m, HttpSession session) {
		int employee_id = (Integer) session.getAttribute("employee_id");
		 workreport_dao_object.reportreject(work_report_id);	
		return "redirect:/dashboard";
	}
}
