/**
 * 
 */
package com.indocosmo.hrmis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.indocosmo.hrmis.bean.ClientBean;
import com.indocosmo.hrmis.bean.ClientProjectBean;
import com.indocosmo.hrmis.bean.ProjectManagerBean;
import com.indocosmo.hrmis.dao.ClientDAO;
import com.indocosmo.hrmis.dao.ProjectManagerDAO;

/**
 * @author Ayana P Dharman 
 *
 * @version 0.0.1 Jul 10, 2020
 */
@Controller
public class ProjectManagerController {
	
	@Autowired
	ProjectManagerDAO project_manager_dao;
	
	@RequestMapping(value = "/add_project_manager/{project_id}")
	public String client(@PathVariable int project_id, Model model_object) {
		model_object.addAttribute("project_id", project_id);
		return "admin/clientproject/add_project_manager";
	}
	
	@RequestMapping(value = "/projectmanagersave", method = RequestMethod.POST)
	public String projectManagerSave(@ModelAttribute("projectmanager") ProjectManagerBean projectmanager) {
		project_manager_dao.projectmanagersave(projectmanager);
		return "redirect:/editProject/" + projectmanager.getProject_id();
	}
	
	@RequestMapping(value = "/deleteProjectManager/{manager_id}", method = RequestMethod.GET)
	public String deleteManager(@PathVariable int manager_id, Model model_object) {
		project_manager_dao.deleteprojectmanager(manager_id);
		ProjectManagerBean manager_bean_object = project_manager_dao.getManagerById(manager_id);
		return "redirect:/editProject/" + manager_bean_object.getProject_id();
	}


	@RequestMapping(value = "/editProjectManager/{manager_id}")
	public String manageredit(@PathVariable int manager_id, Model m) {

		ProjectManagerBean manager_list = project_manager_dao.getManagerById(manager_id);
		m.addAttribute("manager_list", manager_list);
		return "admin/clientproject/update_project_manager";
	}

	@RequestMapping(value = "/managereditsave/{manager_id}", method = RequestMethod.POST)
	public String managereditsave(@PathVariable int manager_id,@ModelAttribute("projectmanager") ProjectManagerBean projectmanager) {

		project_manager_dao.projectmanagerupdate(projectmanager);
		ProjectManagerBean manager_bean_object = project_manager_dao.getManagerById(manager_id);
		return "redirect:/editProject/" + manager_bean_object.getProject_id();
	}
}
