/**
 * 
 */
package com.indocosmo.hrmis.bean;


/**
 * @author Ayana P Dharman
 *
 * @version 0.0.1 May 25, 2020
 */
//Leave Allocation Bean Class 
public class LeaveAllocationBean {

	private int leaveallocation_id, no_of_days;
	private String employee_name_array[],employee_name,leavetype_name,location_name;
	private String current_year;
	private String leave_status;
	private int leaveallocation_emp_id,leaveallocation_type_id,leaveallocation_emp_id_array[];

	public int[] getLeaveallocation_emp_id_array() {
		return leaveallocation_emp_id_array;
	}

	public void setLeaveallocation_emp_id_array(int[] leaveallocation_emp_id_array) {
		this.leaveallocation_emp_id_array = leaveallocation_emp_id_array;
	}

	public int getNo_of_days() {
		return no_of_days;
	}

	public void setNo_of_days(int no_of_days) {
		this.no_of_days = no_of_days;
	}

	public int getLeaveallocation_id() {
		return leaveallocation_id;
	}

	public void setLeaveallocation_id(int leaveallocation_id) {
		this.leaveallocation_id = leaveallocation_id;
	}

	public String getCurrent_year() {
		return current_year;
	}

	public void setCurrent_year(String current_year) {
		this.current_year = current_year;
	}

	public String getLeave_status() {
		return leave_status;
	}

	public void setLeave_status(String leave_status) {
		this.leave_status = leave_status;
	}

	public String[] getEmployee_name_array() {
		return employee_name_array;
	}

	public void setEmployee_name_array(String[] employee_name_array) {
		this.employee_name_array = employee_name_array;
	}

	public String getEmployee_name() {
		return employee_name;
	}

	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}

	public String getLeavetype_name() {
		return leavetype_name;
	}

	public void setLeavetype_name(String leavetype_name) {
		this.leavetype_name = leavetype_name;
	}

	public String getLocation_name() {
		return location_name;
	}

	public void setLocation_name(String location_name) {
		this.location_name = location_name;
	}

	public int getLeaveallocation_type_id() {
		return leaveallocation_type_id;
	}

	public void setLeaveallocation_type_id(int leaveallocation_type_id) {
		this.leaveallocation_type_id = leaveallocation_type_id;
	}

	public int getLeaveallocation_emp_id() {
		return leaveallocation_emp_id;
	}

	public void setLeaveallocation_emp_id(int leaveallocation_emp_id) {
		this.leaveallocation_emp_id = leaveallocation_emp_id;
	}

	
}
