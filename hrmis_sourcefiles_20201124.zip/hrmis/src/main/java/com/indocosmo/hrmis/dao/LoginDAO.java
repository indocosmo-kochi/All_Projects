package com.indocosmo.hrmis.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Base64;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

import com.indocosmo.hrmis.bean.LoginBean;

/**
 * @author Ayana P Dharman
 *
 * @version 0.0.1 Mar 5, 2020
 */
public class LoginDAO {
	
JdbcTemplate template;
	
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public int loginCheck(LoginBean login_bean_object) {
		int count = 0;
		String employee_code = login_bean_object.getEmployee_code();
		String loginpwd = login_bean_object.getPassword();
		String encoded_loginpwd = Base64.getEncoder().encodeToString(loginpwd.getBytes());
		
		String sql = "SELECT COUNT(employee_code) FROM employee WHERE employee_code=? AND password=? AND is_deleted=0";
		count = template.queryForObject(sql, new Object[] { employee_code,encoded_loginpwd },Integer.class);
		return count;
	}

	public LoginBean getUserById(String employee_code) { // To get an item by id(used in editing form)
		String sql = "SELECT * FROM employee WHERE employee_code=?";
		return template.queryForObject(sql, new Object[] { employee_code },
				new BeanPropertyRowMapper<LoginBean>(LoginBean.class));
	}
	
	public LoginBean getLoginDeatails(int employee_id) {
		String sql = "call loginRedirect(?)";
		return template.queryForObject(sql, new Object[] { employee_id },
				new BeanPropertyRowMapper<LoginBean>(LoginBean.class));
	}
	
	public int checkPassword(LoginBean login_bean_object) {
		String entered_password = login_bean_object.getCurrent_password();
		String entered_encoded_password = Base64.getEncoder().encodeToString(entered_password.getBytes());
		String encoded_pwd_from_database;
		String sql = "SELECT password FROM employee WHERE employee_id=?";
		encoded_pwd_from_database = template.queryForObject(sql, new Object[] { login_bean_object.getEmployee_id() },String.class);
		if(entered_encoded_password.equals(encoded_pwd_from_database)) {
			return 1;
		}
		else {
			return 0;
		}
	}
	
	public int checkPasswordByCode(LoginBean login_bean_object) {
		String entered_password = login_bean_object.getCurrent_password();
		String entered_encoded_password = Base64.getEncoder().encodeToString(entered_password.getBytes());
		String encoded_pwd_from_database;
		String sql = "SELECT password FROM employee WHERE employee_code=?";
		encoded_pwd_from_database = template.queryForObject(sql, new Object[] { login_bean_object.getEmployee_code() },String.class);
		if(entered_encoded_password.equals(encoded_pwd_from_database)) {
			return 1;
		}
		else {
			return 0;
		}
	}

	public int changePassword(final LoginBean login_bean_object) {
		String entered_password = login_bean_object.getNew_password();
		final String entered_encoded_password = Base64.getEncoder().encodeToString(entered_password.getBytes());
		String sql = "UPDATE employee SET password=? WHERE employee_id=?";
		return template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setString(1, entered_encoded_password);
				prepared_statement_object.setInt(2, login_bean_object.getEmployee_id());
				return prepared_statement_object.executeUpdate();
			}
		});
	}
	
	public int resetPassword(final LoginBean login_bean_object) {
		String entered_password = login_bean_object.getNew_password();
		System.out.println(entered_password);
		final String entered_encoded_password = Base64.getEncoder().encodeToString(entered_password.getBytes());
		String sql = "UPDATE employee SET password=? WHERE employee_code=?";
		return template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setString(1, entered_encoded_password);
				prepared_statement_object.setString(2, login_bean_object.getEmployee_code());
				return prepared_statement_object.executeUpdate();
			}
		});
	}
}
