/**
 * 
 */
package com.indocosmo.hrmis.bean;

/**
 * @author Ayana P Dharman
 * 
 * @version 0.0.1 08 July 2020
 */
public class ClientProjectBean {
	
	private int project_id,client_id;
	private String project_name;
	
	public int getClient_id() {
		return client_id;
	}
	public void setClient_id(int client_id) {
		this.client_id = client_id;
	}
	
	
	public int getProject_id() {
		return project_id;
	}
	public void setProject_id(int project_id) {
		this.project_id = project_id;
	}
	public String getProject_name() {
		return project_name;
	}
	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}
	
	

}
