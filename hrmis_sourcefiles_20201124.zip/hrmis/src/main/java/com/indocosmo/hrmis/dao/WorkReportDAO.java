/**
 * 
 */
package com.indocosmo.hrmis.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.indocosmo.hrmis.bean.AnnouncementBean;
import com.indocosmo.hrmis.bean.EmployeeBean;
import com.indocosmo.hrmis.bean.EmployeeLeaveBean;
import com.indocosmo.hrmis.bean.LeaveTypeBean;
import com.indocosmo.hrmis.bean.LocationBean;
import com.indocosmo.hrmis.bean.WorkReportBean;

/**
 * @author Ayana P Dharman
 * 
 * @version 0.0.1 22 June 2020
 *
 */
public class WorkReportDAO {

	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public int uploadfilesave(WorkReportBean workreport,String employee_name) {
		String sql = "insert into work_report_tbl(employee_id,employee_name,filename,uploaded_month,location,upload_status) values('"
				+ workreport.getEmployee_id() + "','" + employee_name + "','" + workreport.getFilename()
				+ "','" + workreport.getUploaded_month() + "','" + workreport.getLocation() + "','"
				+ workreport.getUpload_status() + "')";
		return template.update(sql);
	}

	public List<WorkReportBean> getReportList() {
		String sql = "select * from work_report_tbl where upload_status='Applied'";
		System.out.println(sql);
		return template.query(sql, new RowMapper<WorkReportBean>() {
			public WorkReportBean mapRow(ResultSet rs, int row) throws SQLException {
				WorkReportBean reportobject = new WorkReportBean();
				reportobject.setWork_report_id(rs.getInt(1));
				reportobject.setEmployee_id(rs.getInt(2));
				reportobject.setEmployee_name(rs.getString(3));
				reportobject.setFilename(rs.getString(4));
				reportobject.setUploaded_month(rs.getString(5));
				reportobject.setLocation(rs.getInt(6));
				reportobject.setUpload_status(rs.getString(7));
				return reportobject;
			}
		});
	}

	public int reportapproval(int work_report_id) {
		String sql = "update work_report_tbl set upload_status='Approved' where work_report_id=" + work_report_id + "";
		return template.update(sql);
		
	}
	public List<LocationBean> getLocations() {
		return template.query("SELECT * FROM location WHERE is_deleted=0", new RowMapper<LocationBean>() {
			public LocationBean mapRow(ResultSet rs, int row) throws SQLException {
				LocationBean location_bean_object = new LocationBean();
				location_bean_object.setLocation_id(rs.getInt(1));
				location_bean_object.setLocation_name(rs.getString(2));
				return location_bean_object;
			}
		});
	}

	public List<EmployeeBean> getEmployeeByCodeHr() { // To show every employees as a table
		return template.query("select * from employee where employee.designation!='1'AND employee.admin_flag!='1';", new RowMapper<EmployeeBean>() {
			public EmployeeBean mapRow(ResultSet rs, int row) throws SQLException {
				EmployeeBean employee_bean_object = new EmployeeBean();
				employee_bean_object.setEmployee_id(rs.getInt(1));
				employee_bean_object.setEmployee_code(rs.getString(2));
				employee_bean_object.setEmployee_name(rs.getString(3));
				employee_bean_object.setLocation(rs.getInt(4));
				employee_bean_object.setDesignation(rs.getInt(5));
				employee_bean_object.setDate_of_appointment(rs.getDate(6));
				employee_bean_object.setPersonal_phone(rs.getString(7));
				employee_bean_object.setEmail_id_personal(rs.getString(8));
				employee_bean_object.setEmail_id_official(rs.getString(9));
				employee_bean_object.setPf_uan(rs.getString(10));
				employee_bean_object.setEsi_num(rs.getString(11));
				employee_bean_object.setStatus(rs.getString(17));
				employee_bean_object.setClient(rs.getInt(18));
				employee_bean_object.setAdmin_flag(rs.getInt(19));
				return employee_bean_object;
			}
		});
	}

	public String getemployeeName(int employee_id) {
		String sql = "Select employee_name from employee where employee_id="+employee_id;
		String name =template.queryForObject(sql, new Object[] {  },String.class);
		return name;
	}

	public List<WorkReportBean> getreporthistoryByid(String fromdate, String todate, int empid) {
		return template.query("select * from work_report_tbl where employee_id='"+empid+"' And uploaded_month between '"+fromdate+"' and '"+todate+"';", new RowMapper<WorkReportBean>() {
			public WorkReportBean mapRow(ResultSet rs, int row) throws SQLException {
				WorkReportBean report_bean_object = new WorkReportBean();
				report_bean_object.setWork_report_id(rs.getInt(1));
				report_bean_object.setEmployee_id(rs.getInt(2));
				report_bean_object.setEmployee_name(rs.getString(3));
				report_bean_object.setFilename(rs.getString(4));
				report_bean_object.setUploaded_month(rs.getString(5));
				report_bean_object.setUpload_status(rs.getString(7));
				return report_bean_object;
			}
		});
	}

	public List<WorkReportBean> getworkreporthistory() {
		return template.query("SELECT * FROM work_report_tbl WHERE is_deleted=0", new RowMapper<WorkReportBean>() {
			public WorkReportBean mapRow(ResultSet rs, int row) throws SQLException {
				WorkReportBean report_bean_object = new WorkReportBean();
				report_bean_object.setWork_report_id(rs.getInt(1));
				report_bean_object.setEmployee_id(rs.getInt(2));
				report_bean_object.setEmployee_name(rs.getString(3));
				report_bean_object.setFilename(rs.getString(4));
				report_bean_object.setUploaded_month(rs.getString(5));
				report_bean_object.setUpload_status(rs.getString(7));
				return report_bean_object;
			}
		});
	}

	public List<WorkReportBean> getreportstatus(int employee_id) {
		return template.query("select * from work_report_tbl where employee_id="+employee_id, new RowMapper<WorkReportBean>() {
			public WorkReportBean mapRow(ResultSet rs, int row) throws SQLException {
				WorkReportBean reportstatus = new WorkReportBean();
				reportstatus.setWork_report_id(rs.getInt(1));
				reportstatus.setEmployee_id(rs.getInt(2));
				reportstatus.setEmployee_name(rs.getString(3));
				reportstatus.setFilename(rs.getString(4));
				reportstatus.setUploaded_month(rs.getString(5));
				reportstatus.setLocation(rs.getInt(6));
				reportstatus.setUpload_status(rs.getString(7));
				return reportstatus;
			}
		});
	}

	public int reportreject(int work_report_id) {
		String sql = "update work_report_tbl set upload_status='Unapproved' where work_report_id=" + work_report_id + "";
		return template.update(sql);

	}

	public List<WorkReportBean> getworkreporthistorybyuser(int employee_id) {
		return template.query("SELECT * FROM work_report_tbl WHERE is_deleted=0 and employee_id="+employee_id, new RowMapper<WorkReportBean>() {
			public WorkReportBean mapRow(ResultSet rs, int row) throws SQLException {
				WorkReportBean report_bean_object = new WorkReportBean();
				report_bean_object.setWork_report_id(rs.getInt(1));
				report_bean_object.setEmployee_id(rs.getInt(2));
				report_bean_object.setEmployee_name(rs.getString(3));
				report_bean_object.setFilename(rs.getString(4));
				report_bean_object.setUploaded_month(rs.getString(5));
				report_bean_object.setUpload_status(rs.getString(7));
				return report_bean_object;
			}
		});
	}

}
