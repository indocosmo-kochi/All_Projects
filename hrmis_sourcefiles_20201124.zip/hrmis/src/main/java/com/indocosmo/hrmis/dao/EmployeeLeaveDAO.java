package com.indocosmo.hrmis.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;

import com.indocosmo.hrmis.bean.EmployeeLeaveBean;
import com.indocosmo.hrmis.bean.LeaveAllocationBean;

public class EmployeeLeaveDAO {
	
	long millis=System.currentTimeMillis();
	Date current_date = new java.sql.Date(millis);
	private JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public List<LeaveAllocationBean> getleavetype(int employee_id) {
		String sql = "SELECT leaveallocation_type_id,leavetype_name FROM leaveallocation_tbl "
				+ "WHERE leaveallocation_emp_id="+employee_id+" AND is_deleted=0";
		return template.query(sql, new RowMapper<LeaveAllocationBean>() {
			public LeaveAllocationBean mapRow(ResultSet rs, int row) throws SQLException {
				LeaveAllocationBean e = new LeaveAllocationBean();
				e.setLeaveallocation_type_id(rs.getInt(1));
				e.setLeavetype_name(rs.getString(2));
				return e;
			}
		});
	}
	public int getApproverinAnyLevel(int employee_id,int level) {
		String getApproverinFirstLevel = "call hrmis.getApproverinAnyLevel(?,?);";
		int approver_emp_id = template.queryForObject(getApproverinFirstLevel, new Object[] { employee_id,level }, Integer.class);
		return approver_emp_id;
	}

	public int leaveApplicationSave(final EmployeeLeaveBean empleave, final int employee_id) {
		String getApproverinFirstLevel = "call hrmis.getApproverinAnyLevel(?,?);";
		final int approver_emp_id = template.queryForObject(getApproverinFirstLevel, new Object[] { employee_id,1 }, Integer.class);
		if(approver_emp_id == 0) {
			return 2;
		}
		else {
			String sql = "INSERT INTO hrmis_leave_application_tbl (leave_app_tbl_from_date, leave_app_tbl_to_date, leave_app_tbl_emp_id,"
					+ " leave_app_tbl_approver_id, leave_app_tbl_total_days, leave_app_tbl_lop_days,leave_app_tbl_leave_type, "
					+ "leave_app_tbl_reason,leave_application_tbl_appr_lvl,leave_app_tbl_created_by,leave_app_tbl_created_by_date,"
					+ "leave_application_lop_flag) "
					+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
			return template.execute(sql, new PreparedStatementCallback<Integer>() {

				public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
						throws SQLException, DataAccessException {
					prepared_statement_object.setDate(1, empleave.getLeave_app_tbl_from_date());
					prepared_statement_object.setDate(2, empleave.getLeave_app_tbl_to_date());
					prepared_statement_object.setInt(3, employee_id);
					prepared_statement_object.setInt(4, approver_emp_id);
					prepared_statement_object.setInt(5, empleave.getLeave_app_tbl_total_days());
					prepared_statement_object.setInt(6, empleave.getLeave_app_tbl_lop_days());
					prepared_statement_object.setInt(7, empleave.getLeave_app_tbl_leave_type());
					prepared_statement_object.setString(8, empleave.getLeave_app_tbl_reason());
					prepared_statement_object.setInt(9, 1);
					prepared_statement_object.setInt(10, employee_id);
					prepared_statement_object.setDate(11, current_date);
					prepared_statement_object.setInt(12, empleave.getLop_flag());
					return prepared_statement_object.executeUpdate();
				}
			});
		}

	}

	public int leaveHistorySave(EmployeeLeaveBean empleave, int employee_id, int status) {
		String getApproverinFirstLevel = "call hrmis.getApproverinAnyLevel(?,?);";
		final int approver_emp_id = template.queryForObject(getApproverinFirstLevel, new Object[] { employee_id,1 }, Integer.class);
		String sql = "insert into hrmis_leave_history_tbl(leave_history_tbl_app_id, leave_history_tbl_from_date, "
				+ "leave_history_tbl_to_date, leave_history_tbl_totaldays, leave_history_tbl_lop_days, leave_history_tbl_reason, "
				+ "leave_history_tbl_status,leave_history_tbl_type, leave_history_tbl_approver_emp_id, leave_history_tbl_emp_id,"
				+ "createdBy,createdDate,leave_history_lop_flag) "
				+ "values((SELECT max(leave_app_tbl_id) as 'leave_history_tbl_app_id' FROM hrmis.hrmis_leave_application_tbl),'"
				+ empleave.getLeave_app_tbl_from_date() + "','" + empleave.getLeave_app_tbl_to_date() + "','"
				+ empleave.getLeave_app_tbl_total_days() + "','" + empleave.getLeave_app_tbl_lop_days() + "','"
				+ empleave.getLeave_app_tbl_reason() + "','" + status + "','" + empleave.getLeave_app_tbl_leave_type()
				+ "',"+approver_emp_id+",'" + employee_id + "',"+employee_id+",'"+current_date+"',"+empleave.getLop_flag()+")";
		return template.update(sql);

	}

	public EmployeeLeaveBean getEmpLeaveById(int leave_app_tbl_id) {
		String sql = "select leave_app_tbl_id,leave_app_tbl_from_date,leave_app_tbl_to_date, leave_app_tbl_emp_id,"
				+ "leave_app_tbl_approver_id, leave_application_tbl_appr_lvl,leave_app_tbl_total_days,"
				+ "leave_app_tbl_lop_days,leave_app_tbl_leave_type,leave_app_tbl_reason,employee.employee_name,"
				+ "leavetype_tbl.leavetype_name,leave_application_lop_flag AS lop_flag,hrmis_leave_application_tbl.leave_status "
				+ "from hrmis_leave_application_tbl,employee,leavetype_tbl "
				+ "where employee.employee_id=hrmis_leave_application_tbl.leave_app_tbl_emp_id "
				+ "and leave_app_tbl_leave_type = leavetype_id "
				+ "and hrmis_leave_application_tbl.leave_app_tbl_id="+leave_app_tbl_id+" "
				+ "and hrmis_leave_application_tbl.leave_app_tbl_isdeleted=0 "
				+ "UNION "
				+ "select leave_app_tbl_id,leave_app_tbl_from_date,leave_app_tbl_to_date, leave_app_tbl_emp_id,"
				+ "leave_app_tbl_approver_id, leave_application_tbl_appr_lvl,leave_app_tbl_total_days,"
				+ "leave_app_tbl_lop_days,leave_app_tbl_leave_type,leave_app_tbl_reason,employee.employee_name,"
				+ "(SELECT 'LOP' AS leavetype_name),leave_application_lop_flag AS lop_flag,hrmis_leave_application_tbl.leave_status "
				+ "from hrmis_leave_application_tbl,employee "
				+ "where employee.employee_id=leave_app_tbl_emp_id "
				+ "and leave_app_tbl_leave_type = 0 "
				+ "and hrmis_leave_application_tbl.leave_app_tbl_id="+leave_app_tbl_id+" "
				+ "and hrmis_leave_application_tbl.leave_app_tbl_isdeleted=0 ";
		return template.queryForObject(sql,new BeanPropertyRowMapper<EmployeeLeaveBean>(EmployeeLeaveBean.class));
	}
	
	public List<EmployeeLeaveBean> getApproveList(int approver_id) {
		return template.query(
				"SELECT hrmis_leave_application_tbl.leave_app_tbl_id,leave_app_tbl_from_date, "
				+ "hrmis_leave_application_tbl.leave_app_tbl_to_date, hrmis_leave_application_tbl.leave_app_tbl_emp_id, "
				+ "hrmis_leave_application_tbl.leave_app_tbl_approver_id, leave_app_tbl_total_days, "
				+ "hrmis_leave_application_tbl.leave_app_tbl_lop_days, "
				+ "hrmis_leave_application_tbl.leave_app_tbl_reason,employee.employee_name,leavetype_tbl.leavetype_name "
				+ "FROM hrmis_leave_application_tbl,employee,leavetype_tbl "
				+ "WHERE employee.employee_id=hrmis_leave_application_tbl.leave_app_tbl_emp_id "
				+ "AND hrmis_leave_application_tbl.leave_app_tbl_leave_type = leavetype_tbl.leavetype_id "
				+ "AND hrmis_leave_application_tbl.leave_app_tbl_approver_id="+approver_id+" "
				+ "AND hrmis_leave_application_tbl.leave_app_tbl_isdeleted=0 "
				+ "AND hrmis_leave_application_tbl.leave_status = 2 "
				+ "UNION "
				+ "SELECT hrmis_leave_application_tbl.leave_app_tbl_id,leave_app_tbl_from_date, "
				+ "hrmis_leave_application_tbl.leave_app_tbl_to_date, hrmis_leave_application_tbl.leave_app_tbl_emp_id, "
				+ "hrmis_leave_application_tbl.leave_app_tbl_approver_id, leave_app_tbl_total_days, "
				+ "hrmis_leave_application_tbl.leave_app_tbl_lop_days, "
				+ "hrmis_leave_application_tbl.leave_app_tbl_reason,employee.employee_name,(SELECT 'LOP' AS leavetype_name) "
				+ "FROM hrmis_leave_application_tbl,employee "
				+ "WHERE employee.employee_id=hrmis_leave_application_tbl.leave_app_tbl_emp_id "
				+ "AND leave_app_tbl_leave_type = 0 "
				+ "AND hrmis_leave_application_tbl.leave_app_tbl_approver_id="+approver_id+" "
				+ "AND hrmis_leave_application_tbl.leave_app_tbl_isdeleted=0 "
				+ "AND hrmis_leave_application_tbl.leave_status = 2",
				new RowMapper<EmployeeLeaveBean>() {
					public EmployeeLeaveBean mapRow(ResultSet rs, int row) throws SQLException {
						EmployeeLeaveBean empleaveobject = new EmployeeLeaveBean();
						empleaveobject.setLeave_app_tbl_id(rs.getInt(1));
						empleaveobject.setLeave_app_tbl_from_date(rs.getDate(2));
						empleaveobject.setLeave_app_tbl_to_date(rs.getDate(3));
						empleaveobject.setLeave_app_tbl_total_days(rs.getInt(6));
						empleaveobject.setLeave_app_tbl_lop_days(rs.getInt(7));
						empleaveobject.setLeave_app_tbl_reason(rs.getString(8));
						empleaveobject.setEmp_tbl_name(rs.getString(9));
						empleaveobject.setLeavetype_name(rs.getString(10));
						return empleaveobject;
					}
				});
	}
	
	public List<EmployeeLeaveBean> getRequestList(int employee_id) {
		return template.query(
				"SELECT leave_app_tbl_from_date,leave_app_tbl_to_date,leavetype_name,leave_app_tbl_total_days,"
				+ "leave_app_tbl_lop_days,leave_app_tbl_reason,leave_status.leave_status_name,leave_app_tbl_id "
				+ "FROM ((hrmis_leave_application_tbl INNER JOIN leavetype_tbl ON leave_app_tbl_leave_type = leavetype_id) "
				+ "INNER JOIN leave_status ON leave_status=leave_status_id) "
				+ "WHERE leave_app_tbl_emp_id="+employee_id+" AND leave_app_tbl_from_date > CURDATE() "
				+ "AND leave_status <> 5 AND leave_status <> 4 "
				+ "UNION "
				+ "SELECT leave_app_tbl_from_date,leave_app_tbl_to_date,(SELECT 'LOP' AS leavetype_name),leave_app_tbl_total_days,"
				+ "leave_app_tbl_lop_days,leave_app_tbl_reason,leave_status.leave_status_name,leave_app_tbl_id "
				+ "FROM hrmis_leave_application_tbl "
				+ "INNER JOIN leave_status ON leave_status=leave_status_id "
				+ "WHERE leave_app_tbl_emp_id="+employee_id+" AND leave_app_tbl_leave_type = 0 "
				+ "AND leave_app_tbl_from_date > CURDATE() AND leave_status <> 5 AND leave_status <> 4 ",
				new RowMapper<EmployeeLeaveBean>() {
					public EmployeeLeaveBean mapRow(ResultSet rs, int row) throws SQLException {
						EmployeeLeaveBean empleaveobject = new EmployeeLeaveBean();
						empleaveobject.setLeave_app_tbl_from_date(rs.getDate(1));
						empleaveobject.setLeave_app_tbl_to_date(rs.getDate(2));
						empleaveobject.setLeavetype_name(rs.getString(3));
						empleaveobject.setLeave_app_tbl_total_days(rs.getInt(4));
						empleaveobject.setLeave_app_tbl_lop_days(rs.getInt(5));
						empleaveobject.setLeave_app_tbl_reason(rs.getString(6));
						empleaveobject.setLeave_status_name(rs.getString(7));
						empleaveobject.setLeave_app_tbl_id(rs.getInt(8));
						return empleaveobject;
					}
				});
	}
	
	public int approveLeave(EmployeeLeaveBean empleave,int user_id) {
		int employee_id = empleave.getLeave_app_tbl_emp_id();
		int approver_id = empleave.getLeave_app_tbl_approver_id();
		int approver_level = empleave.getLeave_application_tbl_appr_lvl();
		int next_approver_level = approver_level+1;
		String next_approver_sql = "call hrmis.getApproverinAnyLevel(?,?);";
		int next_approver_id = template.queryForObject(next_approver_sql, new Object[] { employee_id,next_approver_level }, Integer.class);
		if(next_approver_id == 0) {
			String approved_sql = "UPDATE hrmis_leave_application_tbl SET leave_status = 3,"
					+ "leave_app_tbl_updated_by = "+user_id+",leave_app_tbl_updated_by_date = '"+current_date+"' "
					+ "WHERE leave_app_tbl_id = "+empleave.getLeave_app_tbl_id();
			int flag = template.update(approved_sql);
			if(flag == 0) {
				return 0;
			}
			else {
				String sql = "insert into hrmis_leave_history_tbl(leave_history_tbl_app_id, leave_history_tbl_from_date, "
						+ "leave_history_tbl_to_date, leave_history_tbl_totaldays, leave_history_tbl_lop_days, leave_history_tbl_reason, "
						+ "leave_history_tbl_status,leave_history_tbl_type, leave_history_tbl_approver_emp_id, leave_history_tbl_emp_id,"
						+ "leave_history_tbl_comment,createdBy,createdDate,leave_history_lop_flag) "
						+ "values("+empleave.getLeave_app_tbl_id()+",'"
						+ empleave.getLeave_app_tbl_from_date() + "','" + empleave.getLeave_app_tbl_to_date() + "','"
						+ empleave.getLeave_app_tbl_total_days() + "','" + empleave.getLeave_app_tbl_lop_days() + "','"
						+ empleave.getLeave_app_tbl_reason() + "','" + 3 + "','" + empleave.getLeave_app_tbl_leave_type()
						+ "',"+approver_id+",'" + employee_id + "','"+empleave.getLeave_history_tbl_comment()+"',"
						+user_id+",'"+current_date+"',"+empleave.getLop_flag()+")";
				return template.update(sql);
			}
		}
		else {
			String forward_request = "UPDATE hrmis_leave_application_tbl SET leave_application_tbl_appr_lvl = "
				+next_approver_level+",leave_app_tbl_approver_id = "+next_approver_id+","
				+ "leave_app_tbl_updated_by = "+user_id+",leave_app_tbl_updated_by_date = '"+current_date+"' "
				+ "WHERE leave_app_tbl_id = "+empleave.getLeave_app_tbl_id();
			int flag = template.update(forward_request);
			if(flag == 0) {
				return 0;
			}
			else {
				String sql = "insert into hrmis_leave_history_tbl(leave_history_tbl_app_id, leave_history_tbl_from_date, "
						+ "leave_history_tbl_to_date, leave_history_tbl_totaldays, leave_history_tbl_lop_days, leave_history_tbl_reason, "
						+ "leave_history_tbl_status,leave_history_tbl_type, leave_history_tbl_approver_emp_id, leave_history_tbl_emp_id,"
						+ "leave_history_tbl_comment,createdBy,createdDate,leave_history_lop_flag) "
						+ "values("+empleave.getLeave_app_tbl_id()+",'"
						+ empleave.getLeave_app_tbl_from_date() + "','" + empleave.getLeave_app_tbl_to_date() + "','"
						+ empleave.getLeave_app_tbl_total_days() + "','" + empleave.getLeave_app_tbl_lop_days() + "','"
						+ empleave.getLeave_app_tbl_reason() + "','" + 3 + "','" + empleave.getLeave_app_tbl_leave_type()
						+ "',"+approver_id+",'" + employee_id + "','"+empleave.getLeave_history_tbl_comment()+"',"
						+user_id+",'"+current_date+"',"+empleave.getLop_flag()+")";
				int i = template.update(sql);
				if(i == 0) {
					return 0;
				}
				else {
					return 2;
				}
			}
		}
	}
	
	public int rejectLeave(EmployeeLeaveBean empleave,int user_id) {
		int employee_id = empleave.getLeave_app_tbl_emp_id();
		int approver_id = empleave.getLeave_app_tbl_approver_id();
		String rejected_sql = "UPDATE hrmis_leave_application_tbl SET leave_status = 4,"
				+ "leave_app_tbl_updated_by = "+user_id+",leave_app_tbl_updated_by_date = '"+current_date+"'  "
				+ "WHERE leave_app_tbl_id = "+empleave.getLeave_app_tbl_id();
		int flag = template.update(rejected_sql);
		if(flag == 0) {
			return 0;
		}
		else {
			String sql = "insert into hrmis_leave_history_tbl(leave_history_tbl_app_id, leave_history_tbl_from_date, "
					+ "leave_history_tbl_to_date, leave_history_tbl_totaldays, leave_history_tbl_lop_days, leave_history_tbl_reason, "
					+ "leave_history_tbl_status,leave_history_tbl_type, leave_history_tbl_approver_emp_id, leave_history_tbl_emp_id,"
					+ "leave_history_tbl_comment,createdBy,createdDate,leave_history_lop_flag) "
					+ "values("+empleave.getLeave_app_tbl_id()+",'"
					+ empleave.getLeave_app_tbl_from_date() + "','" + empleave.getLeave_app_tbl_to_date() + "','"
					+ empleave.getLeave_app_tbl_total_days() + "','" + empleave.getLeave_app_tbl_lop_days() + "','"
					+ empleave.getLeave_app_tbl_reason() + "','" + 4 + "','" + empleave.getLeave_app_tbl_leave_type()
					+ "',"+approver_id+",'" + employee_id + "','"+empleave.getLeave_history_tbl_comment()+"',"
					+user_id+",'"+current_date+"',"+empleave.getLop_flag()+")";
			return template.update(sql);
		}
	}
	
	public int cancelLeave(EmployeeLeaveBean empleave,int user_id) {
		int leave_app_tbl_id = empleave.getLeave_app_tbl_id();
		int employee_id = empleave.getLeave_app_tbl_emp_id();
		int approver_id = empleave.getLeave_app_tbl_approver_id();
		String cancelled_sql = "UPDATE hrmis_leave_application_tbl SET leave_status = 5,"
				+ "leave_app_tbl_updated_by = "+user_id+",leave_app_tbl_updated_by_date = '"+current_date+"'  "
				+ "WHERE leave_app_tbl_id = "+leave_app_tbl_id;
		int flag = template.update(cancelled_sql);
		String cancel_history = "insert into hrmis_leave_history_tbl(leave_history_tbl_app_id, leave_history_tbl_from_date, "
				+ "leave_history_tbl_to_date, leave_history_tbl_totaldays, leave_history_tbl_lop_days, leave_history_tbl_reason, "
				+ "leave_history_tbl_status,leave_history_tbl_type, leave_history_tbl_approver_emp_id, leave_history_tbl_emp_id,"
				+ "createdBy,createdDate,leave_history_lop_flag) "
				+ "values("+empleave.getLeave_app_tbl_id()+",'"
				+ empleave.getLeave_app_tbl_from_date() + "','" + empleave.getLeave_app_tbl_to_date() + "','"
				+ empleave.getLeave_app_tbl_total_days() + "','" + empleave.getLeave_app_tbl_lop_days() + "','"
				+ empleave.getLeave_app_tbl_reason() + "','" + 4 + "','" + empleave.getLeave_app_tbl_leave_type()
				+ "',"+approver_id+",'" + employee_id + "',"+user_id+",'"+current_date+"',"+empleave.getLop_flag()+")";
		flag = template.update(cancel_history);
		return flag;
	}

	public List<EmployeeLeaveBean> getApproveHistory(int leave_app_tbl_id) {
		return template.query("SELECT leave_history_tbl_comment,employee.employee_name,hrmis_leave_history_tbl.createdDate,"
				+ "employee.employee_id "
				+ "FROM hrmis_leave_history_tbl "
				+ "INNER JOIN employee ON leave_history_tbl_approver_emp_id = employee.employee_id "
				+ "WHERE leave_history_tbl_app_id="+leave_app_tbl_id+" "
				+ "AND leave_history_tbl_status=3;", new RowMapper<EmployeeLeaveBean>() {
			public EmployeeLeaveBean mapRow(ResultSet rs, int row) throws SQLException {
				EmployeeLeaveBean empleave = new EmployeeLeaveBean();
				empleave.setLeave_history_tbl_comment(rs.getString(1));
				empleave.setEmp_tbl_name(rs.getString(2));
				empleave.setCreatedDate(rs.getDate(3));
				empleave.setLeave_app_tbl_approver_id(rs.getInt(4));
				return empleave;
			}
		});
	}

	public List<EmployeeLeaveBean> getLeaveEmployees(int flag,int employee_id) {
		if(flag == 1) {
			return template.query("SELECT employee_name,employee_id FROM employee "
					+ "WHERE is_deleted=0 AND admin_flag=0", new RowMapper<EmployeeLeaveBean>() {
				public EmployeeLeaveBean mapRow(ResultSet rs, int row) throws SQLException {
					EmployeeLeaveBean empleave = new EmployeeLeaveBean();
					empleave.setEmp_tbl_name(rs.getString(1));
					empleave.setLeave_app_tbl_emp_id(rs.getInt(2));
					return empleave;
				}
			});
		}
		else if(flag == 2) {
			return template.query("SELECT approver_tbl.employee_id,employee.employee_name "
					+ "FROM approver_tbl INNER JOIN employee ON approver_tbl.employee_id = employee.employee_id "
					+ "WHERE approver_emp_id="+employee_id+" AND approver_isdeleted = 0 "
					+ "UNION SELECT employee_id,employee_name "
					+ "FROM employee WHERE employee_id="+employee_id+" AND employee.is_deleted=0", new RowMapper<EmployeeLeaveBean>() {
				public EmployeeLeaveBean mapRow(ResultSet rs, int row) throws SQLException {
					EmployeeLeaveBean empleave = new EmployeeLeaveBean();
					empleave.setLeave_app_tbl_emp_id(rs.getInt(1));
					empleave.setEmp_tbl_name(rs.getString(2));
					return empleave;
				}
			});
		}
		else {
			return template.query("SELECT employee_id,employee_name "
					+ "FROM employee WHERE employee_id="+employee_id+" "
					+ "AND employee.is_deleted = 0", new RowMapper<EmployeeLeaveBean>() {
				public EmployeeLeaveBean mapRow(ResultSet rs, int row) throws SQLException {
					EmployeeLeaveBean empleave = new EmployeeLeaveBean();
					empleave.setLeave_app_tbl_emp_id(rs.getInt(1));
					empleave.setEmp_tbl_name(rs.getString(2));
					return empleave;
				}
			});
		}
	}

	public List<EmployeeLeaveBean> getLoadLeaveHistory(EmployeeLeaveBean empleavebeanobj) {
		String from_date = empleavebeanobj.getFrom_month()+"-01";
		String to_date = empleavebeanobj.getTo_month()+"-31";
		String sql = "SELECT leave_app_tbl_id,leave_app_tbl_from_date,leave_app_tbl_to_date,"
				+ "leavetype_name,leave_app_tbl_total_days,leave_app_tbl_reason,"
				+ "leave_status.leave_status_name "
				+ "FROM ((hrmis_leave_application_tbl INNER JOIN leavetype_tbl ON leave_app_tbl_leave_type = leavetype_id) "
				+ "INNER JOIN leave_status ON leave_status=leave_status_id) "
				+ "WHERE leave_app_tbl_emp_id="+empleavebeanobj.getLeave_app_tbl_emp_id()+" "
				+ "AND leave_app_tbl_from_date BETWEEN '"+from_date+"' AND '"+to_date+"' "
				+ "UNION "
				+ "SELECT leave_app_tbl_id,leave_app_tbl_from_date,leave_app_tbl_to_date,"
				+"(SELECT 'LOP' AS leavetype_name),leave_app_tbl_total_days,leave_app_tbl_reason,"
				+"leave_status.leave_status_name "
				+"FROM hrmis_leave_application_tbl "
				+"INNER JOIN leave_status ON leave_status=leave_status_id "
				+"WHERE leave_app_tbl_emp_id="+empleavebeanobj.getLeave_app_tbl_emp_id()+" AND leave_application_lop_flag = 1 "
				+"AND leave_app_tbl_from_date BETWEEN '"+from_date+"' AND '"+to_date+"'";
		return template.query(sql, new RowMapper<EmployeeLeaveBean>() {
			public EmployeeLeaveBean mapRow(ResultSet rs, int row) throws SQLException {
				EmployeeLeaveBean empleave = new EmployeeLeaveBean();
				empleave.setLeave_app_tbl_id(rs.getInt(1));
				empleave.setLeave_app_tbl_from_date(rs.getDate(2));
				empleave.setLeave_app_tbl_to_date(rs.getDate(3));
				empleave.setLeavetype_name(rs.getString(4));
				empleave.setLeave_app_tbl_total_days(rs.getInt(5));
				empleave.setLeave_app_tbl_reason(rs.getString(6));
				empleave.setLeave_status_name(rs.getString(7));
				return empleave;
			}
		});
	}

	public List<EmployeeLeaveBean> getLoadLeaveReport(EmployeeLeaveBean empleavebeanobj) {
		int employee_id = empleavebeanobj.getLeave_app_tbl_emp_id();
		String from_date = empleavebeanobj.getFrom_month()+"-01";
		String to_date = empleavebeanobj.getTo_month()+"-31";
		Date from = Date.valueOf(from_date);
		Date to = Date.valueOf(to_date);
		String sql = "call hrmis.get_monthwise("+employee_id+",'"+from+"','"+to+"')";
		System.out.println(sql);
		return template.query(sql, new RowMapper<EmployeeLeaveBean>() {
			public EmployeeLeaveBean mapRow(ResultSet rs, int row) throws SQLException {
				System.out.println("hii");
				EmployeeLeaveBean empleave = new EmployeeLeaveBean();
				empleave.setFrom_month(rs.getString(1));
				empleave.setLeave_app_tbl_total_days(rs.getInt(2));
				empleave.setEmp_tbl_name(rs.getString(3));
				empleave.setLeavetype_name(rs.getString(4));
				return empleave;
			}
		});
	}
	
	public int getAvailableLeaves(int employee_id,int leave_type_id,String year) {
		String toatal_available_sql = "SELECT no_of_days FROM leaveallocation_tbl "
				+ "WHERE leaveallocation_emp_id = "+employee_id+" AND leaveallocation_type_id = "+leave_type_id+" "
				+ "AND current_year="+year+" AND is_deleted = 0 LIMIT 1";
		try {
			int toatal_available = template.queryForObject(toatal_available_sql, Integer.class);
			String total_used_sql = "call hrmis.totalAppliedLeaves("+employee_id+","+leave_type_id+")";
			int total_used = template.queryForObject(total_used_sql, Integer.class);
			int available = toatal_available - total_used;
			return available;
		}
		catch(Exception e) {
			return 0;
		}
	}
	
	
	public List<EmployeeLeaveBean> getApproveListForHr(int approver_id) {
		return template.query(
				"SELECT hrmis_leave_application_tbl.leave_app_tbl_id,leave_app_tbl_from_date, "
				+ "hrmis_leave_application_tbl.leave_app_tbl_to_date, hrmis_leave_application_tbl.leave_app_tbl_emp_id, "
				+ "hrmis_leave_application_tbl.leave_app_tbl_approver_id, leave_app_tbl_total_days, "
				+ "hrmis_leave_application_tbl.leave_app_tbl_lop_days, "
				+ "hrmis_leave_application_tbl.leave_app_tbl_reason,employee.employee_name,leavetype_tbl.leavetype_name "
				+ "FROM hrmis_leave_application_tbl,employee,leavetype_tbl "
				+ "WHERE employee.employee_id=hrmis_leave_application_tbl.leave_app_tbl_emp_id "
				+ "AND hrmis_leave_application_tbl.leave_app_tbl_leave_type = leavetype_tbl.leavetype_id "
				+ "AND hrmis_leave_application_tbl.leave_app_tbl_approver_id<>"+approver_id+" "
				+ "AND hrmis_leave_application_tbl.leave_app_tbl_isdeleted=0 "
				+ "AND hrmis_leave_application_tbl.leave_status = 2 "
				+ "UNION "
				+ "SELECT hrmis_leave_application_tbl.leave_app_tbl_id,leave_app_tbl_from_date, "
				+ "hrmis_leave_application_tbl.leave_app_tbl_to_date, hrmis_leave_application_tbl.leave_app_tbl_emp_id, "
				+ "hrmis_leave_application_tbl.leave_app_tbl_approver_id, leave_app_tbl_total_days, "
				+ "hrmis_leave_application_tbl.leave_app_tbl_lop_days, "
				+ "hrmis_leave_application_tbl.leave_app_tbl_reason,employee.employee_name,(SELECT 'LOP' AS leavetype_name) "
				+ "FROM hrmis_leave_application_tbl,employee "
				+ "WHERE employee.employee_id=hrmis_leave_application_tbl.leave_app_tbl_emp_id "
				+ "AND leave_app_tbl_leave_type = 0 "
				+ "AND hrmis_leave_application_tbl.leave_app_tbl_approver_id<>"+approver_id+" "
				+ "AND hrmis_leave_application_tbl.leave_app_tbl_isdeleted=0 "
				+ "AND hrmis_leave_application_tbl.leave_status = 2",
				new RowMapper<EmployeeLeaveBean>() {
					public EmployeeLeaveBean mapRow(ResultSet rs, int row) throws SQLException {
						EmployeeLeaveBean empleaveobject = new EmployeeLeaveBean();
						empleaveobject.setLeave_app_tbl_id(rs.getInt(1));
						empleaveobject.setLeave_app_tbl_from_date(rs.getDate(2));
						empleaveobject.setLeave_app_tbl_to_date(rs.getDate(3));
						empleaveobject.setLeave_app_tbl_total_days(rs.getInt(6));
						empleaveobject.setLeave_app_tbl_lop_days(rs.getInt(7));
						empleaveobject.setLeave_app_tbl_reason(rs.getString(8));
						empleaveobject.setEmp_tbl_name(rs.getString(9));
						empleaveobject.setLeavetype_name(rs.getString(10));
						return empleaveobject;
					}
				});
	}
}
