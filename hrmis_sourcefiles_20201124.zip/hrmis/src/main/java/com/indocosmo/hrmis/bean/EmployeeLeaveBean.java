/**
 * 
 * this is a bean class for leave apply,reject,cancel,accept and leave history,leave reports operations
 */
package com.indocosmo.hrmis.bean;

import java.sql.Date;

public class EmployeeLeaveBean 
{
	int leave_app_tbl_id, leave_app_tbl_emp_id, leave_app_tbl_approver_id, leave_app_tbl_total_days,
	leave_app_tbl_lop_days,leave_history_tbl_id,leave_history_tbl_type,leave_app_tbl_leave_type;
	Date leave_app_tbl_from_date, leave_app_tbl_to_date, createdDate;
	String leave_app_tbl_reason,emp_tbl_name,leave_history_tbl_comment,createdBy,leavetype_name;
	int leave_application_tbl_appr_lvl;
	int leave_status,lop_flag;
	String leave_status_name;
	String from_month,to_month,available_leaves;
	
	public String getAvailable_leaves() {
		return available_leaves;
	}
	public void setAvailable_leaves(String available_leaves) {
		this.available_leaves = available_leaves;
	}
	public int getLeave_app_tbl_id() {
		return leave_app_tbl_id;
	}
	public void setLeave_app_tbl_id(int leave_app_tbl_id) {
		this.leave_app_tbl_id = leave_app_tbl_id;
	}
	public int getLeave_app_tbl_emp_id() {
		return leave_app_tbl_emp_id;
	}
	public void setLeave_app_tbl_emp_id(int leave_app_tbl_emp_id) {
		this.leave_app_tbl_emp_id = leave_app_tbl_emp_id;
	}
	public int getLeave_app_tbl_approver_id() {
		return leave_app_tbl_approver_id;
	}
	public void setLeave_app_tbl_approver_id(int leave_app_tbl_approver_id) {
		this.leave_app_tbl_approver_id = leave_app_tbl_approver_id;
	}
	public int getLeave_app_tbl_total_days() {
		return leave_app_tbl_total_days;
	}
	public void setLeave_app_tbl_total_days(int leave_app_tbl_total_days) {
		this.leave_app_tbl_total_days = leave_app_tbl_total_days;
	}
	public int getLeave_app_tbl_lop_days() {
		return leave_app_tbl_lop_days;
	}
	public void setLeave_app_tbl_lop_days(int leave_app_tbl_lop_days) {
		this.leave_app_tbl_lop_days = leave_app_tbl_lop_days;
	}
	public Date getLeave_app_tbl_from_date() {
		return leave_app_tbl_from_date;
	}
	public void setLeave_app_tbl_from_date(Date leave_app_tbl_from_date) {
		this.leave_app_tbl_from_date = leave_app_tbl_from_date;
	}
	public Date getLeave_app_tbl_to_date() {
		return leave_app_tbl_to_date;
	}
	public void setLeave_app_tbl_to_date(Date leave_app_tbl_to_date) {
		this.leave_app_tbl_to_date = leave_app_tbl_to_date;
	}
	public String getLeave_app_tbl_reason() {
		return leave_app_tbl_reason;
	}
	public void setLeave_app_tbl_reason(String leave_app_tbl_reason) {
		this.leave_app_tbl_reason = leave_app_tbl_reason;
	}
	public String getEmp_tbl_name() {
		return emp_tbl_name;
	}
	public void setEmp_tbl_name(String emp_tbl_name) {
		this.emp_tbl_name = emp_tbl_name;
	}
	public String getLeave_history_tbl_comment() {
		return leave_history_tbl_comment;
	}
	public void setLeave_history_tbl_comment(String leave_history_tbl_comment) {
		this.leave_history_tbl_comment = leave_history_tbl_comment;
	}
	public int getLeave_application_tbl_appr_lvl() {
		return leave_application_tbl_appr_lvl;
	}
	public void setLeave_application_tbl_appr_lvl(int leave_application_tbl_appr_lvl) {
		this.leave_application_tbl_appr_lvl = leave_application_tbl_appr_lvl;
	}
	public int getLeave_status() {
		return leave_status;
	}
	public void setLeave_status(int leave_status) {
		this.leave_status = leave_status;
	}
	public String getLeave_status_name() {
		return leave_status_name;
	}
	public void setLeave_status_name(String leave_status_name) {
		this.leave_status_name = leave_status_name;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getFrom_month() {
		return from_month;
	}
	public void setFrom_month(String from_month) {
		this.from_month = from_month;
	}
	public String getTo_month() {
		return to_month;
	}
	public void setTo_month(String to_month) {
		this.to_month = to_month;
	}
	public int getLeave_history_tbl_id() {
		return leave_history_tbl_id;
	}
	public void setLeave_history_tbl_id(int leave_history_tbl_id) {
		this.leave_history_tbl_id = leave_history_tbl_id;
	}
	public int getLeave_history_tbl_type() {
		return leave_history_tbl_type;
	}
	public void setLeave_history_tbl_type(int leave_history_tbl_type) {
		this.leave_history_tbl_type = leave_history_tbl_type;
	}
	public int getLeave_app_tbl_leave_type() {
		return leave_app_tbl_leave_type;
	}
	public void setLeave_app_tbl_leave_type(int leave_app_tbl_leave_type) {
		this.leave_app_tbl_leave_type = leave_app_tbl_leave_type;
	}
	public String getLeavetype_name() {
		return leavetype_name;
	}
	public void setLeavetype_name(String leavetype_name) {
		this.leavetype_name = leavetype_name;
	}
	public int getLop_flag() {
		return lop_flag;
	}
	public void setLop_flag(int lop_flag) {
		this.lop_flag = lop_flag;
	}
	
	

}
