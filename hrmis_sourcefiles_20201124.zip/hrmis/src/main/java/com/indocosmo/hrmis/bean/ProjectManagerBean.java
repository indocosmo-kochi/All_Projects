/**
 * 
 */
package com.indocosmo.hrmis.bean;

/**
 * @author Ayana P Dharman 
 * 
 * @version 0.0.1 09 July 2020
 *
 */
public class ProjectManagerBean {
	
	private int manager_id,project_id;
	private String manager_name;
	public int getManager_id() {
		return manager_id;
	}
	public void setManager_id(int manager_id) {
		this.manager_id = manager_id;
	}
	public int getProject_id() {
		return project_id;
	}
	public void setProject_id(int project_id) {
		this.project_id = project_id;
	}
	public String getManager_name() {
		return manager_name;
	}
	public void setManager_name(String manager_name) {
		this.manager_name = manager_name;
	}
	
	
	

}
