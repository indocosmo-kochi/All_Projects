/**
 * 
 */
package com.indocosmo.hrmis.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;

import com.indocosmo.hrmis.bean.LeaveAllocationBean;
import com.indocosmo.hrmis.bean.EmployeeBean;
import com.indocosmo.hrmis.bean.LeaveAllocationBean;
import com.indocosmo.hrmis.bean.LeaveTypeBean;
import com.indocosmo.hrmis.bean.LocationBean;
import com.indocosmo.hrmis.bean.ProfessionBean;

/**
 * @author Ayana P Dharman
 *
 * @version 0.0.1 May 24, 2020
 */
//-----Leave Allocation DAO -------
public class LeaveAllocationDAO {

	JdbcTemplate jdbc_template;

	public void setTemplate(JdbcTemplate jdbc_template) {
		this.jdbc_template = jdbc_template;
	}

	public List<LocationBean> getLocations() {
		return jdbc_template.query("SELECT * FROM location WHERE is_deleted=0", new RowMapper<LocationBean>() {
			public LocationBean mapRow(ResultSet rs, int row) throws SQLException {
				LocationBean location_bean_object = new LocationBean();
				location_bean_object.setLocation_id(rs.getInt(1));
				location_bean_object.setLocation_name(rs.getString(2));
				return location_bean_object;
			}
		});
	}

	public List<LeaveTypeBean> getLeaveType() {
		return jdbc_template.query("SELECT * FROM leavetype_tbl WHERE leavetype_isdeleted=0",
				new RowMapper<LeaveTypeBean>() {
					public LeaveTypeBean mapRow(ResultSet rs, int row) throws SQLException {
						LeaveTypeBean leavetype_bean_object = new LeaveTypeBean();
						leavetype_bean_object.setLeavetype_id(rs.getInt(1));
						leavetype_bean_object.setLeavetype_name(rs.getString(2));
						leavetype_bean_object.setLeavetype_location(rs.getString(3));
						leavetype_bean_object.setSchedular_type(rs.getString(4));
						leavetype_bean_object.setCarry_forward_status(rs.getString(5));
						leavetype_bean_object.setLeaves_per_year(rs.getInt(6));
						return leavetype_bean_object;
					}
				});
	}

	public List<EmployeeBean> getEmployees() { // To show every employees as a table
		return jdbc_template.query("SELECT * FROM employee WHERE is_deleted=0", new RowMapper<EmployeeBean>() {
			public EmployeeBean mapRow(ResultSet rs, int row) throws SQLException {
				EmployeeBean employee_bean_object = new EmployeeBean();
				employee_bean_object.setEmployee_id(rs.getInt(1));
				employee_bean_object.setEmployee_code(rs.getString(2));
				employee_bean_object.setEmployee_name(rs.getString(3));
				employee_bean_object.setLocation(rs.getInt(4));
				employee_bean_object.setDate_of_appointment(rs.getDate(6));
				employee_bean_object.setPersonal_phone(rs.getString(7));
				employee_bean_object.setEmail_id_personal(rs.getString(8));
				employee_bean_object.setEmail_id_official(rs.getString(9));
				employee_bean_object.setPf_uan(rs.getString(10));
				employee_bean_object.setEsi_num(rs.getString(11));
				employee_bean_object.setStatus(rs.getString(17));
				employee_bean_object.setClient(rs.getInt(18));
				return employee_bean_object;
			}
		});
	}

	public List<LeaveAllocationBean> getleaveallocations() {
		return jdbc_template.query("SELECT * FROM leaveallocation_tbl WHERE is_deleted=0",
				new RowMapper<LeaveAllocationBean>() {
					public LeaveAllocationBean mapRow(ResultSet rs, int row) throws SQLException {
						LeaveAllocationBean leaveallocation_bean_object = new LeaveAllocationBean();
						leaveallocation_bean_object.setLeaveallocation_id(rs.getInt(1));
						leaveallocation_bean_object.setEmployee_name(rs.getString(2));
						leaveallocation_bean_object.setLeavetype_name(rs.getString(3));
						leaveallocation_bean_object.setLocation_name(rs.getString(4));
						leaveallocation_bean_object.setCurrent_year(rs.getString(5));
						leaveallocation_bean_object.setNo_of_days(rs.getInt(6));
						leaveallocation_bean_object.setLeave_status(rs.getString(6));

						return leaveallocation_bean_object;
					}
				});
	}

	public int deleteLeaveAllocation(String leaveallocation_id) {
		String sql = "UPDATE leaveallocation_tbl SET is_deleted=1 WHERE leaveallocation_id='" + leaveallocation_id
				+ "'";
		return jdbc_template.update(sql);
	}

	public LeaveAllocationBean getleaveallocationById(int leaveallocation_id) {
		String sql = "select * from leaveallocation_tbl where leaveallocation_id=?";
		return jdbc_template.queryForObject(sql, new Object[] { leaveallocation_id },
				new BeanPropertyRowMapper<LeaveAllocationBean>(LeaveAllocationBean.class));
	}

	public int leaveallocationupdate(LeaveAllocationBean leaveallocation, String leavetype_name) {
		String sql = "update leaveallocation_tbl set leavetype_name='" + leavetype_name + "',no_of_days='"
				+ leaveallocation.getNo_of_days() + "' where leaveallocation_id='"
				+ leaveallocation.getLeaveallocation_id() + "'";
		return jdbc_template.update(sql);

	}

	public List<LeaveTypeBean> getleavetype() {
		return jdbc_template.query("select * from leavetype_tbl where leavetype_isdeleted=0",
				new RowMapper<LeaveTypeBean>() {
					public LeaveTypeBean mapRow(ResultSet rs, int row) throws SQLException {
						LeaveTypeBean e = new LeaveTypeBean();
						e.setLeavetype_id(rs.getInt(1));
						e.setLeavetype_name(rs.getString(2));
						e.setLeavetype_location(rs.getString(3));
						e.setSchedular_type(rs.getString(4));
						e.setCarry_forward_status(rs.getString(5));
						e.setLeaves_per_year(rs.getInt(6));

						return e;
					}
				});
	}

	public List<LeaveAllocationBean> getEmployeesByLocation(String location_name, String current_year) {
		return jdbc_template.query("SELECT * FROM leaveallocation_tbl WHERE is_deleted=0 AND location_name='"
				+ location_name + "' AND current_year='" + current_year + "'", new RowMapper<LeaveAllocationBean>() {
					public LeaveAllocationBean mapRow(ResultSet rs, int row) throws SQLException {
						LeaveAllocationBean leaveallocation_bean_object = new LeaveAllocationBean();
						leaveallocation_bean_object.setLeaveallocation_id(rs.getInt(1));
						leaveallocation_bean_object.setEmployee_name(rs.getString(2));
						leaveallocation_bean_object.setLeavetype_name(rs.getString(3));
						leaveallocation_bean_object.setLocation_name(rs.getString(4));
						leaveallocation_bean_object.setCurrent_year(rs.getString(5));
						leaveallocation_bean_object.setNo_of_days(rs.getInt(6));
						leaveallocation_bean_object.setLeave_status(rs.getString(7));
						return leaveallocation_bean_object;
					}
				});
	}

	public LeaveTypeBean getleavetypeByName(String leavetype_name) {
		String sql = "select * from leavetype_tbl where leavetype_name=? and leavetype_isdeleted=0";
		return jdbc_template.queryForObject(sql, new Object[] { leavetype_name },
				new BeanPropertyRowMapper<LeaveTypeBean>(LeaveTypeBean.class));
	}

	public int AllocateLeaveInsert(final LeaveAllocationBean leaveallocation_bean_object, ArrayList employee_list,
			String leavetype_name) {
		int flag = 0;

		int[] employee_id_array = leaveallocation_bean_object.getLeaveallocation_emp_id_array();

		for (int i = 0; i < employee_list.size(); i++) {

			String sql1 = "select count(distinct leaveallocation_emp_id,leaveallocation_type_id,current_year) from leaveallocation_tbl where employee_name='"
					+ employee_list.get(i) + "' and leaveallocation_type_id='"
					+ leaveallocation_bean_object.getLeaveallocation_type_id() + "' and current_year='"
					+ leaveallocation_bean_object.getCurrent_year() + "'";
			String count = jdbc_template.queryForObject(sql1, new Object[] {}, String.class);
			int countvalue = Integer.parseInt(count);
			if (countvalue == 0) {

				String sql = "INSERT INTO leaveallocation_tbl (employee_name,leavetype_name,location_name,current_year,no_of_days,leave_status,leaveallocation_emp_id,leaveallocation_type_id) VALUES ('"
						+ employee_list.get(i) + "','" + leavetype_name + "','"
						+ leaveallocation_bean_object.getLocation_name() + "','"
						+ leaveallocation_bean_object.getCurrent_year() + "','"
						+ leaveallocation_bean_object.getNo_of_days() + "',' Allocate ','" + employee_id_array[i]
						+ "','" + leaveallocation_bean_object.getLeaveallocation_type_id() + "')";
				flag = jdbc_template.update(sql);
			}
		}
		System.out.println(flag);

		return flag;
	}

	public ArrayList<String> getEmployeeNames(LeaveAllocationBean leaveallocation) {

		int[] employee_id_list = leaveallocation.getLeaveallocation_emp_id_array();
		ArrayList<String> employee_name_list = new ArrayList<String>();

		for (int i = 0; i < employee_id_list.length; i++) {

			String sql = "Select employee_name from employee where employee_id=" + employee_id_list[i];
			String name = jdbc_template.queryForObject(sql, new Object[] {}, String.class);
			employee_name_list.add(name);

		}
		return employee_name_list;
	}

	public String getleavetypeName(int leaveallocation_type_id) {
		String sql = "Select leavetype_name from leavetype_tbl where leavetype_id=" + leaveallocation_type_id;
		String name = jdbc_template.queryForObject(sql, new Object[] {}, String.class);
		return name;
	}

}
