package com.indocosmo.hrmis.bean;

import java.sql.Date;

/**
 * @author Ayana P Dharman
 *
 * @version 0.0.1 Mar 5, 2020
 */
public class LoginBean {
	
	private String employee_code,designation_name;
	private String employee_name,status;
	private int location;
	private int designation,designation_id,employee_id,client;
	private int isApprover;
	public String getDesignation_name() {
		return designation_name;
	}
	public void setDesignation_name(String designation_name) {
		this.designation_name = designation_name;
	}
	public int getDesignation_id() {
		return designation_id;
	}
	public void setDesignation_id(int designation_id) {
		this.designation_id = designation_id;
	}
	private String email_id_personal;
	private String email_id_official;
	private String personal_phone;
	private String pf_uan;
	private String esi_num;
	private String father_or_spouse_name;
	private String employee_address;
	private Date date_of_birth;
	private String blood_group;
	private String password;
	private int admin_flag;
	private String current_password,new_password;
	
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	public int getLocation() {
		return location;
	}
	public void setLocation(int location) {
		this.location = location;
	}
	public int getDesignation() {
		return designation;
	}
	public void setDesignation(int designation) {
		this.designation = designation;
	}
	public String getEmail_id_personal() {
		return email_id_personal;
	}
	public void setEmail_id_personal(String email_id_personal) {
		this.email_id_personal = email_id_personal;
	}
	public String getEmail_id_official() {
		return email_id_official;
	}
	public void setEmail_id_official(String email_id_official) {
		this.email_id_official = email_id_official;
	}
	public String getPersonal_phone() {
		return personal_phone;
	}
	public void setPersonal_phone(String personal_phone) {
		this.personal_phone = personal_phone;
	}
	public String getPf_uan() {
		return pf_uan;
	}
	public void setPf_uan(String pf_uan) {
		this.pf_uan = pf_uan;
	}
	public String getEsi_num() {
		return esi_num;
	}
	public void setEsi_num(String esi_num) {
		this.esi_num = esi_num;
	}
	public String getFather_or_spouse_name() {
		return father_or_spouse_name;
	}
	public void setFather_or_spouse_name(String father_or_spouse_name) {
		this.father_or_spouse_name = father_or_spouse_name;
	}
	public String getEmployee_address() {
		return employee_address;
	}
	public void setEmployee_address(String employee_address) {
		this.employee_address = employee_address;
	}
	public Date getDate_of_birth() {
		return date_of_birth;
	}
	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}
	public String getBlood_group() {
		return blood_group;
	}
	public void setBlood_group(String blood_group) {
		this.blood_group = blood_group;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmployee_code() {
		return employee_code;
	}
	public void setEmployee_code(String employee_code) {
		this.employee_code = employee_code;
	}
	public int getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public int getClient() {
		return client;
	}
	public void setClient(int client) {
		this.client = client;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getAdmin_flag() {
		return admin_flag;
	}
	public void setAdmin_flag(int admin_flag) {
		this.admin_flag = admin_flag;
	}
	public int getIsApprover() {
		return isApprover;
	}
	public void setIsApprover(int isApprover) {
		this.isApprover = isApprover;
	}
	public String getCurrent_password() {
		return current_password;
	}
	public void setCurrent_password(String current_password) {
		this.current_password = current_password;
	}
	public String getNew_password() {
		return new_password;
	}
	public void setNew_password(String new_password) {
		this.new_password = new_password;
	}
	


	
}
