package com.indocosmo.hrmis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.indocosmo.hrmis.bean.ClientBean;
import com.indocosmo.hrmis.bean.ClientProjectBean;
import com.indocosmo.hrmis.bean.HolidayBean;
import com.indocosmo.hrmis.dao.ClientDAO;
import com.indocosmo.hrmis.dao.ClientProjectDAO;
import com.indocosmo.hrmis.dao.HolidayDAO;

/**
 * @author Ayana P Dharman
 *
 * @version 0.0.1 Mar 5, 2020
 */
@Controller
public class ClientController {
	
	@Autowired
	ClientDAO daoclient;
	@Autowired
	HolidayDAO holiday_dao_object;
	@Autowired
	ClientProjectDAO daoclientproject;
	

	@RequestMapping("/client_list")
	public String viewclient(Model m) {
		List<ClientBean> list = daoclient.getclient();
		m.addAttribute("list", list);
		return "admin/employee/client_list";
	}

	@RequestMapping("add_client")
	public String client(Model model_object) {
		List<HolidayBean> holiday_list = holiday_dao_object.getHolidays();
		model_object.addAttribute("holiday_list", holiday_list);
		return "admin/employee/add_client";
	}

	@RequestMapping(value = "/clientsave", method = RequestMethod.POST)
	public String clientMasterSave(@ModelAttribute("client") ClientBean client) {
		daoclient.clientsave(client);
		return "redirect:/client_list";
	}

	@RequestMapping(value = "/deleteclient/{client_id}", method = RequestMethod.GET)
	public String deleteclient(@PathVariable int client_id) {
		daoclient.clientdelete(client_id);
		return "redirect:/client_list";
	}

	@RequestMapping(value = "/editclient/{client_id}")
	public String clientedit(@PathVariable int client_id, Model m) {
		List<HolidayBean> holiday_list = holiday_dao_object.getHolidays();
		m.addAttribute("holiday_list", holiday_list);
		List<ClientProjectBean> project_list = daoclientproject.getclientprojectById(client_id);
		m.addAttribute("project_list", project_list);
		ClientBean client = daoclient.getclientById(client_id);
		m.addAttribute("client", client);
		return "admin/employee/update_client";
	}

	/* It updates model object. */
	@RequestMapping(value = "/clienteditsave", method = RequestMethod.POST)
	public String clienteditsave(@ModelAttribute("client") ClientBean client) {

		daoclient.clientupdate(client);
		return "redirect:/client_list";
	}

	

}
