/**
 * 
 */
package com.indocosmo.hrmis.bean;



import org.springframework.web.multipart.MultipartFile;

/**
 * @author Ayana P Dharman
 * 
 * @version 0.0.1 22 June 2020
 *
 */
public class WorkReportBean {

	private int work_report_id, employee_id, location;
	private String uploaded_month;
	private MultipartFile files;
	private String employee_name, filename, upload_status;
	private String from_month,to_month;

	

	public String getFrom_month() {
		return from_month;
	}

	public void setFrom_month(String from_month) {
		this.from_month = from_month;
	}

	public String getTo_month() {
		return to_month;
	}

	public void setTo_month(String to_month) {
		this.to_month = to_month;
	}

	public int getEmployee_id() {
		return employee_id;
	}

	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public MultipartFile getFiles() {
		return files;
	}

	public void setFiles(MultipartFile files) {
		this.files = files;
	}

	public int getWork_report_id() {
		return work_report_id;
	}

	public void setWork_report_id(int work_report_id) {
		this.work_report_id = work_report_id;
	}

	public int getLocation() {
		return location;
	}

	public void setLocation(int location) {
		this.location = location;
	}

	public String getEmployee_name() {
		return employee_name;
	}

	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}

	public String getUpload_status() {
		return upload_status;
	}

	public void setUpload_status(String upload_status) {
		this.upload_status = upload_status;
	}

	public String getUploaded_month() {
		return uploaded_month;
	}

	public void setUploaded_month(String uploaded_month) {
		this.uploaded_month = uploaded_month;
	}

	

}
