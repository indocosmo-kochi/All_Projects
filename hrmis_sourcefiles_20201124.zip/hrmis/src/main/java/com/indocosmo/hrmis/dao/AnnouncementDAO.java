package com.indocosmo.hrmis.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.indocosmo.hrmis.bean.AnnouncementBean;

/**
 * @author Anandhapadmanabhan
 *
 * @version 0.0.1 Feb 29, 2020
 */

public class AnnouncementDAO {
	
	private JdbcTemplate template;
	public void setTemplate(JdbcTemplate template) {  
	    this.template = template;  
	} 
	public int save1(AnnouncementBean anc){
	    String sql="insert into hrmis_announcement_tbl(announcement_tbl_name, announcement_tbl_description, announcement_tbl_start_date, announcement_tbl_end_date, announcement_tbl_status) values('"+anc.getAnnouncement_tbl_name()+"','"+anc.getAnnouncement_tbl_description()+"','"+anc.getAnnouncement_tbl_start_date()+"','"+anc.getAnnouncement_tbl_end_date()+"','"+anc.getAnnouncement_tbl_status()+"')";  
	    return template.update(sql);  
	} 
	public int update1(AnnouncementBean anc){ 
	    String sql="update hrmis_announcement_tbl set announcement_tbl_name='"+anc.getAnnouncement_tbl_name()+"',announcement_tbl_description='"+anc.getAnnouncement_tbl_description()+"',announcement_tbl_start_date='"+anc.getAnnouncement_tbl_start_date()+"',announcement_tbl_end_date='"+anc.getAnnouncement_tbl_end_date()+"',announcement_tbl_status='"+anc.getAnnouncement_tbl_status()+"' where announcement_tbl_id='"+anc.getAnnouncement_tbl_id()+"'";  
	    return template.update(sql);  
	}  
	public int delete1(int id){  
	    String sql="update hrmis_announcement_tbl set isdeleted=1 where announcement_tbl_id='"+id+"'";  
	    return template.update(sql);  
	}  
	public AnnouncementBean getAnnouncementById(int announcement_tbl_id){  
	    String sql="select * from hrmis_announcement_tbl where announcement_tbl_id=? and isdeleted=0";  
	    return template.queryForObject(sql, new Object[]{announcement_tbl_id},new BeanPropertyRowMapper<AnnouncementBean>(AnnouncementBean.class));   
	} 
	public List<AnnouncementBean> getAnnouncement(){  
		return  template.query("select * from hrmis_announcement_tbl where isdeleted=0",new RowMapper<AnnouncementBean>(){  
	        public AnnouncementBean mapRow(ResultSet rs, int row) throws SQLException {  
	        	AnnouncementBean anc=new AnnouncementBean();  
	          anc.setAnnouncement_tbl_id(rs.getInt(1));
	          anc.setAnnouncement_tbl_name(rs.getString(2));
	          anc.setAnnouncement_tbl_description(rs.getString(3));
	          anc.setAnnouncement_tbl_start_date(rs.getDate(4));
	          anc.setAnnouncement_tbl_end_date(rs.getDate(5));
	          anc.setAnnouncement_tbl_status(rs.getString(6));
	            return anc;  
	        }

			
	    });  
	} 

}
