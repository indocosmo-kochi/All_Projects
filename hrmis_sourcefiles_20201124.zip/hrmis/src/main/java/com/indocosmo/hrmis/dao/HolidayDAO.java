/**
 * @author Jeswin Chacko P A
 *
 * @version 0.0.1 Jun 2, 2020
 *
 *
 */
package com.indocosmo.hrmis.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;

import com.indocosmo.hrmis.bean.HolidayBean;

public class HolidayDAO {

	JdbcTemplate jdbc_template;

	public void setTemplate(JdbcTemplate jdbc_template) {
		this.jdbc_template = jdbc_template;
	}

	public List<HolidayBean> getHolidays() {
		return jdbc_template.query("SELECT * FROM holiday_tbl WHERE is_deleted=0", new RowMapper<HolidayBean>() {
			public HolidayBean mapRow(ResultSet rs, int row) throws SQLException {
				HolidayBean holiday_bean_object = new HolidayBean();
				holiday_bean_object.setHoliday_id(rs.getInt(1));
				holiday_bean_object.setHoliday_name(rs.getString(2));
				return holiday_bean_object;
			}
		});
	}

	public List<HolidayBean> getHolidayDate(int holiday_id) {
		return jdbc_template.query("SELECT * FROM holiday_date WHERE holiday_id="+holiday_id+" AND is_deleted=0", new RowMapper<HolidayBean>() {
			public HolidayBean mapRow(ResultSet rs, int row) throws SQLException {
				HolidayBean holiday_bean_object = new HolidayBean();
				holiday_bean_object.setHoliday_date_id(rs.getInt(1));
				holiday_bean_object.setHoliday_date(rs.getDate(2));
				holiday_bean_object.setHoliday_date_name(rs.getString(4));
				return holiday_bean_object;
			}
		});
	}

	public int insertHoliday(final HolidayBean holiday_bean_object) {
		String sql = "INSERT INTO holiday_tbl (holiday_name) VALUES (?)";
		return jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setString(1, holiday_bean_object.getHoliday_name());
				return prepared_statement_object.executeUpdate();
			}
		});
	}

	public int insertHolidayDate(final HolidayBean holiday_bean_object) {
		String sql = "INSERT INTO holiday_date (holiday_date,holiday_date_name,holiday_id) VALUES (?,?,?)";
		return jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setDate(1, holiday_bean_object.getHoliday_date());
				prepared_statement_object.setString(2, holiday_bean_object.getHoliday_date_name());
				prepared_statement_object.setInt(3, holiday_bean_object.getHoliday_id());
				return prepared_statement_object.executeUpdate();
			}
		});
	}

	public HolidayBean getHolidayById(int holiday_id) {
		String sql = "SELECT * FROM holiday_tbl WHERE holiday_id=?";
		return jdbc_template.queryForObject(sql, new Object[] { holiday_id },
				new BeanPropertyRowMapper<HolidayBean>(HolidayBean.class));
	}

	public HolidayBean getHolidayDateById(String holiday_date_id) {
		String sql = "SELECT * FROM holiday_date WHERE holiday_date_id=?";
		return jdbc_template.queryForObject(sql, new Object[] { holiday_date_id },
				new BeanPropertyRowMapper<HolidayBean>(HolidayBean.class));
	}

	public int editHoliday(final HolidayBean holiday_bean_object) {
		String sql = "UPDATE holiday_tbl SET holiday_name=? WHERE holiday_id=?";
		return jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setString(1, holiday_bean_object.getHoliday_name());
				prepared_statement_object.setInt(2, holiday_bean_object.getHoliday_id());
				return prepared_statement_object.executeUpdate();
			}
		});
	}

	public int editHolidayDate(final HolidayBean holiday_bean_object) {
		String sql = "UPDATE holiday_date SET holiday_date_name=?,holiday_date=? WHERE holiday_date_id=?";
		return jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setString(1, holiday_bean_object.getHoliday_date_name());
				prepared_statement_object.setDate(2, holiday_bean_object.getHoliday_date());
				prepared_statement_object.setInt(3, holiday_bean_object.getHoliday_date_id());
				return prepared_statement_object.executeUpdate();
			}
		});
	}

	public int deleteHoliday(String holiday_id) {
		String sql = "UPDATE holiday_tbl SET is_deleted=1 WHERE holiday_id='" + holiday_id + "'";
		return jdbc_template.update(sql);
	}

	public int deleteHolidayDate(String holiday_date_id) {
		String sql = "UPDATE holiday_date SET is_deleted=1 WHERE holiday_date_id='" + holiday_date_id + "'";
		return jdbc_template.update(sql);
	}

	public int importHolidayDate(String file_location,int holiday_id) {
		String jdbcURL = "jdbc:mysql://localhost:3306/hrmis";
		String username = "root";
		String password = "root";

		String excelFilePath = file_location;
		int batchSize = 20;

		Connection connection = null;

		try {
			long start = System.currentTimeMillis();

			FileInputStream inputStream = new FileInputStream(excelFilePath);

			Workbook workbook = new XSSFWorkbook(inputStream);

			Sheet firstSheet = workbook.getSheetAt(0);
			Iterator<Row> rowIterator = firstSheet.iterator();

			connection = DriverManager.getConnection(jdbcURL, username, password);
			connection.setAutoCommit(false);

			String sql = "INSERT INTO holiday_date (holiday_date_name,holiday_date,holiday_id) VALUES (?,?,?)";
			PreparedStatement statement = connection.prepareStatement(sql);
			
			statement.setInt(3, holiday_id);
			
			int count = 0;

			rowIterator.next(); // skip the header row

			while (rowIterator.hasNext()) {
				Row nextRow = rowIterator.next();
				Iterator<Cell> cellIterator = nextRow.cellIterator();

				while (cellIterator.hasNext()) {
					Cell nextCell = cellIterator.next();

					int columnIndex = nextCell.getColumnIndex();

					switch (columnIndex) {
					case 0:
						String name = nextCell.getStringCellValue();
						statement.setString(1, name);
						break;
					case 1:
						Date Date = nextCell.getDateCellValue();
						statement.setTimestamp(2, new Timestamp(Date.getTime()));
					}

				}

				statement.addBatch();

				if (count % batchSize == 0) {
					statement.executeBatch();
				}

			}

			workbook.close();

			// execute the remaining queries
			statement.executeBatch();

			connection.commit();
			connection.close();

			long end = System.currentTimeMillis();
			System.out.printf("Import done in %d ms\n", (end - start));

		} catch (IOException ex1) {
			System.out.println("Error reading file");
			ex1.printStackTrace();
		} catch (SQLException ex2) {
			System.out.println("Database error");
			ex2.printStackTrace();
		}
		return batchSize;
	}

	public List<HolidayBean> getHolidayDateByEmployee(int employee_id) {
		return jdbc_template.query("call hrmis.getHolidayDate(" + employee_id + ")", new RowMapper<HolidayBean>() {
			public HolidayBean mapRow(ResultSet rs, int row) throws SQLException {
				HolidayBean holiday_bean_object = new HolidayBean();
				holiday_bean_object.setHoliday_date(rs.getDate(1));
				return holiday_bean_object;
			}
		});
	}
}
