/**
 * 
 */
package com.indocosmo.hrmis.controller;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.indocosmo.hrmis.bean.HolidayBean;
import com.indocosmo.hrmis.dao.HolidayDAO;

/**
 * @author Anandhapadmanabhan
 * 
 * @version 0.0.1 
 *
 */
@Controller
public class HolidayController {
	
	@Autowired
	HolidayDAO holiday_dao_object;
	
	@RequestMapping("viewHoliday")
	public String viewHoliday(Model model_object) {
		List<HolidayBean> holiday_list = holiday_dao_object.getHolidays();
		model_object.addAttribute("holiday_list", holiday_list);
		return "admin/holidays/view_holidays";
	}
	
	@RequestMapping("addHoliday")
    public String addHoliday(){
		return "admin/holidays/add_holiday";
    }
	
	@RequestMapping(value="addHolidayDate/{holiday_id}")
    public String holidayadd(@PathVariable String holiday_id, Model model_object){
		model_object.addAttribute("holiday_id",holiday_id);
		return "admin/holidays/add_holiday_date";
    }
	
	@RequestMapping(value = "/addHolidaySave", method = RequestMethod.POST)
	public String addHolidaySave(@ModelAttribute("holiday_bean_object") HolidayBean holiday_bean_object) {
		holiday_dao_object.insertHoliday(holiday_bean_object);
		return "redirect:/viewHoliday";
	}
	
	@RequestMapping(value = "/addHolidayDateSave", method = RequestMethod.POST)
	public String addHolidayDateSave(@ModelAttribute("holiday_bean_object") HolidayBean holiday_bean_object) {
		holiday_dao_object.insertHolidayDate(holiday_bean_object);
		return "redirect:/editHolidayView/"+holiday_bean_object.getHoliday_id();
	}
	
	@RequestMapping(value = "/editHolidayView/{holiday_id}")
	public String editHolidayView(@PathVariable int holiday_id, Model model_object) {
		HolidayBean holiday_bean_object = holiday_dao_object.getHolidayById(holiday_id);
		model_object.addAttribute("holiday", holiday_bean_object);
		List<HolidayBean> holiday_list = holiday_dao_object.getHolidayDate(holiday_id);
		model_object.addAttribute("holiday_list", holiday_list);
		return "admin/holidays/editholiday";
	}
	
	@RequestMapping(value = "/editHolidayDateView/{holiday_date_id}")
	public String editHolidayDateView(@PathVariable String holiday_date_id, Model model_object) {
		HolidayBean holiday_bean_object = holiday_dao_object.getHolidayDateById(holiday_date_id);
		model_object.addAttribute("holiday_date", holiday_bean_object);
		return "admin/holidays/edit_holiday_date";
	}
	
	@RequestMapping(value = "/editHolidaySave", method = RequestMethod.POST)
	public String editHolidaySave(@ModelAttribute("holiday_bean_object") HolidayBean holiday_bean_object) {
		holiday_dao_object.editHoliday(holiday_bean_object);
		return "redirect:/viewHoliday";
	}
	
	@RequestMapping(value = "/editHolidayDateSave", method = RequestMethod.POST)
	public String editHolidayDateSave(@ModelAttribute("holiday_bean_object") HolidayBean holiday_bean_object) {
		holiday_dao_object.editHolidayDate(holiday_bean_object);
		return "redirect:/editHolidayView/"+holiday_bean_object.getHoliday_id();
	}
	
	@RequestMapping(value = "/deleteHoliday/{holiday_id}")
	public String deleteHoliday(@PathVariable String holiday_id, Model model_object) {
		int holiday_bean_object = holiday_dao_object.deleteHoliday(holiday_id);
		model_object.addAttribute("holiday", holiday_bean_object);
		return "redirect:/viewHoliday";
	}
	
	@RequestMapping(value = "/deleteHolidayDate/{holiday_date_id}")
	public String deleteHolidayDate(@PathVariable String holiday_date_id, Model model_object) {
		holiday_dao_object.deleteHolidayDate(holiday_date_id);
		return "redirect:/viewHoliday";
	}
	
	@RequestMapping(value="importHoliday/{holiday_id}")
    public String importHoliday(@PathVariable String holiday_id, Model model_object){
		model_object.addAttribute("holiday_id",holiday_id);
		return "admin/holidays/import_holiday";
    }
	
	@RequestMapping(value = "/importHolidayDateSave", method = RequestMethod.POST)
	public String importHolidayDateSave(@RequestParam CommonsMultipartFile file,HttpSession session,
										@ModelAttribute("holiday_bean_object") HolidayBean holiday_bean_object) {
		int holiday_id = holiday_bean_object.getHoliday_id();
		String path=session.getServletContext().getRealPath("/");
		String filename=file.getOriginalFilename();
		String file_location = path+filename;
		try{
			byte barr[]=file.getBytes();
			BufferedOutputStream bout=new BufferedOutputStream(new FileOutputStream(path+filename));  
			bout.write(barr);  
			bout.flush();  
			bout.close();
			}
		catch(Exception e){System.out.println(e);}
		holiday_dao_object.importHolidayDate(file_location,holiday_id);
		return "redirect:/editHolidayView/"+holiday_bean_object.getHoliday_id();
	}
}
