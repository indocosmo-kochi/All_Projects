/**
 * @author Jeswin Chacko P A
 *
 * @version 0.0.1 Jun 2, 2020
 *
 *
 */
package com.indocosmo.hrmis.bean;

import java.sql.Date;

public class HolidayBean {

	private int holiday_id;
	private String holiday_name;
	private int holiday_date_id;
	private Date holiday_date;
	private String holiday_date_name;
	
	public int getHoliday_id() {
		return holiday_id;
	}
	public void setHoliday_id(int holiday_id) {
		this.holiday_id = holiday_id;
	}
	public String getHoliday_name() {
		return holiday_name;
	}
	public void setHoliday_name(String holiday_name) {
		this.holiday_name = holiday_name;
	}
	public int getHoliday_date_id() {
		return holiday_date_id;
	}
	public void setHoliday_date_id(int holiday_date_id) {
		this.holiday_date_id = holiday_date_id;
	}
	public Date getHoliday_date() {
		return holiday_date;
	}
	public void setHoliday_date(Date holiday_date) {
		this.holiday_date = holiday_date;
	}
	public String getHoliday_date_name() {
		return holiday_date_name;
	}
	public void setHoliday_date_name(String holiday_date_name) {
		this.holiday_date_name = holiday_date_name;
	}
}
