/**
 * @author Jeswin Chacko P A
 *
 * @version 0.0.1 Mar 5, 2020
 *
 *
 */
package com.indocosmo.hrmis.bean;

public class ProfessionBean {

	private int profession_id,profession_id_array[];
	private String company_name_array[],period_array[],nature_of_work_array[];
	private String company_name,period,nature_of_work;
	public String[] getCompany_name_array() {
		return company_name_array;
	}
	public void setCompany_name_array(String[] company_name_array) {
		this.company_name_array = company_name_array;
	}
	public String[] getPeriod_array() {
		return period_array;
	}
	public void setPeriod_array(String[] period_array) {
		this.period_array = period_array;
	}
	public String[] getNature_of_work_array() {
		return nature_of_work_array;
	}
	public void setNature_of_work_array(String[] nature_of_work_array) {
		this.nature_of_work_array = nature_of_work_array;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getPeriod() {
		return period;
	}
	public void setPeriod(String period) {
		this.period = period;
	}
	public String getNature_of_work() {
		return nature_of_work;
	}
	public void setNature_of_work(String nature_of_work) {
		this.nature_of_work = nature_of_work;
	}
	public int[] getProfession_id_array() {
		return profession_id_array;
	}
	public void setProfession_id_array(int profession_id_array[]) {
		this.profession_id_array = profession_id_array;
	}
	public int getProfession_id() {
		return profession_id;
	}
	public void setProfession_id(int profession_id) {
		this.profession_id = profession_id;
	}
}
