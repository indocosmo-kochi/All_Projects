/**
 * @author Jeswin Chacko P A
 *
 * @version 0.0.1 Mar 5, 2020
 *
 *
 */
package com.indocosmo.hrmis.controller;

import java.io.IOException;
import java.io.InputStream;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamSource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.indocosmo.hrmis.bean.ClientBean;
import com.indocosmo.hrmis.bean.EmployeeBean;
import com.indocosmo.hrmis.bean.LoginBean;
import com.indocosmo.hrmis.dao.EducationDAO;
import com.indocosmo.hrmis.dao.EmailDAO;
import com.indocosmo.hrmis.dao.EmployeeDAO;
import com.indocosmo.hrmis.dao.EmployeeLeaveDAO;
import com.indocosmo.hrmis.dao.HolidayDAO;
import com.indocosmo.hrmis.dao.LoginDAO;

@Controller
public class CommonController {

	static final String emailFromRecipient = "indocosmohrmis@gmail.com";

	@Autowired
	EmployeeDAO employee_dao_object;
	@Autowired
	EducationDAO education_dao_object;
	@Autowired
	EmployeeLeaveDAO emp_leavedao_object;
	@Autowired
	HolidayDAO holiday_dao_object;
	@Autowired
	LoginDAO daologin;
	@Autowired
	EmailDAO email_dao_object;

	@Autowired
	private JavaMailSender mailSenderObj;

	@RequestMapping("personalBioData")
	public String personalBioData(Model model_object, HttpSession session) {
		String employee_code = (String) session.getAttribute("userid");
		EmployeeBean employee_bean_object = employee_dao_object.getEmployeeByCode(employee_code);
		model_object.addAttribute("employee", employee_bean_object);
		return "employee/personalInformation/personal_bio_data";
	}

	@RequestMapping(value = "/changePassword/{employee_id}")
	public String changePassword(@PathVariable int employee_id, Model model_object, HttpSession session) {
		model_object.addAttribute("employee_id", employee_id);
		int admin_flag = (Integer) session.getAttribute("admin_flag");
		model_object.addAttribute("admin_flag", admin_flag);
		return "change_password";
	}

	@RequestMapping(value = "/changePasswordSave", method = RequestMethod.POST)
	public String changePasswordSave(@ModelAttribute("login_bean_object") LoginBean login_bean_object, Model m) {
		int check = daologin.checkPassword(login_bean_object);
		if (check == 0) {
			m.addAttribute("check", 0);
			return "redirect:/changePassword/" + login_bean_object.getEmployee_id();
		} else {
			int change = daologin.changePassword(login_bean_object);
			if (change == 0) {
				m.addAttribute("check", 1);
				return "redirect:/changePassword/" + login_bean_object.getEmployee_id();
			} else {
				m.addAttribute("check", 2);
				return "redirect:/changePassword/" + login_bean_object.getEmployee_id();
			}
		}
	}

	@RequestMapping(value = "/forgotpassword")
	public String forgotpassword(Model model_object, HttpSession session) {
		return "forgotpassword";
	}

	@RequestMapping(value = "/resetpassword/{userid}")
	public String restpassword(@PathVariable String userid,Model model_object, HttpSession session) {
		EmployeeBean employee = employee_dao_object.getEmployeeByCode(userid);
		model_object.addAttribute("employee", employee);
		return "resetpassword";
	}

	@RequestMapping(value = "/forgot-password", method = RequestMethod.POST)
	public String forgotUserPassword(HttpServletRequest request, EmployeeBean employee, Model m) {
		final String userid = request.getParameter("employee_code");
		System.out.println(userid);
		
		EmployeeBean existingUser = employee_dao_object.findById(userid);
		
		int empid = existingUser.getEmployee_id();
		System.out.println(empid);
		
		final String to = existingUser.getEmail_id_official();
		System.out.println(to);
		
		String subject  = "Complete Password Reset!";
		String message = "To complete the password reset process, please click here:" + "http://localhost:8080/HRMIS/resetpassword/" +userid;
				
		if (existingUser != null) {
			EmailDAO.sendEmail(to, subject, message,null,mailSenderObj);
			m.addAttribute("success", 1);
			return "forgotpassword";

		} else {
			m.addAttribute("success", 0);
			return "forgotpassword";
		}
		
	}


	@RequestMapping(value = "/resetpasswordsave/{employee_code}", method = RequestMethod.POST)
	public String resetpasswordsave(@PathVariable String employee_code,
			@ModelAttribute("login_bean_object") LoginBean login_bean_object, Model m) {
			int change = daologin.resetPassword(login_bean_object);
			if (change == 0) {
				m.addAttribute("check", 1);
				return "redirect:/resetpassword/" + login_bean_object.getEmployee_code();
			} else {
				m.addAttribute("check", 2);
				return "redirect:/resetpassword/" + login_bean_object.getEmployee_code();
			}
	}

}
