/**
 * 
 */
package com.indocosmo.hrmis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.indocosmo.hrmis.bean.LeaveTypeBean;
import com.indocosmo.hrmis.bean.LocationBean;
import com.indocosmo.hrmis.dao.LeaveTypeDAO;

/**
 * @author Ayana P Dharman
 * 
 * @version 0.0.1 24 April 2020
 *
 */
@Controller
public class LeaveTypeController {
	
	@Autowired
	LeaveTypeDAO daoleavetype;
	
	@RequestMapping("/view_leavetype")
	public String viewleavetype(Model m) {
		List<LeaveTypeBean> leavetype_list = daoleavetype.getleavetype();
		m.addAttribute("leavetype_list", leavetype_list);
		return "admin/leave/view_leavetype";
	}

	@RequestMapping("add_leavetype")
	public String leavetype(Model m) {
		List<LocationBean> location_list = daoleavetype.getLocations();
		m.addAttribute("location_list", location_list);
		m.addAttribute("command", new LeaveTypeBean());
		return "admin/leave/add_leavetype";
	}

	@RequestMapping(value = "/leavetypesave", method = RequestMethod.POST)
	public String leavetypeMasterSave(@ModelAttribute("leavetype") LeaveTypeBean leavetype) {
		
		daoleavetype.leavetypesave(leavetype);
		return "redirect:/view_leavetype";
	}

	@RequestMapping(value = "/deleteleavetype/{leavetype_id}", method = RequestMethod.GET)
	public String deleteleavetype(@PathVariable int leavetype_id) {
		daoleavetype.leavetypedelete(leavetype_id);
		return "redirect:/view_leavetype";
	}

	@RequestMapping(value = "/editleavetype/{leavetype_id}")
	public String leavetypeedit(@PathVariable int leavetype_id, Model m) {
		LeaveTypeBean leavetype = daoleavetype.getleavetypeById(leavetype_id);
		
		List<LocationBean> location_list = daoleavetype.getLocations();
		m.addAttribute("location_list", location_list);
		
		m.addAttribute("leavetype", leavetype);
		return "admin/leave/edit_leavetype";
	}

	/* It updates model object. */
	@RequestMapping(value = "/leavetypeeditsave", method = RequestMethod.POST)
	public String leavetypeeditsave(@ModelAttribute("leavetype") LeaveTypeBean leavetype) {
        System.out.println(leavetype.getLeavetype_location());
		daoleavetype.leavetypeupdate(leavetype);
		return "redirect:/view_leavetype";
	}


}
