/**
 * @author Jeswin Chacko P A
 *
 * @version 0.0.1 Mar 5, 2020
 *
 *
 */
package com.indocosmo.hrmis.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.indocosmo.hrmis.bean.ProfessionBean;
import com.indocosmo.hrmis.common.CommonQueries;

public class ProfessionDAO {

	CommonQueries sql_object;
	JdbcTemplate jdbc_template;

	public void setTemplate(JdbcTemplate jdbc_template) {
		this.jdbc_template = jdbc_template;
	}
	
	public int insertProfession(final ProfessionBean profession_bean_object, String employee_id) {   
		int flag = 0;
		String company[] = profession_bean_object.getCompany_name_array();
		String period[] = profession_bean_object.getPeriod_array();
		String nature[] = profession_bean_object.getNature_of_work_array();
		for(int i = 0;i<company.length;i++) {
			if(company[i].equals("")) {
				break;
			}
			String sql="INSERT INTO profession (company_name,period,nature_of_work,employee_id) "
					+ "VALUES ('"+company[i]+"','"+period[i]+"','"+nature[i]+"','"+employee_id+"')";
		    flag = jdbc_template.update(sql);
		}
		return flag;
	}

	public List<ProfessionBean> getProfessions(String employee_id) {
		String sql = "SELECT * FROM profession WHERE employee_id='"+employee_id+"'";
		return jdbc_template.query(sql, new RowMapper<ProfessionBean>() {
			public ProfessionBean mapRow(ResultSet rs, int row) throws SQLException {
				ProfessionBean profession_bean_object = new ProfessionBean();
				profession_bean_object.setProfession_id(rs.getInt(1));
				profession_bean_object.setCompany_name(rs.getString(2));
				profession_bean_object.setPeriod(rs.getString(3));
				profession_bean_object.setNature_of_work(rs.getString(4));
				return profession_bean_object;
			}
		});
	}

	public int editProfession(final ProfessionBean profession_bean_object,String employee_id) {   
		int flag = 0;
		int profession_id[] = profession_bean_object.getProfession_id_array();
		String company[] = profession_bean_object.getCompany_name_array();
		String period[] = profession_bean_object.getPeriod_array();
		String nature[] = profession_bean_object.getNature_of_work_array();
		for(int i = 0;i<company.length;i++) {
			if(company[i].equals("")) {
				break;
			}
			String sql="UPDATE profession SET company_name='"+company[i]+"',period='"+period[i]+"',"
					+ "nature_of_work='"+nature[i]+"' WHERE profession_id="+profession_id[i];
		    flag = jdbc_template.update(sql);
		}
		return flag;
	}
}
