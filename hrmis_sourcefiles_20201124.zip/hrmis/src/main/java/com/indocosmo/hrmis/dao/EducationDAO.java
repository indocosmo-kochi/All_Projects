/**
 * @author Jeswin Chacko P A
 *
 * @version 0.0.1 Feb 29, 2020
 *
 *
 */
package com.indocosmo.hrmis.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.indocosmo.hrmis.bean.EducationBean;
import com.indocosmo.hrmis.common.CommonQueries;

public class EducationDAO {

	CommonQueries sql_object;
	JdbcTemplate jdbc_template;

	public void setTemplate(JdbcTemplate jdbc_template) {
		this.jdbc_template = jdbc_template;
	}

	public int insertEducation(final EducationBean education_bean_object,String employee_id) {   
		int flag = 0;
		String qualification[] = education_bean_object.getQualification_array();
		String board[] = education_bean_object.getBoard_or_university_array();
		String year[] = education_bean_object.getEducation_year_array();
		double marks[] = education_bean_object.getMarks_array();
		for(int i = 0;i<qualification.length;i++) {
			if(marks[i]==0) {
				break;
			}
			String sql="INSERT INTO education (qualification,board_or_university,year,marks,employee_id) "
					+ "VALUES ('"+qualification[i]+"','"+board[i]+"','"+year[i]+"',"+marks[i]+",'"+employee_id+"')";
		    flag = jdbc_template.update(sql);
		}
		return flag;
	}

	public List<EducationBean> getEducations(String employee_id) {
		String sql = "SELECT * FROM education WHERE employee_id='"+employee_id+"'";
		return jdbc_template.query(sql, new RowMapper<EducationBean>() {
			public EducationBean mapRow(ResultSet rs, int row) throws SQLException {
				EducationBean education_bean_object = new EducationBean();
				education_bean_object.setEducation_id(rs.getInt(1));
				education_bean_object.setQualification(rs.getString(2));
				education_bean_object.setBoard_or_university(rs.getString(3));
				education_bean_object.setEducation_year(rs.getString(4));
				education_bean_object.setMarks(rs.getDouble(5));
				return education_bean_object;
			}
		});
	}

	public int editEducation(final EducationBean education_bean_object,String employee_id) {   
		int flag = 0;
		int education_id[] = education_bean_object.getEducation_id_array();
		String qualification[] = education_bean_object.getQualification_array();
		String board[] = education_bean_object.getBoard_or_university_array();
		String year[] = education_bean_object.getEducation_year_array();
		double marks[] = education_bean_object.getMarks_array();
		for(int i = 0;i<qualification.length;i++) {
			if(marks[i]==0) {
				break;
			}
			String sql="UPDATE education SET qualification='"+qualification[i]+"',board_or_university='"+board[i]+"',"
					+ "year='"+year[i]+"',marks="+marks[i]+" WHERE education_id="+education_id[i];
		    flag = jdbc_template.update(sql);
		}
		return flag;
	}
}
