/**
 * @author Anandhapadmanabhan
 *
 * @version 0.0.1 Mar 11, 2020
 *
 *
 */
package com.indocosmo.hrmis.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;

import com.indocosmo.hrmis.bean.DesignationBean;
import com.indocosmo.hrmis.bean.LocationBean;
import com.indocosmo.hrmis.common.CommonQueries;

public class DesignationDAO {

	CommonQueries sql_object;
	JdbcTemplate jdbc_template;

	public void setTemplate(JdbcTemplate jdbc_template) {
		this.jdbc_template = jdbc_template;
	}

	public List<DesignationBean> getDesignations() {
		return jdbc_template.query("SELECT * FROM designation WHERE is_deleted=0", new RowMapper<DesignationBean>() {
			public DesignationBean mapRow(ResultSet rs, int row) throws SQLException {
				DesignationBean designation_bean_object = new DesignationBean();
				designation_bean_object.setDesignation_id(rs.getInt(1));
				designation_bean_object.setDesignation_name(rs.getString(2));
				return designation_bean_object;
			}
		});
	}

	public List<LocationBean> getLocations() {
		return jdbc_template.query("SELECT * FROM location WHERE is_deleted=0", new RowMapper<LocationBean>() {
			public LocationBean mapRow(ResultSet rs, int row) throws SQLException {
				LocationBean location_bean_object = new LocationBean();
				location_bean_object.setLocation_id(rs.getInt(1));
				location_bean_object.setLocation_name(rs.getString(2));
				return location_bean_object;
			}
		});
	}

	public int insertDesignation(final DesignationBean designation_bean_object) {
		String sql = "INSERT INTO designation (designation_id,designation_name) VALUES (?,?)";
		return jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setInt(1, designation_bean_object.getDesignation_id());
				prepared_statement_object.setString(2, designation_bean_object.getDesignation_name());
				return prepared_statement_object.executeUpdate();
			}
		});
	}

	public DesignationBean getDesignationById(String designation_id) { // To get an item by id(used in editing form)
		String sql = "SELECT * FROM designation WHERE designation_id=?";
		return jdbc_template.queryForObject(sql, new Object[] { designation_id },
				new BeanPropertyRowMapper<DesignationBean>(DesignationBean.class));
	}

	public int editDesignation(final DesignationBean designation_bean_object) {
		String sql = "UPDATE designation SET designation_name=? WHERE designation_id=?";
		return jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setString(1, designation_bean_object.getDesignation_name());
				prepared_statement_object.setInt(2, designation_bean_object.getDesignation_id());
				return prepared_statement_object.executeUpdate();
			}
		});
	}

	public int deleteDesignation(String designation_id) {
		String sql = "UPDATE designation SET is_deleted=1 WHERE designation_id='"+designation_id+"'";
		return jdbc_template.update(sql);
	}
}
