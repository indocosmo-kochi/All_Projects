/**
 * @author Jeswin Chacko P A
 *
 * @version 0.0.1 May 15, 2020
 *
 *
 */
package com.indocosmo.hrmis.bean;

import java.sql.Date;

public class ApproverBean {

	private int approver_tbl_id;
	private int approver_level;
	private int approver_emp_id;
	private String employee_name;
	private int is_mail;
	private String created_by;
	private String updated_by;
	private Date created_date;
	private Date updated_date;
	private int employee_id;
	
	public int getApprover_tbl_id() {
		return approver_tbl_id;
	}
	public void setApprover_tbl_id(int approver_tbl_id) {
		this.approver_tbl_id = approver_tbl_id;
	}
	public int getIs_mail() {
		return is_mail;
	}
	public void setIs_mail(int is_mail) {
		this.is_mail = is_mail;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public String getUpdated_by() {
		return updated_by;
	}
	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	public Date getUpdated_date() {
		return updated_date;
	}
	public void setUpdated_date(Date updated_date) {
		this.updated_date = updated_date;
	}
	public int getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public int getApprover_emp_id() {
		return approver_emp_id;
	}
	public void setApprover_emp_id(int approver_emp_id) {
		this.approver_emp_id = approver_emp_id;
	}
	public int getApprover_level() {
		return approver_level;
	}
	public void setApprover_level(int approver_level) {
		this.approver_level = approver_level;
	}
	
}
