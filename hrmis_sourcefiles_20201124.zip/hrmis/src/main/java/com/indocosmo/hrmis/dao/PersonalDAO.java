/**
 * @author Jeswin Chacko P A
 *
 * @version 0.0.1 Mar 5, 2020
 *
 *
 */
package com.indocosmo.hrmis.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.annotation.Transactional;

import com.indocosmo.hrmis.bean.PersonalBean;
import com.indocosmo.hrmis.common.CommonQueries;

public class PersonalDAO {

	CommonQueries sql_object;
	JdbcTemplate jdbc_template;

	public void setTemplate(JdbcTemplate jdbc_template) {
		this.jdbc_template = jdbc_template;
	}
	
	@Transactional(rollbackFor = Exception.class)
	public int insertPersonal(final PersonalBean personal_bean_object,final String employee_id) {   
		int flag = 0;
		String child_name[] = personal_bean_object.getChild_name_array();
		int child_age[] = personal_bean_object.getChild_age_array();
		String child_occupation[] = personal_bean_object.getChild_occupation_array();
		String sibling_name[] = personal_bean_object.getSibling_name_array();
		int sibling_age[] = personal_bean_object.getSibling_age_array();
		String sibling_occupation[] = personal_bean_object.getSibling_occupation_array();
		
		String sql = "INSERT INTO personal (father_name,father_age,father_occupation,mother_name,mother_age,mother_occupation,spouse_name,spouse_age,spouse_occupation,employee_id) VALUES (?,?,?,?,?,?,?,?,?,?)";
		flag = jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {
			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setString(1, personal_bean_object.getFather_name());
				prepared_statement_object.setLong(2, personal_bean_object.getFather_age());
				prepared_statement_object.setString(3, personal_bean_object.getFather_occupation());
				prepared_statement_object.setString(4, personal_bean_object.getMother_name());
				prepared_statement_object.setLong(5, personal_bean_object.getMother_age());
				prepared_statement_object.setString(6, personal_bean_object.getMother_occupation());
				prepared_statement_object.setString(7, personal_bean_object.getSpouse_name());
				prepared_statement_object.setLong(8, personal_bean_object.getSpouse_age());
				prepared_statement_object.setString(9, personal_bean_object.getSpouse_occupation());
				prepared_statement_object.setString(10, employee_id);
				return prepared_statement_object.executeUpdate();
			}});
		
		for(int i = 0;i<child_name.length;i++) {
			if(child_name[i]==null) {
				break;
			}
			String sql_child = "INSERT INTO child (child_name,child_age,child_occupation,employee_id) VALUES "
					+ "('"+child_name[i]+"',"+child_age[i]+",'"+child_occupation[i]+"','"+employee_id+"')";
		    flag = jdbc_template.update(sql_child);
		}
		for(int i = 0;i<sibling_name.length;i++) {
			if(sibling_name[i]==null) {
				break;
			}
			String sql_sibling = "INSERT INTO sibling (sibling_name,sibling_age,sibling_occupation,employee_id) VALUES "
					+ "('"+sibling_name[i]+"',"+sibling_age[i]+",'"+sibling_occupation[i]+"','"+employee_id+"')";
		    flag = jdbc_template.update(sql_sibling);
		}
		return flag;
	}

	public int check(String employee_id) {
		int count = 0;
		Object[] params = null;
		String sql = "SELECT COUNT(personal_id) FROM personal WHERE employee_id=?";
		params = new Object[] { employee_id };
		count = this.jdbc_template.queryForObject(sql,params, Integer.class);
		return count;
	}

	public PersonalBean getPersonal(String employee_id) {
		String sql = "SELECT * FROM personal WHERE employee_id=?";
		return jdbc_template.queryForObject(sql, new Object[] { employee_id },
				new BeanPropertyRowMapper<PersonalBean>(PersonalBean.class));
	}

	public List<PersonalBean> getSibling(String employee_id) {
		String sql = "SELECT * FROM sibling WHERE employee_id='"+employee_id+"'";
		return jdbc_template.query(sql, new RowMapper<PersonalBean>() {
			public PersonalBean mapRow(ResultSet rs, int row) throws SQLException {
				PersonalBean personal_bean_object = new PersonalBean();
				personal_bean_object.setSibling_id(rs.getInt(1));
				personal_bean_object.setSibling_name(rs.getString(2));
				personal_bean_object.setSibling_age(rs.getInt(3));
				personal_bean_object.setSibling_occupation(rs.getString(4));
				return personal_bean_object;
			}
		});
	}

	public List<PersonalBean> getChild(String employee_id) {
		String sql = "SELECT * FROM child WHERE employee_id='"+employee_id+"'";
		return jdbc_template.query(sql, new RowMapper<PersonalBean>() {
			public PersonalBean mapRow(ResultSet rs, int row) throws SQLException {
				PersonalBean personal_bean_object = new PersonalBean();
				personal_bean_object.setChild_id(rs.getInt(1));
				personal_bean_object.setChild_name(rs.getString(2));
				personal_bean_object.setChild_age(rs.getInt(3));
				personal_bean_object.setChild_occupation(rs.getString(4));
				return personal_bean_object;
			}
		});
	}
	
	@Transactional(rollbackFor = Exception.class)
	public int editPersonal(final PersonalBean personal_bean_object,final String employee_id) {   
		int flag = 0;
		int child_id[] = personal_bean_object.getChild_id_array();
		String child_name[] = personal_bean_object.getChild_name_array();
		int child_age[] = personal_bean_object.getChild_age_array();
		String child_occupation[] = personal_bean_object.getChild_occupation_array();
		int sibling_id[] = personal_bean_object.getSibling_id_array();
		String sibling_name[] = personal_bean_object.getSibling_name_array();
		int sibling_age[] = personal_bean_object.getSibling_age_array();
		String sibling_occupation[] = personal_bean_object.getSibling_occupation_array();
		
		String sql = "UPDATE personal SET father_name=?,father_age=?,father_occupation=?,mother_name=?,mother_age=?,"
				+ "mother_occupation=?,spouse_name=?,spouse_age=?,spouse_occupation=? WHERE employee_id=?";
		flag = jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {
			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setString(1, personal_bean_object.getFather_name());
				prepared_statement_object.setLong(2, personal_bean_object.getFather_age());
				prepared_statement_object.setString(3, personal_bean_object.getFather_occupation());
				prepared_statement_object.setString(4, personal_bean_object.getMother_name());
				prepared_statement_object.setLong(5, personal_bean_object.getMother_age());
				prepared_statement_object.setString(6, personal_bean_object.getMother_occupation());
				prepared_statement_object.setString(7, personal_bean_object.getSpouse_name());
				prepared_statement_object.setLong(8, personal_bean_object.getSpouse_age());
				prepared_statement_object.setString(9, personal_bean_object.getSpouse_occupation());
				prepared_statement_object.setString(10, employee_id);
				return prepared_statement_object.executeUpdate();
			}});
		
		for(int i = 0;i<child_name.length;i++) {
			if(child_name[i]==null) {
				break;
			}
			String sql_child = "UPDATE child SET child_name='"+child_name[i]+"',child_age="+child_age[i]+","
					+ "child_occupation='"+child_occupation[i]+"' WHERE child_id="+child_id[i];
		    flag = jdbc_template.update(sql_child);
		}
		for(int i = 0;i<sibling_name.length;i++) {
			if(sibling_name[i]==null) {
				break;
			}
			String sql_sibling = "UPDATE sibling SET sibling_name='"+sibling_name[i]+"',sibling_age="+sibling_age[i]+","
					+ "sibling_occupation='"+sibling_occupation[i]+"' WHERE sibling_id="+sibling_id[i];
		    flag = jdbc_template.update(sql_sibling);
		}
		return flag;
	}
}
