/**
 * @author Jeswin Chacko P A
 *
 * @version 0.0.1 Feb 27, 2020
 *
 *
 */
package com.indocosmo.hrmis.common;

public class CommonQueries {

	public String select(String table_name) {
		String sql = "SELECT * FROM "+table_name+" WHERE is_deleted=0";
		System.out.println(sql);
		return sql;
	}
}
