package com.indocosmo.hrmis.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.indocosmo.hrmis.bean.ClientBean;

/**
 * @author Ayana P Dharman
 *
 * @version 0.0.1 Mar 5, 2020
 */
public class ClientDAO {
	
JdbcTemplate template;
	
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public int clientsave(ClientBean client) {
		// TODO Auto-generated method stub
		 String sql="insert into client_tbl(client_name,client_location,holiday_id) values('"+client.getclient_name()+"','"+client.getclient_location()+"',"+client.getHoliday_id()+")";    
		    return template.update(sql);  
		
	}
	
	public int clientupdate(ClientBean client){
	    String sql="update client_tbl set client_name='"+client.getclient_name()+"',client_location='"+client.getclient_location()+"',holiday_id="+client.getHoliday_id()+" where client_id="+client.getclient_id()+"";    
	    return template.update(sql);    
	}    
	public int clientdelete(int client_id){    
	    String sql="update client_tbl set client_isdelete=1 where client_id="+client_id+"";    
	    return template.update(sql);    
	}    
	public ClientBean getclientById(int client_id){    
	    String sql="select * from client_tbl where client_id=?";    
	    return template.queryForObject(sql, new Object[]{client_id},new BeanPropertyRowMapper<ClientBean>(ClientBean.class));    
	}    
	public List<ClientBean> getclient(){    
	    return template.query("select * from client_tbl where client_isdelete=0",new RowMapper<ClientBean>(){    
	        public ClientBean mapRow(ResultSet rs, int row) throws SQLException {    
	        	ClientBean e=new ClientBean();  
	        	e.setclient_id(rs.getInt(1));
	        	e.setclient_name(rs.getString(2));
	        	e.setclient_location(rs.getString(3));
	            return e;    
	        }    
	    });    
	}    

}
