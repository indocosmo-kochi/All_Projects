/**
 * 
 */
package com.indocosmo.hrmis.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.indocosmo.hrmis.bean.LeaveAllocationBean;
import com.indocosmo.hrmis.bean.EmployeeBean;
import com.indocosmo.hrmis.bean.LeaveTypeBean;
import com.indocosmo.hrmis.bean.LocationBean;
import com.indocosmo.hrmis.dao.EmployeeDAO;
import com.indocosmo.hrmis.dao.LeaveAllocationDAO;
import com.indocosmo.hrmis.dao.LeaveTypeDAO;

/**
 * @author Ayana P Dharman
 * 
 * @version 0.0.1 29 April 2020
 *
 */
@Controller
public class LeaveAllocationController {

	@Autowired
	LeaveAllocationDAO leaveallocation_dao_object;

	@Autowired
	LeaveTypeDAO leavetype_dao_object;
	@Autowired
	EmployeeDAO employee_dao_object;

	@RequestMapping("/leaveallocation")
	public String leaveallocate(Model m) {
		List<LocationBean> location_list = leaveallocation_dao_object.getLocations();
		m.addAttribute("location_list", location_list);
		return "admin/leave/leave_allocation";
	}

	@RequestMapping("/loademployee")
	public String loademployeelist(
			@ModelAttribute("leaveallocation_bean_object") LeaveAllocationBean leaveallocation_bean_object, Model m) {
		List<LocationBean> location_list = leaveallocation_dao_object.getLocations();
		m.addAttribute("location_list", location_list);
		List<LeaveAllocationBean> employee_list = leaveallocation_dao_object.getEmployeesByLocation(
				leaveallocation_bean_object.getLocation_name(), leaveallocation_bean_object.getCurrent_year());
		m.addAttribute("employee_list", employee_list);

		return "admin/leave/leave_allocation";
	}

	@RequestMapping("/AllocateLeave")
	public String allocateleave(Model m) {

		List<LocationBean> location_list = leaveallocation_dao_object.getLocations();
		m.addAttribute("location_list", location_list);
		List<EmployeeBean> employee_list = leaveallocation_dao_object.getEmployees();
		m.addAttribute("employee_list", employee_list);
		List<LeaveTypeBean> leavetype_list = leaveallocation_dao_object.getLeaveType();
		m.addAttribute("leavetype_list", leavetype_list);
		return "admin/leave/allocate_leave";
	}

	@RequestMapping(value = "/getLeavetypeById/{leavetype_id}")
	public String getleavetypebyid(@PathVariable String leavetype_id, Model model_object) {
		LeaveTypeBean leavetype_bean_object = leavetype_dao_object.getleavetypeByName(leavetype_id);
		model_object.addAttribute("leavetype", leavetype_bean_object);
		return "admin/leave/allocate_leave1";
	}

	@RequestMapping(value = "/getemployeeByName/{employee_name_array}")
	public String getemployeebyid(@PathVariable String employee_name_array, Model model_object) {
		EmployeeBean employee_bean_object = employee_dao_object.getemployeeByName(employee_name_array);
		model_object.addAttribute("employee", employee_bean_object);
		return "admin/leave/allocate_leave1";
	}

	@RequestMapping(value = "/deleteleaveallocation/{leaveallocation_id}")
	public String deleteLeaveAllocation(@PathVariable String leaveallocation_id, Model model_object) {
		int leaveallocation_bean_object1 = leaveallocation_dao_object.deleteLeaveAllocation(leaveallocation_id);
		model_object.addAttribute("leaveallocation", leaveallocation_bean_object1);
		return "redirect:/loademployee";
	}

	@RequestMapping(value = "/editleaveallocation/{leaveallocation_id}")
	public String leaveallocationedit(@PathVariable int leaveallocation_id, Model m) {
		List<LeaveTypeBean> leavetype_list = leaveallocation_dao_object.getleavetype();
		m.addAttribute("leavetype_list", leavetype_list);
		LeaveAllocationBean leaveallocation = leaveallocation_dao_object.getleaveallocationById(leaveallocation_id);
		m.addAttribute("leaveallocation", leaveallocation);
		return "admin/leave/edit_leaveallocation";
	}

	@RequestMapping(value = "/editLeaveallocationsave", method = RequestMethod.POST)
	public String leaveallocationeditsave(@ModelAttribute("leaveallocation") LeaveAllocationBean leaveallocation) {
		String leavetype_name = leaveallocation_dao_object
				.getleavetypeName(leaveallocation.getLeaveallocation_type_id());
		leaveallocation_dao_object.leaveallocationupdate(leaveallocation, leavetype_name);
		return "redirect:/loademployee";
	}

	@RequestMapping(value = "/allocateleavesave", method = RequestMethod.POST)
	public String leaveAllocate(@ModelAttribute("leaveallocation") LeaveAllocationBean leaveallocation, Model m) {
		String leavetype_name = leaveallocation_dao_object
				.getleavetypeName(leaveallocation.getLeaveallocation_type_id());
		ArrayList<String> employee_list = leaveallocation_dao_object.getEmployeeNames(leaveallocation);
		int validate = leaveallocation_dao_object.AllocateLeaveInsert(leaveallocation, employee_list, leavetype_name);
		if (validate == 1) {
			m.addAttribute("error", 1);
		} else {
			m.addAttribute("error", 0);
		}

		return "redirect:/AllocateLeave";
	}

}
