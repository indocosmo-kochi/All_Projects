/**
 * @author Anandhapadmanabhan
 *
 * @version 0.0.1 Mar 11, 2020
 *
 *
 */
package com.indocosmo.hrmis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.indocosmo.hrmis.bean.DesignationBean;
import com.indocosmo.hrmis.dao.DesignationDAO;

@Controller
public class DesignationController {

	@Autowired
	DesignationDAO designation_dao_object;
	
	@RequestMapping("viewDesignation")
	public String viewDesignation(Model model_object) {
		List<DesignationBean> designation_list = designation_dao_object.getDesignations();
		model_object.addAttribute("designation_list", designation_list);
		return "admin/employee/view_designation";
	}

	@RequestMapping("addDesignation")
	public String addDesignation() {
		return "admin/employee/add_designation";
	}
	
	@RequestMapping(value = "/addDesignationSave", method = RequestMethod.POST)
	public String addDesignationSave(@ModelAttribute("designation_bean_object") DesignationBean designation_bean_object) {
		designation_dao_object.insertDesignation(designation_bean_object);
		return "redirect:/viewDesignation";
	}
	
	@RequestMapping(value = "/editDesignationView/{designation_id}")
	public String editDesignationView(@PathVariable String designation_id, Model model_object) {
		DesignationBean designation_bean_object = designation_dao_object.getDesignationById(designation_id);
		model_object.addAttribute("designation", designation_bean_object);
		return "admin/employee/edit_designation";
	}
	
	@RequestMapping(value = "/editDesignationSave", method = RequestMethod.POST)
	public String editDesignationSave(@ModelAttribute("designation_bean_object") DesignationBean designation_bean_object) {
		designation_dao_object.editDesignation(designation_bean_object);
		return "redirect:/viewDesignation";
	}
	
	@RequestMapping(value = "/deleteDesignation/{designation_id}")
	public String deleteDesignation(@PathVariable String designation_id, Model model_object) {
		int designation_bean_object = designation_dao_object.deleteDesignation(designation_id);
		model_object.addAttribute("designation", designation_bean_object);
		return "redirect:/viewDesignation";
	}
}
