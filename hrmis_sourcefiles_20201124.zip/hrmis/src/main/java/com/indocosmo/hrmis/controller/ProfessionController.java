/**
 * @author Jeswin Chacko P A
 *
 * @version 0.0.1 Mar 5, 2020
 *
 *
 */
package com.indocosmo.hrmis.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.indocosmo.hrmis.bean.ProfessionBean;
import com.indocosmo.hrmis.dao.ProfessionDAO;

@Controller
public class ProfessionController {

	@Autowired
	ProfessionDAO profession_dao_object;
	
	@RequestMapping("professionalQualification")
	public String professionalQualification(Model model_object,HttpSession session) {
		String employee_id = (String) session.getAttribute("userid");
		List<ProfessionBean> profession_list = profession_dao_object.getProfessions(employee_id);
		if(profession_list.size() == 0) {
			return "employee/personalInformation/professional_qualifications_empty";
		}
		model_object.addAttribute("profession_list", profession_list);
		return "employee/personalInformation/professional_qualifications_view";
	}
	
	@RequestMapping(value = "/addProfessionSave", method = RequestMethod.POST)
	public String saveProfession(@ModelAttribute("profession_bean_object") ProfessionBean profession_bean_object,HttpSession session) {
		String employee_id = (String) session.getAttribute("userid");
		profession_dao_object.insertProfession(profession_bean_object,employee_id);
		return "redirect:/professionalQualification";
	}
	
	@RequestMapping(value = "/editProfessionSave", method = RequestMethod.POST)
	public String editProfessionSave(@ModelAttribute("profession_bean_object") ProfessionBean profession_bean_object,HttpSession session) {
		String employee_id = (String) session.getAttribute("userid");
		profession_dao_object.editProfession(profession_bean_object,employee_id);
		return "redirect:/professionalQualification";
	}
	
	@RequestMapping("addProfession")
	public String personalDetails() {
		return "employee/personalInformation/professional_qualifications_add";
	}
}
