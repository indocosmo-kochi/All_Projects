/**
 * 
 */
package com.indocosmo.hrmis.bean;

/**
 * @author Ayana P Dharman
 *
 * @version 0.0.1 May 12, 2020
 */
public class LeaveTypeBean {
	
	private int leavetype_id;
	private String leavetype_name;
	private String leavetype_location;
	private String schedular_type;
	private String carry_forward_status;
	private int leaves_per_year;
	private String location;
	
	
	
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getLeavetype_id() {
		return leavetype_id;
	}
	public void setLeavetype_id(int leavetype_id) {
		this.leavetype_id = leavetype_id;
	}
	public String getLeavetype_name() {
		return leavetype_name;
	}
	public void setLeavetype_name(String leavetype_name) {
		this.leavetype_name = leavetype_name;
	}
	public String getLeavetype_location() {
		return leavetype_location;
	}
	public void setLeavetype_location(String leavetype_location) {
		this.leavetype_location = leavetype_location;
	}
	public String getSchedular_type() {
		return schedular_type;
	}
	public void setSchedular_type(String schedular_type) {
		this.schedular_type = schedular_type;
	}
	public String getCarry_forward_status() {
		return carry_forward_status;
	}
	public void setCarry_forward_status(String carry_forward_status) {
		this.carry_forward_status = carry_forward_status;
	}
	public int getLeaves_per_year() {
		return leaves_per_year;
	}
	public void setLeaves_per_year(int leaves_per_year) {
		this.leaves_per_year = leaves_per_year;
	}
	
	
	

}
