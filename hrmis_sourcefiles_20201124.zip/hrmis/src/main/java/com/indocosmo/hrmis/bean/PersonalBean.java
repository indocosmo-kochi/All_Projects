/**
 * @author Jeswin Chacko P A
 *
 * @version 0.0.1 Mar 5, 2020
 *
 *
 */
package com.indocosmo.hrmis.bean;

public class PersonalBean {

	private String father_name;
	private int father_age;
	private String father_occupation;
	private String mother_name;
	private int mother_age;
	private String mother_occupation;
	private String spouse_name;
	private int spouse_age;
	private String spouse_occupation;
	private String child_name,child_name_array[];
	private int child_age,child_age_array[];
	private String child_occupation,child_occupation_array[];
	private String sibling_name,sibling_name_array[];
	private int sibling_age,sibling_age_array[];
	private String sibling_occupation,sibling_occupation_array[];
	private int child_id,child_id_array[];
	private int sibling_id,sibling_id_array[];
	
	public String getFather_name() {
		return father_name;
	}
	public void setFather_name(String father_name) {
		this.father_name = father_name;
	}
	public int getFather_age() {
		return father_age;
	}
	public void setFather_age(int father_age) {
		this.father_age = father_age;
	}
	public String getFather_occupation() {
		return father_occupation;
	}
	public void setFather_occupation(String father_occupation) {
		this.father_occupation = father_occupation;
	}
	public String getMother_name() {
		return mother_name;
	}
	public void setMother_name(String mother_name) {
		this.mother_name = mother_name;
	}
	public int getMother_age() {
		return mother_age;
	}
	public void setMother_age(int mother_age) {
		this.mother_age = mother_age;
	}
	public String getMother_occupation() {
		return mother_occupation;
	}
	public void setMother_occupation(String mother_occupation) {
		this.mother_occupation = mother_occupation;
	}
	public String getSpouse_name() {
		return spouse_name;
	}
	public void setSpouse_name(String spouse_name) {
		this.spouse_name = spouse_name;
	}
	public int getSpouse_age() {
		return spouse_age;
	}
	public void setSpouse_age(int spouse_age) {
		this.spouse_age = spouse_age;
	}
	public String getSpouse_occupation() {
		return spouse_occupation;
	}
	public void setSpouse_occupation(String spouse_occupation) {
		this.spouse_occupation = spouse_occupation;
	}
	public String getChild_name() {
		return child_name;
	}
	public void setChild_name(String child_name) {
		this.child_name = child_name;
	}
	public String[] getChild_name_array() {
		return child_name_array;
	}
	public void setChild_name_array(String[] child_name_array) {
		this.child_name_array = child_name_array;
	}
	public int getChild_age() {
		return child_age;
	}
	public void setChild_age(int child_age) {
		this.child_age = child_age;
	}
	public int[] getChild_age_array() {
		return child_age_array;
	}
	public void setChild_age_array(int[] child_age_array) {
		this.child_age_array = child_age_array;
	}
	public String getChild_occupation() {
		return child_occupation;
	}
	public void setChild_occupation(String child_occupation) {
		this.child_occupation = child_occupation;
	}
	public String[] getChild_occupation_array() {
		return child_occupation_array;
	}
	public void setChild_occupation_array(String[] child_occupation_array) {
		this.child_occupation_array = child_occupation_array;
	}
	public String getSibling_name() {
		return sibling_name;
	}
	public void setSibling_name(String sibling_name) {
		this.sibling_name = sibling_name;
	}
	public String[] getSibling_name_array() {
		return sibling_name_array;
	}
	public void setSibling_name_array(String[] sibling_name_array) {
		this.sibling_name_array = sibling_name_array;
	}
	public int getSibling_age() {
		return sibling_age;
	}
	public void setSibling_age(int sibling_age) {
		this.sibling_age = sibling_age;
	}
	public int[] getSibling_age_array() {
		return sibling_age_array;
	}
	public void setSibling_age_array(int[] sibling_age_array) {
		this.sibling_age_array = sibling_age_array;
	}
	public String getSibling_occupation() {
		return sibling_occupation;
	}
	public void setSibling_occupation(String sibling_occupation) {
		this.sibling_occupation = sibling_occupation;
	}
	public String[] getSibling_occupation_array() {
		return sibling_occupation_array;
	}
	public void setSibling_occupation_array(String[] sibling_occupation_array) {
		this.sibling_occupation_array = sibling_occupation_array;
	}
	public int getChild_id() {
		return child_id;
	}
	public void setChild_id(int child_id) {
		this.child_id = child_id;
	}
	public int[] getChild_id_array() {
		return child_id_array;
	}
	public void setChild_id_array(int[] child_id_array) {
		this.child_id_array = child_id_array;
	}
	public int getSibling_id() {
		return sibling_id;
	}
	public void setSibling_id(int sibling_id) {
		this.sibling_id = sibling_id;
	}
	public int[] getSibling_id_array() {
		return sibling_id_array;
	}
	public void setSibling_id_array(int[] sibling_id_array) {
		this.sibling_id_array = sibling_id_array;
	}
}
