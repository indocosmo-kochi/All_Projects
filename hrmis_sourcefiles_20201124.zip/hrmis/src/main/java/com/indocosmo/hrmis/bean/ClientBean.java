package com.indocosmo.hrmis.bean;

/**
 * @author Ayana P Dharman
 *
 * @version 0.0.1 Mar 5, 2020
 */
public class ClientBean {
	
	private int client_id;
	private String client_name,client_location;
	private int holiday_id;
	
	
	public int getclient_id() {
		return client_id;
	}
	public void setclient_id(int client_id) {
		this.client_id = client_id;
	}
	public String getclient_name() {
		return client_name;
	}
	public void setclient_name(String client_name) {
		this.client_name = client_name;
	}
	public String getclient_location() {
		return client_location;
	}
	public void setclient_location(String client_location) {
		this.client_location = client_location;
	}
	public int getHoliday_id() {
		return holiday_id;
	}
	public void setHoliday_id(int holiday_id) {
		this.holiday_id = holiday_id;
	}

}
