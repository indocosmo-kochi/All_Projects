/**
 * @author Jeswin Chacko P A
 * 
 * @version 0.0.1 Feb 27, 2020
 * 
 * 
 */
package com.indocosmo.hrmis.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.indocosmo.hrmis.bean.ApproverBean;
import com.indocosmo.hrmis.bean.ClientBean;
import com.indocosmo.hrmis.bean.DesignationBean;
import com.indocosmo.hrmis.bean.EmployeeBean;
import com.indocosmo.hrmis.bean.LocationBean;
import com.indocosmo.hrmis.dao.ApproverDAO;
import com.indocosmo.hrmis.dao.ClientDAO;
import com.indocosmo.hrmis.dao.DesignationDAO;
import com.indocosmo.hrmis.dao.EmployeeDAO;

@Controller
public class EmployeeController {

	@Autowired
	EmployeeDAO employee_dao_object;
	@Autowired
	DesignationDAO designation_dao_object;
	@Autowired
	ClientDAO client_dao_object;
	@Autowired
	ApproverDAO approver_dao_object;

	@RequestMapping("viewEmployee")
	public String viewEmployee(Model model_object) {
		List<EmployeeBean> employee_list = employee_dao_object.getEmployees();
		model_object.addAttribute("employee_list", employee_list);
		return "admin/employee/view_employee";
	}

	@RequestMapping("addEmployee")
	public String addEmployee(Model model_object) {
		List<DesignationBean> designation_list = designation_dao_object.getDesignations();
		model_object.addAttribute("designation_list", designation_list);
		List<LocationBean> location_list = designation_dao_object.getLocations();
		model_object.addAttribute("location_list", location_list);
		List<ClientBean> client_list = client_dao_object.getclient();
		model_object.addAttribute("client_list", client_list);
		return "admin/employee/add_employee";
	}

	@RequestMapping(value = "/addEmployeeSave", method = RequestMethod.POST)
	public String addEmployeeSave(@ModelAttribute("employee_bean_object") EmployeeBean employee_bean_object) {
		employee_dao_object.insertEmployee(employee_bean_object);
		return "redirect:/viewEmployee";
	}

	@RequestMapping(value = "/editEmployeeView/{employee_id}")
	public String editEmployeeView(@PathVariable int employee_id, Model model_object) {
		EmployeeBean employee_bean_object = employee_dao_object.getEmployeeById(employee_id);
		model_object.addAttribute("employee", employee_bean_object);
		List<DesignationBean> designation_list = designation_dao_object.getDesignations();
		model_object.addAttribute("designation_list", designation_list);
		List<LocationBean> location_list = designation_dao_object.getLocations();
		model_object.addAttribute("location_list", location_list);
		List<ClientBean> client_list = client_dao_object.getclient();
		model_object.addAttribute("client_list", client_list);
		List<ApproverBean> approver_list = approver_dao_object.getApprovers(employee_id);
		model_object.addAttribute("approver_list", approver_list);
		
		return "admin/employee/edit_employee";
	}

	@RequestMapping(value = "/editEmployeeSave", method = RequestMethod.POST)
	public String editEmployeeSave(@ModelAttribute("employee_bean_object") EmployeeBean employee_bean_object) {
		employee_dao_object.editEmployee(employee_bean_object);
		return "redirect:/viewEmployee";
	}

	@RequestMapping(value = "/deleteEmployee/{employee_id}")
	public String deleteEmployee(@PathVariable int employee_id, Model model_object) {
		int employee_bean_object = employee_dao_object.deleteEmployee(employee_id);
		model_object.addAttribute("employee", employee_bean_object);
		return "redirect:/viewEmployee";
	}

	@RequestMapping(value = "/saveBioData", method = RequestMethod.POST)
	public String saveBioData(@ModelAttribute("employee_bean_object") EmployeeBean employee_bean_object,HttpSession session) {
		int employee_id = (Integer) session.getAttribute("userid");
		employee_dao_object.saveBioData(employee_bean_object,employee_id);
		return "redirect:/employeeHome";
	}
	
}
