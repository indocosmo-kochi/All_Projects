package com.indocosmo.hrmis.controller;

import java.util.List;
import java.util.Map;

import javax.mail.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.indocosmo.hrmis.bean.EmployeeLeaveBean;
import com.indocosmo.hrmis.bean.HolidayBean;
import com.indocosmo.hrmis.bean.LeaveTypeBean;
import com.indocosmo.hrmis.bean.LoginBean;
import com.indocosmo.hrmis.bean.WorkReportBean;
import com.indocosmo.hrmis.dao.EmployeeLeaveDAO;
import com.indocosmo.hrmis.dao.HolidayDAO;
import com.indocosmo.hrmis.dao.LoginDAO;
import com.indocosmo.hrmis.dao.WorkReportDAO;

/**
 * @author Ayana P Dharman
 *
 * @version 0.0.1 Mar 5, 2020
 */
@Controller
public class LoginController {

	@Autowired
	LoginDAO daologin;
	@Autowired
	HolidayDAO holiday_dao_object;
	@Autowired
	EmployeeLeaveDAO emp_leavedao_object;
	@Autowired
	WorkReportDAO workreport_dao_object;

	@RequestMapping("hrmis_login")
	public String index() {
		return "login/hrmis_login";
	}

	@RequestMapping(value = "/loginCheck", method = RequestMethod.POST)
	public String login(@ModelAttribute("loginbeanobj") LoginBean loginbeanobj, HttpSession session,
			Model model_object) {
		int count = daologin.loginCheck(loginbeanobj);
		if (count == 0) {
			return "redirect:/";
		}
		String employee_code = loginbeanobj.getEmployee_code();
		session.setAttribute("userid", employee_code);
		loginbeanobj = daologin.getUserById(employee_code);
		int employee_id = loginbeanobj.getEmployee_id();
		loginbeanobj = daologin.getLoginDeatails(employee_id);
		int admin_flag = loginbeanobj.getAdmin_flag();
		int is_approver = loginbeanobj.getIsApprover();
		String designation_name = loginbeanobj.getDesignation_name();
		session.setAttribute("employee_id", employee_id);
		session.setAttribute("employee_code", employee_code);
		session.setAttribute("admin_flag", admin_flag);
		session.setAttribute("designation_name", designation_name);
		session.setAttribute("is_approver", loginbeanobj.getIsApprover());
		if (admin_flag == 1) {
			model_object.addAttribute("admin", 1);
			model_object.addAttribute("employee_id", employee_id);
			List<HolidayBean> holiday_list = holiday_dao_object.getHolidayDateByEmployee(employee_id);
			model_object.addAttribute("holiday_list", holiday_list);
			return "admin/admin_home";
		} else {
			if (designation_name.equalsIgnoreCase("HR Manager")) {
				model_object.addAttribute("employee_id", employee_id);
				model_object.addAttribute("hr", 1);
				List<HolidayBean> holiday_list = holiday_dao_object.getHolidayDateByEmployee(employee_id);
				model_object.addAttribute("holiday_list", holiday_list);
				List<EmployeeLeaveBean> approve_list = emp_leavedao_object.getApproveList(employee_id);
				model_object.addAttribute("approve_list", approve_list);

				List<EmployeeLeaveBean> request_list = emp_leavedao_object.getRequestList(employee_id);
				model_object.addAttribute("request_list", request_list);

				List<WorkReportBean> reportlist = workreport_dao_object.getReportList();
				model_object.addAttribute("reportlist", reportlist);
				System.out.println(reportlist.size());
				return "employee/employee_home";
			} else if (is_approver == 0) {
				model_object.addAttribute("employee_id", employee_id);
				model_object.addAttribute("approver", 0);
				model_object.addAttribute("hr", 0);
				List<HolidayBean> holiday_list = holiday_dao_object.getHolidayDateByEmployee(employee_id);
				model_object.addAttribute("holiday_list", holiday_list);
				List<EmployeeLeaveBean> request_list = emp_leavedao_object.getRequestList(employee_id);
				model_object.addAttribute("request_list", request_list);
				return "employee/employee_home";
			} else {
				model_object.addAttribute("employee_id", employee_id);
				model_object.addAttribute("approver", 1);
				model_object.addAttribute("hr", 0);
				List<HolidayBean> holiday_list = holiday_dao_object.getHolidayDateByEmployee(employee_id);
				model_object.addAttribute("holiday_list", holiday_list);
				List<EmployeeLeaveBean> approve_list = emp_leavedao_object.getApproveList(employee_id);
				model_object.addAttribute("approve_list", approve_list);
				List<EmployeeLeaveBean> request_list = emp_leavedao_object.getRequestList(employee_id);
				model_object.addAttribute("request_list", request_list);
				return "employee/employee_home";
			}
		}

	}

	@RequestMapping("dashboard")
	public String dashboard(Model model_object, HttpSession session) {
		int employee_id = (Integer) session.getAttribute("employee_id");
		int admin_flag = (Integer) session.getAttribute("admin_flag");
		int is_approver = (Integer) session.getAttribute("is_approver");
		String designation_name = (String) session.getAttribute("designation_name");

		if (admin_flag == 1) {
			model_object.addAttribute("employee_id", employee_id);
			List<HolidayBean> holiday_list = holiday_dao_object.getHolidayDateByEmployee(employee_id);
			model_object.addAttribute("holiday_list", holiday_list);
			return "admin/admin_home";
		} else {
			if (designation_name.equalsIgnoreCase("HR Manager")) {
				model_object.addAttribute("employee_id", employee_id);
				model_object.addAttribute("hr", 1);
				List<HolidayBean> holiday_list = holiday_dao_object.getHolidayDateByEmployee(employee_id);
				model_object.addAttribute("holiday_list", holiday_list);
				List<EmployeeLeaveBean> approve_list = emp_leavedao_object.getApproveList(employee_id);
				model_object.addAttribute("approve_list", approve_list);
				List<EmployeeLeaveBean> request_list = emp_leavedao_object.getRequestList(employee_id);
				model_object.addAttribute("request_list", request_list);
				List<WorkReportBean> reportlist = workreport_dao_object.getReportList();
				model_object.addAttribute("reportlist", reportlist);
				
				return "employee/employee_home";
			} else if (is_approver == 0) {
				model_object.addAttribute("employee_id", employee_id);
				model_object.addAttribute("approver", 0);
				model_object.addAttribute("hr", 0);
				List<HolidayBean> holiday_list = holiday_dao_object.getHolidayDateByEmployee(employee_id);
				model_object.addAttribute("holiday_list", holiday_list);
				List<EmployeeLeaveBean> request_list = emp_leavedao_object.getRequestList(employee_id);
				model_object.addAttribute("request_list", request_list);
				return "employee/employee_home";
			} else {
				model_object.addAttribute("employee_id", employee_id);
				model_object.addAttribute("approver", 1);
				model_object.addAttribute("hr", 0);
				List<HolidayBean> holiday_list = holiday_dao_object.getHolidayDateByEmployee(employee_id);
				model_object.addAttribute("holiday_list", holiday_list);
				List<EmployeeLeaveBean> approve_list = emp_leavedao_object.getApproveList(employee_id);
				model_object.addAttribute("approve_list", approve_list);
				List<EmployeeLeaveBean> request_list = emp_leavedao_object.getRequestList(employee_id);
				model_object.addAttribute("request_list", request_list);
				return "employee/employee_home";
			}
		}
	}

	@RequestMapping("logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}

	/*
	 * @RequestMapping(value = "/getApproverlistbyhr", method = RequestMethod.POST)
	 * public String approverlist(@ModelAttribute("loginbeanobj") LoginBean
	 * loginbeanobj, HttpSession session, Model model_object) { int employee_id =
	 * (Integer) session.getAttribute("employee_id"); List<EmployeeLeaveBean>
	 * approve_listHr = emp_leavedao_object.getApproveListForHr(employee_id);
	 * model_object.addAttribute("approve_list", approve_listHr); return
	 * "employee/leaveRequest/table"; }
	 */

	/*
	 * @RequestMapping(value = "/getApproverlistbyhr") public String
	 * getleavetypebyid(Model model_object,HttpSession session) { int employee_id =
	 * (Integer) session.getAttribute("employee_id"); List<EmployeeLeaveBean>
	 * approve_listHr = emp_leavedao_object.getApproveListForHr(employee_id);
	 * model_object.addAttribute("approve_list", approve_listHr); return
	 * "employee/leaveRequest/table"; }
	 */
	
	@RequestMapping(method=RequestMethod.POST, value="/getApproverlistbyhr")
	public @ResponseBody List<EmployeeLeaveBean> getApproverList(Model model_object,HttpSession session)
	{
		System.out.println("hgvvghhgh");
		int employee_id = (Integer) session.getAttribute("employee_id");
		List<EmployeeLeaveBean> approve_listHr = emp_leavedao_object.getApproveListForHr(employee_id);
		System.out.println(approve_listHr.size());
	    return approve_listHr;
	}

}
