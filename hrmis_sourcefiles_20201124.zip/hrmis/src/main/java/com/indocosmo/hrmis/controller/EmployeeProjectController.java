/**
 * 
 */
package com.indocosmo.hrmis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.indocosmo.hrmis.bean.ClientProjectBean;
import com.indocosmo.hrmis.bean.EmployeeProjectBean;
import com.indocosmo.hrmis.bean.LocationBean;
import com.indocosmo.hrmis.bean.ProjectManagerBean;
import com.indocosmo.hrmis.dao.ClientProjectDAO;
import com.indocosmo.hrmis.dao.EmployeeprojectDAO;
import com.indocosmo.hrmis.dao.LocationDAO;
import com.indocosmo.hrmis.dao.ProjectManagerDAO;

/**
 * @author Ayana P Dharman 
 *
 * @version 0.0.1 Jul 23, 2020
 */

@Controller
public class EmployeeProjectController {
	
	@Autowired
	EmployeeprojectDAO employee_project_dao_object;
	@Autowired
	LocationDAO location_dao_object;
	@Autowired
	ClientProjectDAO client_project_dao_object;
	@Autowired
	ProjectManagerDAO project_manager_dao_object;
	
	@RequestMapping("/employeeProjectView/{employee_id}")
	public String employeeProjectView(@PathVariable int employee_id, Model m) {
		List<EmployeeProjectBean> employee_project_list = employee_project_dao_object.getEmployeeProjects(employee_id);
		m.addAttribute("employee_project", employee_project_list);
		m.addAttribute("employee_id",employee_id);
		return "admin/employeeproject/view_employee_project";
	}
	
	@RequestMapping("/projecthistory")
	public String projecthistory(Model m) {
		List<EmployeeProjectBean> employee_project_history = employee_project_dao_object.getEmployeeHistory();
		m.addAttribute("employee_project_history", employee_project_history);
		return "admin/employeeproject/employee_project_history";
	}
	
	@RequestMapping("/addEmployeeProject/{employee_id}")
	public String addEmployeeProject(@PathVariable int employee_id, Model m) {
		List<LocationBean> location_list = location_dao_object.getLocations();
		m.addAttribute("location_list", location_list);
		List<ClientProjectBean> clientt_project_list = client_project_dao_object.getClientProjects();
		m.addAttribute("clientt_project_list", clientt_project_list);
		List<ProjectManagerBean> project_manager_list = project_manager_dao_object.getProjectManagers();
		m.addAttribute("project_manager_list", project_manager_list);
		m.addAttribute("employee_id",employee_id);
		return "admin/employeeproject/add_employee_project";
	}
	
	@RequestMapping(value = "/addEmployeeProjectSave", method = RequestMethod.POST)
	public String addEmployeeProjectSave(@ModelAttribute("designation_bean_object") EmployeeProjectBean employee_project_bean_object){
		employee_project_dao_object.insertEmployeeProject(employee_project_bean_object);
		return "redirect:/employeeProjectView/"+employee_project_bean_object.getEmployee_id();
	}
	
	@RequestMapping("/editEmployeeProjectView/{employee_project_id}")
	public String editEmployeeProjectView(@PathVariable int employee_project_id, Model m) {
		List<LocationBean> location_list = location_dao_object.getLocations();
		m.addAttribute("location_list", location_list);
		List<ClientProjectBean> clientt_project_list = client_project_dao_object.getClientProjects();
		m.addAttribute("clientt_project_list", clientt_project_list);
		List<ProjectManagerBean> project_manager_list = project_manager_dao_object.getProjectManagers();
		m.addAttribute("project_manager_list", project_manager_list);
		EmployeeProjectBean employee_project_bean_object = employee_project_dao_object.getEmployeeProjectById(employee_project_id);
		m.addAttribute("employee_project",employee_project_bean_object);
		m.addAttribute("employee_id",employee_project_bean_object.getEmployee_id());
		return "admin/employeeproject/edit_employee_project";
	}
	
	@RequestMapping(value = "/editEmployeeProjectSave", method = RequestMethod.POST)
	public String editEmployeeProjectSave(@ModelAttribute("designation_bean_object") EmployeeProjectBean employee_project_bean_object){
		employee_project_dao_object.editEmployeeProject(employee_project_bean_object);
		return "redirect:/employeeProjectView/"+employee_project_bean_object.getEmployee_id();
	}
	
	@RequestMapping(value = "/deleteEmployeeProject")
	public String deleteDesignation(@RequestParam("emp_project_id") int emp_project_id,
					@RequestParam("employee_id") int employee_id, Model model_object) {
		employee_project_dao_object.deleteEmployeeProject(emp_project_id);
		return "redirect:/employeeProjectView/"+employee_id;
	}

}
