/**
 * 
 */
package com.indocosmo.hrmis.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.indocosmo.hrmis.bean.ClientBean;
import com.indocosmo.hrmis.bean.ClientProjectBean;

/**
 * @author Ayana P Dharman
 * 
 * @version 0.0.1 08 July 2020
 *
 */
public class ClientProjectDAO {

	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	
	public List<ClientProjectBean> getClientProjects() {
		return template.query("SELECT * FROM client_project_tbl WHERE is_deleted=0", new RowMapper<ClientProjectBean>() {
			public ClientProjectBean mapRow(ResultSet rs, int row) throws SQLException {
				ClientProjectBean client_project_bean_object = new ClientProjectBean();
				client_project_bean_object.setProject_id(rs.getInt(1));
				client_project_bean_object.setProject_name(rs.getString(2));
				client_project_bean_object.setClient_id(rs.getInt(3));
				return client_project_bean_object;
			}
		});
	}

	public int clientprojectsave(ClientProjectBean clientproject) {
		System.out.println("inside");
		// TODO Auto-generated method stub
		String sql = "insert into client_project_tbl(project_name,client_id) values('" + clientproject.getProject_name()
				+ "','" + clientproject.getClient_id() + "')";
		return template.update(sql);

	}

	public int clientdelete(int client_id) {
		String sql = "update client_tbl set client_isdelete=1 where client_id=" + client_id + "";
		return template.update(sql);
	}

	public ClientBean getclientById(int client_id) {
		String sql = "select * from client_tbl where client_id=?";
		return template.queryForObject(sql, new Object[] { client_id },
				new BeanPropertyRowMapper<ClientBean>(ClientBean.class));
	}

	public List<ClientProjectBean> getclientprojectById(int client_id) {
		return template.query("select * from client_project_tbl where is_deleted=0 and client_id=" + client_id + "",
				new RowMapper<ClientProjectBean>() {
					public ClientProjectBean mapRow(ResultSet rs, int row) throws SQLException {
						ClientProjectBean e = new ClientProjectBean();
						e.setProject_id(rs.getInt(1));
						e.setProject_name(rs.getString(2));
						return e;
					}
				});
	}

	public ClientProjectBean getprojectById(int project_id) {
		String sql = "select * from client_project_tbl where project_id=?";
		return template.queryForObject(sql, new Object[] { project_id },
				new BeanPropertyRowMapper<ClientProjectBean>(ClientProjectBean.class));
	}

	public int deleteproject(int project_id) {
		String sql = "update client_project_tbl set is_deleted=1 where project_id=" + project_id + "";
		return template.update(sql);
	}

	public int clientprojectupdate(ClientProjectBean clientproject) {

		String sql = "update client_project_tbl set project_name='" + clientproject.getProject_name()
				+ "' where project_id=" + clientproject.getProject_id() + "";
		return template.update(sql);

	}

}
