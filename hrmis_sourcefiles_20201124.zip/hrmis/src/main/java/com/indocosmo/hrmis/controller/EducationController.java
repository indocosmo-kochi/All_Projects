/**
 * @author Jeswin Chacko P A
 *
 * @version 0.0.1 Feb 29, 2020
 *
 *
 */
package com.indocosmo.hrmis.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.indocosmo.hrmis.bean.EducationBean;
import com.indocosmo.hrmis.dao.EducationDAO;

@Controller
public class EducationController {

	@Autowired
	EducationDAO education_dao_object;
	
	@RequestMapping("educationalQualification")
	public String educationalQualification(Model model_object,HttpSession session) {
		String employee_id = (String) session.getAttribute("userid");
		List<EducationBean> education_list = education_dao_object.getEducations(employee_id);
		if(education_list.size() == 0) {
			return "employee/personalInformation/educational_qualification_empty";
		}
		model_object.addAttribute("education_list", education_list);
		return "employee/personalInformation/educational_qualification_view";
	}
	
	@RequestMapping(value = "/addEducationSave", method = RequestMethod.POST)
	public String saveEducation(@ModelAttribute("education_bean_object") EducationBean education_bean_object,HttpSession session) {
		String employee_id = (String) session.getAttribute("userid");
		education_dao_object.insertEducation(education_bean_object,employee_id);
		return "redirect:/educationalQualification";
	}
	
	@RequestMapping(value = "/editEducationSave", method = RequestMethod.POST)
	public String editEducationSave(@ModelAttribute("education_bean_object") EducationBean education_bean_object,HttpSession session) {
		String employee_id = (String) session.getAttribute("userid");
		education_dao_object.editEducation(education_bean_object,employee_id);
		return "redirect:/educationalQualification";
	}
	
	@RequestMapping("addEducation")
	public String personalDetails() {
		return "employee/personalInformation/educational_qualification_add";
	}
}
