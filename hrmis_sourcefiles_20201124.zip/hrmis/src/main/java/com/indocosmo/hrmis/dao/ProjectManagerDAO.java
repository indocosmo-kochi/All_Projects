/**
 * 
 */
package com.indocosmo.hrmis.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.indocosmo.hrmis.bean.ProjectManagerBean;

/**
 * @author Ayana P Dharman
 *
 * @version 0.0.1 Jul 10, 2020
 */
public class ProjectManagerDAO {

	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	
	public List<ProjectManagerBean> getProjectManagers() {
		return template.query("SELECT * FROM project_manager_tbl WHERE is_deleted=0", new RowMapper<ProjectManagerBean>() {
			public ProjectManagerBean mapRow(ResultSet rs, int row) throws SQLException {
				ProjectManagerBean project_manager_bean_object = new ProjectManagerBean();
				project_manager_bean_object.setManager_id(rs.getInt(1));
				project_manager_bean_object.setManager_name(rs.getString(2));
				project_manager_bean_object.setProject_id(rs.getInt(3));
				return project_manager_bean_object;
			}
		});
	}

	public List<ProjectManagerBean> getprojectManagerById(int project_id) {
		return template.query("select * from project_manager_tbl where is_deleted=0 and project_id=" + project_id + "",
				new RowMapper<ProjectManagerBean>() {
					public ProjectManagerBean mapRow(ResultSet rs, int row) throws SQLException {
						ProjectManagerBean e = new ProjectManagerBean();
						e.setManager_id(rs.getInt(1));
						e.setManager_name(rs.getString(2));
						return e;
					}
				});
	}

	public int projectmanagersave(ProjectManagerBean projectmanager) {
		String sql = "insert into project_manager_tbl(manager_name,project_id) values('"
				+ projectmanager.getManager_name() + "','" + projectmanager.getProject_id() + "')";
		return template.update(sql);

	}

	public int deleteprojectmanager(int manager_id) {
		String sql = "update project_manager_tbl set is_deleted=1 where manager_id=" + manager_id + "";
		return template.update(sql);

	}

	public ProjectManagerBean getManagerById(int manager_id) {
		String sql = "select * from project_manager_tbl where manager_id=?";
		return template.queryForObject(sql, new Object[] { manager_id },
				new BeanPropertyRowMapper<ProjectManagerBean>(ProjectManagerBean.class));
	}

	public int projectmanagerupdate(ProjectManagerBean projectmanager) {
		// TODO Auto-generated method stub
		String sql = "update project_manager_tbl set manager_name='" + projectmanager.getManager_name()
				+ "' where manager_id=" + projectmanager.getManager_id() + "";
		return template.update(sql);
	}

}
