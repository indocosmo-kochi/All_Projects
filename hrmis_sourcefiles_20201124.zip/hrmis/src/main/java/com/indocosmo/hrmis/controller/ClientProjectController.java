/**
 * 
 */
package com.indocosmo.hrmis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.indocosmo.hrmis.bean.ClientProjectBean;
import com.indocosmo.hrmis.bean.ProjectManagerBean;
import com.indocosmo.hrmis.dao.ClientDAO;
import com.indocosmo.hrmis.dao.ClientProjectDAO;
import com.indocosmo.hrmis.dao.HolidayDAO;
import com.indocosmo.hrmis.dao.ProjectManagerDAO;

/**
 * @author Ayana P Dharman
 * 
 * @version 0.0.1 08 July 2020
 */
@Controller
public class ClientProjectController {

	@Autowired
	ClientDAO daoclient;

	@Autowired
	ClientProjectDAO daoclientproject;

	@Autowired
	HolidayDAO holiday_dao_object;
	
	@Autowired
	ProjectManagerDAO daoprojectmanager;

	@RequestMapping(value = "/add_client_project/{client_id}")
	public String client(@PathVariable int client_id, Model model_object) {
		model_object.addAttribute("client_id", client_id);
		return "admin/clientproject/add_client_project";
	}

	@RequestMapping(value = "/projectsave", method = RequestMethod.POST)
	public String clientprojectMasterSave(@ModelAttribute("clientproject") ClientProjectBean clientproject) {
		daoclientproject.clientprojectsave(clientproject);
		return "redirect:/editclient/" + clientproject.getClient_id();
	}

	@RequestMapping(value = "/deleteProject/{project_id}", method = RequestMethod.GET)
	public String deleteProject(@PathVariable int project_id, Model model_object) {
		daoclientproject.deleteproject(project_id);
		ClientProjectBean project_bean_object = daoclientproject.getprojectById(project_id);
		return "redirect:/editclient/" + project_bean_object.getClient_id();
	}

	@RequestMapping(value = "/editProject/{project_id}")
	public String clientprojectedit(@PathVariable int project_id, Model m) {

		ClientProjectBean project_list = daoclientproject.getprojectById(project_id);
		m.addAttribute("project_list", project_list);
		List<ProjectManagerBean> manager_list = daoprojectmanager.getprojectManagerById(project_id);
		m.addAttribute("manager_list", manager_list);
		
		return "admin/clientproject/update_client_project";
	}

	@RequestMapping(value = "/projecteditsave/{project_id}", method = RequestMethod.POST)
	public String clientprojecteditsave(@PathVariable int project_id,@ModelAttribute("clientproject") ClientProjectBean clientproject) {

		daoclientproject.clientprojectupdate(clientproject);
		ClientProjectBean project_bean_object = daoclientproject.getprojectById(project_id);
		return "redirect:/editclient/" + project_bean_object.getClient_id();
	}

}
