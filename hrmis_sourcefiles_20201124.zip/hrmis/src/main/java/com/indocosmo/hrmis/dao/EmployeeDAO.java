/**
 * @author Jeswin Chacko P A
 * 
 * @version 0.0.1 Feb 27, 2020
 * 
 * 
 */
package com.indocosmo.hrmis.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;

import com.indocosmo.hrmis.bean.EmployeeBean;
import com.indocosmo.hrmis.bean.LoginBean;
import com.indocosmo.hrmis.common.CommonQueries;

public class EmployeeDAO {

	CommonQueries sql_object;
	JdbcTemplate jdbc_template;

	public void setTemplate(JdbcTemplate jdbc_template) {
		this.jdbc_template = jdbc_template;
	}

	public List<EmployeeBean> getEmployees() { // To show every employees as a table
		/*String table_name = "employee";
		String sql = sql_object.select(table_name);
		System.out.println(sql);*/
		return jdbc_template.query("SELECT * FROM employee WHERE is_deleted=0", new RowMapper<EmployeeBean>() {
			public EmployeeBean mapRow(ResultSet rs, int row) throws SQLException {
				EmployeeBean employee_bean_object = new EmployeeBean();
				employee_bean_object.setEmployee_id(rs.getInt(1));
				employee_bean_object.setEmployee_code(rs.getString(2));
				employee_bean_object.setEmployee_name(rs.getString(3));
				employee_bean_object.setLocation(rs.getInt(4));
				employee_bean_object.setDesignation(rs.getInt(5));
				employee_bean_object.setDate_of_appointment(rs.getDate(6));
				employee_bean_object.setPersonal_phone(rs.getString(7));
				employee_bean_object.setEmail_id_personal(rs.getString(8));
				employee_bean_object.setEmail_id_official(rs.getString(9));
				employee_bean_object.setPf_uan(rs.getString(10));
				employee_bean_object.setEsi_num(rs.getString(11));
				employee_bean_object.setStatus(rs.getString(17));
				employee_bean_object.setClient(rs.getInt(18));
				return employee_bean_object;
			}
		});
	}
	
	public List<EmployeeBean> getApproverForList(int selected_emp) { 
		return jdbc_template.query("SELECT employee_id,employee_name FROM employee "
				+ "WHERE employee_id<>"+selected_emp+" AND is_deleted=0 AND admin_flag=0 AND employee_id " + 
				"NOT IN (SELECT approver_emp_id FROM hrmis.approver_tbl "
				+ "WHERE employee_id="+selected_emp+" AND approver_isdeleted=0)", new RowMapper<EmployeeBean>() {
			public EmployeeBean mapRow(ResultSet rs, int row) throws SQLException {
				EmployeeBean employee_bean_object = new EmployeeBean();
				employee_bean_object.setEmployee_id(rs.getInt(1));
				employee_bean_object.setEmployee_name(rs.getString(2));
				return employee_bean_object;
			}
		});
	}

	public int insertEmployee(final EmployeeBean employee_bean_object) {
		String password = employee_bean_object.getPassword();
		final String encodedPassword = Base64.getEncoder().encodeToString(password.getBytes());
		
		String sql = "INSERT INTO employee (employee_code,employee_name,location,designation,date_of_appointment,personal_phone,email_id_personal,email_id_official,pf_uan,esi_num,password,status,client,admin_flag) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		return jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setString(1, employee_bean_object.getEmployee_code());
				prepared_statement_object.setString(2, employee_bean_object.getEmployee_name());
				prepared_statement_object.setInt(3, employee_bean_object.getLocation());
				prepared_statement_object.setInt(4, employee_bean_object.getDesignation());
				prepared_statement_object.setDate(5, employee_bean_object.getDate_of_appointment());
				prepared_statement_object.setString(6, employee_bean_object.getPersonal_phone());
				prepared_statement_object.setString(7, employee_bean_object.getEmail_id_personal());
				prepared_statement_object.setString(8, employee_bean_object.getEmail_id_official());
				prepared_statement_object.setString(9, employee_bean_object.getPf_uan());
				prepared_statement_object.setString(10, employee_bean_object.getEsi_num());
				prepared_statement_object.setString(11, encodedPassword);
				prepared_statement_object.setString(12, employee_bean_object.getStatus());
				prepared_statement_object.setInt(13, employee_bean_object.getClient());
				prepared_statement_object.setInt(14, employee_bean_object.getAdmin_flag());
				return prepared_statement_object.executeUpdate();
			}
		});
	}

	public EmployeeBean getEmployeeByCode(String employee_code) {
		String sql = "SELECT * FROM employee WHERE employee_code=? and is_deleted=0";
		return jdbc_template.queryForObject(sql, new Object[] { employee_code },
				new BeanPropertyRowMapper<EmployeeBean>(EmployeeBean.class));
	}
	
	
	
	

	public EmployeeBean getEmployeeById(int employee_id) {
		String sql = "SELECT * FROM employee WHERE employee_id=?";
		return jdbc_template.queryForObject(sql, new Object[] { employee_id },
				new BeanPropertyRowMapper<EmployeeBean>(EmployeeBean.class));
	}

	public int editEmployee(final EmployeeBean employee_bean_object) {
		String sql = "UPDATE employee SET employee_code=?,employee_name=?,location=?,designation=?,date_of_appointment=?,personal_phone=?,email_id_personal=?,email_id_official=?,pf_uan=?,esi_num=?,status=?,client=?,admin_flag=? WHERE employee_id=?";
		return jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setString(1, employee_bean_object.getEmployee_code());
				prepared_statement_object.setString(2, employee_bean_object.getEmployee_name());
				prepared_statement_object.setInt(3, employee_bean_object.getLocation());
				prepared_statement_object.setInt(4, employee_bean_object.getDesignation());
				prepared_statement_object.setDate(5, employee_bean_object.getDate_of_appointment());
				prepared_statement_object.setString(6, employee_bean_object.getPersonal_phone());
				prepared_statement_object.setString(7, employee_bean_object.getEmail_id_personal());
				prepared_statement_object.setString(8, employee_bean_object.getEmail_id_official());
				prepared_statement_object.setString(9, employee_bean_object.getPf_uan());
				prepared_statement_object.setString(10, employee_bean_object.getEsi_num());
				prepared_statement_object.setString(11, employee_bean_object.getStatus());
				prepared_statement_object.setInt(12, employee_bean_object.getClient());
				prepared_statement_object.setInt(13, employee_bean_object.getAdmin_flag());
				prepared_statement_object.setInt(14, employee_bean_object.getEmployee_id());
				return prepared_statement_object.executeUpdate();
			}
		});
	}

	public int deleteEmployee(int employee_id) {
		String sql = "UPDATE employee SET is_deleted=1 WHERE employee_id='"+employee_id+"'";
		return jdbc_template.update(sql);
	}

	public int saveBioData(final EmployeeBean employee_bean_object,int employee_id) {
		String sql = "UPDATE employee SET employee_name=?,father_or_spouse_name=?,employee_address=?,personal_phone=?,date_of_birth=?,email_id_personal=?,blood_group=? WHERE employee_id='"+employee_id+"'";
		return jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setString(1, employee_bean_object.getEmployee_name());
				prepared_statement_object.setString(2, employee_bean_object.getFather_or_spouse_name());
				prepared_statement_object.setString(3, employee_bean_object.getEmployee_address());
				prepared_statement_object.setString(4, employee_bean_object.getPersonal_phone());
				prepared_statement_object.setDate(5, employee_bean_object.getDate_of_birth());
				prepared_statement_object.setString(6, employee_bean_object.getEmail_id_personal());
				prepared_statement_object.setString(7, employee_bean_object.getBlood_group());
				return prepared_statement_object.executeUpdate();
			}
		});
	}

	public EmployeeBean getemployeeByName(String employee_name_array) {
		String sql = "select * from employee where employee_name=? and is_deleted=0";
		return jdbc_template.queryForObject(sql, new Object[] { employee_name_array },
				new BeanPropertyRowMapper<EmployeeBean>(EmployeeBean.class));
	}

	public EmployeeBean findById(String userid) {
		String sql = "select * from employee where employee_code=? and is_deleted=0";
		return jdbc_template.queryForObject(sql, new Object[] { userid },
				new BeanPropertyRowMapper<EmployeeBean>(EmployeeBean.class));
	}

	
	
	
	
}
