/**
 * 
 */
package com.indocosmo.hrmis.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.indocosmo.hrmis.bean.EmployeeBean;
import com.indocosmo.hrmis.bean.LeaveTypeBean;
import com.indocosmo.hrmis.bean.LocationBean;

/**
 * @author Ayana P Dharman
 * 
 * @version 0.0.1 24 April 2020
 *
 */
public class LeaveTypeDAO {

	  JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public int leavetypesave(LeaveTypeBean leavetype) {
		String sql = "insert into leavetype_tbl(leavetype_name,leavetype_location,schedular_type,leaves_per_year,carry_forward_status) values('"
				+ leavetype.getLeavetype_name() + "','" + leavetype.getLeavetype_location() + "','"
				+ leavetype.getSchedular_type() + "','" + leavetype.getLeaves_per_year() + "','"
				+ leavetype.getCarry_forward_status() + "')";
		return template.update(sql);

	}

	public int leavetypedelete(int leavetype_id) {
		String sql = "update leavetype_tbl set leavetype_isdeleted=1 where leavetype_id=" + leavetype_id + "";
		return template.update(sql);

	}

	public LeaveTypeBean getleavetypeById(int leavetype_id) {
		String sql = "select * from leavetype_tbl where leavetype_id=? and leavetype_isdeleted=0";
		return template.queryForObject(sql, new Object[] { leavetype_id },
				new BeanPropertyRowMapper<LeaveTypeBean>(LeaveTypeBean.class));
	}

	public int leavetypeupdate(LeaveTypeBean leavetype) {
		String sql = "update leavetype_tbl set leavetype_name='" + leavetype.getLeavetype_name()
				+ "',leavetype_location='" + leavetype.getLeavetype_location() + "',schedular_type='"
				+ leavetype.getSchedular_type() + "',leaves_per_year='" + leavetype.getLeaves_per_year()
				+ "',carry_forward_status='" + leavetype.getCarry_forward_status() + "' where leavetype_id='"
				+ leavetype.getLeavetype_id() + "'";
		return template.update(sql);

	}

	public List<LeaveTypeBean> getleavetype() {
		return template.query("select * from leavetype_tbl where leavetype_isdeleted=0",
				new RowMapper<LeaveTypeBean>() {
					public LeaveTypeBean mapRow(ResultSet rs, int row) throws SQLException {
						LeaveTypeBean e = new LeaveTypeBean();
						e.setLeavetype_id(rs.getInt(1));
						e.setLeavetype_name(rs.getString(2));
						e.setLeavetype_location(rs.getString(3));
						e.setSchedular_type(rs.getString(4));
						e.setCarry_forward_status(rs.getString(5));
						e.setLeaves_per_year(rs.getInt(6));

						return e;
					}
				});
	}

	public List<LocationBean> getLocations() {
		return template.query("SELECT * FROM location WHERE is_deleted=0", new RowMapper<LocationBean>() {
			public LocationBean mapRow(ResultSet rs, int row) throws SQLException {
				LocationBean location_bean_object = new LocationBean();
				location_bean_object.setLocation_id(rs.getInt(1));
				location_bean_object.setLocation_name(rs.getString(2));
				return location_bean_object;
			}
		});
	}

	public LeaveTypeBean getleavetypeByName(String leavetype_id) {
		String sql = "select * from leavetype_tbl where leavetype_id=? and leavetype_isdeleted=0";
		return template.queryForObject(sql, new Object[] { leavetype_id },
				new BeanPropertyRowMapper<LeaveTypeBean>(LeaveTypeBean.class));
	}

	

}
