/**
 * 
 */
package com.indocosmo.hrmis.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;

import com.indocosmo.hrmis.bean.EmployeeProjectBean;

/**
 * @author Ayana P Dharman 
 *
 * @version 0.0.1 Jul 23, 2020
 */
public class EmployeeprojectDAO {
	
	JdbcTemplate jdbc_template;

	public void setTemplate(JdbcTemplate jdbc_template) {
		this.jdbc_template = jdbc_template;
	}

	public List<EmployeeProjectBean> getEmployeeProjects(int employee_id) {
		String sql = "call hrmis.getProjects("+employee_id+")";
		return jdbc_template.query(sql, new RowMapper<EmployeeProjectBean>() {
			public EmployeeProjectBean mapRow(ResultSet rs, int row) throws SQLException {
				EmployeeProjectBean employee_project_bean_object = new EmployeeProjectBean();
				employee_project_bean_object.setEmp_project_id(rs.getInt(1));
				employee_project_bean_object.setProject_name(rs.getString(2));
				employee_project_bean_object.setLocation_name(rs.getString(3));
				employee_project_bean_object.setManager_name(rs.getString(4));
				employee_project_bean_object.setStart_date(rs.getDate(5));
				employee_project_bean_object.setEnd_date(rs.getDate(6));
				employee_project_bean_object.setProject_status(rs.getString(7));
				employee_project_bean_object.setTechnologies(rs.getString(8));
				return employee_project_bean_object;
			}
		});
	}

	public int insertEmployeeProject(final EmployeeProjectBean employee_project_bean_object) {
		String sql = "INSERT INTO employee_project_tbl (employee_id,project_id,location_id,manager_id,start_date,end_date,project_status,"
					+ "technologies) VALUES (?,?,?,?,?,?,?,?)";
		return jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setInt(1, employee_project_bean_object.getEmployee_id());
				prepared_statement_object.setInt(2, employee_project_bean_object.getProject_id());
				prepared_statement_object.setInt(3, employee_project_bean_object.getLocation_id());
				prepared_statement_object.setInt(4, employee_project_bean_object.getManager_id());
				prepared_statement_object.setDate(5, employee_project_bean_object.getStart_date());
				prepared_statement_object.setDate(6, employee_project_bean_object.getEnd_date());
				prepared_statement_object.setString(7, employee_project_bean_object.getProject_status());
				prepared_statement_object.setString(8, employee_project_bean_object.getTechnologies());
				return prepared_statement_object.executeUpdate();
			}
		});
	}

	public EmployeeProjectBean getEmployeeProjectById(int employee_project_id) {
		String sql = "SELECT * FROM employee_project_tbl WHERE emp_project_id=?";
		return jdbc_template.queryForObject(sql, new Object[]{employee_project_id},
				new BeanPropertyRowMapper<EmployeeProjectBean>(EmployeeProjectBean.class));
	}

	public int editEmployeeProject(final EmployeeProjectBean employee_project_bean_object) {
		String sql = "UPDATE employee_project_tbl SET project_id=?,location_id=?,manager_id=?,start_date=?,end_date=?,"
				+ "project_status=?,technologies=? WHERE emp_project_id=?";
		return jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setInt(1, employee_project_bean_object.getProject_id());
				prepared_statement_object.setInt(2, employee_project_bean_object.getLocation_id());
				prepared_statement_object.setInt(3, employee_project_bean_object.getManager_id());
				prepared_statement_object.setDate(4, employee_project_bean_object.getStart_date());
				prepared_statement_object.setDate(5, employee_project_bean_object.getEnd_date());
				prepared_statement_object.setString(6, employee_project_bean_object.getProject_status());
				prepared_statement_object.setString(7, employee_project_bean_object.getTechnologies());
				prepared_statement_object.setInt(8, employee_project_bean_object.getEmp_project_id());
				return prepared_statement_object.executeUpdate();
			}
		});
	}

	public int deleteEmployeeProject(final int emp_project_id) {
		String sql = "UPDATE employee_project_tbl SET is_deleted=1 WHERE emp_project_id=?";
		return jdbc_template.execute(sql, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement prepared_statement_object)
					throws SQLException, DataAccessException {
				prepared_statement_object.setInt(1, emp_project_id);
				return prepared_statement_object.executeUpdate();
			}
		});
	}

	public List<EmployeeProjectBean> getEmployeeHistory() {
		String sql = "call hrmis.getprojecthistory()";
		return jdbc_template.query(sql, new RowMapper<EmployeeProjectBean>() {
			public EmployeeProjectBean mapRow(ResultSet rs, int row) throws SQLException {
				EmployeeProjectBean employee_project_bean_object = new EmployeeProjectBean();
				employee_project_bean_object.setEmp_project_id(rs.getInt(1));
				employee_project_bean_object.setEmployee_name(rs.getString(2));
				employee_project_bean_object.setProject_name(rs.getString(3));
				employee_project_bean_object.setLocation_name(rs.getString(4));
				employee_project_bean_object.setManager_name(rs.getString(5));
				employee_project_bean_object.setStart_date(rs.getDate(6));
				employee_project_bean_object.setEnd_date(rs.getDate(7));
				employee_project_bean_object.setProject_status(rs.getString(8));
				employee_project_bean_object.setTechnologies(rs.getString(9));
				return employee_project_bean_object;
			}
		});
	}

}
