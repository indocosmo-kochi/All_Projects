/*
 *	www.templatemo.com
 *******************************************************/

/* HTML document is loaded. DOM is ready. 
-----------------------------------------*/
$(document).ready(function(){
	
	$('#main').click(function(){
		$('#sub').slideToggle("slow");
	});
	
	$('#empmain').click(function(){
		$('#empsub').slideToggle("slow");
	});
	
	
	
	$('#myBtn').click(function(){
		$('#myModal').toggle();
	});
	
	$('#row1').click(function(){
		$('#popupform').toggle();
	});
	
	
	
});

$(document).ready(function(){

	var i = 0;

	/* Mobile menu */
	$('.mobile-menu-icon').click(function(){
		$('.templatemo-left-nav').slideToggle();				
	});

	/* Close the widget when clicked on close button */
	$('.templatemo-content-widget .fa-times').click(function(){
		$(this).parent().slideUp(function(){
			$(this).hide();
		});
	});

	/* Plus Button for sibling */
	$('#add_sibling').click(function(){
		i++;
		$('#sibling_div').append(
			'<div class="row form-group">'+
				'<div class="col-lg-4 col-md-4 form-group">'+
					'<label for="sibling_name_array['+i+']">Sibling Name</label>'+
					'<input type="text" class="form-control" id="sibling_name_array['+i+']" name="sibling_name_array['+i+']" placeholder="Jack Xavier">'+
				'</div>'+
				'<div class="col-lg-4 col-md-4 form-group">'+
					'<label for="sibling_age_array['+i+']">Age</label>'+
					'<input type="number" class="form-control" id="sibling_age_array['+i+']" name="sibling_age_array['+i+']" placeholder="25">'+
				'</div>'+
				'<div class="col-lg-4 col-md-4 form-group">'+
					'<label for="sibling_occupation_array['+i+']">Occupation</label>'+
					'<input type="text" class="form-control" id="sibling_occupation_array['+i+']" name="sibling_occupation_array['+i+']" placeholder="Farmer">'+
				'</div>'+
			'</div>');
	
	});
});

$(document).ready(function(){

	var i = 0;

		/* Plus Button for child */
	$('#add_child').click(function(){
		i++;
		$('#child_div').append(
			'<div class="row form-group">'+
				'<div class="col-lg-4 col-md-4 form-group">'+
					'<label for="child_name_array['+i+']">Child Name</label>'+
					'<input type="text" class="form-control" id="child_name_array['+i+']" name="child_name_array['+i+']" placeholder="Robert Savio">'+
				'</div>'+
				'<div class="col-lg-4 col-md-4 form-group">'+
					'<label for="child_age_array['+i+']">Age</label>'+
					'<input type="number" class="form-control" id="child_age_array['+i+']" name="child_age_array['+i+']" placeholder="12">'+
				'</div>'+
				'<div class="col-lg-4 col-md-4 form-group">'+
					'<label for="child_occupation_array['+i+']">Occupation</label>'+
					'<input type="text" class="form-control" id="child_occupation_array['+i+']" name="child_occupation_array['+i+']" placeholder="Studying">'+
				'</div>'+
			'</div>');
		
	});
});

$(document).ready(function(){

	var i = 0;

		/* Plus Button for education */
	$('#add_education').click(function(){
		i++;
		$('#education_div').append(
			'<div class="row form-group">'+
				'<div class="col-lg-3 col-md-3 form-group">'+
					'<label for="qualification_array['+i+']">Qualification</label>'+
					'<input type="text" class="form-control" id="qualification_array['+i+']" name="qualification_array['+i+']" placeholder="Plus Two">'+
				'</div>'+
				'<div class="col-lg-3 col-md-3 form-group">'+
					'<label for="board_or_university_array['+i+']">Board/University</label>'+
					'<input type="text" class="form-control" id="board_or_university_array['+i+']" name="board_or_university_array['+i+']" placeholder="ICSE">'+
				'</div>'+
				'<div class="col-lg-3 col-md-3 form-group">'+
					'<label for="education_year_array['+i+']">Year(From - To)</label>'+
					'<input type="text" class="form-control" id="education_year_array['+i+']" name="education_year_array['+i+']" placeholder="2013-15">'+
				'</div>'+
				'<div class="col-lg-3 col-md-3 form-group">'+
					'<label for="marks_array['+i+']">Marks(%)</label>'+
					'<input type="text" class="form-control" id="marks_array['+i+']" name="marks_array['+i+']" placeholder="95">'+
				'</div>'+
			'</div>');
		
	});
	
});

$(document).ready(function(){

	var i = 0;

		/* Plus Button for profession */
	$('#add_profession').click(function(){
		i++;
		$('#professional_div').append(
			'<div class="row form-group">'+
				'<div class="col-lg-4 col-md-4 form-group">'+
					'<label for="comapny_name_array['+i+']">Company Name</label>'+
					'<input type="text" class="form-control" id="comapny_name_array['+i+']" name="company_name_array['+i+']" placeholder="JP Morgan">'+
				'</div>'+
				'<div class="col-lg-4 col-md-4 form-group">'+
					'<label for="Period_array['+i+']">Period</label>'+
					'<input type="text" class="form-control" id="period_array['+i+']" name="period_array['+i+']" placeholder="2018-12-31 - 2020-01-09">'+
				'</div>'+
				'<div class="col-lg-4 col-md-4 form-group">'+
					'<label for="nature_of_work_array['+i+']">Nature of Work</label>'+
					'<input type="text" class="form-control" id="nature_of_work_array['+i+']" name="nature_of_work_array['+i+']" placeholder="Developer">'+
				'</div>'+
			'</div>');
		
	});
	
});










	

