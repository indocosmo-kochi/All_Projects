﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BONutrition;
using BLNutrition;
using DLNutrition;
using System.ComponentModel;
using System.Data;

namespace APITest.Controllers
{
    public class DishController : ApiController
    {
        private List<DishIngredient> dishIngredientList = new List<DishIngredient>();
        private List<string> IngredientNameList = new List<string>();
        private Dish dish = new Dish();
        private DishIngredient dishIngredient = new DishIngredient();
        private static int dishID;
        private float planWeight = 0;
        private float planWeight1 = 0;
        private float planWeight2 = 0;

        private float dishCalorie;
        private float dishProtien;
        private float dishCarboHydrates;
        private float dishFAT;
        private float dishFibre;
        private float dishIron;
        private float dishCalcium;
        private float dishPhosphorus;
        private float dishVitaminARetinol;
        private float dishVitaminABetaCarotene;
        private float dishThiamine;
        private float dishRiboflavin;
        private float dishNicotinicAcid;
        private float dishPyridoxine;
        private float dishFolicAcid;
        private float dishVitaminB12;
        private float dishVitaminC;

        public List<string> Get(string DishJsonStr)
        {
            //Exract dish details into object
            var NameObject = JsonConvert.DeserializeObject<Dish>(DishJsonStr);

            //string Name = NameObject.Name;
            //string DisplayName = NameObject.DisplayName;
            //foreach (DishIngredient dishIngredient in NameObject.DishIngredientList)
            //{
            //    IngredientNameList.Add((dishIngredient.IngredientName));
            //}

            //GetDishList()

            try
            {
                //string imageDestination;
                dish = new Dish();
                if (NameObject.Id > 0)
                {
                    dish.Id = NameObject.Id;
                }
                else
                {
                    dish.Id = DishManager.GetID();
                }

                dish.EthnicID = (NameObject.EthnicID);
                dish.FoodHabitID = Convert.ToByte(Convert.ToString(NameObject.FoodHabitID));
                dish.DishCategoryID = Convert.ToByte(Convert.ToString(NameObject.DishCategoryID));

                dish.MedicalFavourable = string.Empty;
                dish.MedicalUnFavourable = string.Empty;
                dish.AyurvedicFavourable = string.Empty;
                dish.AyurvedicUnFavourable = string.Empty;

                dish.Keywords = string.Empty;
                dish.CreatedDate = DateTime.Now;

                dish.IsSystemDish = false;
                dish.IsAyurvedic = false;

                if (Convert.ToInt32(NameObject.ServeCount) > 0)
                {
                    dish.IsCountable = true;
                }
                else
                {
                    dish.IsCountable = false;
                }

                dish.ItemCount = 0;

                //// Default Serving Size

                //dish.ServeCount = Convert2Float(NameObject.ServeCount.ToString());
                //dish.ServeCount1 = Convert2Float(NameObject.ServeCount1.ToString());
                //dish.ServeCount2 = Convert2Float(NameObject.ServeCount2.ToString());

                dish.ServeCount = 1;
                dish.ServeCount1 = 2;
                dish.ServeCount2 = 3;

                //dish.ServeUnit = Convert.ToByte(Convert.ToString(NameObject.ServeUnit));
                dish.ServeUnit = 1;//unit gram

                int cooktime = 0;
                int.TryParse(NameObject.CookingTime, out cooktime);
                dish.CookingTime = Convert.ToString(cooktime.ToString());

                dish.FrozenLife = Convert.ToInt32(NameObject.FrozenLife);
                dish.RefrigeratedLife = Convert.ToInt32(NameObject.RefrigeratedLife);
                dish.ShelfLife = Convert.ToInt32(NameObject.ShelfLife);

                //// Set Default StandardWeight 

                //dish.StandardWeight = Convert2Float(NameObject.StandardWeight.ToString());
                //dish.StandardWeight1 = Convert2Float(NameObject.StandardWeight1.ToString());
                //dish.StandardWeight2 = Convert2Float(NameObject.StandardWeight2.ToString());
                dish.StandardWeight = 20;
                dish.StandardWeight1 = 40;
                dish.StandardWeight2 = 80;
                dish.DishWeight = Convert2Float(NameObject.StandardWeight.ToString());

                dish.PlanWeight = planWeight;
                dish.PlanWeight1 = planWeight1;
                dish.PlanWeight2 = planWeight2;

                dish.AuthorID = (byte)RecipeSource.Users;

                // Dish Lan (Primary)
                dish.Name = Convert.ToString(NameObject.Name);
                dish.DisplayName = Convert.ToString(NameObject.Name);
                dish.Comments = Convert.ToString(NameObject.Comments);
                dish.DishAyurFeatures = string.Empty;
                dish.RegionalName = Convert.ToString(NameObject.RegionalName);

                //// Dish Ingredient List
                string nutriName = string.Empty;

                float totalYieldWeight = dish.ServeCount  * Convert2Float(dish.StandardWeight.ToString());
                NSysNutrient sysNutrientItem = new NSysNutrient();
                List<DishIngredient> dishIngredientUpdateList = new List<DishIngredient>();
                IngredientStandardUnit ingredientStandardUnitItem = new IngredientStandardUnit();
                IngredientNutrients ingredientNutrientsItem = new IngredientNutrients();
                try
                {
                    //ClearNutrientValues();
                    dishIngredient = new DishIngredient();
                    foreach (DishIngredient dishIngredient in NameObject.DishIngredientList)
                    {
                        dishIngredient.IngredientID = IngredientManager.GetIngredientDetailsByName(dishIngredient.IngredientName);

                        //Weight Change Rate = Ready to Serve percentage of each Ingredient
                        //Standard unit nd  Ready to Serve Value

                        //Check Whether Ingrediwnt Exists
                        if (dishIngredient.IngredientID > 0)
                        {
                            List<IngredientAPI> lst = IngredientManager.GetIngredientDetailsByID(dishIngredient.IngredientID);
                            dishIngredient.StandardUnitID = IngredientManager.GetStandardUnitByName(dishIngredient.StandardUnitName);

                            ingredientStandardUnitItem = IngredientStandardUnitManager.GetItem(dishIngredient.IngredientID, dishIngredient.StandardUnitID);
                            if (ingredientStandardUnitItem != null)
                            {
                                ingredientNutrientsItem = IngredientNutrientsManager.GetItemNutrients(dishIngredient.IngredientID, (int)MainNutrients.Calorie);
                                if (ingredientNutrientsItem != null)
                                {
                                    dishCalorie = dishCalorie + ((dishIngredient.Quantity * ingredientStandardUnitItem.StandardWeight * ingredientNutrientsItem.NutrientValue) / totalYieldWeight);
                                }
                                ingredientNutrientsItem = IngredientNutrientsManager.GetItemNutrients(dishIngredient.IngredientID, (int)MainNutrients.Protien);
                                if (ingredientNutrientsItem != null)
                                {
                                    dishProtien = dishProtien + ((dishIngredient.Quantity * ingredientStandardUnitItem.StandardWeight * ingredientNutrientsItem.NutrientValue) / totalYieldWeight);
                                }
                                ingredientNutrientsItem = IngredientNutrientsManager.GetItemNutrients(dishIngredient.IngredientID, (int)MainNutrients.CarboHydrates);
                                if (ingredientNutrientsItem != null)
                                {
                                    dishCarboHydrates = dishCarboHydrates + ((dishIngredient.Quantity * ingredientStandardUnitItem.StandardWeight * ingredientNutrientsItem.NutrientValue) / totalYieldWeight);
                                }
                                ingredientNutrientsItem = IngredientNutrientsManager.GetItemNutrients(dishIngredient.IngredientID, (int)MainNutrients.FAT);
                                if (ingredientNutrientsItem != null)
                                {
                                    dishFAT = dishFAT + ((dishIngredient.Quantity * ingredientStandardUnitItem.StandardWeight * ingredientNutrientsItem.NutrientValue) / totalYieldWeight);
                                }
                                ingredientNutrientsItem = IngredientNutrientsManager.GetItemNutrients(dishIngredient.IngredientID, (int)MainNutrients.Fibre);
                                if (ingredientNutrientsItem != null)
                                {
                                    dishFibre = dishFibre + ((dishIngredient.Quantity * ingredientStandardUnitItem.StandardWeight * ingredientNutrientsItem.NutrientValue) / totalYieldWeight);
                                }
                                ingredientNutrientsItem = IngredientNutrientsManager.GetItemNutrients(dishIngredient.IngredientID, (int)MainNutrients.Iron);
                                if (ingredientNutrientsItem != null)
                                {
                                    dishIron = dishIron + ((dishIngredient.Quantity * ingredientStandardUnitItem.StandardWeight * ingredientNutrientsItem.NutrientValue) / totalYieldWeight);
                                }
                                ingredientNutrientsItem = IngredientNutrientsManager.GetItemNutrients(dishIngredient.IngredientID, (int)MainNutrients.Calcium);
                                if (ingredientNutrientsItem != null)
                                {
                                    dishCalcium = dishCalcium + ((dishIngredient.Quantity * ingredientStandardUnitItem.StandardWeight * ingredientNutrientsItem.NutrientValue) / totalYieldWeight);
                                }
                                ingredientNutrientsItem = IngredientNutrientsManager.GetItemNutrients(dishIngredient.IngredientID, (int)MainNutrients.Phosphorus);
                                if (ingredientNutrientsItem != null)
                                {
                                    dishPhosphorus = dishPhosphorus + ((dishIngredient.Quantity * ingredientStandardUnitItem.StandardWeight * ingredientNutrientsItem.NutrientValue) / totalYieldWeight);
                                }
                                ingredientNutrientsItem = IngredientNutrientsManager.GetItemNutrients(dishIngredient.IngredientID, (int)MainNutrients.VitaminA_Retinol);
                                if (ingredientNutrientsItem != null)
                                {
                                    dishVitaminARetinol = dishVitaminARetinol + ((dishIngredient.Quantity * ingredientStandardUnitItem.StandardWeight * ingredientNutrientsItem.NutrientValue) / totalYieldWeight);
                                }
                                ingredientNutrientsItem = IngredientNutrientsManager.GetItemNutrients(dishIngredient.IngredientID, (int)MainNutrients.VitaminA_BetaCarotene);
                                if (ingredientNutrientsItem != null)
                                {
                                    dishVitaminABetaCarotene = dishVitaminABetaCarotene + ((dishIngredient.Quantity * ingredientStandardUnitItem.StandardWeight * ingredientNutrientsItem.NutrientValue) / totalYieldWeight);
                                }
                                ingredientNutrientsItem = IngredientNutrientsManager.GetItemNutrients(dishIngredient.IngredientID, (int)MainNutrients.Thiamine);
                                if (ingredientNutrientsItem != null)
                                {
                                    dishThiamine = dishThiamine + ((dishIngredient.Quantity * ingredientStandardUnitItem.StandardWeight * ingredientNutrientsItem.NutrientValue) / totalYieldWeight);
                                }

                                ingredientNutrientsItem = IngredientNutrientsManager.GetItemNutrients(dishIngredient.IngredientID, (int)MainNutrients.Riboflavin);
                                if (ingredientNutrientsItem != null)
                                {
                                    dishRiboflavin = dishRiboflavin + ((dishIngredient.Quantity * ingredientStandardUnitItem.StandardWeight * ingredientNutrientsItem.NutrientValue) / totalYieldWeight);
                                }
                                ingredientNutrientsItem = IngredientNutrientsManager.GetItemNutrients(dishIngredient.IngredientID, (int)MainNutrients.NicotinicAcid);
                                if (ingredientNutrientsItem != null)
                                {
                                    dishNicotinicAcid = dishNicotinicAcid + ((dishIngredient.Quantity * ingredientStandardUnitItem.StandardWeight * ingredientNutrientsItem.NutrientValue) / totalYieldWeight);
                                }
                                ingredientNutrientsItem = IngredientNutrientsManager.GetItemNutrients(dishIngredient.IngredientID, (int)MainNutrients.Pyridoxine);
                                if (ingredientNutrientsItem != null)
                                {
                                    dishPyridoxine = dishPyridoxine + ((dishIngredient.Quantity * ingredientStandardUnitItem.StandardWeight * ingredientNutrientsItem.NutrientValue) / totalYieldWeight);
                                }
                                ingredientNutrientsItem = IngredientNutrientsManager.GetItemNutrients(dishIngredient.IngredientID, (int)MainNutrients.FolicAcid);
                                if (ingredientNutrientsItem != null)
                                {
                                    dishFolicAcid = dishFolicAcid + ((dishIngredient.Quantity * ingredientStandardUnitItem.StandardWeight * ingredientNutrientsItem.NutrientValue) / totalYieldWeight);
                                }
                                ingredientNutrientsItem = IngredientNutrientsManager.GetItemNutrients(dishIngredient.IngredientID, (int)MainNutrients.VitaminB12);
                                if (ingredientNutrientsItem != null)
                                {
                                    dishVitaminB12 = dishVitaminB12 + ((dishIngredient.Quantity * ingredientStandardUnitItem.StandardWeight * ingredientNutrientsItem.NutrientValue) / totalYieldWeight);
                                }
                                ingredientNutrientsItem = IngredientNutrientsManager.GetItemNutrients(dishIngredient.IngredientID, (int)MainNutrients.VitaminC);
                                if (ingredientNutrientsItem != null)
                                {
                                    dishVitaminC = dishVitaminC + ((dishIngredient.Quantity * ingredientStandardUnitItem.StandardWeight * ingredientNutrientsItem.NutrientValue) / totalYieldWeight);
                                }
                            }
                        }

                        dishIngredientUpdateList.Add(dishIngredient);
                    }

                    if (dishIngredientUpdateList != null)
                    {
                        dish.DishIngredientList = dishIngredientUpdateList;
                    }
                    else
                    {
                        if (dishIngredientList != null)
                        {
                            dish.DishIngredientList = dishIngredientList;
                        }
                    }
                }
                catch (Exception ex)
                {
                    //MessageBox.Show(ex.Message);
                }

                dish.Calorie = (float)Math.Round(Convert.ToDecimal(dishCalorie), 2);
                dish.Protien = (float)Math.Round(Convert.ToDecimal(dishProtien), 2);
                dish.CarboHydrates = (float)Math.Round(Convert.ToDecimal(dishCarboHydrates), 2);
                dish.FAT = (float)Math.Round(Convert.ToDecimal(dishFAT), 2);
                dish.Fibre = (float)Math.Round(Convert.ToDecimal(dishFibre), 2);
                dish.Iron = (float)Math.Round(Convert.ToDecimal(dishIron), 2);
                dish.Calcium = (float)Math.Round(Convert.ToDecimal(dishCalcium), 2);
                dish.Phosphorus = (float)Math.Round(Convert.ToDecimal(dishPhosphorus), 2);
                dish.VitaminARetinol = (float)Math.Round(Convert.ToDecimal(dishVitaminARetinol), 2);
                dish.VitaminABetaCarotene = (float)Math.Round(Convert.ToDecimal(dishVitaminABetaCarotene), 2);
                dish.Thiamine = (float)Math.Round(Convert.ToDecimal(dishThiamine), 2);
                dish.Riboflavin = (float)Math.Round(Convert.ToDecimal(dishRiboflavin), 2);
                dish.NicotinicAcid = (float)Math.Round(Convert.ToDecimal(dishNicotinicAcid), 2);
                dish.Pyridoxine = (float)Math.Round(Convert.ToDecimal(dishPyridoxine), 2);
                dish.FolicAcid = (float)Math.Round(Convert.ToDecimal(dishFolicAcid), 2);
                dish.VitaminB12 = (float)Math.Round(Convert.ToDecimal(dishVitaminB12), 2);
                dish.VitaminC = (float)Math.Round(Convert.ToDecimal(dishVitaminC), 2);

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }
            finally
            {

            }

            DishManager.Save(dish);

            return IngredientNameList;
        }

        public static float Convert2Float(string expression)
        {
            if (expression.Length == 0)
                return (0);
            else
            {
                try
                {
                    float val = float.Parse(expression);
                    return (val);
                }
                catch
                {
                    return (0);
                }
            }
        }

        public enum RecipeSource
        {
            System = 1,
            MathewShila = 2,
            Users = 3,
            Ayurvedic = 4,
        }
        public enum MainNutrients
        {
            Calorie = 1,
            Protien = 2,
            CarboHydrates = 3,
            FAT = 4,
            Fibre = 5,
            Iron = 13,
            Calcium = 10,
            Phosphorus = 12,
            [Description("VitaminA(Retinol)")]
            VitaminA_Retinol = 16,
            [Description("VitaminA(BetaCarotene)")]
            VitaminA_BetaCarotene = 17,
            Thiamine = 31,
            Riboflavin = 18,
            NicotinicAcid = 122,
            Pyridoxine = 123,
            FolicAcid = 27,
            VitaminB12 = 26,
            VitaminC = 29
        }
    }
}