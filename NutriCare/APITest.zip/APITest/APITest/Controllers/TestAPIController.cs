﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BLNutrition;
using BONutrition;
using DLNutrition;
using Newtonsoft.Json;
using NutritionV1.Classes;

namespace APITest.Controllers
{
    public class TestAPIController : ApiController
    {
        string DisplayName = string.Empty;
        public string Get()
        {
            return "Hello World";
        }
        public Dish Get(int Id)
        {
            DBHelper dBHelper = new DBHelper();
            Dish dish = null;
            return dish = DishDL.GetItem(Id, "");
        }
        public string Get(string JsonStr)
        {
            var jsonString = "@" + JsonStr;
            //Use of the method
            var NameObject = JsonConvert.DeserializeObject<Name>(JsonStr);

            DisplayName = NameObject.ItemCode;
            string UOM = NameObject.UOM;
            string Qty = NameObject.Quantity;

            return FillDishDetails(DisplayName);
        }

        public class Name
        {
            public string ItemCode
            {
                get;
                set;
            }
            public string UOM
            {
                get;
                set;
            }
            public string Quantity
            {
                get;
                set;
            }
        }

        //Into NutiCare
        private string GetImagePath(string FolderName)
        {
            string filePath = string.Empty;
            try
            {
                filePath = AppDomain.CurrentDomain.BaseDirectory + "Pictures\\" + FolderName;
                if (Directory.Exists(filePath))
                {
                    return filePath;
                }
                else
                {
                    Directory.CreateDirectory(filePath);
                    return filePath;
                }
            }
            catch
            {
                return filePath;
            }
        }
        private string FillDishDetails(string DisplayName)
        {
            Dish dish = new Dish();
            dish = DishManager.GetItem(DisplayName);

            string JsonResult = string.Empty;
            string JsonIngredient = string.Empty;

            if (dish != null)
            {
                string imgDishDisplay = string.Empty;
                if (dish.DisplayImage != "")
                {
                    string imgPath = GetImagePath("Dishes") + "\\" + dish.Id + ".jpg";

                    if (File.Exists(imgPath))
                    {
                        imgDishDisplay = imgPath;
                    }
                    else
                    {
                        imgDishDisplay = string.Empty;
                    }
                }
                else
                {
                    imgDishDisplay = string.Empty;
                }
                List<DishIngredient> dishIngredientList = FillIngredientsList(dish.Id);

                for (int i = 0; i < dishIngredientList.Count; i++)
                {
                    JsonIngredient += " 'IngredientList' : [" +
                            "{ 'IngredientName': '" + dishIngredientList[i].IngredientName + "'," +
                            "  'Quantity':'" + dishIngredientList[i].Quantity + "'," +
                            "  'StandardUnitName':'" + dishIngredientList[i].StandardUnitName + "' }" +
                                                         "]";
                }


                JsonResult = "{" +
                    " 'DishID': '" + Convert.ToString(dish.Id) + "'," +
                    " 'DishName': '" + dish.Name + "'," +
                    " 'DishImage': '" + imgDishDisplay + "'," +
                    " 'Comments': '" + Convert.ToString(dish.Comments) + "'," +
                    //" 'ControlID': '" + Convert.ToString(ControlID) + "'," +
                    //" 'ControlName': '" + ControlName + "'," +
                    " 'PlanWeight': '" + dish.StandardWeight + "'," +
                    " 'Calorie': '" + Convert.ToString(Math.Round((dish.Calorie / 100) * dish.StandardWeight, 2)) + "'," +
                    " 'CalorieUnit': 'Kcal'," +
                    " 'Protein': '" + Convert.ToString(Math.Round((dish.Protien / 100) * dish.StandardWeight, 2)) + "'," +
                    " 'ProteinUnit': 'gm'," +
                    " 'FAT': '" + Convert.ToString(Math.Round((dish.FAT / 100) * dish.StandardWeight, 2)) + "'," +
                    " 'FATUnit': 'gm'," +
                    " 'Fibre': '" + Convert.ToString(Math.Round((dish.Fibre / 100) * dish.StandardWeight, 2)) + "'," +
                    " 'FibreUnit': 'gm'," +
                    " 'CarboHydrates': '" + Convert.ToString(Math.Round((dish.CarboHydrates / 100) * dish.StandardWeight, 2)) + "'," +
                    " 'CarboHydratesUnit': 'gm'," +
                    " 'Iron': '" + Convert.ToString(Math.Round((dish.Iron / 100) * dish.StandardWeight, 2)) + "'," +
                    " 'IronUnit': 'mg'," +
                    " 'Calcium': '" + Convert.ToString(Math.Round((dish.Calcium / 100) * dish.StandardWeight, 2)) + "'," +
                    " 'CalciumUnit': 'mg'," +
                    " 'Phosphorus': '" + Convert.ToString(Math.Round((dish.Phosphorus / 100) * dish.StandardWeight, 2)) + "'," +
                    " 'PhosphorusUnit': 'mg'," +
                    " 'VitaminARetinol': '" + Convert.ToString(Math.Round((dish.VitaminARetinol / 100) * dish.StandardWeight, 2)) + "'," +
                    " 'VitaminARetinolUnit': 'mcg'," +
                    " 'VitaminABetaCarotene': '" + Convert.ToString(Math.Round((dish.VitaminABetaCarotene / 100) * dish.StandardWeight, 2)) + "'," +
                    " 'VitaminABetaCaroteneUnit': 'mcg'," +
                    " 'Thiamine': '" + Convert.ToString(Math.Round((dish.Thiamine / 100) * dish.StandardWeight, 2)) + "'," +
                    " 'ThiamineUnit': 'mg'," +
                    " 'Riboflavin': '" + Convert.ToString(Math.Round((dish.Riboflavin / 100) * dish.StandardWeight, 2)) + "'," +
                    " 'RiboflavinUnit': 'mg'," +
                    " 'NicotinicAcid': '" + Convert.ToString(Math.Round((dish.NicotinicAcid / 100) * dish.StandardWeight, 2)) + "'," +
                    " 'NicotinicAcidUnit': 'mg'," +
                    " 'Pyridoxine': '" + Convert.ToString(Math.Round((dish.Pyridoxine / 100) * dish.StandardWeight, 2)) + "'," +
                    " 'PyridoxineUnit': 'mg'," +
                    " 'FolicAcid': '" + Convert.ToString(Math.Round((dish.FolicAcid / 100) * dish.StandardWeight, 2)) + "'," +
                    " 'FolicAcidUnit': 'mcg'," +
                    " 'VitaminC': '" + Convert.ToString(Math.Round((dish.VitaminC / 100) * dish.StandardWeight, 2)) + "'," +
                    " 'VitaminCUnit': 'mg'," +
                    " 'PreparationRecipe': '" + Convert.ToString(dish.DishRecipe) + "'," +

                    " 'Calorie100': '" + Convert.ToString(dish.Calorie) + "'," +
                    " 'Protein100': '" + Convert.ToString(dish.Protien) + "'," +
                    " 'FAT100': '" + Convert.ToString(dish.FAT) + "'," +
                    " 'Fibre100': '" + Convert.ToString(dish.Fibre) + "'," +
                    " 'CarboHydrates100': '" + Convert.ToString(dish.CarboHydrates) + "'," +
                    " 'Iron100': '" + Convert.ToString(dish.Iron) + "'," +
                    " 'Calcium100': '" + Convert.ToString(dish.Calcium) + "'," +
                    " 'Phosphorus100': '" + Convert.ToString(dish.Phosphorus) + "'," +
                    " 'VitaminARetinol100': '" + Convert.ToString(dish.VitaminARetinol) + "'," +
                    " 'VitaminABetaCarotene100': '" + Convert.ToString(dish.VitaminABetaCarotene) + "'," +
                    " 'Thiamine100': '" + Convert.ToString(dish.Thiamine) + "'," +
                    " 'Riboflavin100': '" + Convert.ToString(dish.Riboflavin) + "'," +
                    " 'NicotinicAcid100': '" + Convert.ToString(dish.NicotinicAcid) + "'," +
                    " 'Pyridoxine100': '" + Convert.ToString(dish.Pyridoxine) + "'," +
                    " 'FolicAcid100': '" + Convert.ToString(dish.FolicAcid) + "'," +
                    " 'VitaminC100': '" + Convert.ToString(dish.VitaminC) + "'," +

                    JsonIngredient +
                "}";

            }

            return JsonResult;

        }

        private List<DishIngredient> FillIngredientsList(int dishID)
        {
            List<DishIngredient> dishIngredientList = new List<DishIngredient>();
            dishIngredientList = DishIngredientManager.GetIngredientDisplayList(dishID);

            return dishIngredientList;
        }
    }
}
