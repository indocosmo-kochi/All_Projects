﻿using System;
using System.Collections.Generic;

namespace BONutrition
{
    public class IngredientAPI
    {
        #region Varaibles

        // Ingredient Table
        private int ingredientid;
        private string ingredientname;
        private int ethnicID;
        private byte foodHabitID;
        private string ayurvedicFavourable;
        private string ayurvedicUnFavourable;
        private string ayurvedicBalanced;
        private string medicalFavourable;
        private string medicalUnFavourable;
        private string medicalBalanced;
        private string keywords;
        private float scrappageRate;
        private float weightChangeRate;
        private string displayImage;
        private bool isAllergic;
        private bool isSystemIngredient;
        private int frozenLife;
        private int refrigeratedLife;
        private int shelfLife;
        private bool isFavourites;
        private byte displayOrder;
        private string generalHealthValue;
        private string ayurHealthValue;

        #endregion

        #region Properties - Ingredient

        public int IngredientID
        {
            get { return this.ingredientid; }
            set { this.ingredientid = value; }
        }
        public string IngredientName
        {
            get { return this.ingredientname; }
            set { this.ingredientname = value; }
        }

        public int EthnicID
        {
            get { return this.ethnicID; }
            set { this.ethnicID = value; }
        }

        public byte FoodHabitID
        {
            get { return this.foodHabitID; }
            set { this.foodHabitID = value; }
        }

        public string AyurvedicFavourable
        {
            get { return this.ayurvedicFavourable; }
            set { this.ayurvedicFavourable = value; }
        }

        public string AyurvedicUnFavourable
        {
            get { return this.ayurvedicUnFavourable; }
            set { this.ayurvedicUnFavourable = value; }
        }

        public string AyurvedicBalanced
        {
            get { return this.ayurvedicBalanced; }
            set { this.ayurvedicBalanced = value; }
        }

        public string MedicalFavourable
        {
            get { return this.medicalFavourable; }
            set { this.medicalFavourable = value; }
        }

        public string MedicalUnFavourable
        {
            get { return this.medicalUnFavourable; }
            set { this.medicalUnFavourable = value; }
        }

        public string MedicalBalanced
        {
            get { return this.medicalBalanced; }
            set { this.medicalBalanced = value; }
        }

        public string Keywords
        {
            get { return this.keywords; }
            set { this.keywords = value; }
        }

        public float ScrappageRate
        {
            get { return this.scrappageRate; }
            set { this.scrappageRate = value; }
        }

        public float WeightChangeRate
        {
            get { return this.weightChangeRate; }
            set { this.weightChangeRate = value; }
        }

        public string DisplayImage
        {
            get { return this.displayImage; }
            set { this.displayImage = value; }
        }

        public bool IsAllergic
        {
            get { return this.isAllergic; }
            set { this.isAllergic = value; }
        }

        public bool IsSystemIngredient
        {
            get { return this.isSystemIngredient; }
            set { this.isSystemIngredient = value; }
        }

        public int FrozenLife
        {
            get { return this.frozenLife; }
            set { this.frozenLife = value; }
        }

        public int RefrigeratedLife
        {
            get { return this.refrigeratedLife; }
            set { this.refrigeratedLife = value; }
        }

        public int ShelfLife
        {
            get { return this.shelfLife; }
            set { this.shelfLife = value; }
        }

        public bool IsFavourites
        {
            get { return this.isFavourites; }
            set { this.isFavourites = value; }
        }

        public byte DisplayOrder
        {
            get { return this.displayOrder; }
            set { this.displayOrder = value; }
        }

        public string GeneralHealthValue
        {
            get { return this.generalHealthValue; }
            set { this.generalHealthValue = value; }
        }

        public string AyurHealthValue
        {
            get { return this.ayurHealthValue; }
            set { this.ayurHealthValue = value; }
        }

        #endregion

    }
}
