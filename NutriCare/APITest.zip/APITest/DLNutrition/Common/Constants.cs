﻿namespace DLNutrition.Common
{
    class Constants
    {
    }
}
