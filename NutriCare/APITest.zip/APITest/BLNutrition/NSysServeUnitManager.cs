﻿using System.Collections.Generic;
using BONutrition;
using DLNutrition;

namespace BLNutrition
{
    public class NSysServeUnitManager
    {
        public static List<NSysServeUnit> GetList()
        {
            return NSysServeUnitDL.GetList();
        }

        public static NSysServeUnit GetItem(int serveUnitID)
        {
            return NSysServeUnitDL.GetItem(serveUnitID);
        }
    }
}
