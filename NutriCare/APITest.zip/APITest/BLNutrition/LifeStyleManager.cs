﻿using BONutrition;
using DLNutrition;

namespace BLNutrition
{
    public class LifeStyleManager
    {
        public static LifeStyle GetItem(int LanguageID, int LifeStyleID)
        {
            return LifeStyleDL.GetItem(LanguageID, LifeStyleID);
        }
    }
}
