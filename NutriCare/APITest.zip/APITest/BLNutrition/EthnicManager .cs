﻿using System.Collections.Generic;
using BONutrition;
using DLNutrition;

namespace BLNutrition
{
    public class EthnicManager
    {
        public static List<Ethnic> GetEthnic()
        {
            return EthnicDL.GetEthnic();
        }

        public static Ethnic GetItem(int ethnicID)
        {
            return EthnicDL.GetItem(ethnicID);
        }
    }
}
