﻿using System.Collections.Generic;
using BONutrition;
using DLNutrition;

namespace BLNutrition
{
    public class MealPlanManager
    {
        public static List<MealPlan> GetFoodPlanList(int dishID)
        {
            return MealPlanDL.GetFoodPlanList(dishID);
        }
    }
}
