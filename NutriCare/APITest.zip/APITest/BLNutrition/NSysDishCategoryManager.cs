﻿using System.Collections.Generic;
using BONutrition;
using DLNutrition;

namespace BLNutrition
{
    public class NSysDishCategoryManager
    {
        public static List<NSysDishCategory> GetList()
        {
            return NSysDishCategoryDL.GetList();
        }        

        public static NSysDishCategory GetItem(int dishCategoryID)
        {
            return NSysDishCategoryDL.GetItem(dishCategoryID);
        }
    }
}
