﻿using BONutrition;
using DLNutrition;

namespace BLNutrition
{
    public class BloodGroupManager
    {
        public static BloodGroup GetItem(int LanguageID, int BloodGroupID)
        {
            return BloodGroupDL.GetItem(LanguageID, BloodGroupID);
        }
    }
}
