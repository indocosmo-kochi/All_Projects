﻿using BONutrition;
using DLNutrition;


namespace BLNutrition
{
    public class FoodHabitManager
    {

        public static FoodHabit GetItem(int LanguageID, int FoodHabitID)
        {
            return FoodHabitDL.GetItem(LanguageID, FoodHabitID);
        }
    }
}
