﻿using BONutrition;
using DLNutrition;

namespace BLNutrition
{
    public class SexManager
    {
        public static Sex GetItem(int LanguageID, int SexID)
        {
            return SexDL.GetItem(LanguageID, SexID);
        }
    }
}
