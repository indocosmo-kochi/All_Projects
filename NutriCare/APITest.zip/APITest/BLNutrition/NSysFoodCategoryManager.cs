﻿using System.Collections.Generic;
using BONutrition;
using DLNutrition;

namespace BLNutrition
{
    public class NSysFoodCategoryManager
    {
        public static List<NSysFoodCategory> GetList()
        {
            return NSysFoodCategoryDL.GetList();
        }
       
        public static NSysFoodCategory GetItem(int foodCategoryID)
        {
            return NSysFoodCategoryDL.GetItem(foodCategoryID);
        }
    }
}
