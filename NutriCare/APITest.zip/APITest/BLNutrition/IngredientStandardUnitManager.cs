﻿using System.Collections.Generic;
using BONutrition;
using DLNutrition;

namespace BLNutrition
{
    public class IngredientStandardUnitManager
    {
        public static List<IngredientStandardUnit> GetUnitList(int ingredientID)
        {
            return IngredientStandardUnitDL.GetUnitList(ingredientID);
        }

        public static IngredientStandardUnit GetItem(int ingredientID, byte standardUnitID)
        {
            StandardUnit standardUnit = new StandardUnit();
            IngredientStandardUnit ingredientStandardUnitItem = new IngredientStandardUnit();
            ingredientStandardUnitItem = IngredientStandardUnitDL.GetItem(ingredientID, standardUnitID);
            return ingredientStandardUnitItem;
        }

        public static bool DeleteStandardUnit(int ingredientID)
        {
            return IngredientStandardUnitDL.DeleteStandardUnit(ingredientID);
        }
    }
}
