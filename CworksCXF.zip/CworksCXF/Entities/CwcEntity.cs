﻿using System;
using System.Collections.Generic;
using Teigha.Colors;
using Teigha.DatabaseServices;
using Teigha.Geometry;
using CWorksCXF.Common;

namespace CWorksCXF.Entities
{


    public abstract class CwcDbObject
    {
        public string Id { get; set; }
        public string TypeName { get; set; }

    }

    public class CwcDBSettings 
    {
        public int Pdmode { get; set; }
        public double Pdsize { get; set; }
        public Enums.MeasurementValue Measurement { get; set; }
        public double Ltscale { get; set; }
        //public int Isolines { get; set; }
        //public double Facetres { get; set; }

    }


    public class CwcTextStyle : CwcDbObject
    {
        public string Name { get; set; }
        public string FileName { get; set; }
        public string FontName { get; set; }
        public int Characters { get; set; }
        public int PitchAndFamily { get; set; }
        public double TextSize { get; set; }
        public byte FlagBits { get; set; }
        public double ObliquingAngle { get; set; }
        public bool IsVertical { get; set; }
        public bool IsItallic { get; set; }
        public bool IsBold { get; set; }
        public AnnotativeStates Annotative { get; set; }
        public string BigFontFileName { get; set; }
        public double PriorSize { get; set; }
        public double XScale { get; set; }

        public CwcTextStyle()
        {
            TypeName = "TextStyle";
        }
    }

    public class CwcLayer : CwcDbObject
    {
        public string Name { get; set; }
        public CwcColor Color { get; set; }
        public string LineTypeId { get; set; }
        public string LineType { get; set; }
        public LineWeight LineWeight { get; set; }
        public string Transparency { get; set; }
        public bool IsHidden { get; set; }
        public bool IsOff { get; set; }
        public bool IsLocked { get; set; }
        public bool IsPlottable { get; set; }
        public CwcLayer()
        {
            TypeName = "Layer";
        }
    }

    public class CwcLineType : CwcDbObject
    {
        public string Name { get; set; }
        //  public CwcColor Color { get; set; }
        public int NumDashes { get; set; }
        public double PatternLength { get; set; }
        public bool IsScaledToFit { get; set; }
        public double[] DashLengthAt { get; set; }

        public CwcLineType()
        {
            TypeName = "LineType";
        }
    }

    public class CwcViewport : CwcDbObject
    {
        public string Name { get; set; }
        public CwcPoint2D CenterPoint { get; set; }
        public short CircleSides { get; set; }
        public bool GridEnabled { get; set; }
        public double Height { get; set; }
        public double Width { get; set; }
        public CwcViewport()
        {
            TypeName = "Viewport";
        }
    }

    public abstract class CwcEntity : CwcDbObject
    {
        public CwcColor Color { get; set; }
        public string LayerId { get; set; }

        public string BlockId { get; set; }
        public string BlockName { get; set; }
    }


    public class CwcPoint2D
    {
        public Double X { get; set; }
        public Double Y { get; set; }
        public CwcPoint2D(Double x, Double y)
        {
            X = x;
            Y = y;
        }

        public static implicit operator CwcPoint2D(Point2d point)
        {
            return new CwcPoint2D(point.X, point.Y);
        }

        public override string ToString()
        {
            return string.Format("({0},{1})", X.ToString(), Y.ToString());
        }
    }

    public class CwcPoint3D
    {
        public Double X { get; set; }
        public Double Y { get; set; }
        public Double Z { get; set; }

        public CwcPoint3D(Double x, Double y, Double z)
        {
            X = x;
            Y = y;
            Z = z;
        }

        public static implicit operator CwcPoint3D(Point3d point)
        {
            return new CwcPoint3D(point.X, point.Y, point.Z);
        }

        public override string ToString()
        {
            return string.Format("({0},{1},{2})", X.ToString(), Y.ToString(), Z.ToString());
        }

    }

    public class CwcVector2D
    {
        public Double X { get; set; }
        public Double Y { get; set; }

        public CwcVector2D(Double x, Double y)
        {
            X = x;
            Y = y;
        }

        public static implicit operator CwcVector2D(Vector2d point)
        {
            return new CwcVector2D(point.X, point.Y);
        }

        public override string ToString()
        {
            return string.Format("({0},{1})", X.ToString(), Y.ToString());
        }

    }


    public class CwcVector3D
    {
        public Double X { get; set; }
        public Double Y { get; set; }
        public Double Z { get; set; }

        public CwcVector3D(Double x, Double y, Double z)
        {
            X = x;
            Y = y;
            Z = z;
        }

        public static implicit operator CwcVector3D(Vector3d point)
        {
            return new CwcVector3D(point.X, point.Y, point.Z);
        }

        public override string ToString()
        {
            return string.Format("({0},{1},{2})", X.ToString(), Y.ToString(), Z.ToString());
        }

    }

    public class CwcColor
    {
        public byte? Red { get; set; }
        public byte? Green { get; set; }
        public byte? Blue { get; set; }
        public bool IsNone { get; set; }
        public string Color { get; set; }
        public short ColorIndex { get; set; }

        public ColorMethod ColorMethod { get; set; }

        // Extension method called using ClassName
        public static CwcColor GetColorFrom(CwcColor color)
        {
            if (color.IsNone)
            {
                return new CwcColor(color.IsNone);
            }
            else
            {
                CwcColor cwcColor = new CwcColor(color.Red, color.Green, color.Blue);
                cwcColor.ColorMethod = color.ColorMethod;
                cwcColor.ColorIndex = color.ColorIndex;
                return cwcColor;
            }
        }


        public CwcColor(byte? red, byte? green, byte? blue)
        {
            if ((red == null) || (green == null) || (blue == null))
            {
                this.IsNone = true;
                this.ColorMethod = ColorMethod.None;
                this.ColorIndex = 257;
            }
            else
            {
                this.Red = red;
                this.Green = green;
                this.Blue = blue;
            }
        }

        public CwcColor(bool isNone)
        {
            this.Red = null;
            this.Green = null;
            this.Blue = null;
            this.IsNone = isNone;
            this.ColorMethod = ColorMethod.None;
            this.ColorIndex = 257;
        }


        public static implicit operator CwcColor(Color color)
        {
            CwcColor cwcColor;
            if (color.IsNone)
            {
                cwcColor = new CwcColor(color.IsNone);
            }
            else
            {
                cwcColor = new CwcColor(color.Red, color.Green, color.Blue);
                cwcColor.ColorMethod = color.ColorMethod;
                cwcColor.ColorIndex = color.ColorIndex;
                System.Drawing.Color sysColor = color.ColorValue;
                cwcColor.Color = sysColor.Name;
            }
            return cwcColor;
        }

        public override string ToString()
        {
            if (this.IsNone)
            {
                return string.Format("({0},{1},{2})", -1, -1, -1);
            }
            else
            {
                return string.Format("({0},{1},{2})", Red, Green, Blue);
            }
        }

    }

    public class CwcBlock : CwcDbObject
    {
        public string Name { get; set; }
        public int NumberAttributeDefs { get; set; }
        public List<CwcAttributeDefinition> AttributeDefs { get; set; }
        public CwcBlock()
        {
            TypeName = "Block";
            AttributeDefs = new List<CwcAttributeDefinition>();
        }

    }


    public class CwcAttributeDefinition : CwcDBText
    {
        public bool Constant { get; set; }
        public int FieldLength { get; set; }
        public bool Invisible { get; set; }
        public bool IsMTextAttributeDefinition { get; set; }
        public bool LockPositionInBlock { get; set; }
        public double MTextWidth { get; set; }
        public string MTextContents { get; set; }
        public bool Preset { get; set; }
        public string Prompt { get; set; }
        public string Tag { get; set; }
        public bool Verifiable { get; set; }
        public CwcAttributeDefinition()
        {
        }
        public CwcAttributeDefinition(DBText dbObject)
        {
            AttributeDefinition attdef = dbObject as AttributeDefinition;
            Position = attdef.Position;
            Tag = attdef.Tag;
            TextString = attdef.TextString;
            Height = attdef.Height;
            Justify = attdef.Justify;
            Constant = attdef.Constant;
            FieldLength = attdef.FieldLength;
            Invisible = attdef.Invisible;
            IsMTextAttributeDefinition = attdef.IsMTextAttributeDefinition;
            LockPositionInBlock = attdef.LockPositionInBlock;
            if (IsMTextAttributeDefinition)
            {
                MTextWidth = attdef.MTextAttributeDefinition.Width;
                MTextContents = attdef.MTextAttributeDefinition.Contents;
            }
            if (!Constant)
            {
                Verifiable = attdef.Verifiable;
                Prompt = attdef.Prompt;
                Preset = attdef.Preset;
            }

            AlignmentPoint = attdef.AlignmentPoint;
            Annotative = attdef.Annotative;
            IsMirroredInX = attdef.IsMirroredInX;
            IsMirroredInY = attdef.IsMirroredInY;
            Oblique = attdef.Oblique;
            Rotation = attdef.Rotation;
            WidthFactor = attdef.WidthFactor;

            TextStyleId = attdef.TextStyleId.ToString();
            LayerId = attdef.LayerId.ToString();
        }
    }

    public class CwcAttributeReference : CwcDbObject
    {
        public string Tag { get; set; }
        public string TextString { get; set; }
    }


    public class CwcBlockReference : CwcEntity
    {
        public string BlockDefId { get; set; }
        public string Name { get; set; }   // To identify the BTR, when Writing into DWG
        public CwcPoint3D Position { get; set; }
        public double Rotation { get; set; }
        public UnitsValue BlockUnit { get; set; }
        public bool IsDynamicBlock { get; set; }
        public CwcPoint3D ScaleFactors { get; set; }
        public string Linetype { get; set; }
        public double LinetypeScale { get; set; }
        public LineWeight LineWeight { get; set; }
        public int NumberAttributeRefs { get; set; }
        public List<CwcAttributeReference> AttributeRefs { get; set; }
        public List<CwcBlockReference> BlockRefs { get; set; }
        public CwcBlockReference()
        {
            TypeName = "BlockReference";
            AttributeRefs = new List<CwcAttributeReference>();
            BlockRefs = new List<CwcBlockReference>();
        }
    }

    public class CwcDBPoint : CwcEntity
    {
        public CwcPoint3D Position { get; set; }
        public string Linetype { get; set; }
        public double LinetypeScale { get; set; }
        public LineWeight LineWeight { get; set; }

        public CwcDBPoint()
        {
            TypeName = "DBPoint";
        }
    }




    public class CwcLine : CwcEntity
    {
        public CwcPoint3D StartPoint { get; set; }
        public CwcPoint3D EndPoint { get; set; }
        public string Linetype { get; set; }
        public double LinetypeScale { get; set; }
        public LineWeight LineWeight { get; set; }

        public CwcLine()
        {
            TypeName = "Line";
        }
    }


    public class CwcCircle : CwcEntity
    {

        public CwcPoint3D Center { get; set; }
        public Double Radius { get; set; }
        public string Linetype { get; set; }
        public double LinetypeScale { get; set; }
        public LineWeight LineWeight { get; set; }
        public string LinetypeId { get; set; }

        public CwcCircle()
        {
            TypeName = "Circle";
        }
    }

    public class CwcArc : CwcEntity
    {
        public CwcPoint3D Center { get; set; }
        public Double Radius { get; set; }
        public CwcPoint3D StartPoint { get; set; }
        public CwcPoint3D EndPoint { get; set; }
        public CwcVector3D Normal { get; set; }
        public Double StartAngle { get; set; }
        public Double EndAngle { get; set; }
        public string Linetype { get; set; }
        public double LinetypeScale { get; set; }
        public LineWeight LineWeight { get; set; }
        public string LinetypeId { get; set; }

        public CwcArc()
        {
            TypeName = "Arc";
        }
    }

    public class CwcEllipse : CwcEntity
    {
        public CwcPoint3D Center { get; set; }
        public Double MajorRadius { get; set; }
        public Double MinorRadius { get; set; }
        public CwcVector3D UnitNormal { get; set; }
        public CwcVector3D MajorAxis { get; set; }
        public CwcVector3D MinorAxis { get; set; }
        public Double RadiusRatio { get; set; }
        public Double StartAngle { get; set; }
        public Double EndAngle { get; set; }
        public string Linetype { get; set; }
        public double LinetypeScale { get; set; }
        public LineWeight LineWeight { get; set; }
        public string LinetypeId { get; set; }

        public CwcEllipse()
        {
            TypeName = "Ellipse";
        }
    }

    public class CwcRotatedDimension : CwcDimension
    {
        public CwcPoint3D XLine1Point { get; set; }
        public CwcPoint3D XLine2Point { get; set; }
        public CwcPoint3D DimLinePoint { get; set; }
        public Double Rotation { get; set; }
        public string DimStyleId { get; set; }
        public string TextStyleId { get; set; }
        public CwcPoint3D TextPosition { get; set; }
        public double TextRotation { get; set; }

        ///////////////////        /////////////
        public string DimBlockId { get; set; } 
        public string DimensionText { get; set; } 

        public bool DynamicDimension { get; set; }
        public double Elevation { get; set; }
        public double HorizontalRotation { get; set; }
        public string AlternatePrefix { get; set; }
        public string AlternateSuffix { get; set; }
        public bool AltSuppressLeadingZeros { get; set; }
        public bool AltSuppressTrailingZeros { get; set; }
        public bool AltSuppressZeroFeet { get; set; }
        public bool AltSuppressZeroInches { get; set; }
        public bool AltToleranceSuppressLeadingZeros { get; set; }
        public bool AltToleranceSuppressTrailingZeros { get; set; }
        public bool AltToleranceSuppressZeroFeet { get; set; }
        public bool AltToleranceSuppressZeroInches { get; set; }
        public string Prefix { get; set; }
        public string Suffix { get; set; }
        public bool SuppressAngularLeadingZeros { get; set; }
        public bool SuppressAngularTrailingZeros { get; set; }
        public bool SuppressLeadingZeros { get; set; }
        public bool SuppressTrailingZeros { get; set; }
        public bool SuppressZeroFeet { get; set; }
        public bool SuppressZeroInches { get; set; }
        public AttachmentPoint TextAttachment { get; set; }
        public double TextLineSpacingFactor { get; set; }
        public LineSpacingStyle TextLineSpacingStyle { get; set; }
        public bool ToleranceSuppressLeadingZeros { get; set; }
        public bool ToleranceSuppressTrailingZeros { get; set; }
        public bool ToleranceSuppressZeroFeet { get; set; }
        public bool ToleranceSuppressZeroInches { get; set; }
        public bool UsingDefaultTextPosition { get; set; }
        ///////////////////        //////////////
        public string Linetype { get; set; }
        public double LinetypeScale { get; set; }
        public LineWeight LineWeight { get; set; }
        public string LinetypeId { get; set; }

        public CwcRotatedDimension()
        {
            TypeName = "RotatedDimension";
        }
        public CwcRotatedDimension(Dimension dim):base(dim)
        {
            TypeName = "RotatedDimension";
        }
    }

    public class CwcDimStyle : CwcDbObject
    {
        public string Name { get; set; }
        public int Dimadec { get; set; }
        public bool Dimalt { get; set; }
        public int Dimaltd { get; set; }
        public double Dimaltf { get; set; }
        public double Dimaltrnd { get; set; }
        public int Dimalttd { get; set; }
        public int Dimalttz { get; set; }
        public int Dimaltu { get; set; }
        public int Dimaltz { get; set; }
        public string Dimapost { get; set; }
        public int Dimarcsym { get; set; }
        public double Dimasz { get; set; }
        public int Dimatfit { get; set; }
        public int Dimaunit { get; set; }
        public int Dimazin { get; set; }
        // If Dimsah is true, the arrowheads are formed by blocks set by the Dimblk1 and Dimblk2. If false, a block from Dimblk is used
        public bool Dimsah { get; set; }
        public string Dimblk1s { get; set; }
        public string Dimblk2s { get; set; }
        public string Dimblks { get; set; }
        public double Dimcen { get; set; }
        public CwcColor Dimclrd { get; set; }
        public CwcColor Dimclre { get; set; }
        public CwcColor Dimclrt { get; set; }
        public int Dimdec { get; set; }
        public double Dimdle { get; set; }
        public double Dimdli { get; set; }
        public char Dimdsep { get; set; }
        public double Dimexe { get; set; }
        public double Dimexo { get; set; }
        public int Dimfrac { get; set; }
        public double Dimfxlen { get; set; }
        public bool DimfxlenOn { get; set; }
        public double Dimgap { get; set; }
        public double Dimjogang { get; set; }
        public int Dimjust { get; set; }
        public string Dimldrblks { get; set; }
        public double Dimlfac { get; set; }
        public bool Dimlim { get; set; }
        // Linetype Ext 1		
        public string Dimltex1 { get; set; }
        // Linetype Ext 2
        public string Dimltex2 { get; set; }
        // Linetype
        public string Dimltype { get; set; }
        public int Dimlunit { get; set; }
        // Lineweight
        public LineWeight Dimlwd { get; set; }
        // Lineweight
        public LineWeight Dimlwe { get; set; }
        public string Dimpost { get; set; }
        public double Dimrnd { get; set; }
        public double Dimscale { get; set; }
        public bool Dimsd1 { get; set; }
        public bool Dimsd2 { get; set; }
        public bool Dimse1 { get; set; }
        public bool Dimse2 { get; set; }
        public bool Dimsoxd { get; set; }
        public int Dimtad { get; set; }
        public int Dimtdec { get; set; }
        public double Dimtfac { get; set; }
        public int Dimtfill { get; set; }
        public CwcColor Dimtfillclr { get; set; }
        public bool Dimtih { get; set; }
        public bool Dimtix { get; set; }
        public double Dimtm { get; set; }
        public int Dimtmove { get; set; }
        public bool Dimtofl { get; set; }
        public bool Dimtoh { get; set; }
        public bool Dimtol { get; set; }
        public int Dimtolj { get; set; }
        public double Dimtp { get; set; }
        public double Dimtsz { get; set; }
        public double Dimtvp { get; set; }
        public double Dimtxt { get; set; }
        public int Dimtzin { get; set; }
        public bool Dimupt { get; set; }
        public int Dimzin { get; set; }
        // Dimtxsty -ObjectId of a TextStyleTableRecord object  
        public string Dimtxsty { get; set; }

        public CwcDimStyle()
        {
            TypeName = "DimStyle";
        }

        public CwcDimStyle(DimStyleTableRecord dimsTR) : this()
        {
            Id = dimsTR.Id.ToString();
            Name = dimsTR.Name;
            Dimadec = dimsTR.Dimadec;
            Dimalt = dimsTR.Dimalt;
            Dimaltd = dimsTR.Dimaltd;
            Dimaltf = dimsTR.Dimaltf;
            Dimaltrnd = dimsTR.Dimaltrnd;
            Dimalttd = dimsTR.Dimalttd;
            Dimalttz = dimsTR.Dimalttz;
            Dimaltu = dimsTR.Dimaltu;
            Dimaltz = dimsTR.Dimaltz;
            Dimapost = dimsTR.Dimapost;
            Dimarcsym = dimsTR.Dimarcsym;
            Dimasz = dimsTR.Dimasz;
            Dimatfit = dimsTR.Dimatfit;
            Dimaunit = dimsTR.Dimaunit;
            Dimazin = dimsTR.Dimazin;
            /// If Dimsah is true, the arrowheads are formed by blocks set by the Dimblk1 and Dimblk2. If false, a block from Dimblk is used
            Dimsah = dimsTR.Dimsah;
            if (dimsTR.Dimsah)
            {
                Dimblk1s = dimsTR.Dimblk1s;
                Dimblk2s = dimsTR.Dimblk2s;
            }
            else
            {
                Dimblks = dimsTR.Dimblks;
            }
            Dimcen = dimsTR.Dimcen;
            Dimdec = dimsTR.Dimdec;
            Dimdle = dimsTR.Dimdle;
            Dimdli = dimsTR.Dimdli;
            Dimdsep = dimsTR.Dimdsep;
            Dimexe = dimsTR.Dimexe;
            Dimexo = dimsTR.Dimexo;
            Dimfrac = dimsTR.Dimfrac;
            Dimfxlen = dimsTR.Dimfxlen;
            DimfxlenOn = dimsTR.DimfxlenOn;
            Dimgap = dimsTR.Dimgap;
            Dimjogang = dimsTR.Dimjogang;
            Dimjust = dimsTR.Dimjust;
            Dimldrblks = dimsTR.Dimldrblks;
            Dimlfac = dimsTR.Dimlfac;
            Dimlim = dimsTR.Dimlim;
            //////////// Linetype Ext 1		
            Dimltex1 = dimsTR.Dimltex1.ToString();
            /////////////////////////// Linetype Ext 2
            Dimltex2 = dimsTR.Dimltex2.ToString();
            /////////////////////////// Linetype
            Dimltype = dimsTR.Dimltype.ToString();
            Dimlunit = dimsTR.Dimlunit;
            /////////////////////////// Lineweight
            Dimlwd = dimsTR.Dimlwd;
            /////////////////////////// Lineweight
            Dimlwe = dimsTR.Dimlwe;
            Dimpost = dimsTR.Dimpost;
            Dimrnd = dimsTR.Dimrnd;
            Dimscale = dimsTR.Dimscale;
            Dimsd1 = dimsTR.Dimsd1;
            Dimsd2 = dimsTR.Dimsd2;
            Dimse1 = dimsTR.Dimse1;
            Dimse2 = dimsTR.Dimse2;
            Dimsoxd = dimsTR.Dimsoxd;
            Dimtad = dimsTR.Dimtad;
            Dimtdec = dimsTR.Dimtdec;
            Dimtfac = dimsTR.Dimtfac;
            Dimtfill = dimsTR.Dimtfill;
            Dimtih = dimsTR.Dimtih;
            Dimtix = dimsTR.Dimtix;
            Dimtm = dimsTR.Dimtm;
            Dimtmove = dimsTR.Dimtmove;
            Dimtofl = dimsTR.Dimtofl;
            Dimtoh = dimsTR.Dimtoh;
            Dimtol = dimsTR.Dimtol;
            Dimtolj = dimsTR.Dimtolj;
            Dimtp = dimsTR.Dimtp;
            Dimtsz = dimsTR.Dimtsz;
            Dimtvp = dimsTR.Dimtvp;
            /////////////////////////// Dimtxsty -ObjectId of a TextStyleTableRecord object  
            Dimtxsty = dimsTR.Dimtxsty.ToString();
            Dimtxt = dimsTR.Dimtxt;
            Dimtzin = dimsTR.Dimtzin;
            Dimupt = dimsTR.Dimupt;
            Dimzin = dimsTR.Dimzin;

        }

        public static implicit operator CwcDimStyle(DimStyleTableRecord dimstyleTR)
        {
            return new CwcDimStyle(dimstyleTR);
        }

    }


    public class CwcAlignedDimension : CwcEntity
    {
        public CwcPoint3D XLine1Point { get; set; }
        public CwcPoint3D XLine2Point { get; set; }
        public CwcPoint3D DimLinePoint { get; set; }
        public string DimStyleId { get; set; }
        //public string DimensionStyleName { get; set; }
        //public CwcDimStyle DimensionStyle { get; set; }
        public string TextStyleId { get; set; }
        public CwcPoint3D TextPosition { get; set; }
        public double TextRotation { get; set; }
        public string Linetype { get; set; }
        public double LinetypeScale { get; set; }
        public LineWeight LineWeight { get; set; }
        public string LinetypeId { get; set; }

        public CwcAlignedDimension()
        {
            TypeName = "AlignedDimension";
        }
    }

    public class CwcOrdinateDimension : CwcEntity
    {
        public CwcPoint3D DefiningPoint { get; set; }
        public CwcPoint3D LeaderEndPoint { get; set; }
        public CwcPoint3D Origin { get; set; }
        public Boolean UsingXAxis { get; set; }
        public Boolean UsingYAxis { get; set; }
        public string DimStyleId { get; set; }
        //public string DimensionStyleName { get; set; }
        public string TextStyleId { get; set; }
        public CwcPoint3D TextPosition { get; set; }
        public double TextRotation { get; set; }
        public string Linetype { get; set; }
        public double LinetypeScale { get; set; }
        public LineWeight LineWeight { get; set; }
        public string LinetypeId { get; set; }

        public CwcOrdinateDimension()
        {
            TypeName = "OrdinateDimension";
        }
    }

    public abstract class CwcDimension : CwcEntity
    {
        public int Dimadec { get; set; }
        public bool Dimalt { get; set; }
        public int Dimaltd { get; set; }
        public double Dimaltf { get; set; }
        public double Dimaltrnd { get; set; }
        public int Dimalttd { get; set; }
        public int Dimalttz { get; set; }
        public int Dimaltu { get; set; }
        public int Dimaltz { get; set; }
        public string Dimapost { get; set; }
        public int Dimarcsym { get; set; }
        public double Dimasz { get; set; }
        public int Dimatfit { get; set; }
        public int Dimaunit { get; set; }
        public int Dimazin { get; set; }
        // If Dimsah is true, the arrowheads are formed by blocks set by the Dimblk1 and Dimblk2. If false, a block from Dimblk is used
        public bool Dimsah { get; set; }
        public string Dimblk1s { get; set; } 
        public string Dimblk2s { get; set; }
        public string Dimblks { get; set; }
        public double Dimcen { get; set; }
        public CwcColor Dimclrd { get; set; }
        public CwcColor Dimclre { get; set; }
        public CwcColor Dimclrt { get; set; }
        public int Dimdec { get; set; }
        public double Dimdle { get; set; }
        public double Dimdli { get; set; }
        public char Dimdsep { get; set; }
        public double Dimexe { get; set; }
        public double Dimexo { get; set; }
        public int Dimfrac { get; set; }
        public double Dimfxlen { get; set; }
        public bool DimfxlenOn { get; set; }
        public double Dimgap { get; set; }
        public double Dimjogang { get; set; }
        public int Dimjust { get; set; }
        public string Dimldrblks { get; set; }
        public double Dimlfac { get; set; }
        public bool Dimlim { get; set; }
        // Linetype Ext 1		
        public string Dimltex1 { get; set; } 
        // Linetype Ext 2
        public string Dimltex2 { get; set; } 
        // Linetype
        public string Dimltype { get; set; } 
        public int Dimlunit { get; set; }
        // Lineweight
        public LineWeight Dimlwd { get; set; }
        // Lineweight
        public LineWeight Dimlwe { get; set; }
        public string Dimpost { get; set; }
        public double Dimrnd { get; set; }
        public double Dimscale { get; set; }
        public bool Dimsd1 { get; set; }
        public bool Dimsd2 { get; set; }
        public bool Dimse1 { get; set; }
        public bool Dimse2 { get; set; }
        public bool Dimsoxd { get; set; }
        public int Dimtad { get; set; }
        public int Dimtdec { get; set; }
        public double Dimtfac { get; set; }
        public int Dimtfill { get; set; }
        public CwcColor Dimtfillclr { get; set; }
        public bool Dimtih { get; set; }
        public bool Dimtix { get; set; }
        public double Dimtm { get; set; }
        public int Dimtmove { get; set; }
        public bool Dimtofl { get; set; }
        public bool Dimtoh { get; set; }
        public bool Dimtol { get; set; }
        public int Dimtolj { get; set; }
        public double Dimtp { get; set; }
        public double Dimtsz { get; set; }
        public double Dimtvp { get; set; }
        public double Dimtxt { get; set; }
        public int Dimtzin { get; set; }
        public bool Dimupt { get; set; }
        public int Dimzin { get; set; }
        public CwcDimension()
        {
        }
        public CwcDimension (Dimension dim)
        {
            Dimadec = dim.Dimadec;
            Dimalt = dim.Dimalt;
            Dimaltd = dim.Dimaltd;
            Dimaltf = dim.Dimaltf;
            Dimaltrnd = dim.Dimaltrnd;
            Dimalttd = dim.Dimalttd;
            Dimalttz = dim.Dimalttz;
            Dimaltu = dim.Dimaltu;
            Dimaltz = dim.Dimaltz;
            Dimapost = dim.Dimapost;
            Dimarcsym = dim.Dimarcsym;
            Dimasz = dim.Dimasz;
            Dimatfit = dim.Dimatfit;
            Dimaunit = dim.Dimaunit;
            Dimazin = dim.Dimazin;
            /// If Dimsah is true, the arrowheads are formed by blocks set by the Dimblk1 and Dimblk2. If false, a block from Dimblk is used
            Dimsah = dim.Dimsah;
            if (dim.Dimsah)
            {
                Dimblk1s = dim.Dimblk1s;
                Dimblk2s = dim.Dimblk2s;
            }
            else
            {
                Dimblks = dim.Dimblks;
            }
            Dimcen = dim.Dimcen;
            Dimdec = dim.Dimdec;
            Dimdle = dim.Dimdle;
            Dimdli = dim.Dimdli;
            Dimdsep = dim.Dimdsep;
            Dimexe = dim.Dimexe;
            Dimexo = dim.Dimexo;
            Dimfrac = dim.Dimfrac;
            Dimfxlen = dim.Dimfxlen;
            DimfxlenOn = dim.DimfxlenOn;
            Dimgap = dim.Dimgap;
            Dimjogang = dim.Dimjogang;
            Dimjust = dim.Dimjust;
            Dimldrblks = dim.Dimldrblks;
            Dimlfac = dim.Dimlfac;
            Dimlim = dim.Dimlim;
            //////////// Linetype Ext 1		
            Dimltex1 = dim.Dimltex1.ToString();
            /////////////////////////// Linetype Ext 2
            Dimltex2 = dim.Dimltex2.ToString();
            /////////////////////////// Linetype
            Dimltype = dim.Dimltype.ToString();
            Dimlunit = dim.Dimlunit;
            /////////////////////////// Lineweight
            Dimlwd = dim.Dimlwd;
            /////////////////////////// Lineweight
            Dimlwe = dim.Dimlwe;
            Dimpost = dim.Dimpost;
            Dimrnd = dim.Dimrnd;
            Dimscale = dim.Dimscale;
            Dimsd1 = dim.Dimsd1;
            Dimsd2 = dim.Dimsd2;
            Dimse1 = dim.Dimse1;
            Dimse2 = dim.Dimse2;
            Dimsoxd = dim.Dimsoxd;
            Dimtad = dim.Dimtad;
            Dimtdec = dim.Dimtdec;
            Dimtfac = dim.Dimtfac;
            Dimtfill = dim.Dimtfill;
            Dimtih = dim.Dimtih;
            Dimtix = dim.Dimtix;
            Dimtm = dim.Dimtm;
            Dimtmove = dim.Dimtmove;
            Dimtofl = dim.Dimtofl;
            Dimtoh = dim.Dimtoh;
            Dimtol = dim.Dimtol;
            Dimtolj = dim.Dimtolj;
            Dimtp = dim.Dimtp;
            Dimtsz = dim.Dimtsz;
            Dimtvp = dim.Dimtvp;
            Dimtxt = dim.Dimtxt;
            Dimtzin = dim.Dimtzin;
            Dimupt = dim.Dimupt;
            Dimzin = dim.Dimzin;
        }

    }

    public class CwcMText : CwcEntity
    {
        public string TextString { get; set; }
        public CwcPoint3D Location { get; set; }
        //       public string Font { get; set; }  /// Font  not used 
        public Double Height { get; set; }
        public Double TextHeight { get; set; }
        public Double Width { get; set; }
        public string TextStyleId { get; set; }
        public AttachmentPoint Attachment { get; set; }
        public bool BackgroundFill { get; set; }
        public CwcColor BackgroundFillColor { get; set; }
        public double BackgroundScaleFactor { get; set; }
     //   public Transparency BackgroundTransparency { get; set; }
        public bool ColumnAutoHeight { get; set; }
        public int ColumnCount { get; set; }
        public bool ColumnFlowReversed { get; set; }
        public double ColumnGutterWidth { get; set; }
        public ColumnType ColumnType { get; set; }
        public double ColumnWidth { get; set; }
        public double[] ColumnHeight { get; set; }
        public CwcVector3D Direction { get; set; }
        public FlowDirection FlowDirection { get; set; }
        public double LineSpaceDistance { get; set; }
        public double LineSpacingFactor { get; set; }
        public LineSpacingStyle LineSpacingStyle { get; set; }
        public CwcVector3D Normal { get; set; }
        public double Rotation { get; set; }
        public bool UseBackgroundColor { get; set; }

        public CwcMText()
        {
            TypeName = "MText";
        }
        public CwcMText(ColumnType col_type, bool col_autoheight, int col_Count) : this()
        {
            if ((col_type == ColumnType.DynamicColumns) && (!col_autoheight))
            {
                if (col_Count > 0)
                    ColumnHeight = new double[col_Count];
            }
            ColumnType = col_type;
            ColumnAutoHeight = col_autoheight;
            ColumnCount = col_Count;
        }
    }


    public class CwcDBText : CwcEntity
    {
        public CwcPoint3D AlignmentPoint { get; set; }
        public TextHorizontalMode HorizontalMode { get; set; }
        public bool IsDefaultAlignment { get; set; }
        public bool IsMirroredInX { get; set; }
        public bool IsMirroredInY { get; set; }
        public AttachmentPoint Justify { get; set; }
        public CwcVector3D Normal { get; set; }
        public double Oblique { get; set; }
        public double Rotation { get; set; }
        public TextVerticalMode VerticalMode { get; set; }
        public double Thickness { get; set; }
        public CwcPoint3D Position { get; set; }
        public string TextString { get; set; }
        public string Font { get; set; }
        public Double Height { get; set; }
        public Double WidthFactor { get; set; }
        public string TextStyleId { get; set; }
        public AnnotativeStates Annotative { get; set; }

        public CwcDBText()
        {
            TypeName = "DBText";
        }
    }


    public class CwcHatch : CwcEntity
    {
        public HatchObjectType HatchObjectType { get; set; }
        public string GradientName { get; set; }
        public GradientPatternType GradientType { get; set; }
        public Double GradientAngle { get; set; }
        public bool GradientOneColorMode { get; set; }
        public float GradientShift { get; set; }
        public CwcGradiantColor[] GradientColor { get; set; }
        public bool IsGradient { get; set; }
        public bool IsHatch { get; set; }
        public bool IsSolidFill { get; set; }
        public AnnotativeStates Annotative { get; set; }
        public bool Associative { get; set; }
//        public List<string> AssociatedObjectId { get; set; }  // To Delete this
        public int NumberOfLoops { get; set; }
        public CwcHatchLoop[] Loops { get; set; }
        public string PatternName { get; set; }
        public HatchPatternType PatternType { get; set; }
        public Double PatternAngle { get; set; }
        public Double PatternScale { get; set; }
        public Double PatternSpace { get; set; }
        public CwcColor BackgroundColor { get; set; } // none
        public HatchStyle HatchStyle { get; set; }
        public CwcPoint2D Origin { get; set; }
        public string Linetype { get; set; }
        public double LinetypeScale { get; set; }
        public LineWeight LineWeight { get; set; }

        public CwcHatch(int numberOfLoops)
        {
            TypeName = "Hatch";
            GradientColor = new CwcGradiantColor[2];
            Loops = new CwcHatchLoop[numberOfLoops];
            NumberOfLoops = numberOfLoops;
        }
    }

    public class CwcHatchLoop
    {
        public HatchLoopTypes LoopType { get; set; }
        public string[] AssociativeIds { get; set; }
        public int NumberOfAssociativeIds { get; set; }
        public bool IsPolyline { get; set; }
        public int NumberOfBulgeVertices { get; set; }
        public CwcBulgeVertex[] BulgeVertices { get; set; }
        public int NumberOfCurves { get; set; }
        public CwcCurve2D[] Curve2DCollection { get; set; } // else // set TypeOfCurve2D = 1 .. for various types //  

        public CwcHatchLoop(bool isPolyline, int objCount)
        {
            IsPolyline = isPolyline;
            if (IsPolyline)
            {
                NumberOfBulgeVertices = objCount;
                BulgeVertices = new CwcBulgeVertex[objCount];
            }
            else
            {
                NumberOfCurves = objCount;
                Curve2DCollection = new CwcCurve2D[objCount];
            }
        }

        public CwcHatchLoop(int idCount)
        {
            IsPolyline = false;
            NumberOfAssociativeIds = idCount;
            AssociativeIds = new string[NumberOfAssociativeIds];
        }

        public CwcHatchLoop(ObjectIdCollection ids)
        {
            IsPolyline = false;
            NumberOfAssociativeIds = ids.Count;
            AssociativeIds = new string[NumberOfAssociativeIds];
            for(int i = 0; i < NumberOfAssociativeIds; i++)
            {
                AssociativeIds[i] = ids[i].ToString();
            }
        }

        public static implicit operator CwcHatchLoop(HatchLoop loop)
        {
            return GetCwcLoopFromACADLoop(loop);
        }


        public static CwcHatchLoop GetCwcLoopFromACADLoop(HatchLoop dwghatchloop)
        {
            CwcHatchLoop hatchLoop = null;
            if (dwghatchloop.IsPolyline)
            {
                hatchLoop = new CwcHatchLoop(dwghatchloop.IsPolyline, dwghatchloop.Polyline.Count);
                BulgeVertexCollection bvCollection = dwghatchloop.Polyline;
                hatchLoop.NumberOfBulgeVertices = bvCollection.Count;
                for (int bv = 0; bv < bvCollection.Count; bv++)
                {
                    hatchLoop.BulgeVertices[bv] = bvCollection[bv];
                }
            }
            else
            {
                hatchLoop = new CwcHatchLoop(dwghatchloop.IsPolyline, dwghatchloop.Curves.Count);
                //for (int cc = 0; cc < hatchLoop.NumberOfCurves; cc++)
                //{
                //    hatchLoop.Curve2DCollection[cc].CurveType = Enums.ConvertStringToEnumValue<Enums.CurveType>(dwghatchloop.Curves[cc].GetType().Name);
                //}
            }
            return hatchLoop;
        }

    }

    public class CwcBulgeVertex
    {
        public double Bulge { get; set; }
        public CwcPoint2D Vertex { get; set; }

        public CwcBulgeVertex(double b, CwcPoint2D v)
        {
            Bulge = b;
            Vertex = v;
        }

        public static implicit operator CwcBulgeVertex(BulgeVertex bv)
        {
            return new CwcBulgeVertex(bv.Bulge, bv.Vertex);
        }
        public override string ToString()
        {
            return string.Format("({0},{1})", Bulge.ToString(), Vertex.ToString()); // bulge and vertex seperatee

        }
    }

    public class CwcCurve2D
    {
        public Enums.CurveType CurveType { get; set; }


    }

    public class CwcEllipticalArc2D : CwcCurve2D
    {
        public CwcPoint2D Center { get; set; }
        public Double MajorRadius { get; set; }
        public Double MinorRadius { get; set; }
        public CwcVector2D MajorAxis { get; set; }
        public CwcVector2D MinorAxis { get; set; }
        public Double StartAngle { get; set; }
        public Double EndAngle { get; set; }
        public CwcEllipticalArc2D(Enums.CurveType curvetype)
        {
            CurveType = curvetype;
        }
    }

    public class CwcCircularArc2D : CwcCurve2D
    {
        public CwcPoint2D Center { get; set; }
        public Double Radius { get; set; }
        public CwcVector2D ReferenceVector { get; set; }
        public Double StartAngle { get; set; }
        public Double EndAngle { get; set; }
        public bool IsClockWise { get; set; }
        public CwcCircularArc2D(Enums.CurveType curvetype)
        {
            CurveType = curvetype;
        }
    }

    public class CwcLineSegment2D : CwcCurve2D
    {
        public CwcPoint2D StartPoint { get; set; }
        public CwcPoint2D EndPoint { get; set; }

        public CwcLineSegment2D(Enums.CurveType curvetype)
        {
            CurveType = curvetype;
        }
    }

    public class CwcNurbCurve2D : CwcCurve2D
    {
        public bool HasFitData { get; set; }
        public int Degree { get; set; }
        public int NumFitPoints { get; set; }
        public int NumControlPoints { get; set; }
        public int NumKnots { get; set; }
        public int NumWeights { get; set; }
        public CwcPoint2D[] FitPoints { get; set; }
        public CwcVector2D Fit_StartTangent { get; set; }
        public CwcVector2D Fit_EndTangent { get; set; }
        public bool Fit_TangentsExist { get; set; }
        public KnotParameterizationEnum FitKnotParameterization { get; set; }
        public double FitTolerance_EqualVector { get; set; }
        public double FitTolerance_EqualPoint { get; set; }
        public CwcPoint2D[] ControlPoints { get; set; }
        public double[] Knots { get; set; }
        public double[] Weights { get; set; }
        public bool Periodic { get; set; }

        public CwcNurbCurve2D(int numOfFitPoints, Enums.CurveType curvetype)
        {
            NumFitPoints = numOfFitPoints;
            FitPoints = new CwcPoint2D[numOfFitPoints];
            CurveType = curvetype;
            HasFitData = true;
        }

        public CwcNurbCurve2D(int numOfControlPoints, int numKnots, int numWeights, Enums.CurveType curvetype)
        {
            HasFitData = false;
            NumControlPoints = numOfControlPoints;
            NumKnots = numKnots;
            NumWeights = numWeights;
            ControlPoints = new CwcPoint2D[numOfControlPoints];
            Knots = new double[numKnots];
            Weights = new double[numWeights];
            CurveType = curvetype;
        }

    }



    public struct CwcGradiantColor
    {
        public byte Red { get; set; }
        public byte Green { get; set; }
        public byte Blue { get; set; }
        public float Value { get; set; }
        public CwcGradiantColor(byte red, byte green, byte blue, float value)
        {
            Red = red;
            Green = green;
            Blue = blue;
            Value = value;
        }

        public static implicit operator CwcGradiantColor(GradientColor color)
        {
            return new CwcGradiantColor(color.get_Color().Red, color.get_Color().Green, color.get_Color().Blue, color.get_Value()); 
        }

        public override string ToString()
        {
            return string.Format("({0},{1},{2},{3})", Red, Green, Blue, Value);
        }

    }


    public class CwcPolyline : CwcEntity
    {
        public CwcPoint3D StartPoint { get; set; }
        public CwcPoint3D EndPoint { get; set; }
        public CwcPoint3D[] Vertices { get; set; }
        public double[] Bulge { get; set; }
        public double[] StartWidth { get; set; }
        public double[] EndWidth { get; set; }
        public int NumberOfVertices { get; set; }
        public bool IsClosed { get; set; }
        public string Linetype { get; set; }
        public double LinetypeScale { get; set; }
        public LineWeight LineWeight { get; set; }
        public string LinetypeId { get; set; }
        public CwcPolyline(int numberOfVertices)
        {
            TypeName = "Polyline";
            Vertices = new CwcPoint3D[numberOfVertices];
            Bulge = new double[numberOfVertices];
            StartWidth = new double[numberOfVertices];
            EndWidth = new double[numberOfVertices];
            NumberOfVertices = numberOfVertices;
        }
    }


    public class CwcSpline : CwcEntity
    {
        public bool HasFitData { get; set; }
        public bool FitTangentsExist { get; set; }
        public CwcVector3D StartFitTangent { get; set; }
        public CwcVector3D EndFitTangent { get; set; }
        public int NumFitPoints { get; set; }
        public CwcPoint3D[] FitPoints { get; set; }
        public double FitTolerance { get; set; }
        public int Order { get; set; }
        public CwcNurbsData NurbsData { get; set; }
        public int NumControlPoints { get; set; }
        public CwcPoint3D[] ControlPoints { get; set; }

        public string Linetype { get; set; }
        public double LinetypeScale { get; set; }
        public LineWeight LineWeight { get; set; }
        public string LinetypeId { get; set; }
        public CwcSpline(bool hasFitData, int numPoints)
        {
            TypeName = "Spline";
            HasFitData = hasFitData;
            if (hasFitData)
            {
                FitPoints = new CwcPoint3D[numPoints];
                NumFitPoints = numPoints;
            }
            else
            {
                ControlPoints = new CwcPoint3D[numPoints];
                NumControlPoints = numPoints;
            }
        }
        public CwcSpline(bool hasFitData, int numControlPoints, int numKnots, int numWeights)
        {
            TypeName = "Spline";
            HasFitData = hasFitData;
            ControlPoints = new CwcPoint3D[numControlPoints];
            NumControlPoints = numControlPoints;
            NurbsData = new CwcNurbsData(numKnots, numWeights);
        }
    }

    public class CwcNurbsData
    {
        public bool Closed { get; set; }
        public double ControlPointTolerance { get; set; }
        public int Degree { get; set; }
        public double KnotTolerance { get; set; }
        public bool Periodic { get; set; }
        public bool Rational { get; set; }
        public int NumKnots { get; set; }
        public int NumWeights { get; set; }
        public double[] Knots { get; set; }
        public double[] Weights { get; set; }

        public CwcNurbsData(int numKnots, int numWeights)
        {
            Knots = new double[numKnots];
            NumKnots = numKnots;
            Weights = new double[numWeights];
            NumWeights = numWeights;
        }

        public static implicit operator CwcNurbsData(NurbsData nurbsData)
        {
            DoubleCollection knots = nurbsData.GetKnots();

            DoubleCollection weights = nurbsData.GetWeights();

            CwcNurbsData cwcNurbsdata = new CwcNurbsData(knots.Count, weights.Count);

            cwcNurbsdata.Closed = nurbsData.Closed;
            cwcNurbsdata.ControlPointTolerance = nurbsData.ControlPointTolerance;
            cwcNurbsdata.Degree = nurbsData.Degree;
            cwcNurbsdata.KnotTolerance = nurbsData.KnotTolerance;
            cwcNurbsdata.Periodic = nurbsData.Periodic;
            cwcNurbsdata.Rational = nurbsData.Rational;

            for (int knt = 0; knt < knots.Count; knt++)
            {
                cwcNurbsdata.Knots[knt] = knots[knt];
            }

            for (int wt = 0; wt < weights.Count; wt++)
            {
                cwcNurbsdata.Weights[wt] = weights[wt];
            }

            return cwcNurbsdata;
        }

        public override string ToString()
        {
            return string.Format("Closed={0}", Closed.ToString()) + Environment.NewLine + 
                string.Format("ControlPointTolerance={0}", ControlPointTolerance.ToString()) + Environment.NewLine +
                string.Format("Degree={0}", Degree.ToString()) + Environment.NewLine +
                string.Format("KnotTolerance={0}", KnotTolerance.ToString()) + Environment.NewLine +
                string.Format("Periodic={0}", Periodic.ToString()) + Environment.NewLine +
                string.Format("Rational={0}", Rational.ToString());
        }
    }


    public class CwcLeader : CwcEntity
    {
        public int NumVertices { get; set; }
        public CwcPoint3D[] Vertices { get; set; }
        public String DimensionStyle { get; set; }
        public double Dimasz { get; set; }
        public CwcColor Dimclrd { get; set; }
        public double Dimgap { get; set; }
        public string Dimblks { get; set; }
        public string Dimldrblk { get; set; }
        public LineWeight Dimlwd { get; set; }
        public bool Dimsah { get; set; }
        public double Dimscale { get; set; }
        public int Dimtad { get; set; }
        public double Dimtxt { get; set; }
        public bool HasArrowHead { get; set; }
        public bool IsSplined { get; set; }
        public String TextStyleId { get; set; }
        public string Annotation { get; set; }
        public CwcVector3D AnnotationOffset { get; set; }
        public AnnotationType AnnoType { get; set; }
        public string Linetype { get; set; }
        public double LinetypeScale { get; set; }
        public LineWeight LineWeight { get; set; }
        public CwcLeader(int numberOfVertices) : this()
        {
            Vertices = new CwcPoint3D[numberOfVertices];
            NumVertices = numberOfVertices;
        }
        public CwcLeader()
        {
            TypeName = "Leader";
        }
    }


    public class CwcFace : CwcEntity
    {
        public CwcPoint3D Vertex1 { get; set; }
        public CwcPoint3D Vertex2 { get; set; }
        public CwcPoint3D Vertex3 { get; set; }
        public CwcPoint3D Vertex4 { get; set; }
        public bool IsEdgeVisibleAtVertex1 { get; set; }
        public bool IsEdgeVisibleAtVertex2 { get; set; }
        public bool IsEdgeVisibleAtVertex3 { get; set; }
        public bool IsEdgeVisibleAtVertex4 { get; set; }
        public bool IsVisible { get; set; }
        public string Material { get; set; }
        public string Linetype { get; set; }
        public LineWeight LineWeight { get; set; }
        public string LinetypeId { get; set; }
        public CwcFace()
        {
            TypeName = "Face";
        }
    }



}
