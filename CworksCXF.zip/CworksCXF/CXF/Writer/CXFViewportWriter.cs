﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{
    public class CXFViewportWriter : CXFEntityWriter
    {
        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcViewport);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("Name={0}", entity.Name))
                    .AppendLine(String.Format("CircleSides={0}", entity.CircleSides.ToString()))
                    .AppendLine(String.Format("GridEnabled={0}", entity.GridEnabled.ToString(1)))
                    .AppendLine(String.Format("CenterPoint={0}", entity.CenterPoint.ToString()))
                    .AppendLine(String.Format("Height={0}", entity.Height.ToString()))
                    .AppendLine(String.Format("Width={0}", entity.Width.ToString()))
            ;
            return strBuilder.ToString();
        }
    }
}
