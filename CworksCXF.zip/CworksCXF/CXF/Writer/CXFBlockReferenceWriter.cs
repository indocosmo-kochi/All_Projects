﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{
    public class CXFBlockReferenceWriter : CXFEntityWriter
    {
        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcBlockReference);

            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("BlockDefId={0}", entity.BlockDefId))
                    .AppendLine(String.Format("Position={0}", entity.Position.ToString()))
                    .AppendLine(String.Format("Rotation={0}", entity.Rotation.ToString()))
                    .AppendLine(String.Format("BlockUnit={0}", entity.BlockUnit.ToString("D")))
                    .AppendLine(String.Format("IsDynamicBlock={0}", entity.IsDynamicBlock.ToString(1)))
                    .AppendLine(String.Format("ScaleFactors={0}", entity.ScaleFactors.ToString()))
                    .AppendLine(String.Format("Name={0}", entity.Name))
                    .AppendLine(String.Format("Color={0}", entity.Color.ToString()))
                    .AppendLine(String.Format("ColorMethod={0}", entity.Color.ColorMethod.ToString("D")))
                    .AppendLine(String.Format("ColorIndex={0}", entity.Color.ColorIndex.ToString()))
                    .AppendLine(String.Format("Linetype={0}", entity.Linetype))
                    .AppendLine(String.Format("LinetypeScale={0}", entity.LinetypeScale))
                    .AppendLine(String.Format("NumberAttributeRefs={0}", entity.NumberAttributeRefs))
                    .AppendLine(String.Format("LayerId={0}", entity.LayerId))
                    .AppendLine(String.Format("LineWeight={0}", entity.LineWeight.ToString("D")))
            ;
            for (int i = 0; i < entity.NumberAttributeRefs; i++)
            {
                strBuilder
                  .AppendLine(String.Format("Tag({0})={1}", i, entity.AttributeRefs[i].Tag))
                  .AppendLine(String.Format("TextString({0})={1}", i, entity.AttributeRefs[i].TextString));
            }

            strBuilder.AppendLine(String.Format("BlockName={0}", entity.BlockName));
            return strBuilder.ToString();
        }
    }
}

