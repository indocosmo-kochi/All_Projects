﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;
using Teigha.DatabaseServices;

namespace CWorksCXF.CXF.Writer
{
    public class CXFLeaderWriter : CXFEntityWriter
    {

        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcLeader);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("NumVertices={0}", entity.NumVertices.ToString()))
                    ;

            for (int i = 0; i < entity.NumVertices; i++)
            {
                strBuilder.AppendLine(String.Format("Vertex({0})={1}", i, entity.Vertices[i].ToString()));
            }

            strBuilder                   
                   .AppendLine(String.Format("HasArrowHead={0}", entity.HasArrowHead.ToString(1)))
                   .AppendLine(String.Format("IsSplined={0}", entity.IsSplined.ToString(1)))
                   .AppendLine(String.Format("LayerId={0}", entity.LayerId))
                   .AppendLine(String.Format("Dimlwd={0}", entity.Dimlwd.ToString("D")))
                   .AppendLine(String.Format("Dimldrblk={0}", entity.Dimldrblk.ToString()))
                   .AppendLine(String.Format("DimensionStyle={0}", entity.DimensionStyle))
                   .AppendLine(String.Format("Dimasz={0}", entity.Dimasz.ToString()))
                   .AppendLine(String.Format("Dimgap={0}", entity.Dimgap.ToString()))
                   .AppendLine(String.Format("Dimscale={0}", entity.Dimscale.ToString()))
                   .AppendLine(String.Format("Dimtad={0}", entity.Dimtad.ToString()))
                   .AppendLine(String.Format("Dimtxt={0}", entity.Dimtxt.ToString()))
                   .AppendLine(String.Format("Dimblks={0}", entity.Dimblks))
                   .AppendLine(String.Format("AnnoType={0}", entity.AnnoType.ToString("D")))
                   .AppendLine(String.Format("Dimclrd={0}", entity.Dimclrd))
                   .AppendLine(String.Format("Dimclrd_ColorIndex={0}", entity.Dimclrd.ColorIndex))
                   .AppendLine(String.Format("Dimclrd_ColorMethod={0}", entity.Dimclrd.ColorMethod))
                   .AppendLine(String.Format("Linetype={0}", entity.Linetype))
                   .AppendLine(String.Format("LinetypeScale={0}", entity.LinetypeScale))
                   .AppendLine(String.Format("LineWeight={0}", (int)entity.LineWeight))
                   .AppendLine(String.Format("TextStyleId={0}", entity.TextStyleId.ToString()))
                   ;
            if (entity.AnnoType == AnnotationType.MText)
                strBuilder.AppendLine(String.Format("Annotation={0}", entity.Annotation));

            if (entity.BlockName.Trim().ToUpper() != CONST.MODEL_SPACE)
                strBuilder.AppendLine(String.Format("BlockId={0}", entity.BlockId));
            return strBuilder.ToString();
        }
    }
}
