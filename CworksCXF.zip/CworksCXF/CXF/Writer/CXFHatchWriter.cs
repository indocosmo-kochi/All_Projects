﻿using System;
using System.Text;
using System.Collections.Generic;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{
    public class CXFHatchWriter : CXFEntityWriter
    {

        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcHatch);

            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("HatchObjectType={0}", entity.HatchObjectType.ToString("D")))
                    .AppendLine(String.Format("IsHatch={0}", entity.IsHatch.ToString(1)))
                    .AppendLine(String.Format("IsGradient={0}", entity.IsGradient.ToString(1)))
                    .AppendLine(String.Format("IsSolidFill={0}", entity.IsSolidFill.ToString(1)))
                    .AppendLine(String.Format("Origin={0}", entity.Origin.ToString()))
                    .AppendLine(String.Format("Annotative={0}", entity.Annotative.ToString("D")))
                    .AppendLine(String.Format("Associative={0}", entity.Associative.ToString(1)))
                    ;
            if (entity.IsGradient)
            {
                strBuilder
                    .AppendLine(String.Format("GradientName={0}", entity.GradientName))
                    .AppendLine(String.Format("GradientType={0}", entity.GradientType.ToString("D")))
                    .AppendLine(String.Format("GradientAngle={0}", entity.GradientAngle))
                    .AppendLine(String.Format("GradientShift={0}", entity.GradientShift.ToString()))
                    .AppendLine(String.Format("GradientOneColorMode={0}", entity.GradientOneColorMode.ToString(1)))
                    .AppendLine(String.Format("GradientColor(1)={0}", entity.GradientColor[0].ToString()))
                    .AppendLine(String.Format("GradientColor(2)={0}", entity.GradientColor[1].ToString()));
            }

            if (entity.IsHatch)
            {
                strBuilder
                    .AppendLine(String.Format("PatternName={0}", entity.PatternName))
                    .AppendLine(String.Format("PatternType={0}", entity.PatternType.ToString("D")))
                    .AppendLine(String.Format("PatternAngle={0}", entity.PatternAngle.ToString()))
                    .AppendLine(String.Format("PatternScale={0}", entity.PatternScale.ToString()))
                    .AppendLine(String.Format("PatternSpace={0}", entity.PatternSpace.ToString()))
                    .AppendLine(String.Format("HatchStyle={0}", entity.HatchStyle.ToString("D")))
                    .AppendLine(String.Format("Color={0}", entity.Color.ToString()))
                    .AppendLine(String.Format("ColorMethod={0}", entity.Color.ColorMethod.ToString("D")))
                    .AppendLine(String.Format("ColorIndex={0}", entity.Color.ColorIndex.ToString()))
                    .AppendLine(String.Format("BackgroundColor={0}", entity.BackgroundColor.ToString()))
                    .AppendLine(String.Format("BackgroundColorIndex={0}", entity.BackgroundColor.ColorIndex.ToString()))
                    .AppendLine(String.Format("BackgroundColorMethod={0}", entity.BackgroundColor.ColorMethod.ToString("D")));
            }

            strBuilder.AppendLine(String.Format("NumberOfLoops={0}", entity.NumberOfLoops));
            for (int i = 0; i < entity.NumberOfLoops; i++)
            {
                strBuilder.AppendLine(String.Format("LoopType({0})={1}", i, entity.Loops[i].LoopType.ToString("D")));
                if (entity.Associative)
                {
                    strBuilder.AppendLine(String.Format("NumberOfAssociativeIds({0})={1}", i, entity.Loops[i].NumberOfAssociativeIds.ToString()));
                    for (int j = 0; j < entity.Loops[i].NumberOfAssociativeIds; j++)
                    {
                        strBuilder.AppendLine(String.Format("AssociativeId({0},{1})={2}", i, j, entity.Loops[i].AssociativeIds[j]));
                    }
                }
                else
                {
                    strBuilder.AppendLine(String.Format("IsPolyline({0})={1}", i, entity.Loops[i].IsPolyline.ToString(1)));
                    if (entity.Loops[i].IsPolyline)
                    {
                        strBuilder.AppendLine(String.Format("NumberOfBulgeVertices({0})={1}", i, entity.Loops[i].NumberOfBulgeVertices.ToString()));
                        for (int j = 0; j < entity.Loops[i].NumberOfBulgeVertices; j++)
                        {
                            strBuilder.AppendLine(String.Format("Bulge({0},{1})={2}", i, j, entity.Loops[i].BulgeVertices[j].Bulge.ToString()));
                            strBuilder.AppendLine(String.Format("Vertex({0},{1})={2}", i, j, entity.Loops[i].BulgeVertices[j].Vertex.ToString()));
                        }
                    }
                    else
                    {
                        strBuilder.Append(WriteCurvesIntoCXF(i, entity.Loops[i]));
                    }
                }
            }
            strBuilder
                    .AppendLine(String.Format("Linetype={0}", entity.Linetype))
                    .AppendLine(String.Format("LinetypeScale={0}", entity.LinetypeScale))
                    .AppendLine(String.Format("LayerId={0}", entity.LayerId))
                    .AppendLine(String.Format("LineWeight={0}", entity.LineWeight.ToString("D")))
                    ;
            if (entity.BlockName.Trim().ToUpper() != CONST.MODEL_SPACE)
                strBuilder.AppendLine(String.Format("BlockId={0}", entity.BlockId));
            return strBuilder.ToString();

        }

        private string WriteCurvesIntoCXF(int hlCtr, CwcHatchLoop hatchLoop)
        {
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(String.Format("NumberOfCurves({0})={1}", hlCtr, hatchLoop.NumberOfCurves.ToString()));

            for (int curCtr = 0; curCtr < hatchLoop.NumberOfCurves; curCtr++)
            {
                Enums.CurveType curvetype = hatchLoop.Curve2DCollection[curCtr].CurveType;
                strBuilder.AppendLine(String.Format("CurveType({0},{1})={2}", hlCtr, curCtr, curvetype.ToString("D")));

                switch (curvetype)
                {
                    case Common.Enums.CurveType.LineSegment2d:
                        CwcLineSegment2D linesegment = hatchLoop.Curve2DCollection[curCtr] as CwcLineSegment2D;
                        strBuilder
                            .AppendLine(String.Format("StartPoint({0},{1})={2}", hlCtr, curCtr, linesegment.StartPoint.ToString()))
                            .AppendLine(String.Format("EndPoint({0},{1})={2}", hlCtr, curCtr, linesegment.EndPoint.ToString()))
                            ;
                        break;
                    case Common.Enums.CurveType.CircularArc2d:
                        CwcCircularArc2D circularArc = hatchLoop.Curve2DCollection[curCtr] as CwcCircularArc2D;
                        strBuilder
                            .AppendLine(String.Format("Center({0},{1})={2}", hlCtr, curCtr, circularArc.Center.ToString()))
                            .AppendLine(String.Format("Radius({0},{1})={2}", hlCtr, curCtr, circularArc.Radius.ToString()))
                            .AppendLine(String.Format("StartAngle({0},{1})={2}", hlCtr, curCtr, circularArc.StartAngle.ToString()))
                            .AppendLine(String.Format("EndAngle({0},{1})={2}", hlCtr, curCtr, circularArc.EndAngle.ToString()))
                            .AppendLine(String.Format("ReferenceVector({0},{1})={2}", hlCtr, curCtr, circularArc.ReferenceVector.ToString()))
                            .AppendLine(String.Format("IsClockWise({0},{1})={2}", hlCtr, curCtr, circularArc.IsClockWise.ToString(1)))
                            ;
                        break;
                    case Common.Enums.CurveType.EllipticalArc2d:
                        CwcEllipticalArc2D ellipticalArc = hatchLoop.Curve2DCollection[curCtr] as CwcEllipticalArc2D;
                        strBuilder
                            .AppendLine(String.Format("Center({0},{1})={2}", hlCtr, curCtr, ellipticalArc.Center.ToString()))
                            .AppendLine(String.Format("MajorRadius({0},{1})={2}", hlCtr, curCtr, ellipticalArc.MajorRadius.ToString()))
                            .AppendLine(String.Format("MinorRadius({0},{1})={2}", hlCtr, curCtr, ellipticalArc.MinorRadius.ToString()))
                            .AppendLine(String.Format("MajorAxis({0},{1})={2}", hlCtr, curCtr, ellipticalArc.MajorAxis.ToString()))
                            .AppendLine(String.Format("MinorAxis({0},{1})={2}", hlCtr, curCtr, ellipticalArc.MinorAxis.ToString()))
                            .AppendLine(String.Format("StartAngle({0},{1})={2}", hlCtr, curCtr, ellipticalArc.StartAngle.ToString()))
                            .AppendLine(String.Format("EndAngle({0},{1})={2}", hlCtr, curCtr, ellipticalArc.EndAngle.ToString()))
                            ;
                        break;
                    case Common.Enums.CurveType.NurbCurve2d:
                        CwcNurbCurve2D nurbCurve2d = hatchLoop.Curve2DCollection[curCtr] as CwcNurbCurve2D;
                        strBuilder.AppendLine(String.Format("HasFitData({0},{1})={2}", hlCtr, curCtr, nurbCurve2d.HasFitData.ToString(1)));

                        if (nurbCurve2d.HasFitData)
                        {
                            strBuilder
                                .AppendLine(String.Format("Degree({0},{1})={2}", hlCtr, curCtr, nurbCurve2d.Degree.ToString()))
                                .AppendLine(String.Format("FitKnotParameterization({0},{1})={2}", hlCtr, curCtr, nurbCurve2d.FitKnotParameterization.ToString("D")))
                                .AppendLine(String.Format("FitTolerance_EqualPoint({0},{1})={2}", hlCtr, curCtr, nurbCurve2d.FitTolerance_EqualPoint.ToString()))
                                .AppendLine(String.Format("FitTolerance_EqualVector({0},{1})={2}", hlCtr, curCtr, nurbCurve2d.FitTolerance_EqualVector.ToString()))
                                .AppendLine(String.Format("NumFitPoints({0},{1})={2}", hlCtr, curCtr, nurbCurve2d.NumFitPoints.ToString()))
                                .AppendLine(String.Format("Fit_TangentsExist({0},{1})={2}", hlCtr, curCtr, nurbCurve2d.Fit_TangentsExist.ToString(1)))
                                ;
                            if (nurbCurve2d.Fit_TangentsExist)
                            {
                                strBuilder
                                    .AppendLine(String.Format("Fit_StartTangent({0},{1})={2}", hlCtr, curCtr, nurbCurve2d.Fit_StartTangent.ToString()))
                                    .AppendLine(String.Format("Fit_EndTangent({0},{1})={2}", hlCtr, curCtr, nurbCurve2d.Fit_EndTangent.ToString()));
                            }
                            for (int fp = 0; fp < nurbCurve2d.NumFitPoints; fp++)
                            {
                                strBuilder.AppendLine(String.Format("FitPoints({0},{1},{2})={3}", hlCtr, curCtr, fp, nurbCurve2d.FitPoints[fp].ToString()));
                            }
                        }
                        else
                        {
                            strBuilder
                                .AppendLine(String.Format("Degree({0},{1})={2}", hlCtr, curCtr, nurbCurve2d.Degree.ToString()))
                                .AppendLine(String.Format("Periodic({0},{1})={2}", hlCtr, curCtr, nurbCurve2d.Periodic.ToString(1)))
                                .AppendLine(String.Format("NumControlPoints({0},{1})={2}", hlCtr, curCtr, nurbCurve2d.NumControlPoints.ToString()))
                                .AppendLine(String.Format("NumKnots({0},{1})={2}", hlCtr, curCtr, nurbCurve2d.NumKnots.ToString()))
                                .AppendLine(String.Format("NumWeights({0},{1})={2}", hlCtr, curCtr, nurbCurve2d.NumWeights.ToString()))
                                ;

                            for (int cp = 0; cp < nurbCurve2d.NumControlPoints; cp++)
                            {
                                strBuilder.AppendLine(String.Format("ControlPoints({0},{1},{2})={3}", hlCtr, curCtr, cp, nurbCurve2d.ControlPoints[cp].ToString()));
                            }

                            for (int knt = 0; knt < nurbCurve2d.NumKnots; knt++)
                            {
                                strBuilder.AppendLine(String.Format("Knots({0},{1},{2})={3}", hlCtr, curCtr, knt, nurbCurve2d.Knots[knt].ToString()));
                            }

                            for (int wt = 0; wt < nurbCurve2d.NumWeights; wt++)
                            {
                                strBuilder.AppendLine(String.Format("Weights({0},{1},{2})={3}", hlCtr, curCtr, wt, nurbCurve2d.Weights[wt].ToString()));
                            }
                        }
                        break;

                } // switch

            } // 

            return strBuilder.ToString();

        }

    }
}
