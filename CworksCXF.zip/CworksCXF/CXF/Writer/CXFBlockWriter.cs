﻿using System;
using System.Text;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Writer
{
    public class CXFBlockWriter : CXFEntityWriter
    {
        public override string getEntityDetails(CwcDbObject item)
        {
            var entity = (item as CwcBlock);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(Resource.GetCXFEntityTitle(entity.TypeName))
                    .AppendLine(String.Format("Id={0}", entity.Id))
                    .AppendLine(String.Format("Name={0}", entity.Name.ToString()))
                    .AppendLine(String.Format("NumberAttributeDefs={0}", entity.NumberAttributeDefs.ToString()))
                    ;
            for (int i = 0; i < entity.NumberAttributeDefs; i++)
            {
                strBuilder.AppendLine(String.Format("Tag({0})={1}", i, entity.AttributeDefs[i].Tag));
                if (!entity.AttributeDefs[i].Constant)
                {
                    strBuilder.AppendLine(String.Format("Prompt({0})={1}", i, entity.AttributeDefs[i].Prompt))
                                .AppendLine(String.Format("Verifiable({0})={1}", i, entity.AttributeDefs[i].Verifiable.ToString(1)))
                                .AppendLine(String.Format("Preset({0})={1}", i, entity.AttributeDefs[i].Preset.ToString(1)))
                        ;
                }
                if (entity.AttributeDefs[i].IsMTextAttributeDefinition)
                {
                    strBuilder.AppendLine(String.Format("MTextWidth({0})={1}", i, entity.AttributeDefs[i].MTextWidth.ToString()));
                    strBuilder.AppendLine(String.Format("MTextContents({0})={1}", i, entity.AttributeDefs[i].MTextContents));
                }

                strBuilder.AppendLine(String.Format("TextString({0})={1}", i, entity.AttributeDefs[i].TextString))
                    .AppendLine(String.Format("Position({0})={1}", i, entity.AttributeDefs[i].Position.ToString()))
                    .AppendLine(String.Format("AlignmentPoint({0})={1}", i, entity.AttributeDefs[i].AlignmentPoint.ToString()))
                    .AppendLine(String.Format("Oblique({0})={1}", i, entity.AttributeDefs[i].Oblique.ToString()))
                    .AppendLine(String.Format("Rotation({0})={1}", i, entity.AttributeDefs[i].Rotation.ToString()))
                    .AppendLine(String.Format("WidthFactor({0})={1}", i, entity.AttributeDefs[i].WidthFactor.ToString()))
                    .AppendLine(String.Format("Height({0})={1}", i, entity.AttributeDefs[i].Height.ToString()))
                    .AppendLine(String.Format("Justify({0})={1}", i, entity.AttributeDefs[i].Justify.ToString("D")))
                    .AppendLine(String.Format("Constant({0})={1}", i, entity.AttributeDefs[i].Constant.ToString(1)))
                    .AppendLine(String.Format("Invisible({0})={1}", i, entity.AttributeDefs[i].Invisible.ToString(1)))
                    .AppendLine(String.Format("IsMTextAttributeDefinition({0})={1}", i, entity.AttributeDefs[i].IsMTextAttributeDefinition.ToString(1)))
                    .AppendLine(String.Format("LockPositionInBlock({0})={1}", i, entity.AttributeDefs[i].LockPositionInBlock.ToString(1)))
                    .AppendLine(String.Format("Annotative({0})={1}", i, entity.AttributeDefs[i].Annotative.ToString("D")))
                    .AppendLine(String.Format("IsMirroredInX({0})={1}", i, entity.AttributeDefs[i].IsMirroredInX.ToString(1)))
                    .AppendLine(String.Format("IsMirroredInY({0})={1}", i, entity.AttributeDefs[i].IsMirroredInY.ToString(1)))
                    .AppendLine(String.Format("FieldLength({0})={1}", i, entity.AttributeDefs[i].FieldLength.ToString()))
                    .AppendLine(String.Format("Color({0})={1}", i, entity.AttributeDefs[i].Color.ToString()))
                    .AppendLine(String.Format("ColorMethod({0})={1}", i, entity.AttributeDefs[i].Color.ColorMethod.ToString("D")))
                    .AppendLine(String.Format("ColorIndex({0})={1}", i, entity.AttributeDefs[i].Color.ColorIndex.ToString()))
                    .AppendLine(String.Format("TextStyleId({0})={1}", i, entity.AttributeDefs[i].TextStyleId))
                    .AppendLine(String.Format("LayerId({0})={1}", i, entity.AttributeDefs[i].LayerId))
                    ;
            }

            return strBuilder.ToString();
        }
    }
}
