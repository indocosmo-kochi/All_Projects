﻿using System.Collections.Generic;
using CWorksCXF.Entities;
using CWorksCXF.Common;
using System.Text.RegularExpressions;
using System;
using System.Linq;
using Teigha.DatabaseServices;

namespace CWorksCXF.CXF.Reader
{
    public class CXFHatchReader : CXFEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            string value;
            int numberOfLoops = 0;
            if (ReadPropertyValue(entityRecord, "NumberOfLoops", true, out value))
                numberOfLoops = ConvertCXFValue2Integer(value);

            CwcHatch entity = new CwcHatch(numberOfLoops);

            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            entity.IsHatch = ConvertCXFValue2Bool(entityRecord, "IsHatch", true, true);
         
            entity.IsGradient = ConvertCXFValue2Bool(entityRecord, "IsGradient", true, false);

            entity.IsSolidFill = ConvertCXFValue2Bool(entityRecord, "IsSolidFill", true, false);

            entity.Associative = ConvertCXFValue2Bool(entityRecord, "Associative", true, false);

            CwcPoint2D point2d;
            if (ParseCXFPoint2d(entityRecord, "Origin", true, out point2d))
                entity.Origin = point2d;

            if (entity.IsHatch)
            {
                if (ReadPropertyValue(entityRecord, "PatternName", true, out value))
                    entity.PatternName = value;
                if (ReadPropertyValue(entityRecord, "PatternType", false, out value))
                    entity.PatternType = ConvertCXFHatchPatternTypeToDwg(value);
                if (ReadPropertyValue(entityRecord, "PatternAngle", false, out value))
                    entity.PatternAngle = ConvertCXFValue2Double(value);
                if (ReadPropertyValue(entityRecord, "PatternSpace", false, out value))
                    entity.PatternSpace = ConvertCXFValue2Double(value);
                if (ReadPropertyValue(entityRecord, "HatchStyle", false, out value))
                    entity.HatchStyle = ConvertCXFHatchStyleToDwg(value);

                if (ReadPropertyValue(entityRecord, "PatternScale", false, out value))
                    entity.PatternScale = ConvertCXFValue2Double(value);

                entity.Color = ParseCXFColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

                entity.BackgroundColor = ParseCXFColor(entityRecord, "BackgroundColor", "BackgroundColorMethod", "BackgroundColorIndex");
            }
            else
            {
                if (ReadPropertyValue(entityRecord, "GradientName", true, out value))
                    entity.GradientName = value;
                if (ReadPropertyValue(entityRecord, "GradientType", true, out value))
                    entity.GradientType = ConvertCXFGradientPatternTypeToDwg(value);
                if (ReadPropertyValue(entityRecord, "GradientAngle", true, out value))
                    entity.GradientAngle = ConvertCXFValue2Double(value);
                if (ReadPropertyValue(entityRecord, "GradientShift", true, out value))
                    entity.GradientShift = ConvertCXFValue2float(value);

                CwcGradiantColor[] cwcGradiantColor = new CwcGradiantColor[2];
                if (ParseCXFGradientColor(entityRecord, "GradientColor(1)", true, out cwcGradiantColor[0]))
                    entity.GradientColor[0] = cwcGradiantColor[0];

                if (ParseCXFGradientColor(entityRecord, "GradientColor(2)", true, out cwcGradiantColor[1]))
                    entity.GradientColor[1] = cwcGradiantColor[1];

                entity.GradientOneColorMode = ConvertCXFValue2Bool(entityRecord, "GradientOneColorMode", false, true);

            }


            for (int i = 0; i < numberOfLoops; i++)
            {
                if (entity.Associative)
                {

                    int nofAssociativeIds = 0;

                    if (ReadPropertyValue(entityRecord, String.Format("NumberOfAssociativeIds({0})", i), true, out value))
                        nofAssociativeIds = ConvertCXFValue2Integer(value);

                    entity.Loops[i] = new CwcHatchLoop(nofAssociativeIds);

                    for (int j = 0; j < nofAssociativeIds; j++)
                    {
                        string id = string.Empty;
                        if (ReadPropertyValue(entityRecord, string.Format("AssociativeId({0},{1})", i, j), true, out id))
                            entity.Loops[i].AssociativeIds[j] = id;
                    }
                }
                else
                {

                    bool isPolyline = ConvertCXFValue2Bool(entityRecord, string.Format("IsPolyline({0})", i), true, true); 


                    if (isPolyline)
                    {
                        int noOfBulgeVertices = 0;

                        if (ReadPropertyValue(entityRecord, String.Format("NumberOfBulgeVertices({0})", i), true, out value))
                            noOfBulgeVertices = ConvertCXFValue2Integer(value);

                        entity.Loops[i] = new CwcHatchLoop(isPolyline, noOfBulgeVertices);

                        CwcPoint2D point2D;
                        for (int j = 0; j < entity.Loops[i].NumberOfBulgeVertices; j++)
                        {
                            double bulge = 0;
                            if (ReadPropertyValue(entityRecord, string.Format("Bulge({0},{1})", i, j), true, out value))
                                bulge = ConvertCXFValue2Double(value);

                            if (ParseCXFPoint2d(entityRecord, string.Format("Vertex({0},{1})", i, j), true, out point2D))
                                entity.Loops[i].BulgeVertices[j] = new CwcBulgeVertex(bulge, point2D);

                        }
                    }
                    else
                    {
                        ReadCurvesFromCXF(entityRecord, i, entity, isPolyline);
                    }
                }

                if (ReadPropertyValue(entityRecord, String.Format("LoopType({0})", i), true, out value))
                    entity.Loops[i].LoopType = ConvertCXFHatchLoopTypeToDwg(value);

            }

            if (ReadPropertyValue(entityRecord, "HatchObjectType", false, out value))
                entity.HatchObjectType = ConvertCXFHatchObjectTypeToDwg(value);

            if (ReadPropertyValue(entityRecord, "Annotative", false, out value))
                entity.Annotative = ConvertCXFAnnotativeStatesToDwg(value);

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            if (ReadPropertyValue(entityRecord, "Linetype", false, out value))
                entity.Linetype = value;

            if (ReadPropertyValue(entityRecord, "LinetypeScale", false, out value))
                entity.LinetypeScale = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                entity.LineWeight = ConvertCXFLineWeightToDwg(value);

            return entity;
        }

        private void ReadCurvesFromCXF(Dictionary<string, string> entityRecord, int hlCtr, CwcHatch entity, bool isPolyline=false)
        {
            string value = string.Empty;
            int noOfCurves = 0;

            if (ReadPropertyValue(entityRecord, String.Format("NumberOfCurves({0})", hlCtr), true, out value))
                noOfCurves = ConvertCXFValue2Integer(value);

            entity.Loops[hlCtr] = new CwcHatchLoop(isPolyline, noOfCurves);


            for (int curCtr = 0; curCtr < entity.Loops[hlCtr].NumberOfCurves; curCtr++)
            {

                Enums.CurveType curvetype = 0;

                if (ReadPropertyValue(entityRecord, String.Format("CurveType({0},{1})", hlCtr, curCtr), false, out value))
                    curvetype = ConvertCXFCurveTypeToDwg(value);

                CwcPoint2D point2d;

                switch (curvetype)
                {
                    case Common.Enums.CurveType.LineSegment2d:
                        CwcLineSegment2D linesegment = new CwcLineSegment2D(curvetype);

                        if (ParseCXFPoint2d(entityRecord, String.Format("StartPoint({0},{1})", hlCtr, curCtr), true, out point2d))
                            linesegment.StartPoint = point2d;

                        if (ParseCXFPoint2d(entityRecord, String.Format("EndPoint({0},{1})", hlCtr, curCtr), true, out point2d))
                            linesegment.EndPoint = point2d;

                        entity.Loops[hlCtr].Curve2DCollection[curCtr] = linesegment;
                        break;
                    case Common.Enums.CurveType.CircularArc2d:
                        CwcCircularArc2D circularArc = new CwcCircularArc2D(curvetype);

                        if (ParseCXFPoint2d(entityRecord, String.Format("Center({0},{1})", hlCtr, curCtr), true, out point2d))
                            circularArc.Center = point2d;

                        if (ReadPropertyValue(entityRecord, String.Format("Radius({0},{1})", hlCtr, curCtr), true, out value))
                            circularArc.Radius = ConvertCXFValue2Double(value);

                        if (ReadPropertyValue(entityRecord, String.Format("StartAngle({0},{1})", hlCtr, curCtr), false, out value))
                            circularArc.StartAngle = ConvertCXFValue2Double(value);

                        if (ReadPropertyValue(entityRecord, String.Format("EndAngle({0},{1})", hlCtr, curCtr), false, out value))
                            circularArc.EndAngle = ConvertCXFValue2Double(value);

                        circularArc.IsClockWise = ConvertCXFValue2Bool(entityRecord, String.Format("IsClockWise({0},{1})", hlCtr, curCtr), false, false);

                        CwcVector2D vector2d;
                        if (circularArc.IsClockWise) 
                        {
                            // Assumption : if IsClockWise then ReferenceVector is required for creating the circularArc2d 
                            if (ParseCXFVector2d(entityRecord, String.Format("ReferenceVector({0},{1})", hlCtr, curCtr), true, out vector2d))
                                circularArc.ReferenceVector = vector2d;
                        }
                        else
                        {
                            if (ParseCXFVector2d(entityRecord, String.Format("ReferenceVector({0},{1})", hlCtr, curCtr), false, out vector2d))
                                circularArc.ReferenceVector = vector2d;
                        }

                        entity.Loops[hlCtr].Curve2DCollection[curCtr] = circularArc;
                        break;
                    case Common.Enums.CurveType.EllipticalArc2d:
                        CwcEllipticalArc2D ellipticalArc = new CwcEllipticalArc2D(curvetype);

                        if (ParseCXFPoint2d(entityRecord, String.Format("Center({0},{1})", hlCtr, curCtr), true, out point2d))
                            ellipticalArc.Center = point2d;

                        if (ReadPropertyValue(entityRecord, String.Format("MajorRadius({0},{1})", hlCtr, curCtr), true, out value))
                            ellipticalArc.MajorRadius = ConvertCXFValue2Double(value);

                        if (ReadPropertyValue(entityRecord, String.Format("MinorRadius({0},{1})", hlCtr, curCtr), true, out value))
                            ellipticalArc.MinorRadius = ConvertCXFValue2Double(value);

                        if (ParseCXFVector2d(entityRecord, String.Format("MajorAxis({0},{1})", hlCtr, curCtr), true, out vector2d))
                            ellipticalArc.MajorAxis = vector2d;

                        if (ParseCXFVector2d(entityRecord, String.Format("MinorAxis({0},{1})", hlCtr, curCtr), true, out vector2d))
                            ellipticalArc.MinorAxis = vector2d;

                        if (ReadPropertyValue(entityRecord, String.Format("StartAngle({0},{1})", hlCtr, curCtr), false, out value))
                            ellipticalArc.StartAngle = ConvertCXFValue2Double(value);

                        if (ReadPropertyValue(entityRecord, String.Format("EndAngle({0},{1})", hlCtr, curCtr), false, out value))
                            ellipticalArc.EndAngle = ConvertCXFValue2Double(value);

                        entity.Loops[hlCtr].Curve2DCollection[curCtr] = ellipticalArc;

                        break;
                    case Common.Enums.CurveType.NurbCurve2d:

                        CwcNurbCurve2D nurbCurve2d = null;

                        bool hasFitData = ConvertCXFValue2Bool(entityRecord, String.Format("HasFitData({0},{1})", hlCtr, curCtr), false, false);
                        if (hasFitData)
                        {
                            int noOfFitPoints = 0;

                            if (ReadPropertyValue(entityRecord, String.Format("NumFitPoints({0},{1})", hlCtr, curCtr), true, out value))
                                noOfFitPoints = ConvertCXFValue2Integer(value);

                            nurbCurve2d = new CwcNurbCurve2D(noOfFitPoints, curvetype);

                            if (ReadPropertyValue(entityRecord, String.Format("Degree({0},{1})", hlCtr, curCtr), false, out value))
                                nurbCurve2d.Degree = ConvertCXFValue2Integer(value);

                            nurbCurve2d.FitKnotParameterization = ConvertCXFKnotParameterizationToDwg(String.Format("FitKnotParameterization({0},{1})", hlCtr, curCtr));

                            if (ReadPropertyValue(entityRecord, String.Format("FitTolerance_EqualPoint({0},{1})", hlCtr, curCtr), false, out value))
                                nurbCurve2d.FitTolerance_EqualPoint = ConvertCXFValue2Double(value);

                            if (ReadPropertyValue(entityRecord, String.Format("FitTolerance_EqualVector({0},{1})", hlCtr, curCtr), false, out value))
                                nurbCurve2d.FitTolerance_EqualVector = ConvertCXFValue2Double(value);

                            nurbCurve2d.Fit_TangentsExist = ConvertCXFValue2Bool(entityRecord, String.Format("Fit_TangentsExist({0},{1})", hlCtr, curCtr), false, false);
                            if (nurbCurve2d.Fit_TangentsExist)
                            {
                                if (ParseCXFVector2d(entityRecord, String.Format("Fit_StartTangent({0},{1})", hlCtr, curCtr), true, out vector2d))
                                    nurbCurve2d.Fit_StartTangent = vector2d;

                                if (ParseCXFVector2d(entityRecord, String.Format("Fit_EndTangent({0},{1})", hlCtr, curCtr), true, out vector2d))
                                    nurbCurve2d.Fit_EndTangent = vector2d;
                            }
                            for (int fp = 0; fp < nurbCurve2d.NumFitPoints; fp++)
                            {
                                if (ParseCXFPoint2d(entityRecord, String.Format("FitPoints({0},{1},{2})", hlCtr, curCtr, fp), true, out point2d))
                                    nurbCurve2d.FitPoints[fp] = point2d;
                            }
                        }
                        else
                        {

                            int noOfControlPoints = 0;

                            if (ReadPropertyValue(entityRecord, String.Format("NumControlPoints({0},{1})", hlCtr, curCtr), true, out value))
                                noOfControlPoints = ConvertCXFValue2Integer(value);

                            int noOfNumKnots = 0;

                            if (ReadPropertyValue(entityRecord, String.Format("NumKnots({0},{1})", hlCtr, curCtr), true, out value))
                                noOfNumKnots = ConvertCXFValue2Integer(value);

                            int noOfNumWeights = 0;

                            if (ReadPropertyValue(entityRecord, String.Format("NumWeights({0},{1})", hlCtr, curCtr), true, out value))
                                noOfNumWeights = ConvertCXFValue2Integer(value);

                            nurbCurve2d = new CwcNurbCurve2D(noOfControlPoints, noOfNumKnots, noOfNumWeights, curvetype);

                            if (ReadPropertyValue(entityRecord, String.Format("Degree({0},{1})", hlCtr, curCtr), true, out value))
                                nurbCurve2d.Degree = ConvertCXFValue2Integer(value);

                            nurbCurve2d.Periodic = ConvertCXFValue2Bool(entityRecord, String.Format("HasFitData({0},{1})", hlCtr, curCtr), false, false);

                            for (int cp = 0; cp < noOfControlPoints; cp++)
                            {
                                if (ParseCXFPoint2d(entityRecord, String.Format("ControlPoints({0},{1},{2})", hlCtr, curCtr, cp), true, out point2d))
                                    nurbCurve2d.ControlPoints[cp] = point2d;
                            }
                            for (int knt = 0; knt < noOfNumKnots; knt++)
                            {
                                if (ReadPropertyValue(entityRecord, String.Format("Knots({0},{1},{2})", hlCtr, curCtr, knt), false, out value))
                                    nurbCurve2d.Knots[knt] = ConvertCXFValue2Double(value);
                            }
                            for (int wt = 0; wt < noOfNumWeights; wt++)
                            {
                                if (ReadPropertyValue(entityRecord, String.Format("Weights({0},{1},{2})", hlCtr, curCtr, wt), false, out value))
                                    nurbCurve2d.Weights[wt] = ConvertCXFValue2Double(value);
                            }

                        }
                        entity.Loops[hlCtr].Curve2DCollection[curCtr] = nurbCurve2d;

                        break;

                    }

                  
                } // switch

            } // 


        public Teigha.Geometry.KnotParameterizationEnum ConvertCXFKnotParameterizationToDwg(string CXFKnotParameterization)
        {
            return Enums.ConvertStringToEnumValue<Teigha.Geometry.KnotParameterizationEnum>(CXFKnotParameterization);
        }

        public Enums.CurveType ConvertCXFCurveTypeToDwg(string CXFCurveType)
        {
            return Enums.ConvertStringToEnumValue<Enums.CurveType>(CXFCurveType);
        }

        public HatchPatternType ConvertCXFHatchPatternTypeToDwg(string CXFHatchPatternType)
        {
            return Enums.ConvertStringToEnumValue<HatchPatternType>(CXFHatchPatternType);
        }
        private HatchObjectType ConvertCXFHatchObjectTypeToDwg(string CXFHatchObjectType)
        {
            return Enums.ConvertStringToEnumValue<HatchObjectType>(CXFHatchObjectType);
        }
        private HatchStyle ConvertCXFHatchStyleToDwg(string CXFHatchStyle)
        {
            return Enums.ConvertStringToEnumValue<HatchStyle>(CXFHatchStyle);
        }
        private GradientPatternType ConvertCXFGradientPatternTypeToDwg(string CXFGradientPatternType)
        {
            return Enums.ConvertStringToEnumValue<GradientPatternType>(CXFGradientPatternType);
        }

        private HatchLoopTypes ConvertCXFHatchLoopTypeToDwg(string CXFHatchLoopType)
        {
            return Enums.ConvertStringToEnumValue<HatchLoopTypes>(CXFHatchLoopType);
        }


        private CwcGradiantColor ConvertCsvStringToGradiantColor(string csvString)
        {
            string[] strValues = Regex.Match(csvString, @"\(([^)]*)\)").Groups[1].Value.Split(',');

            CwcGradiantColor cwcGradiantColor = new CwcGradiantColor();
            byte bvalue;
            byte.TryParse(strValues[0], out bvalue);
            cwcGradiantColor.Red = bvalue;
            byte.TryParse(strValues[1], out bvalue);
            cwcGradiantColor.Green = bvalue;
            byte.TryParse(strValues[2], out bvalue);
            cwcGradiantColor.Blue = bvalue;
            float fvalue;
            float.TryParse(strValues[3], out fvalue);
            cwcGradiantColor.Value = fvalue;

            return cwcGradiantColor;
        }

        private bool ParseCXFGradientColor(Dictionary<string, string> entityRecord, string entityProperty, bool isRequired, out CwcGradiantColor cwcGradiantColor)
        {
            if (entityRecord.ContainsKey("GradientColor(1)") && entityRecord.ContainsKey("GradientColor(2)"))
            {
                cwcGradiantColor = ConvertCsvStringToGradiantColor(entityRecord[entityProperty]);
                return true;
            }
            else
            {
                if (isRequired)
                {
                    Logger.RecordMessage("ERROR: Missing property '" + entityProperty + "' for Entity [" + EntityTypeName + "], CXF->DWG processing Aborted!!!.", Logs.Log.MessageType.Error);
                    Environment.Exit(1);
                }
                cwcGradiantColor = new CwcGradiantColor(0,0,0,0);
                return false;
            }

        }


    }
}

