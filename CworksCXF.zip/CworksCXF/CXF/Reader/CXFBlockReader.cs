﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFBlockReader : CXFEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcBlock entity = new CwcBlock();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                entity.Id = value;

            if (ReadPropertyValue(entityRecord, "Name", true, out value))
                entity.Name = value;

            if (ReadPropertyValue(entityRecord, "NumberAttributeDefs", true, out value))
                entity.NumberAttributeDefs = ConvertCXFValue2Integer(value);

            for (int i = 0; i < entity.NumberAttributeDefs; i++)
            {
                CwcAttributeDefinition attdef = new CwcAttributeDefinition();

                CwcPoint3D point3d;
                if (ParseCXFPoint3d(entityRecord, string.Format("Position({0})", i), true, out point3d))
                    attdef.Position = point3d;

                if (ParseCXFPoint3d(entityRecord, string.Format("AlignmentPoint({0})", i), true, out point3d))
                    attdef.AlignmentPoint = point3d;

                if (ReadPropertyValue(entityRecord, string.Format("Tag({0})", i), true, out value))
                    attdef.Tag = value;
                
                if (ReadPropertyValue(entityRecord, string.Format("TextString({0})", i), false, out value))
                    attdef.TextString = value;

                if (ReadPropertyValue(entityRecord, string.Format("FieldLength({0})", i), true, out value))
                    attdef.FieldLength = ConvertCXFValue2Integer(value);

                if (ReadPropertyValue(entityRecord, string.Format("Height({0})", i), true, out value))
                    attdef.Height = ConvertCXFValue2Double(value);

                if (ReadPropertyValue(entityRecord, string.Format("Oblique({0})", i), true, out value))
                    attdef.Oblique = ConvertCXFValue2Double(value);

                if (ReadPropertyValue(entityRecord, string.Format("Rotation({0})", i), true, out value))
                    attdef.Rotation = ConvertCXFValue2Double(value);

                if (ReadPropertyValue(entityRecord, string.Format("WidthFactor({0})", i), true, out value))
                    attdef.WidthFactor = ConvertCXFValue2Double(value);

                if (ReadPropertyValue(entityRecord, string.Format("Annotative({0})", i), true, out value))
                    attdef.Annotative = ConvertCXFAnnotativeStatesToDwg(value);

                if (ReadPropertyValue(entityRecord, string.Format("Justify({0})", i), true, out value))
                    attdef.Justify = ConvertCXFTextJustifyToDwg(value);
                
                attdef.IsMirroredInX = ConvertCXFValue2Bool(entityRecord, string.Format("IsMirroredInX({0})", i), true, false);
                attdef.IsMirroredInY = ConvertCXFValue2Bool(entityRecord, string.Format("IsMirroredInY({0})", i), true, false);
                attdef.Constant = ConvertCXFValue2Bool(entityRecord, string.Format("Constant({0})", i), true, false);
                attdef.IsMTextAttributeDefinition = ConvertCXFValue2Bool(entityRecord, string.Format("IsMTextAttributeDefinition({0})", i), true, false);
                attdef.Invisible = ConvertCXFValue2Bool(entityRecord, string.Format("Invisible({0})", i), false, false);
                attdef.LockPositionInBlock = ConvertCXFValue2Bool(entityRecord, string.Format("LockPositionInBlock({0})", i), false, false);

                if (!attdef.Constant)
                {
                    if (ReadPropertyValue(entityRecord, string.Format("Prompt({0})", i), false, out value))
                        attdef.Prompt = value;
                    attdef.Verifiable = ConvertCXFValue2Bool(entityRecord, string.Format("Verifiable({0})", i), false, false);
                    attdef.Preset = ConvertCXFValue2Bool(entityRecord, string.Format("Preset({0})", i), false, false);
                }
                if (attdef.IsMTextAttributeDefinition)
                {
                    if (ReadPropertyValue(entityRecord, string.Format("MTextWidth({0})", i), true, out value))
                        attdef.MTextWidth = ConvertCXFValue2Double(value);

                    if (ReadPropertyValue(entityRecord, string.Format("MTextContents({0})", i), true, out value))
                        attdef.MTextContents = value;
                    
                }
                attdef.Color = ParseCXFColor(entityRecord, string.Format("Color({0})", i), string.Format("ColorMethod({0})", i), string.Format("ColorIndex({0})", i));

                if (ReadPropertyValue(entityRecord, string.Format("TextStyleId({0})", i), false, out value))
                    attdef.TextStyleId = value;

                if (ReadPropertyValue(entityRecord, string.Format("LayerId({0})", i), false, out value))
                    attdef.LayerId = value;

                entity.AttributeDefs.Add(attdef);
            }

            return entity;
        }

    }
}
