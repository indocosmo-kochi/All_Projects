﻿using CWorksCXF.Entities;
using System.Collections.Generic;

namespace CWorksCXF.CXF.Reader
{
    interface ICXFEntityReader
    {
        CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord);
    }
}
