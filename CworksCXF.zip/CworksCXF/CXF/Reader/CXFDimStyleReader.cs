﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFDimStyleReader : CXFEntityReader
    {
        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcDimStyle cwcDimStyle = new CwcDimStyle();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                cwcDimStyle.Id = value;

            if (ReadPropertyValue(entityRecord, "Name", true, out value))
                cwcDimStyle.Name = value;

            if (ReadPropertyValue(entityRecord, "Dimadec", false, out value))
                cwcDimStyle.Dimadec = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimaltd", false, out value))
                cwcDimStyle.Dimaltd = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimalttd", false, out value))
                cwcDimStyle.Dimalttd = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimalttz", false, out value))
                cwcDimStyle.Dimalttz = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimaltu", false, out value))
                cwcDimStyle.Dimaltu = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimaltz", false, out value))
                cwcDimStyle.Dimaltz = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimaltf", false, out value))
                cwcDimStyle.Dimaltf = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimaltrnd", false, out value))
                cwcDimStyle.Dimaltrnd = ConvertCXFValue2Double(value);

            cwcDimStyle.Dimalt = ConvertCXFValue2Bool(entityRecord, "Dimalt", false, false);

            if (ReadPropertyValue(entityRecord, "Dimapost", false, out value))
                cwcDimStyle.Dimapost = value;

            if (ReadPropertyValue(entityRecord, "Dimasz", false, out value))
                cwcDimStyle.Dimasz = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimarcsym", false, out value))
                cwcDimStyle.Dimarcsym = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimatfit", false, out value))
                cwcDimStyle.Dimatfit = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimaunit", false, out value))
                cwcDimStyle.Dimaunit = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimazin", false, out value))
                cwcDimStyle.Dimazin = ConvertCXFValue2Integer(value);

            cwcDimStyle.Dimsah = ConvertCXFValue2Bool(entityRecord, "Dimsah", false, false);

            if (ReadPropertyValue(entityRecord, "Dimblk1s", false, out value))
                cwcDimStyle.Dimblk1s = value;

            if (ReadPropertyValue(entityRecord, "Dimblk2s", false, out value))
                cwcDimStyle.Dimblk2s = value;

            if (ReadPropertyValue(entityRecord, "Dimblks", false, out value))
                cwcDimStyle.Dimblks = value;

            if (ReadPropertyValue(entityRecord, "Dimcen", false, out value))
                cwcDimStyle.Dimcen = ConvertCXFValue2Double(value);

            cwcDimStyle.Dimclrd = ParseCXFColor(entityRecord, "Dimclrd", "Dimclrd_ColorMethod", "Dimclrd_ColorIndex");

            cwcDimStyle.Dimclre = ParseCXFColor(entityRecord, "Dimclre", "Dimclre_ColorMethod", "Dimclre_ColorIndex");

            cwcDimStyle.Dimclrt = ParseCXFColor(entityRecord, "Dimclrt", "Dimclrt_ColorMethod", "Dimclrt_ColorIndex");

            if (ReadPropertyValue(entityRecord, "Dimdec", false, out value))
                cwcDimStyle.Dimdec = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimfrac", false, out value))
                cwcDimStyle.Dimfrac = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimdle", false, out value))
                cwcDimStyle.Dimdle = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimdli", false, out value))
                cwcDimStyle.Dimdli = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimexe", false, out value))
                cwcDimStyle.Dimexe = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimexo", false, out value))
                cwcDimStyle.Dimexo = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimfxlen", false, out value))
                cwcDimStyle.Dimfxlen = ConvertCXFValue2Double(value);

            cwcDimStyle.DimfxlenOn = ConvertCXFValue2Bool(entityRecord, "DimfxlenOn", false, false);

            if (ReadPropertyValue(entityRecord, "Dimgap", false, out value))
                cwcDimStyle.Dimgap = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimjogang", false, out value))
                cwcDimStyle.Dimjogang = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimjust", false, out value))
                cwcDimStyle.Dimjust = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimdsep", false, out value))
            {
                if (value.Trim().Length > 0)
                {
                    cwcDimStyle.Dimdsep = value.Trim()[0];
                }
            }

            if (ReadPropertyValue(entityRecord, "Dimldrblks", false, out value))
                cwcDimStyle.Dimldrblks = value;

            if (ReadPropertyValue(entityRecord, "Dimlfac", false, out value))
                cwcDimStyle.Dimlfac = ConvertCXFValue2Double(value);

            cwcDimStyle.Dimlim = ConvertCXFValue2Bool(entityRecord, "Dimlim", false, false);

            //if (ReadPropertyValue(entityRecord, "Dimlinetypeex1", false, out value))
            //    cwcDimStyle.Dimlinetypeex1 = value;

            //if (ReadPropertyValue(entityRecord, "Dimlinetypeex2", false, out value))
            //    cwcDimStyle.Dimlinetypeex2 = value;

            //if (ReadPropertyValue(entityRecord, "Dimlinetype", false, out value))
            //    cwcDimStyle.Dimlinetype = value;

            if (ReadPropertyValue(entityRecord, "Dimltex1", false, out value))
                cwcDimStyle.Dimltex1 = value;

            if (ReadPropertyValue(entityRecord, "Dimltex2", false, out value))
                cwcDimStyle.Dimltex2 = value;

            if (ReadPropertyValue(entityRecord, "Dimltype", false, out value))
                cwcDimStyle.Dimltype = value;

            if (ReadPropertyValue(entityRecord, "Dimpost", false, out value))
                cwcDimStyle.Dimpost = value;

            if (ReadPropertyValue(entityRecord, "Dimrnd", false, out value))
                cwcDimStyle.Dimrnd = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimscale", false, out value))
                cwcDimStyle.Dimscale = ConvertCXFValue2Double(value);

            cwcDimStyle.Dimsd1 = ConvertCXFValue2Bool(entityRecord, "Dimsd1", false, false);

            cwcDimStyle.Dimsd2 = ConvertCXFValue2Bool(entityRecord, "Dimsd2", false, false);

            cwcDimStyle.Dimse1 = ConvertCXFValue2Bool(entityRecord, "Dimse1", false, false);

            cwcDimStyle.Dimse2 = ConvertCXFValue2Bool(entityRecord, "Dimse2", false, false);

            cwcDimStyle.Dimsoxd = ConvertCXFValue2Bool(entityRecord, "Dimsoxd", false, false);

            if (ReadPropertyValue(entityRecord, "Dimtad", false, out value))
                cwcDimStyle.Dimtad = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimtdec", false, out value))
                cwcDimStyle.Dimtdec = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimtfill", false, out value))
                cwcDimStyle.Dimtfill = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimtfac", false, out value))
                cwcDimStyle.Dimtfac = ConvertCXFValue2Double(value);

            cwcDimStyle.Dimtfillclr = ParseCXFColor(entityRecord, "Dimtfillclr", "Dimtfillclr_ColorMethod", "Dimtfillclr_ColorIndex");

            cwcDimStyle.Dimtih = ConvertCXFValue2Bool(entityRecord, "Dimtih", false, false);

            cwcDimStyle.Dimtix = ConvertCXFValue2Bool(entityRecord, "Dimtix", false, false);

            if (ReadPropertyValue(entityRecord, "Dimtm", false, out value))
                cwcDimStyle.Dimtm = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtmove", false, out value))
                cwcDimStyle.Dimtmove = ConvertCXFValue2Integer(value);

            cwcDimStyle.Dimtofl = ConvertCXFValue2Bool(entityRecord, "Dimtofl", false, false);

            cwcDimStyle.Dimtoh = ConvertCXFValue2Bool(entityRecord, "Dimtoh", false, false);

            cwcDimStyle.Dimtol = ConvertCXFValue2Bool(entityRecord, "Dimtol", false, false);

            if (ReadPropertyValue(entityRecord, "Dimtolj", false, out value))
                cwcDimStyle.Dimtolj = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimtp", false, out value))
                cwcDimStyle.Dimtp = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtsz", false, out value))
                cwcDimStyle.Dimtsz = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtvp", false, out value))
                cwcDimStyle.Dimtvp = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtxsty", false, out value))
                cwcDimStyle.Dimtxsty = value;

            if (ReadPropertyValue(entityRecord, "Dimtxt", false, out value))
                cwcDimStyle.Dimtxt = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Dimtzin", false, out value))
                cwcDimStyle.Dimtzin = ConvertCXFValue2Integer(value);

            cwcDimStyle.Dimupt = ConvertCXFValue2Bool(entityRecord, "Dimupt", false, false);

            if (ReadPropertyValue(entityRecord, "Dimzin", false, out value))
                cwcDimStyle.Dimzin = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Dimlwd", false, out value))
                cwcDimStyle.Dimlwd = ConvertCXFLineWeightToDwg(value);

            if (ReadPropertyValue(entityRecord, "Dimlwe", false, out value))
                cwcDimStyle.Dimlwe = ConvertCXFLineWeightToDwg(value);

            return cwcDimStyle;

        }
    }
}
