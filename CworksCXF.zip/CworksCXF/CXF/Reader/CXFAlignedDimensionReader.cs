﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFAlignedDimensionReader : CXFEntityReader
    {

        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcAlignedDimension entity = new CwcAlignedDimension();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", false, out value))
                entity.Id = value;

            CwcPoint3D point3d;
            if (ParseCXFPoint3d(entityRecord, "XLine1Point", true, out point3d))
                entity.XLine1Point = point3d;

            if (ParseCXFPoint3d(entityRecord, "XLine2Point", true, out point3d))
                entity.XLine2Point = point3d;

            if (ParseCXFPoint3d(entityRecord, "DimLinePoint", true, out point3d))
                entity.DimLinePoint = point3d;

            if (ReadPropertyValue(entityRecord, "DimStyleId", true, out value))
                entity.DimStyleId = value;

            //if (ReadPropertyValue(entityRecord, "DimensionStyleName", false, out value))
            //    entity.DimensionStyleName = value;

            entity.Color = ParseCXFColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            if (ReadPropertyValue(entityRecord, "TextStyleId", true, out value))
                entity.TextStyleId = value;

            if (ParseCXFPoint3d(entityRecord, "TextPosition", true, out point3d))
                entity.TextPosition = point3d;

            if (ReadPropertyValue(entityRecord, "TextRotation", false, out value))
                entity.TextRotation = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            if (ReadPropertyValue(entityRecord, "Linetype", false, out value))
                entity.Linetype = value;

            if (ReadPropertyValue(entityRecord, "LinetypeScale", false, out value))
                entity.LinetypeScale = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                entity.LineWeight = ConvertCXFLineWeightToDwg(value);

            return entity;
        }

    }
}
