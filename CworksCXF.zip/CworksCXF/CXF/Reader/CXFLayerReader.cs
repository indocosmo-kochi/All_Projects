﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFLayerReader : CXFEntityReader
    {
        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcLayer cwcLayer = new CwcLayer();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                cwcLayer.Id = value;

            if (ReadPropertyValue(entityRecord, "Name", true, out value))
                cwcLayer.Name = value;

            cwcLayer.Color = ParseCXFColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            cwcLayer.IsOff = ConvertCXFValue2Bool(entityRecord, "IsOff", false, false);
            cwcLayer.IsHidden = ConvertCXFValue2Bool(entityRecord, "IsHidden", false, false);
            cwcLayer.IsPlottable = ConvertCXFValue2Bool(entityRecord, "IsPlottable", false, true);
            cwcLayer.IsLocked = ConvertCXFValue2Bool(entityRecord, "IsLocked", false, false);

            if (ReadPropertyValue(entityRecord, "LineType", false, out value))
                cwcLayer.LineType = value;
            //if (ReadPropertyValue(entityRecord, "LineType", false, out value))
            //    cwcLayer.LineType = ConvertCxfLineTypeToDwg(value); 
            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                cwcLayer.LineWeight = ConvertCXFLineWeightToDwg(value);

            return cwcLayer;

        }
    }
}
