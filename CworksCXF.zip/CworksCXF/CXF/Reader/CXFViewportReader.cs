﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFViewportReader : CXFEntityReader
    {
        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcViewport cwcViewport = new CwcViewport();

            string value;
            if (ReadPropertyValue(entityRecord, "Id", true, out value))
                cwcViewport.Id = value;

            if (ReadPropertyValue(entityRecord, "Name", true, out value))
                cwcViewport.Name = value;

            if (ReadPropertyValue(entityRecord, "CircleSides", false, out value))
                cwcViewport.CircleSides = ConvertCXFValue2Short(value);

            cwcViewport.GridEnabled = ConvertCXFValue2Bool(entityRecord, "GridEnabled", false, true);

            CwcPoint2D point2d;
            if (ParseCXFPoint2d(entityRecord, "CenterPoint", true, out point2d))
                cwcViewport.CenterPoint = point2d;

            if (ReadPropertyValue(entityRecord, "Height", false, out value))
                cwcViewport.Height = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Width", false, out value))
                cwcViewport.Width = ConvertCXFValue2Double(value);

            return cwcViewport;

        }
    }
}
