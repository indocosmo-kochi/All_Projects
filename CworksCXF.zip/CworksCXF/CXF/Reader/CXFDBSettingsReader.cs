﻿using System;
using System.Collections.Generic;
using CWorksCXF.Entities;
using CWorksCXF.Common;

namespace CWorksCXF.CXF.Reader
{
    public class CXFDBSettingsReader : CXFEntityReader
    {
        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            throw new NotImplementedException();
        }

        public CwcDBSettings ReadAndParseDBSettings(Dictionary<string, string> entityRecord)
        {
            CwcDBSettings dbSettings = new CwcDBSettings();
            string value;

            if (ReadPropertyValue(entityRecord, "Pdmode", false, out value))
                dbSettings.Pdmode = ConvertCXFValue2Integer(value);

            if (ReadPropertyValue(entityRecord, "Pdsize", false, out value))
                dbSettings.Pdsize = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Ltscale", false, out value))
                dbSettings.Ltscale = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "Measurement", false, out value))
                dbSettings.Measurement = ConvertCXFMeasurementToDwg(value);


            return dbSettings;
        }


        private Enums.MeasurementValue ConvertCXFMeasurementToDwg(string CXFMeasurement)
        {
            int intValue = ConvertCXFValue2Integer(CXFMeasurement);

            return Enums.ConvertEnumValueToString<Enums.MeasurementValue>(intValue);
        }

    }
}
