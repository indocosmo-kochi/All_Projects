﻿using System.Collections.Generic;
using CWorksCXF.Entities;

namespace CWorksCXF.CXF.Reader
{
    public class CXFBlockReferenceReader : CXFEntityReader
    {


        public override CwcDbObject ReadAndParse(Dictionary<string, string> entityRecord)
        {
            CwcBlockReference entity = new CwcBlockReference();

            string value;
            // reading BlockDefId into Id, for getting the correct id from the idmapping
            if (ReadPropertyValue(entityRecord, "BlockDefId", true, out value))
                entity.Id = value;            

            if (ReadPropertyValue(entityRecord, "Name", true, out value))
                entity.Name = value;

            CwcPoint3D point3d;
            if (ParseCXFPoint3d(entityRecord, "Position", true, out point3d))
                entity.Position = point3d;

            if (ParseCXFPoint3d(entityRecord, "ScaleFactors", true, out point3d))
                entity.ScaleFactors = point3d;

            if (ReadPropertyValue(entityRecord, "Rotation", false, out value))
                entity.Rotation = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "BlockUnit", false, out value))
                entity.BlockUnit = ConvertCXFBlockUnitToDwg(value);

            if (ReadPropertyValue(entityRecord, "NumberAttributeRefs", false, out value))
                entity.NumberAttributeRefs = ConvertCXFValue2Integer(value);
            
            for (int i = 0; i < entity.NumberAttributeRefs; i++)
            {
                CwcAttributeReference attReference = new CwcAttributeReference();
                if (ReadPropertyValue(entityRecord, string.Format("Tag({0})", i), true, out value))
                    attReference.Tag = value;
                if (ReadPropertyValue(entityRecord, string.Format("TextString({0})", i), false, out value))
                    attReference.TextString = value;
                entity.AttributeRefs.Add(attReference);
            }


            entity.IsDynamicBlock = ConvertCXFValue2Bool(entityRecord, "IsDynamicBlock", false, false);

            entity.Color = ParseCXFColor(entityRecord, "Color", "ColorMethod", "ColorIndex");

            if (ReadPropertyValue(entityRecord, "LayerId", false, out value))
                entity.LayerId = value;

            if (ReadPropertyValue(entityRecord, "BlockId", false, out value))
                entity.BlockId = value;

            if (ReadPropertyValue(entityRecord, "BlockName", false, out value))
                entity.BlockName = value;

            if (ReadPropertyValue(entityRecord, "Linetype", false, out value))
                entity.Linetype = value;

            if (ReadPropertyValue(entityRecord, "LinetypeScale", false, out value))
                entity.LinetypeScale = ConvertCXFValue2Double(value);

            if (ReadPropertyValue(entityRecord, "LineWeight", false, out value))
                entity.LineWeight = ConvertCXFLineWeightToDwg(value);

            return entity;
        }

    }
}
