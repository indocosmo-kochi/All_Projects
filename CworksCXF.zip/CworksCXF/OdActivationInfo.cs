///////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2002-2017, Open Design Alliance (the "Alliance").
// All rights reserved.
//
// This software and its documentation and related materials are owned by
// the Alliance. The software may only be incorporated into application
// programs owned by members of the Alliance, subject to a signed
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable
// trade secrets of the Alliance and its suppliers. The software is also
// protected by copyright law and international treaty provisions. Application
// programs incorporating this software must include the following statement
// with their copyright notices:
//
//   This application incorporates Teigha(R) software pursuant to a license
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2017 by Open Design Alliance.
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////
using System;
#pragma warning disable 618

public sealed class ActivationData
{
public const string userInfo = "Q1dPUktTIENvIEx0ZA==";
public const string userSignature = "UOjZbtbnBHeiUvXVwT18vtldBaXKNVkGdKLbalq+/ccyw8DtvjkiE1zfxOtaLEJw0ZI/2Z08cqFKhsAPx/3D1//oeDMXu/ZH9xOyVuMUz7K4jDI37PHRDMpHErYbOqKl+h2zlhJjfZEcQVaybI4W13YueUQldaaf6HZIaT3TZNFYoS0X9cdMWOji5O2uehXtZupvVyOV26cC19kvjt2XqqtV5AEyTHGPqtvDfgoKa3EWTRTxoyd22ZMO/36HGvSo+ZCcuAQlXWA2Lna57ugUUdkvd0Ejxrkkkq6qNpJ31DSAnjRPmosrYJqbpI5QtxHDhP+7RMgwzsdIpioRCSpYVV4l6VF4sfwGdqdoPyb+b4ZbNVeZcQTYvRCDM2T2H8mW3ijpv9pZJ+VKw5zUU6ILd9X+82oFhqTX9J+6HgKo+G46PbUlQwpatDMITayj5n2OKflcY8lXFo7jz3FIJaKlpkn+Ijj5GSxpQCVwordC86YYgYNAHO2ekjJPMwU8d2oxsX7Gbwwj9SqQ8lEreeZZOUy3qfZEece6DMEwOM3bThKEex5uy35T3eBkpLvc5CoAMpVVnB//SuDm2Oe2nQdtGpj/gOASiYB2nQQ+mGVX9XTsKO+DoXcAmU+8WXIexDePf/vgf/vD6lBSpgUDzOn8GL2+0RhiM71LuP9aDc9oOVk=";
};
