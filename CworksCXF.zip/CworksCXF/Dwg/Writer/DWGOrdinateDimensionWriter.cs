﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgOrdinateDimensionWriter : DwgEntityWriter
    {

        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId entityId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable blockTbl = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable)
                {

                    // save the current line type for database into a temp variable
                    ObjectId current_linetypeId = db.Celtype;

                    CwcOrdinateDimension entityObject = cwcDbObject as CwcOrdinateDimension;

                    using (OrdinateDimension ordinateDimension = new OrdinateDimension())
                    {

                        ordinateDimension.UsingXAxis = entityObject.UsingXAxis;
                        ordinateDimension.DefiningPoint = new Point3d(entityObject.DefiningPoint.X, entityObject.DefiningPoint.Y, entityObject.DefiningPoint.Z);
                        ordinateDimension.LeaderEndPoint = new Point3d(entityObject.LeaderEndPoint.X, entityObject.LeaderEndPoint.Y, entityObject.LeaderEndPoint.Z);

                        ordinateDimension.DimensionStyle = GetDwgObjectId(entityObject.DimStyleId.ToString());

                        ordinateDimension.SetDatabaseDefaults();

                        if (entityObject.LayerId.Length > 0)
                            ordinateDimension.LayerId = GetDwgObjectId(entityObject.LayerId);

                        ordinateDimension.Color = GetDwgColor(entityObject.Color);

                        if (entityObject.TextStyleId.Length > 0)
                        {
                            ordinateDimension.TextStyleId = GetDwgObjectId(entityObject.TextStyleId);

                        }

                        ordinateDimension.TextPosition = new Point3d(entityObject.TextPosition.X, entityObject.TextPosition.Y, entityObject.TextPosition.Z);
                        ordinateDimension.TextRotation = entityObject.TextRotation;


                        ordinateDimension.LinetypeId = GetLineTypeIdFromName(db, entityObject.Linetype);
                        ordinateDimension.LinetypeScale = entityObject.LinetypeScale;


                        ordinateDimension.LineWeight = entityObject.LineWeight;

                        ObjectId btrId;

                        // Open the Block table record for write
                        if (entityObject.BlockId == null)
                            btrId = blockTbl[BlockTableRecord.ModelSpace];
                        else
                            btrId = GetDwgObjectId(entityObject.BlockId);

                        using (BlockTableRecord btr = tr.GetObject(btrId, OpenMode.ForWrite) as BlockTableRecord)
                        {
                            // Add the new object to the block table record and the transaction
                            entityId = btr.AppendEntity(ordinateDimension);
                            tm.AddNewlyCreatedDBObject(ordinateDimension, true);
                        }

                    }

                    // restore the current line type for database from the temp variable
                    db.Celtype = current_linetypeId;
                }

                tr.Commit();
            }


            return entityId;
        }
    }
}

