﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgLineWriter : DwgEntityWriter
    {

        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId entityId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable blockTbl = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable)
                {

                    // save the current line type for database into a temp variable
                    ObjectId current_linetypeId = db.Celtype;

                    CwcLine entityObject = cwcDbObject as CwcLine;
                    using (Line line = new Line(new Point3d(entityObject.StartPoint.X, entityObject.StartPoint.Y, entityObject.StartPoint.Z),
                                                       new Point3d(entityObject.EndPoint.X, entityObject.EndPoint.Y, entityObject.EndPoint.Z)))
                    {
                        line.SetDatabaseDefaults();

                        if (entityObject.LayerId.Length > 0)
                            line.LayerId = GetDwgObjectId(entityObject.LayerId);

                        line.Color = GetDwgColor(entityObject.Color);

                        line.LinetypeId = GetLineTypeIdFromName(db, entityObject.Linetype);

                        line.LinetypeScale = entityObject.LinetypeScale;

                        line.LineWeight = entityObject.LineWeight;

                        ObjectId btrId;

                        // Open the Block table record for write
                        if (entityObject.BlockId == null)
                            btrId = blockTbl[BlockTableRecord.ModelSpace];
                        else
                            btrId = GetDwgObjectId(entityObject.BlockId);

                        using (BlockTableRecord btr = tr.GetObject(btrId, OpenMode.ForWrite) as BlockTableRecord)
                        {
                            // Add the new object to the block table record and the transaction
                            entityId = btr.AppendEntity(line);
                            tm.AddNewlyCreatedDBObject(line, true);
                        }

                    }

                    // restore the current line type for database from the temp variable
                    db.Celtype = current_linetypeId;

                }

                tr.Commit();
            }


            return entityId;
        }
    }
}
