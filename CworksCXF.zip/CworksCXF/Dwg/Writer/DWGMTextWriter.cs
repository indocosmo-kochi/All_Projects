﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgMTextWriter : DwgEntityWriter
    {

        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId entityId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable blockTbl = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable)
                {

                    CwcMText entityObject = cwcDbObject as CwcMText;

                    using (MText mtext = new MText())
                    {

                        mtext.Contents = entityObject.TextString;

                        mtext.Location = new Point3d(entityObject.Location.X, entityObject.Location.Y, entityObject.Location.Z);

                        mtext.SetDatabaseDefaults();

                        mtext.Height = entityObject.Height;

                        mtext.Width = entityObject.Width;

                        mtext.TextHeight = entityObject.TextHeight;

                        mtext.Attachment = entityObject.Attachment;
                        mtext.BackgroundFill = entityObject.BackgroundFill;
                        mtext.UseBackgroundColor = entityObject.UseBackgroundColor;
                        if (mtext.BackgroundFill)
                            mtext.BackgroundFillColor = GetDwgColor(entityObject.BackgroundFillColor);

                        mtext.BackgroundScaleFactor = entityObject.BackgroundScaleFactor;

                        if (entityObject.ColumnType == ColumnType.StaticColumns)
                        {
                            mtext.SetStaticColumns(entityObject.ColumnWidth, entityObject.ColumnGutterWidth, entityObject.ColumnCount);
                            mtext.ColumnFlowReversed = entityObject.ColumnFlowReversed;
                        }
                        else if (entityObject.ColumnType == ColumnType.DynamicColumns)
                        {
                            mtext.SetDynamicColumns(entityObject.ColumnWidth, entityObject.ColumnGutterWidth, entityObject.ColumnAutoHeight);
                            mtext.ColumnFlowReversed = entityObject.ColumnFlowReversed;

                            if (!entityObject.ColumnAutoHeight)
                            {
                                for (int col = 0; col > entityObject.ColumnCount; col++)
                                    mtext.SetColumnHeight(col, entityObject.ColumnHeight[col]);
                            }
                        }

                        mtext.Direction = new Vector3d(entityObject.Direction.X, entityObject.Direction.Y, entityObject.Direction.Z);
                        mtext.FlowDirection = entityObject.FlowDirection;
                        mtext.LineSpaceDistance = entityObject.LineSpaceDistance;
                        mtext.LineSpacingFactor = entityObject.LineSpacingFactor;
                        mtext.LineSpacingStyle = entityObject.LineSpacingStyle;
                        mtext.Normal = new Vector3d(entityObject.Normal.X, entityObject.Normal.Y, entityObject.Normal.Z);
                        mtext.Rotation = entityObject.Rotation;

                        if (entityObject.TextStyleId.Length > 0)
                            mtext.TextStyleId = GetDwgObjectId(entityObject.TextStyleId);

                        if (entityObject.LayerId.Length > 0)
                            mtext.LayerId = GetDwgObjectId(entityObject.LayerId);

                        mtext.Color = GetDwgColor(entityObject.Color);


                        ObjectId btrId;

                        // Open the Block table record for write
                        if (entityObject.BlockId == null)
                            btrId = blockTbl[BlockTableRecord.ModelSpace];
                        else
                            btrId = GetDwgObjectId(entityObject.BlockId);

                        using (BlockTableRecord btr = tr.GetObject(btrId, OpenMode.ForWrite) as BlockTableRecord)
                        {
                            // Add the new object to the block table record and the transaction
                            entityId = btr.AppendEntity(mtext);
                            tm.AddNewlyCreatedDBObject(mtext, true);
                        }

                    }

                }

                tr.Commit();
            }


            return entityId;
        }
    }
}
