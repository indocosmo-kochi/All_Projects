﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgRotatedDimensionWriter : DwgEntityWriter
    {

        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId entityId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable blockTbl = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable)
                {

                    // save the current line type for database into a temp variable
                    ObjectId current_linetypeId = db.Celtype;

                    CwcRotatedDimension entityObject = cwcDbObject as CwcRotatedDimension;

                    using (RotatedDimension rotatedDimension = new RotatedDimension())
                    {

                        rotatedDimension.XLine1Point = new Point3d(entityObject.XLine1Point.X, entityObject.XLine1Point.Y, entityObject.XLine1Point.Z);
                        rotatedDimension.XLine2Point = new Point3d(entityObject.XLine2Point.X, entityObject.XLine2Point.Y, entityObject.XLine2Point.Z);
                        rotatedDimension.DimLinePoint = new Point3d(entityObject.DimLinePoint.X, entityObject.DimLinePoint.Y, entityObject.DimLinePoint.Z);

                        rotatedDimension.Rotation = entityObject.Rotation;

                        rotatedDimension.DimensionStyle = GetDwgObjectId(entityObject.DimStyleId.ToString());

                        rotatedDimension.SetDatabaseDefaults();

                        ObjectId btrId;

                        // Open the Block table record for write
                        if (entityObject.BlockId == null)
                            btrId = blockTbl[BlockTableRecord.ModelSpace];
                        else
                            btrId = GetDwgObjectId(entityObject.BlockId);

                        using (BlockTableRecord btr = tr.GetObject(btrId, OpenMode.ForWrite) as BlockTableRecord)
                        {
                            // Add the new object to the block table record and the transaction
                            entityId = btr.AppendEntity(rotatedDimension);
                            tm.AddNewlyCreatedDBObject(rotatedDimension, true);
                        }

                        SetDimensionPropertyValues(rotatedDimension, entityObject);

                        if (entityObject.LayerId.Length > 0)
                            rotatedDimension.LayerId = GetDwgObjectId(entityObject.LayerId);

                        rotatedDimension.Color = GetDwgColor(entityObject.Color);

                        if (entityObject.TextStyleId.Length > 0)
                        {
                            ObjectId oid = GetDwgObjectId(entityObject.TextStyleId);
                            rotatedDimension.TextStyleId = oid;
                        }
                        rotatedDimension.TextPosition = new Point3d(entityObject.TextPosition.X, entityObject.TextPosition.Y, entityObject.TextPosition.Z);
                        rotatedDimension.TextRotation = entityObject.TextRotation;

                        rotatedDimension.DimBlockId = GetDwgObjectId(entityObject.DimBlockId);

                        rotatedDimension.DimensionText = entityObject.DimensionText;
                        rotatedDimension.DynamicDimension = entityObject.DynamicDimension;
                        rotatedDimension.Elevation = entityObject.Elevation;
                        rotatedDimension.HorizontalRotation = entityObject.HorizontalRotation;
                        rotatedDimension.AlternatePrefix = entityObject.AlternatePrefix;
                        rotatedDimension.AlternateSuffix = entityObject.AlternateSuffix;

                        rotatedDimension.Prefix = entityObject.Prefix;
                        rotatedDimension.Suffix = entityObject.Suffix;

                        rotatedDimension.TextAttachment = entityObject.TextAttachment;
                        rotatedDimension.TextLineSpacingFactor = entityObject.TextLineSpacingFactor;
                        rotatedDimension.TextLineSpacingStyle = entityObject.TextLineSpacingStyle;

                        rotatedDimension.AltSuppressLeadingZeros = entityObject.AltSuppressLeadingZeros;
                        rotatedDimension.AltSuppressTrailingZeros = entityObject.AltSuppressTrailingZeros;
                        rotatedDimension.AltSuppressZeroFeet = entityObject.AltSuppressZeroFeet;
                        rotatedDimension.AltSuppressZeroInches = entityObject.AltSuppressZeroInches;

                        rotatedDimension.AltToleranceSuppressLeadingZeros = entityObject.AltToleranceSuppressLeadingZeros;
                        rotatedDimension.AltToleranceSuppressTrailingZeros = entityObject.AltToleranceSuppressTrailingZeros;
                        rotatedDimension.AltToleranceSuppressZeroFeet = entityObject.AltToleranceSuppressZeroFeet;
                        rotatedDimension.AltToleranceSuppressZeroInches = entityObject.AltToleranceSuppressZeroInches;

                        rotatedDimension.SuppressAngularLeadingZeros = entityObject.SuppressAngularLeadingZeros;
                        rotatedDimension.SuppressAngularTrailingZeros = entityObject.SuppressAngularTrailingZeros;
                        rotatedDimension.SuppressLeadingZeros = entityObject.SuppressLeadingZeros;
                        rotatedDimension.SuppressTrailingZeros = entityObject.SuppressTrailingZeros;
                        rotatedDimension.SuppressZeroFeet = entityObject.SuppressZeroFeet;
                        rotatedDimension.SuppressZeroInches = entityObject.SuppressZeroInches;

                        rotatedDimension.ToleranceSuppressLeadingZeros = entityObject.ToleranceSuppressLeadingZeros;
                        rotatedDimension.ToleranceSuppressTrailingZeros = entityObject.ToleranceSuppressTrailingZeros;
                        rotatedDimension.ToleranceSuppressZeroFeet = entityObject.ToleranceSuppressZeroFeet;
                        rotatedDimension.ToleranceSuppressZeroInches = entityObject.ToleranceSuppressZeroInches;
                        rotatedDimension.UsingDefaultTextPosition = entityObject.UsingDefaultTextPosition;

                        rotatedDimension.LinetypeId = GetLineTypeIdFromName(db, entityObject.Linetype);
                        rotatedDimension.LinetypeScale = entityObject.LinetypeScale;

                        rotatedDimension.LineWeight = entityObject.LineWeight;

 

                    }

                    // restore the current line type for database from the temp variable
                    db.Celtype = current_linetypeId;

                }

                tr.Commit();
            }


            return entityId;
        }
    }
}
