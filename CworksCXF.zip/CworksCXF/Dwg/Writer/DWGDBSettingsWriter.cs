﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Writer
{
    public class DwgDBSettingsWriter 
    {

        public void SetDBSettings(Database db, CwcDBSettings dbSettings)
        {
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                db.Pdmode = dbSettings.Pdmode;
                db.Pdsize = dbSettings.Pdsize;
                db.Ltscale = dbSettings.Ltscale;
                db.Measurement = (MeasurementValue)dbSettings.Measurement;

                tr.Commit();
            }

        }
    }
}
