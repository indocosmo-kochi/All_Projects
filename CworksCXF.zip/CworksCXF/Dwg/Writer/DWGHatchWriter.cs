﻿using CWorksCXF.Common;
using CWorksCXF.Entities;
using Teigha.Colors;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgHatchWriter : DwgEntityWriter
    {

        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId entityId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable blockTbl = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable)
                {

                    // save the current line type for database into a temp variable
                    ObjectId current_linetypeId = db.Celtype;

                    CwcHatch entityObject = cwcDbObject as CwcHatch;

                    using (Hatch hatch = new Hatch())
                    {

                        // Set the properties of the hatch object
                        hatch.HatchObjectType = entityObject.HatchObjectType;
                        hatch.Origin = new Point2d(entityObject.Origin.X, entityObject.Origin.Y);
                        hatch.Annotative = entityObject.Annotative;
                        hatch.SetDatabaseDefaults();


                        if (entityObject.LayerId.Length > 0)
                            hatch.LayerId = GetDwgObjectId(entityObject.LayerId);

                        hatch.LinetypeId = GetLineTypeIdFromName(db, entityObject.Linetype);
                        hatch.LinetypeScale = entityObject.LinetypeScale;

                        hatch.LineWeight = entityObject.LineWeight;


                        ObjectId btrId;

                        // Open the Block table record for write
                        if (entityObject.BlockId == null)
                            btrId = blockTbl[BlockTableRecord.ModelSpace];
                        else
                            btrId = GetDwgObjectId(entityObject.BlockId);

                        using (BlockTableRecord btr = tr.GetObject(btrId, OpenMode.ForWrite) as BlockTableRecord)
                        {
                            // Add the new object to the block table record and the transaction
                            entityId = btr.AppendEntity(hatch);
                            tm.AddNewlyCreatedDBObject(hatch, true);
                        }

                        if (entityObject.IsHatch)
                        {
                            hatch.PatternAngle = entityObject.PatternAngle;
                            hatch.PatternScale = entityObject.PatternScale;
                            hatch.PatternSpace = entityObject.PatternSpace;
                            //< Added by Suresh on 18-03-2020 >
                            try
                            {
                                hatch.SetHatchPattern(entityObject.PatternType, entityObject.PatternName);
                            }
                            catch (System.Exception ex)
                            {
                                hatch.SetHatchPattern(HatchPatternType.PreDefined, "SOLID");
                                Logger.RecordMessage(ex.Message, Logs.Log.MessageType.Error);
                            }
                            //</ Added by Suresh on 18-03-2020 >
                            hatch.HatchStyle = entityObject.HatchStyle;
                            hatch.Color = GetDwgColor(entityObject.Color);
                            hatch.BackgroundColor = GetDwgColor(entityObject.BackgroundColor);
                        }
                        else
                        {
                            hatch.SetGradient(entityObject.GradientType, entityObject.GradientName);
                            hatch.GradientAngle = entityObject.GradientAngle;
                            hatch.GradientOneColorMode = entityObject.GradientOneColorMode;
                            hatch.GradientShift = entityObject.GradientShift;
                            hatch.SetGradientColors(GetDwgGradiantColor(entityObject.GradientColor));

                        }

                        // Associative must be set after the hatch object is appended to the
                        // block table record and before AppendLoop
                        hatch.Associative = entityObject.Associative;



                        for (int i = 0; i < entityObject.NumberOfLoops; i++)
                        {

                            // Try associative option  to be done in the other way rejee and contents not visible in 1.dwg
                            if (entityObject.Associative)
                            {

                                ObjectIdCollection oIds = new ObjectIdCollection();
                                for (int j = 0; j < entityObject.Loops[i].NumberOfAssociativeIds; j++)
                                {
                                    oIds.Add(GetDwgObjectId(entityObject.Loops[i].AssociativeIds[j]));
                                }
                                hatch.AppendLoop(entityObject.Loops[i].LoopType, oIds);

                            }
                            else
                            {
                                if (entityObject.Loops[i].IsPolyline)
                                {
                                    HatchLoop hatchloop = new HatchLoop(entityObject.Loops[i].LoopType);
                                    for (int j = 0; j < entityObject.Loops[i].NumberOfBulgeVertices; j++)
                                    {
                                        hatchloop.Polyline.Add(new BulgeVertex(new Point2d(entityObject.Loops[i].BulgeVertices[j].Vertex.X,
                                                                                           entityObject.Loops[i].BulgeVertices[j].Vertex.Y),
                                                                                           entityObject.Loops[i].BulgeVertices[j].Bulge));
                                    }
                                    hatch.AppendLoop(hatchloop);
                                }
                                else
                                {
                                    HatchLoop hatchLoop = CreateDwgHatchLoop(entityObject.Loops[i]);
                                    hatch.AppendLoop(hatchLoop);
                                }

                            }
                        }

                        hatch.EvaluateHatch(true);

                    }

                    // restore the current line type for database from the temp variable
                    db.Celtype = current_linetypeId;

                }

                tr.Commit();
            }

            return entityId;
        }


        public GradientColor[] GetDwgGradiantColor(CwcGradiantColor[] CXFGradiantColours)
        {
            GradientColor[] dwgGradiantColours = new GradientColor[2];
            dwgGradiantColours[0] = new GradientColor(Color.FromRgb(CXFGradiantColours[0].Red, CXFGradiantColours[0].Green, CXFGradiantColours[0].Blue), CXFGradiantColours[0].Value);
            dwgGradiantColours[1] = new GradientColor(Color.FromRgb(CXFGradiantColours[1].Red, CXFGradiantColours[1].Green, CXFGradiantColours[1].Blue), CXFGradiantColours[1].Value);
            return dwgGradiantColours;
        }


        private HatchLoop CreateDwgHatchLoop(CwcHatchLoop cwchatchloop)
        {
            HatchLoop hatchloop = new HatchLoop(cwchatchloop.LoopType);
            for (int cur = 0; cur < cwchatchloop.NumberOfCurves; cur++)
            {
                switch (cwchatchloop.Curve2DCollection[cur].CurveType)
                {
                    case Common.Enums.CurveType.LineSegment2d:
                        CwcLineSegment2D cwcLinesegment = (cwchatchloop.Curve2DCollection[cur] as CwcLineSegment2D);
                        Point2d startpoint = new Point2d(cwcLinesegment.StartPoint.X, cwcLinesegment.StartPoint.Y);
                        Point2d endpoint = new Point2d(cwcLinesegment.EndPoint.X, cwcLinesegment.EndPoint.Y);
                        LineSegment2d dwgLinesegment = new LineSegment2d(startpoint, endpoint);
                        hatchloop.Curves.Add(dwgLinesegment);
                        break;
                    case Common.Enums.CurveType.CircularArc2d:
                        CwcCircularArc2D cwcCircularArc = (cwchatchloop.Curve2DCollection[cur] as CwcCircularArc2D);
                        Point2d center = new Point2d(cwcCircularArc.Center.X, cwcCircularArc.Center.Y);
                        Vector2d refVector = new Vector2d(cwcCircularArc.ReferenceVector.X, cwcCircularArc.ReferenceVector.Y);

                        CircularArc2d dwgCircularArc = null;
                        if ((cwcCircularArc.ReferenceVector.X > 0) && (cwcCircularArc.ReferenceVector.Y > 0) && (cwcCircularArc.IsClockWise))
                            dwgCircularArc = new CircularArc2d(center, cwcCircularArc.Radius, cwcCircularArc.StartAngle, cwcCircularArc.EndAngle, refVector, cwcCircularArc.IsClockWise);
                        else
                        {
                            dwgCircularArc = new CircularArc2d(center, cwcCircularArc.Radius);
                            dwgCircularArc.ReferenceVector = refVector;
                            if ((cwcCircularArc.StartAngle > 0) || (cwcCircularArc.EndAngle > 0))
                                dwgCircularArc.SetAngles(cwcCircularArc.StartAngle, cwcCircularArc.EndAngle);
                        }
                        hatchloop.Curves.Add(dwgCircularArc);
                        break;
                    case Common.Enums.CurveType.EllipticalArc2d:
                        CwcEllipticalArc2D cwcEllipticalArc = (cwchatchloop.Curve2DCollection[cur] as CwcEllipticalArc2D);
                        center = new Point2d(cwcEllipticalArc.Center.X, cwcEllipticalArc.Center.Y);
                        Vector2d majAxis = new Vector2d(cwcEllipticalArc.MajorAxis.X, cwcEllipticalArc.MajorAxis.Y);
                        Vector2d minAxis = new Vector2d(cwcEllipticalArc.MinorAxis.X, cwcEllipticalArc.MinorAxis.Y);

                        EllipticalArc2d dwgEllipticalArc = new EllipticalArc2d(center, majAxis, minAxis,cwcEllipticalArc.MajorRadius,cwcEllipticalArc.MinorRadius,cwcEllipticalArc.StartAngle, cwcEllipticalArc.EndAngle);
                        hatchloop.Curves.Add(dwgEllipticalArc);
                        break;
                    case Common.Enums.CurveType.NurbCurve2d:
                        CwcNurbCurve2D cwcnurbCurve2d = (cwchatchloop.Curve2DCollection[cur] as CwcNurbCurve2D);
                        NurbCurve2d dwgNurbCurve2d = null;

                        if (cwcnurbCurve2d.HasFitData)
                        {
                            dwgNurbCurve2d = new NurbCurve2d();

                            Point2dCollection fitpts = new Point2dCollection();
                            for (int fp = 0; fp < cwcnurbCurve2d.NumFitPoints; fp++)
                                fitpts.Add(new Point2d(cwcnurbCurve2d.FitPoints[fp].X, cwcnurbCurve2d.FitPoints[fp].Y));
                            dwgNurbCurve2d.SetFitData(cwcnurbCurve2d.Degree, fitpts);
                            if (cwcnurbCurve2d.Fit_TangentsExist)
                            {
                                Vector2d startTan = new Vector2d(cwcnurbCurve2d.Fit_StartTangent.X, cwcnurbCurve2d.Fit_StartTangent.Y);
                                Vector2d endTan = new Vector2d(cwcnurbCurve2d.Fit_EndTangent.X, cwcnurbCurve2d.Fit_EndTangent.Y);

                                dwgNurbCurve2d.SetFitTangents(startTan, endTan);
                            }
                            dwgNurbCurve2d.FitTolerance = new Tolerance(cwcnurbCurve2d.FitTolerance_EqualVector, cwcnurbCurve2d.FitTolerance_EqualPoint);
                            dwgNurbCurve2d.FitKnotParameterization = cwcnurbCurve2d.FitKnotParameterization;

                        }
                        else
                        {
                            Point2dCollection ctrlpnts = new Point2dCollection();
                            for (int cp = 0; cp < cwcnurbCurve2d.NumControlPoints; cp++)
                                ctrlpnts.Add(new Point2d(cwcnurbCurve2d.ControlPoints[cp].X, cwcnurbCurve2d.ControlPoints[cp].Y));

                            KnotCollection knots = new KnotCollection();
                            for (int knt = 0; knt < cwcnurbCurve2d.NumKnots; knt++)
                                knots.Add(cwcnurbCurve2d.Knots[knt]);

                            dwgNurbCurve2d = new NurbCurve2d(cwcnurbCurve2d.Degree, knots, ctrlpnts, cwcnurbCurve2d.Periodic);

                            for (int wt = 0; wt < cwcnurbCurve2d.NumWeights; wt++)
                                dwgNurbCurve2d.SetWeightAt(wt, cwcnurbCurve2d.Weights[wt]);
                        }
                        hatchloop.Curves.Add(dwgNurbCurve2d);
                        break;
                }
            }
            return hatchloop;
        }

    }

}
