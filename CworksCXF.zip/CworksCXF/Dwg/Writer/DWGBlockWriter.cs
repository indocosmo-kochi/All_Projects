﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgBlockWriter : DwgEntityWriter
    {

        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            ObjectId btrId;
            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {
                using (BlockTable blockTbl = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable)
                {

                    //// save the current line type for database into a temp variable
                    //ObjectId current_linetypeId = db.Celtype;

                    CwcBlock entityObject = cwcDbObject as CwcBlock;

                    btrId = blockTbl[entityObject.Name];
                    if (btrId.IsNull)
                    {
                        using (BlockTableRecord btr = new BlockTableRecord())
                        {
                            btr.Name = entityObject.Name;
                            blockTbl.UpgradeOpen();
                            btrId = blockTbl.Add(btr);

                            for (int i = 0; i < entityObject.NumberAttributeDefs; i++)
                            {
                                using (AttributeDefinition attdef = new AttributeDefinition())
                                {
                                    attdef.Position = new Point3d(entityObject.AttributeDefs[i].Position.X,
                                                                    entityObject.AttributeDefs[i].Position.Y,
                                                                    entityObject.AttributeDefs[i].Position.Z);
                                    attdef.AlignmentPoint = new Point3d(entityObject.AttributeDefs[i].AlignmentPoint.X,
                                                                    entityObject.AttributeDefs[i].AlignmentPoint.Y,
                                                                    entityObject.AttributeDefs[i].AlignmentPoint.Z);
                                    attdef.Tag = entityObject.AttributeDefs[i].Tag;
                                    attdef.TextString = entityObject.AttributeDefs[i].TextString;
                                    attdef.Constant = entityObject.AttributeDefs[i].Constant;
                                    if (!entityObject.AttributeDefs[i].Constant)
                                    {
                                        attdef.Prompt = entityObject.AttributeDefs[i].Prompt;
                                        attdef.Preset = entityObject.AttributeDefs[i].Preset;
                                        attdef.Verifiable = entityObject.AttributeDefs[i].Verifiable;
                                    }
                                    attdef.Color = GetDwgColor(entityObject.AttributeDefs[i].Color);
                                    attdef.Invisible = entityObject.AttributeDefs[i].Invisible;
                                    attdef.LockPositionInBlock = entityObject.AttributeDefs[i].LockPositionInBlock;
                                    attdef.Oblique = entityObject.AttributeDefs[i].Oblique;
                                    attdef.Rotation = entityObject.AttributeDefs[i].Rotation;
                                    attdef.WidthFactor = entityObject.AttributeDefs[i].WidthFactor;
                                    attdef.Height = entityObject.AttributeDefs[i].Height;
                                    attdef.FieldLength = entityObject.AttributeDefs[i].FieldLength;
                                    attdef.Justify = entityObject.AttributeDefs[i].Justify;
                                    attdef.Annotative = entityObject.AttributeDefs[i].Annotative;
                                    attdef.IsMirroredInX = entityObject.AttributeDefs[i].IsMirroredInX;
                                    attdef.IsMirroredInY = entityObject.AttributeDefs[i].IsMirroredInY;

                                    if (entityObject.AttributeDefs[i].IsMTextAttributeDefinition)
                                    {
                                        MText mtext = new MText();
                                        mtext.Width = entityObject.AttributeDefs[i].MTextWidth;
                                        mtext.Contents = entityObject.AttributeDefs[i].MTextContents;
                                        btr.AppendEntity(mtext);
                                        attdef.MTextAttributeDefinition = mtext;
                                        attdef.IsMTextAttributeDefinition = entityObject.AttributeDefs[i].IsMTextAttributeDefinition;
                                    }

                                    if (entityObject.AttributeDefs[i].TextStyleId.Length > 0)
                                        attdef.TextStyleId = GetDwgObjectId(entityObject.AttributeDefs[i].TextStyleId);

                                    if (entityObject.AttributeDefs[i].LayerId.Length > 0)
                                        attdef.LayerId = GetDwgObjectId(entityObject.AttributeDefs[i].LayerId);
                                    btr.AppendEntity(attdef);

                                }
                            }


                            tm.AddNewlyCreatedDBObject(btr, true);
                        }
                    }

                    //// restore the current line type for database from the temp variable
                    //db.Celtype = current_linetypeId;
                }
                tr.Commit();
            }


            return btrId;
        }
    }
}
