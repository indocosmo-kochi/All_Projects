﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;
using Teigha.Geometry;

namespace CWorksCXF.DWG.Writer
{
    public class DwgSplineWriter : DwgEntityWriter
    {

        public override ObjectId CreateDwgEntity(Database db, CwcDbObject cwcDbObject)
        {

            CwcSpline entityObject = cwcDbObject as CwcSpline;

            ObjectId entityId = new ObjectId();
            Point3dCollection point3dCollection = new Point3dCollection();
            Vector3d startTan, endTan;
            if (entityObject.HasFitData)
            {

                for (int i = 0; i < entityObject.NumFitPoints; i++)
                {
                    point3dCollection.Add(new Point3d(entityObject.FitPoints[i].X, entityObject.FitPoints[i].Y, entityObject.FitPoints[i].Z));
                }

                if (entityObject.FitTangentsExist)
                {
                    startTan = new Vector3d(entityObject.StartFitTangent.X, entityObject.StartFitTangent.Y, entityObject.StartFitTangent.Z);
                    endTan = new Vector3d(entityObject.EndFitTangent.X, entityObject.EndFitTangent.Y, entityObject.EndFitTangent.Z);
                    using (Spline spline = new Spline(point3dCollection, startTan, endTan, entityObject.Order, entityObject.FitTolerance))
                    {
                        entityId = SetSplineProperties(db, spline, entityObject);
                    }
                }
                else
                {
                    using (Spline spline = new Spline(point3dCollection, entityObject.Order, entityObject.FitTolerance))
                    {
                        entityId = SetSplineProperties(db, spline, entityObject);
                    }

                }

            }
            else
            {
                for (int cp = 0; cp < entityObject.NumControlPoints; cp++)
                {
                    point3dCollection.Add(new Point3d(entityObject.ControlPoints[cp].X, entityObject.ControlPoints[cp].Y, entityObject.ControlPoints[cp].Z));
                }

                DoubleCollection knotCollection = new DoubleCollection();
                DoubleCollection weightCollection = new DoubleCollection();               

                for (int knt = 0; knt < entityObject.NurbsData.NumKnots; knt++)
                {
                    knotCollection.Add(entityObject.NurbsData.Knots[knt]);
                }

                for (int wt = 0; wt < entityObject.NurbsData.NumWeights; wt++)
                {
                    weightCollection.Add(entityObject.NurbsData.Weights[wt]);
                }

                using (Spline spline = new Spline(entityObject.NurbsData.Degree, entityObject.NurbsData.Rational, entityObject.NurbsData.Closed,
                                                entityObject.NurbsData.Periodic, point3dCollection, knotCollection, weightCollection,
                                                entityObject.NurbsData.ControlPointTolerance, entityObject.NurbsData.KnotTolerance)) 
                {
                    entityId = SetSplineProperties(db, spline, entityObject);
                }

            }

            return entityId;
        }

        private ObjectId SetSplineProperties(Database db, Spline spline, CwcSpline entityObject)
        {
            ObjectId entityId;

            TransactionManager tm = db.TransactionManager;
            using (Transaction tr = tm.StartTransaction())
            {

                // save the current line type for database into a temp variable
                ObjectId current_linetypeId = db.Celtype;

                using (BlockTable blockTbl = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable)
                {

                    if (entityObject.LayerId.Length > 0)
                        spline.LayerId = GetDwgObjectId(entityObject.LayerId);

                    spline.Color = GetDwgColor(entityObject.Color);

                    spline.LinetypeId = GetLineTypeIdFromName(db, entityObject.Linetype);
                    spline.LinetypeScale = entityObject.LinetypeScale;

                    spline.LineWeight = entityObject.LineWeight;

                    ObjectId btrId;

                    // Open the Block table record for write
                    if (entityObject.BlockId == null)
                        btrId = blockTbl[BlockTableRecord.ModelSpace];
                    else
                        btrId = GetDwgObjectId(entityObject.BlockId);

                    using (BlockTableRecord btr = tr.GetObject(btrId, OpenMode.ForWrite) as BlockTableRecord)
                    {
                        // Add the new object to the block table record and the transaction
                        entityId = btr.AppendEntity(spline);
                        tm.AddNewlyCreatedDBObject(spline, true);
                    }

                    // restore the current line type for database from the temp variable
                    db.Celtype = current_linetypeId;

                }

                tr.Commit();

            }

            return entityId;
        }


    }
}
