﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgLayerReader : DwgEnityReader, IDwgEntityReader
    {

        public Transaction acTrans { get; set; }

        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            CwcLayer layer = new CwcLayer();
            LayerTableRecord entity = (dbObject as LayerTableRecord);
            layer.Id = entity.Id.ToString();
            layer.Name = entity.Name;
            layer.Color = entity.Color;
            layer.LineTypeId = entity.LinetypeObjectId.ToString();

            // Open the Linetype table for read
            using (LinetypeTableRecord acLineTypTblRec = acTrans.GetObject(entity.LinetypeObjectId,
                                                OpenMode.ForRead) as LinetypeTableRecord)
            {
                layer.LineType = acLineTypTblRec.Name;
            }
            layer.LineWeight = entity.LineWeight;
            layer.Transparency = entity.Transparency.ToString();
            layer.IsOff = entity.IsOff;
            layer.IsHidden = entity.IsHidden;
            layer.IsPlottable= entity.IsPlottable;
            layer.IsLocked = entity.IsLocked;
            return layer;
        }
    }


}
