﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgBlockReferenceReader : DwgEnityReader, IDwgEntityReader
    {
        public Transaction acTrans { get; set; }
        public BlockTableRecord btrBlock { get; set; }
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            var entity = (dbObject as BlockReference);
            CwcBlockReference blockReference = new CwcBlockReference();
            blockReference.Id = entity.Id.ToString();
            blockReference.BlockDefId = btrBlock.Id.ToString();
            blockReference.Name = entity.Name; 
            blockReference.Position = entity.Position;

            blockReference.Rotation = entity.Rotation;
            blockReference.BlockUnit = entity.BlockUnit;
            blockReference.IsDynamicBlock = entity.IsDynamicBlock;
            blockReference.ScaleFactors = new CwcPoint3D(entity.ScaleFactors.X, entity.ScaleFactors.Y, entity.ScaleFactors.Z);

            blockReference.LayerId = entity.LayerId.ToString();

            blockReference.Linetype = entity.Linetype;
            blockReference.LinetypeScale = entity.LinetypeScale;

            blockReference.LineWeight = entity.LineWeight;

            blockReference.BlockId = entity.BlockId.ToString();
            blockReference.BlockName = entity.BlockName;

            blockReference.Color = entity.Color;

            if (entity.AttributeCollection.Count > 0)
            {
                AttributeCollection attributeCollection = entity.AttributeCollection;

                foreach (ObjectId attRefId in attributeCollection)
                {
                    using (AttributeReference attReference = (AttributeReference)acTrans.GetObject(attRefId, OpenMode.ForRead))
                    {
                        CwcAttributeReference cwcAttRef = new CwcAttributeReference();
                        cwcAttRef.Tag = attReference.Tag;
                        cwcAttRef.TextString = attReference.TextString;
                        blockReference.AttributeRefs.Add(cwcAttRef);
                    }
                }
                blockReference.NumberAttributeRefs = entity.AttributeCollection.Count;
            }

            return blockReference;
        }
    }
}
