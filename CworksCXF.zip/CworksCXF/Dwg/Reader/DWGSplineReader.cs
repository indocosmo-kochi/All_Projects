﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{

    public class DwgSplineReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            var entity = (dbObject as Spline);
            CwcSpline spline = null;

            if (entity.HasFitData)
            {
                spline = new CwcSpline(entity.HasFitData, entity.NumFitPoints);
                spline.FitTangentsExist = entity.FitData.TangentsExist;

                if (entity.FitData.TangentsExist)
                {
                    spline.StartFitTangent = entity.FitData.StartTangent;
                    spline.EndFitTangent = entity.FitData.EndTangent;
                }

                spline.FitTolerance = entity.FitTolerance;
                spline.Order = entity.Degree; 

                for (int i = 0; i < entity.NumFitPoints; i++)
                {
                    spline.FitPoints[i] = entity.GetFitPointAt(i);
                }

            }
            else
            {
                spline = new CwcSpline(entity.HasFitData, entity.NumControlPoints);
                for (int cp = 0; cp < entity.NumControlPoints; cp++)
                {
                    spline.ControlPoints[cp] = entity.GetControlPointAt(cp);
                }
                spline.NurbsData = entity.NurbsData;
            }

            spline.Id = entity.Id.ToString();
            spline.LayerId = entity.LayerId.ToString();
            spline.Linetype = entity.Linetype;
            spline.LinetypeScale = entity.LinetypeScale;

            spline.LineWeight = entity.LineWeight;

            //        spline.LayerName = Layers[spline.LayerId].Name;
            spline.BlockId = entity.BlockId.ToString();
            spline.BlockName = entity.BlockName;
            spline.Color = GetDwgEntityColor(entity.Color, entity.LayerId.ToString());
            return spline;
        }

    }


}


