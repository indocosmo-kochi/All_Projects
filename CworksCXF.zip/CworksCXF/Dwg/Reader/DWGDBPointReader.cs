﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{

    public class DwgDBPointReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {

            CwcDBPoint dbpoint = new CwcDBPoint();
            var entity = (dbObject as DBPoint);

            dbpoint.Id = entity.Id.ToString();
            dbpoint.LayerId = entity.LayerId.ToString();
            dbpoint.Position = entity.Position;

            dbpoint.Linetype = entity.Linetype;
            dbpoint.LinetypeScale = entity.LinetypeScale;

            dbpoint.LineWeight = entity.LineWeight;

            dbpoint.BlockId = entity.BlockId.ToString();

            dbpoint.BlockName = entity.BlockName;

            dbpoint.Color = GetDwgEntityColor(entity.Color, entity.LayerId.ToString());

            return dbpoint;
        }
    }


}
