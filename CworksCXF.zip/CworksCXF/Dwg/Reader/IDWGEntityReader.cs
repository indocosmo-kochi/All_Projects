﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    interface IDwgEntityReader
    {
        CwcDbObject ReadEntityDetails(DBObject dbObject);
    }

}
