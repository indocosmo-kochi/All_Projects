﻿using CWorksCXF.Common;
using CWorksCXF.Entities;
using System.Collections.Generic;
using Teigha.Colors;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public abstract class DwgEnityReader : IDwgEntityReader
    {

        public Dictionary<string, CwcLayer> Layers { get; set; }
        public CwcBlockReference CurrentBlock { get; set; }
        public CwcColor DefaultColor { get; set; }
 //       public Dictionary<string, CwcTextStyle> TextStyles { get; set; }
        public abstract CwcDbObject ReadEntityDetails(DBObject dbObject);

        public CwcColor GetDwgEntityColor(Color  entityColor, string entityLayerId)
        {
            CwcColor color;

            // "Color/Color.Method" of entity is ByBlock
            if (entityColor.ColorMethod == ColorMethod.ByBlock)
            {

                //"If  BlockRef is null , (no user defined block)
                //Black / White depends on the Default color of the Layer "
                if (this.CurrentBlock == null)
                {
                    color = CwcColor.GetColorFrom(this.DefaultColor);
                    color.ColorMethod = entityColor.ColorMethod;  //ByBlock  -- Color.FromColorIndex(ColorMethod.ByBlock, 0);?
                }
                else
                {
                    switch (this.CurrentBlock.Color.ColorMethod)
                    {
                        //"If BlockRef.ColourMethod = ByACi
                        //Take value from BlockRef.Colour.R,G,B"
                        //"If BlockRef.ColourMethod = ByColor
                        //Take value from BlockRef.Colour.R,G,B"
                        case ColorMethod.ByAci:
                        case ColorMethod.ByColor:
                            color = CwcColor.GetColorFrom(this.CurrentBlock.Color);
                            break;
                        //"If BlockRef.ColourMethod = ByLayer
                        //Take value from BlockRef.LayerId->Layer.Colour.R,G,B"
                        case ColorMethod.ByLayer:
                            color = CwcColor.GetColorFrom(this.Layers[this.CurrentBlock.LayerId].Color);
                            break;
                        //"If  BlockRef.ColourMethod = ByBlock
                        // otherwise
                        //Black / White depends on the Default color of the Layer
                        case ColorMethod.ByBlock:
                        default:
                            color = CwcColor.GetColorFrom(this.DefaultColor);
                            break;
                    }

                }
            }
            // "Color/Color.Method" of entity is ByLayer
            else if (entityColor.ColorIndex == 256)
            {
                color = CwcColor.GetColorFrom(this.Layers[entityLayerId].Color);
            }
            else
            {
                // Take Entity.Colour.Red,G,B"
                color = CwcColor.GetColorFrom(entityColor);
            }
            color.ColorMethod = entityColor.ColorMethod;  
            color.ColorIndex = entityColor.ColorIndex;
            return color;
        }





    }
}
