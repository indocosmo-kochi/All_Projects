﻿using CWorksCXF.Common;
using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgDBSettingsReader
    {
        public CwcDBSettings ReadDBSettings(Database db)
        {
            CwcDBSettings dbSettings = new CwcDBSettings();
            dbSettings.Pdmode = db.Pdmode;
            dbSettings.Pdsize = db.Pdsize;
            dbSettings.Ltscale = db.Ltscale;
            dbSettings.Measurement = ConvertDwgMeasurementToCXF(db.Measurement.ToString());

            return dbSettings;
        }

        private Enums.MeasurementValue ConvertDwgMeasurementToCXF(string dwgMeasurementValue)
        {
            return Enums.ConvertStringToEnumValue<Enums.MeasurementValue>(dwgMeasurementValue);
        }

    }
}
