﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgTextStyleReader : IDwgEntityReader
    {
        public CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            CwcTextStyle textStyle = new CwcTextStyle();
            TextStyleTableRecord textStyleRecord = (dbObject as TextStyleTableRecord);
            textStyle.Id = textStyleRecord.Id.ToString();
            textStyle.Name = textStyleRecord.Name;
            textStyle.FileName = textStyleRecord.FileName;
            textStyle.FontName = textStyleRecord.Font.TypeFace;
            textStyle.IsBold = textStyleRecord.Font.Bold;
            textStyle.IsItallic = textStyleRecord.Font.Italic;
            textStyle.Characters = textStyleRecord.Font.CharacterSet;
            textStyle.PitchAndFamily = textStyleRecord.Font.PitchAndFamily;
            textStyle.TextSize = textStyleRecord.TextSize;
            textStyle.ObliquingAngle = textStyleRecord.ObliquingAngle;
            textStyle.FlagBits = textStyleRecord.FlagBits;                        
            textStyle.IsVertical = textStyleRecord.IsVertical;

            textStyle.Annotative = textStyleRecord.Annotative;
            textStyle.BigFontFileName = textStyleRecord.BigFontFileName;
            textStyle.PriorSize = textStyleRecord.PriorSize;
            textStyle.XScale = textStyleRecord.XScale;

            return textStyle;
        }
    }


}
