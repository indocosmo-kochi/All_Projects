﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{

    public class DwgPolylineReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            var entity = (dbObject as Polyline);
            CwcPolyline polyline = new CwcPolyline(entity.NumberOfVertices);

            polyline.Id = entity.Id.ToString();
            polyline.LayerId = entity.LayerId.ToString();
            polyline.StartPoint = entity.StartPoint;
            polyline.EndPoint = entity.EndPoint;
            polyline.NumberOfVertices = entity.NumberOfVertices;

            for (int i = 0; i < polyline.NumberOfVertices; i++)
            {
                polyline.Vertices[i] = entity.GetPoint3dAt(i);
                polyline.Bulge[i] = entity.GetBulgeAt(i);
                polyline.StartWidth[i] = entity.GetStartWidthAt(i);
                polyline.EndWidth[i] = entity.GetEndWidthAt(i);
            }

            polyline.IsClosed = entity.Closed;

            polyline.Linetype = entity.Linetype;
            polyline.LinetypeScale = entity.LinetypeScale;

            polyline.LineWeight = entity.LineWeight;

            //       polyline.LayerName = Layers[polyline.LayerId].Name;
            polyline.BlockId = entity.BlockId.ToString();
            polyline.BlockName = entity.BlockName;
            polyline.Color = GetDwgEntityColor(entity.Color, entity.LayerId.ToString());
            return polyline;
        }

    }


}

