﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgArcReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            CwcArc arc = new CwcArc();
            var entity = (dbObject as Arc);

            arc.Id = entity.Id.ToString();
            arc.LayerId = entity.LayerId.ToString();
            //arc.LayerName = Layers[arc.LayerId].Name;
            arc.Center = entity.Center;
            arc.Radius = entity.Radius;
            arc.StartPoint = entity.StartPoint;
            arc.EndPoint = entity.EndPoint;
            arc.Normal = entity.Normal;
            arc.StartAngle = entity.StartAngle;
            arc.EndAngle = entity.EndAngle;

            arc.Linetype = entity.Linetype;

            arc.LinetypeScale = entity.LinetypeScale;

            arc.LineWeight = entity.LineWeight;
            arc.BlockId = entity.BlockId.ToString();
            arc.BlockName = entity.BlockName;

            arc.Color = GetDwgEntityColor(entity.Color, entity.LayerId.ToString());
            arc.LinetypeId = entity.LinetypeId.ToString();


            return arc;
        }
    }
}
