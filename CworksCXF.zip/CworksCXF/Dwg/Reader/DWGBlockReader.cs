﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgBlockReader : DwgEnityReader, IDwgEntityReader
    {
        public Transaction acTrans { get; set; }

        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            var entity = (dbObject as BlockTableRecord);

            CwcBlock block = new CwcBlock();
            block.Id = entity.Id.ToString();
            block.Name = entity.Name;
            BlockTableRecordEnumerator iterator = entity.GetEnumerator();
            DBObject subentity;
            while (iterator.MoveNext())
            {
                ObjectId id = (ObjectId)iterator.Current;
                using (subentity = acTrans.GetObject(id, OpenMode.ForRead))
                {

                    if (subentity.GetType() == typeof(AttributeDefinition))
                    {
                        AttributeDefinition attdef = subentity as AttributeDefinition;
                        CwcAttributeDefinition cwcAttDef = new CwcAttributeDefinition(attdef);
                        cwcAttDef.Color = GetDwgEntityColor(attdef.Color, attdef.LayerId.ToString());
                        block.AttributeDefs.Add(cwcAttDef);
                    }
                }
                
                block.NumberAttributeDefs = block.AttributeDefs.Count;

            }

            return block;
        }
    }
}

