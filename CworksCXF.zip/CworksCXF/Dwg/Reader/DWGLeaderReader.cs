﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgLeaderReader : DwgEnityReader, IDwgEntityReader
    {

        public Transaction acTrans { get; set; }

        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            var entity = (dbObject as Leader);
            CwcLeader leader = new CwcLeader(entity.NumVertices);
            leader.Id = entity.Id.ToString();
            leader.LayerId = entity.LayerId.ToString();
            leader.Dimlwd = entity.LineWeight;
            leader.Dimldrblk= entity.Dimldrblk.ToString(); 
            leader.NumVertices = entity.NumVertices;
            leader.DimensionStyle = entity.DimensionStyle.ToString();
            leader.Dimasz = entity.Dimasz;
            leader.Dimgap = entity.Dimgap;

            if (!entity.Dimldrblk.IsNull)
            {
                using (DimStyleTableRecord dimStyle = (DimStyleTableRecord)entity.DimensionStyle.GetObject(OpenMode.ForWrite))
                {
                    ObjectId savedId = dimStyle.Dimblk1;
                    dimStyle.Dimblk1 = entity.Dimldrblk;
                    leader.Dimblks = dimStyle.Dimblk1s;
                    dimStyle.Dimblk1 = savedId;
                }
            }
            leader.Dimclrd = GetDwgEntityColor(entity.Dimclrd, entity.LayerId.ToString());
            leader.Dimscale = entity.Dimscale;
            leader.Dimtad = entity.Dimtad;
            leader.Dimtxt = entity.Dimtxt;
            leader.HasArrowHead = entity.HasArrowHead;
            leader.IsSplined = entity.IsSplined;
            if (entity.AnnoType == AnnotationType.MText)
            {
                leader.Annotation = entity.Annotation.ToString();
            }
            else if (entity.AnnoType == AnnotationType.BlockRef)
            {
                //TO DO
                //leader.Annotation = entity.Annotation.ToString();
            }
            for (int i = 0; i < leader.NumVertices; i++)
            {
                leader.Vertices[i] = entity.VertexAt(i);
            }
            leader.Linetype = entity.Linetype;
            leader.LinetypeScale = entity.LinetypeScale;
            leader.LineWeight = entity.LineWeight;
            leader.TextStyleId = entity.TextStyleId.ToString();
            leader.BlockName = entity.BlockName;
            leader.BlockId = entity.BlockId.ToString();
            return leader;
        }
    }
}
