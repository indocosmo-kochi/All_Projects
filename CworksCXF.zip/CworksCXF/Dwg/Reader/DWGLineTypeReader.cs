﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{

    public class DWGLineTypeReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {

            CwcLineType linetype = new CwcLineType();
            var entity = (dbObject as LinetypeTableRecord);

            linetype.Id = entity.Id.ToString();
            //linetype.LayerId = entity.LayerId.ToString();
            //linetype.StartPoint = entity.StartPoint;

            //linetype.EndPoint = entity.EndPoint;

            //linetype.Linetype = entity.Linetype;

            //linetype.LinetypeScale = entity.LinetypeScale;

            //linetype.LineWeight = entity.LineWeight;

            ////      line.LayerName = Layers[line.LayerId].Name;

            //linetype.BlockId = entity.BlockId.ToString();

            //linetype.BlockName = entity.BlockName;

            //linetype.Color = GetDwgEntityColor(entity.Color, entity.LayerId.ToString());

            return linetype;
        }
    }


}

