﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgViewportReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            CwcViewport viewport = new CwcViewport();
            ViewportTableRecord entity = (dbObject as ViewportTableRecord);
            viewport.Id = entity.Id.ToString();
            viewport.Name = entity.Name;
            viewport.CircleSides = entity.CircleSides;
            viewport.GridEnabled = entity.GridEnabled;
            viewport.CenterPoint = entity.CenterPoint;
            viewport.Height = entity.Height;
            viewport.Width = entity.Width;

            return viewport;
        }
    }


}

