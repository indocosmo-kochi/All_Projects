﻿using CWorksCXF.Entities;
using Teigha.DatabaseServices;

namespace CWorksCXF.DWG.Reader
{
    public class DwgAlignedDimensionReader : DwgEnityReader, IDwgEntityReader
    {
        public override CwcDbObject ReadEntityDetails(DBObject dbObject)
        {
            CwcAlignedDimension dimension = new CwcAlignedDimension();
            var entity = (dbObject as AlignedDimension);
            dimension.LayerId = entity.LayerId.ToString();
            dimension.LinetypeId = entity.LinetypeId.ToString();

            dimension.DimLinePoint = entity.DimLinePoint;
            dimension.XLine1Point = entity.XLine1Point;
            dimension.XLine2Point = entity.XLine2Point;

            dimension.DimStyleId = entity.DimensionStyle.ToString();
            //dimension.DimensionStyleName = entity.DimensionStyleName;

            //dimension.DimensionStyle = entity.GetDimstyleData();



            dimension.TextStyleId = entity.TextStyleId.ToString();
            dimension.TextPosition = entity.TextPosition;
            dimension.TextRotation = entity.TextRotation;

            dimension.Linetype = entity.Linetype;
            dimension.LinetypeScale = entity.LinetypeScale;

            dimension.LineWeight = entity.LineWeight; 
            dimension.BlockId = entity.BlockId.ToString();
            dimension.BlockName = entity.BlockName;

            dimension.Color = GetDwgEntityColor(entity.Color,entity.LayerId.ToString());

            return dimension;
        }

    }
}
