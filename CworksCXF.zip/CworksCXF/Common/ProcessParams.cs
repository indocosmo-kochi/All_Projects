﻿using System;

namespace CWorksCXF.Common
{
    using static Enums;

    public class ProcessParam
    {

        private string acadVersionName;
        private int acadVersionNo;
        public string InputFileName { get; set; }
        public string OutputFileName { get; set; }
        public string PaperSize { get; set; }
        public string RotateAngle { get; set; }
        public string FontName { get; set; }
        public string Param1 { get; set; }
        public string Param2 { get; set; }
        public string Param3 { get; set; }

        public int AutoCADVersionNo { get { return acadVersionNo; } }

        public string AutoCADVersionName {
            get { return acadVersionName; }
            set
            {
                VersionNo vno;
                if (Enum.TryParse(value, out vno))
                {
                    acadVersionNo = (int)vno;
                    acadVersionName = value;
                }
                else
                {
                    acadVersionName = "***INVALID_VERSION :" + value;
                    acadVersionNo = (int)vno;
                }
            }
        }

        public override string ToString()
        {
            return " Utility Parameters =>" + System.Environment.NewLine +
                   "Input File :" + InputFileName + System.Environment.NewLine +
                   "Output File :" + OutputFileName + System.Environment.NewLine +
                   "PAPERSIZE :" + PaperSize + System.Environment.NewLine +
                   "ROTATE :" + RotateAngle + System.Environment.NewLine +
                   "FONT :" + FontName + System.Environment.NewLine +
                   "VERSION :" + AutoCADVersionName;
        }
    }
}
