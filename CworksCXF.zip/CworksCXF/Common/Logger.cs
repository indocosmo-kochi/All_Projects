﻿using System;

namespace CWorksCXF.Common
{

    public static class Logger
    {

        public enum LogTypes
        {       
            Event = 1,     
            File = 2
        }
        // Internal logging object   
        private static Logs.Log _Logger;

        // Internal log type   
        private static LogTypes _LogType = LogTypes.File;
        public static LogTypes LogType
        {
            get
            {
                return _LogType;
            }
            set
            {
                // Set the Logger to the appropriate log when      
                // the type changes.      
                switch (value)
                {
                    case LogTypes.Event:
                        _Logger = new Logs.EventLog();
                        break;
                    default:
                        _Logger = new Logs.FileLog();
                        break;
                }
            }
        }

        public static void RecordMessage(Exception Message, Logs.Log.MessageType Severity)
        {
            _Logger.RecordMessage(Message, Severity);
        }

        public static void RecordMessage(string Message, Logs.Log.MessageType Severity)
        {
            if (Severity == Logs.Log.MessageType.Exception)
                throw new CWorksCXFException(Message);
            else
                _Logger.RecordMessage(Message, Severity);
        }
    }


}








