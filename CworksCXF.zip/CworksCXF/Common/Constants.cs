﻿using System.IO;

namespace CWorksCXF.Common
{
    public static class CONST
    {
        public const string MODEL_SPACE = "*MODEL_SPACE";

        public const string DEFAULT_VERSION = "V2012";

        // Line Type file supplied along with the exe
        public const string ACAD_LINETYPES_FILE = "Acad/acadiso.lin";

    }
}
