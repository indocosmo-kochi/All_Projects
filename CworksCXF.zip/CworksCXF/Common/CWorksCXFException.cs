﻿using System;

namespace CWorksCXF.Common
{
    public class CWorksCXFException : ApplicationException
    {
        public CWorksCXFException(String message) : base(message)
        {
        }
    }
}
