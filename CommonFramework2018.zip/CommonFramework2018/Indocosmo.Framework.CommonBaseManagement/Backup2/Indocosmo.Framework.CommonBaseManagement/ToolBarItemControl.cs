using System;
using System.Collections.Generic;
using System.Text;

namespace Indocosmo.Framework.CommonBaseManagement
{
   public class ToolBarItemControl
    {
        
        bool tlStripNew = false;
        bool tlStripAdd = false;
        bool tlStripSave = false;
        bool tlStripDelete = false;
        bool tlStripSearch = false;
        bool tlStripClear = false;
        bool tlStripClose = false;
        bool tlStripPrint = false;

       

        /// <summary>
        /// New Tool button Handle
        /// </summary>
        public bool TlStripNew
        {
            get
            {
                return tlStripNew;
            }
            set
            {
                tlStripNew = value;
            }
        }

        /// <summary>
        /// Add Tool button Handle
        /// </summary>
        public bool TlStripAdd
        {
            get
            {
                return tlStripAdd;
            }
            set
            {
                tlStripAdd = value;
            }
        }

        /// <summary>
        /// Save Tool button Handle
        /// </summary>
        public bool TlStripSave
        {
            get
            {
                return tlStripSave;
            }
            set
            {
                tlStripSave = value;
            }
        }

        /// <summary>
        /// Delete Tool button Handle
        /// </summary>
        public bool TlStripDelete
        {
            get
            {
                return tlStripDelete;
            }
            set
            {
                tlStripDelete = value;
            }
        }

        /// <summary>
        /// Search Tool button Handle
        /// </summary>
        public bool TlStripSearch 
        {
            get
            {
                return tlStripSearch;
            }
            set {
                tlStripSearch = value;
            }
        }

        /// <summary>
        /// Clear Tool button Handle
        /// </summary>
        public bool TlStripClear
        {
            get
            {
                return tlStripClear;
            }
            set
            {
                tlStripClear = value;
            }
        }

        /// <summary>
        /// close Tool button Handle
        /// </summary>
        public bool TlStripClose
        {
            get
            {
                return tlStripClose;
            }
            set
            {
                tlStripClose = value;
            }
        }

        /// <summary>
        /// Print Tool button Handle
        /// </summary>
        public bool TlStripPrint
        {
            get
            {
                return tlStripPrint;
            }
            set
            {
                tlStripPrint = value;
            }
        }

    }
}
