using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Indocosmo.Framework.CommonBaseManagement
{
    /// <summary>
    /// Form Action Controlling
    /// </summary>
    public interface IFormAction
    {
        /// <summary>
        /// Click Save Button 
        /// </summary>   
        void iBtnSave();
        /// <summary>
        /// Click Edit Button 
        /// </summary>   
        void iBtnEdit();
        /// <summary>
        /// Click Delete Button 
        /// </summary> 
        /// 
        void iBtnDelete();
        /// <summary>
        /// Click Close Button 
        /// </summary> 
        void iBtnClose();
        /// <summary>
        /// 
        /// </summary>
        void iBtnPrint();
        /// <summary>
        /// 
        /// </summary>
        void iBtnClear();
        /// <summary>
        /// 
        /// </summary>
        void iBtnAdd();
        /// <summary>
        /// 
        /// </summary>
        void iBtnSearch();

    }
}
