

$(document).ready(function() {



});


function sendMessage() {
	
	
	alert("Haiii");
}

