var receiverId;
var senderImage;

var isReciverExists = false;

var messageContextPath = location.protocol + '//' + location.host
		+ location.pathname;

var groupId;
var isGroupMessge = false;
var isIndMessage = false;
var flagDisableDiv= false;

$(document).ready(function() {

	// establish websocket connection
	connect();

	$("#userNameProfile").html(userFullName)
	// $('.card').hide();
	$("#messageContentDiv").hide();

	
	$("#recoedDivShowLi").click(function(ev){
		
		$('#myModal').modal('show');
		
		
	});
	
	
	var recordOnOrOff = 0;
	$("#recordButton").click(
			function(ev) {

				var recordItemsTag = $(ev.currentTarget).closest(
						'.controlButtons').find('#recordContainer')
						.children('#recordCircle');
				console.log(recordItemsTag);
				recordOnOrOff++;
				if (recordOnOrOff == 1) {
					// $(ev.currentTarget).attr('src','../resources/img/voice/stop.ico');
					$(recordItemsTag).removeClass('startRecord')
							.addClass('stopRecord');
					// $("#recordContainer").removeClass('startContainer').addClass('stopContainer');
					$("#recordText").html("Stop");
					$.stopwatch.startTimer('sw');
					startRecording(recordItemsTag);
					getRecording(recordItemsTag);
				} else {
					startPreloader();
					// alert(totalTime);
					recordVoiceDuration = totalTime;
					recordOnOrOff = 0;
					// $(ev.currentTarget).attr('src','../resources/img/voice/Microphone.png');
					$.stopwatch.resetTimer();
					$(recordItemsTag).removeClass('stopRecord')
							.addClass('startRecord');
					// $("#recordContainer").removeClass('stopContainer').addClass('startContainer');
					$("#recordText").html("Record");
					stopRecording(recordItemsTag);
					getRecording(recordItemsTag);
					$("#audioPreLoader").show();
					$("#audioPreLoaderback").show();
				}

			});
	

});

$("#voiceToTextStart").click(function(ev){
	
	$('#voiceToTextstop').show();
	$("#voiceToTextStart").hide();
	$('.textarea-control').text("");
	
});

//search by contacts name 
function searchContact(ev){
	var searchItem = $('#searchContactList').val().toLowerCase().trim();
	$("#chat_list_searchResult").empty();
	

		if ($('#searchContactList').val() != null && $('#searchContactList').val() != '') {

		$('.userNameDiv').each(function(index) {

			if ($(this).text().toLowerCase().indexOf(searchItem) != -1) {

				var matchedLiData = $(this).closest('li')[0].outerHTML;
				$('#chat_list_searchResult').append(matchedLiData);
				$('#chat_list_search').hide();
				$('#chat_list_searchResult').find('li').css('background-color','rgba(0, 0, 0, 0.05)'); 

			}
		});
	}else{
		$('#chat_list_search').show();
	}
}



$('#voiceToTextstop').click(function(ev){
	
	$('#voiceToTextstop').hide();
	$("#voiceToTextStart").show();

});
function getMessageWindow(event,name, pId, receiverUk, reciverId, image) {

	$('.contactPool').removeClass('active');
     $(event).addClass("active");
	//active
	isReciverExists = true;
	$("#messageContentDiv").show();
	$("#footerDiv").show();
	$('#chat-wrapper').empty();
	
	$('.textarea-control').text("");
	$('#file-input-data').val('');

	isGroupMessge = false;
	isIndMessage = true;
	
	$(".image-upload").show();// file choose only visible for  indv message.

	$("#" + receiverUk).hide();
	senderImage = image;

	receiverId = receiverUk;
	var message = "hey  " + name + "  welcome to Chat";

	$("#currentChatHead").attr("src",
			"../resources/assets/img/profiles/0" + senderImage + ".jpg");
	$(".name").text(name);

	$
			.ajax({
				method : 'GET',
				url : urlMessageAll + "/" + reciverId,
				success : function(data) {
					 //console.log(data);
																						 
					var imageUrl = "../resources/assets/img/profiles/0"
							+ senderImage + ".jpg";
					
					$.map( data, function( val, key ) {
						  // Do something
						var dateDiv='<div class="chat-row" style="text-align: center;" ><p>'+key+'</p></div>';
						$('#chat-wrapper').append(dateDiv);
		
						
						
						$.each(val,function(index, messageObj) {

									
											var senderId = messageObj["senderId"];
												
												var mesageHrMinuts= messageObj["timeOfMessage"].split(":");
												var timeOfMessage=formatAMPM(mesageHrMinuts[0],mesageHrMinuts[1]);
												
												
											if (userId == senderId) {

												if (messageObj.attachment) {

													var attachmentId = messageObj.attachemnt;

													var imgurls = urlAttachemnt
															+ "/"
															+ attachmentId;

													if (messageObj.attachmetExt == "image/jpeg" || messageObj.attachmetExt == "image/png") {
														var messageDiv = '<div class="chat-row" id='
																+ messageObj["id"]
																+ ' ><img src='
																+ imageUrl
																+ ' alt=""class="img-circle img-sm pull-right"><div class="bubble"><div class="divImage">'
																+ '<img onClick="downloadFile(\''
																+ attachmentId
																+ '\')"src="'+ imgurls+ '"></div><div class="message"><p>'
																+ messageObj["messageContent"]
																+ '</p></div><div class="date">'+timeOfMessage+'</div></div></div>';
														$('#chat-wrapper')
																.append(
																		messageDiv);
													
													} else if (messageObj.attachmetExt == "application/pdf") {

														var messageDiv = '<div class="chat-row" id='
																+ messageObj["id"]
																+ ' ><img src='
																+ imageUrl
																+ ' alt=""class="img-circle img-sm pull-right"><div class="bubble"><div class="divImage">'
																+ '<a href="#" onClick="getPdf(\''
																+ attachmentId
																+ '\')"><img src="../resources/assets/static-image/download.jpg"></a></div><div class="message"><p>'
																+ messageObj["messageContent"]
																+ '</p></div><div class="date">'+timeOfMessage+'</div><span></span></div></div>';
														$('#chat-wrapper')
																.append(
																		messageDiv);

													}else if (messageObj.attachmetExt == ".mp3") {
													
															var messageDiv = '<div class="chat-row" id='
																+ messageObj["id"]
														    	+ ' ><img src='
														        + imageUrl
														        + ' alt=""class="img-circle img-sm pull-right"><div class="bubble">'
																+ '<div style="text-align: right;"><audio class="audio1" controls=""><source src="'+ imgurls+'" type="audio/mpeg"></audio></div>'
																+ '<div class="date">'+timeOfMessage+'</div></div></div>';
														$('#chat-wrapper')
																.append(messageDiv);
													}

												} else {
													var message = '<div class="chat-row" id='
															+ messageObj["id"]
															+ '><img src='
															+ imageUrl
															+ ' alt=""class="img-circle img-sm pull-right"><div class="bubble"><div class="message"><p class="currentMsgContentPara">'
															+ '</p></div><div class="date">'+timeOfMessage+'</div><span></span></div></div>';
													$('#chat-wrapper').append(
															message);
													
													$('.currentMsgContentPara').text(messageObj["messageContent"]);
													$('.currentMsgContentPara').removeClass('currentMsgContentPara');
												}

											} else {

												if (messageObj.attachment) { // if attachemnt is exist
													var attachmentId = messageObj.attachemnt;

													var imgurls = urlAttachemnt
															+ "/"
															+ attachmentId;
													if (messageObj.attachmetExt == "image/jpeg" || messageObj.attachmetExt == "image/png") {
														var messageDiv = '<div class="chat-row response" id='
															+ messageObj["id"]
															+ ' ><img src='
															+ imageUrl
															+ ' alt=""class="img-circle img-sm pull-left"><div class="bubble_response"><div class="divImage">'
															+ '<img src="'
															+ imgurls
															+ '"></div><div class="message"><p>'
															+ messageObj["messageContent"]
															+ '</p></div><div class="date">'+timeOfMessage+'</div><span></span></div></div>';
													$('#chat-wrapper').append(
															messageDiv);
													}else if (messageObj.attachmetExt == ".mp3") {
													
														
														var messageDiv = '<div class="chat-row response" id='
															+ messageObj["id"]
															+ ' ><img src='
														    + imageUrl
														    + ' alt=""class="img-circle img-sm pull-left"><div class="bubble_response">'
															+ '<audio class="audio1" controls=""><source src="'+ imgurls+'" type="audio/mpeg"></audio>'
															+ '<div style="text-align: left; font-size: smaller;">'+timeOfMessage+'</div></div></div>';
													$('#chat-wrapper')
															.append(messageDiv);
													
													
													}
												

												} else {
													// if olny text message

													var messageDiv = '<div class="chat-row response" id='
															+ messageObj["id"]
															+ ' ><img src='
															+ imageUrl
															+ ' alt=""class="img-circle img-sm pull-left"><div class="bubble_response"><div class="message"><p class="currentMsgContentPara">'
															+ '</p></div><div class="date">'+timeOfMessage+'</div><span></span></div></div>';
													$('#chat-wrapper').append(
															messageDiv);
													
													$('.currentMsgContentPara').text(messageObj["messageContent"]);
													$('.currentMsgContentPara').removeClass('currentMsgContentPara');

												}

											}
											
										
						});
						
						});
					
				
						
						$('#chart-wrapper').children('div:last').focus();
					
						
				/*	} else {
						var messageDiv = '<div class="chat-row response"><div class="bubble_response"><div class="message"><p>'
								+ message
								+ '</p></div><div class="date"></div></div></div>';

						$('#chat-wrapper').append(messageDiv);

						$('#chat-wrapper').animate({
							scrollTop : $('#chat-wrapper').prop("scrollHeight")
						}, 50);

					}*/
					

					//var aaaaa=$('.chat-row').length();
					//console.log(111);
					//var aaa=$('#chat-wrapper').find('div').length(); 
					//console.log(aaa);
					
				//	$('#chat-wrapper').find('div:last').focus();
					//$('#chart-wrapper').children('div:last').focus();
					
				/*	$('#chat-wrapper').children('div:last').animate({
						scrollBottom : 	$('#chat-wrapper').children('div:last').prop("scrollHeight")
					}, 50);*/
					//console.log("cccccc");
					
					
					//$('#chat-wrapper').find('div:last')[0].children('img').focus();
					//$('#chat-wrapper').find('div:last').closest('span').focus();
				    //$('#chat-wrapper').find('div:last').children('span').attr('src');
					
					
				//	$('#chat-wrapper').find('div:last')[0].focus();
					
					//$('#chat-wrapper').find('div:last')[0].focus();  
					
					//$('#chat-wrapper').find('.chat-row:last').children('img').focus();
					//$('#chat-wrapper').find('.chat-row').last().focus();
					
					//$('#chat-wrapper').find('.chat-row').last().find('img').focus();
					
					
				//	var clientHeight = document.getElementById('chat-wrapper').clientHeight;
					
				//	var offsetHeight = document.getElementById('chat-wrapper').offsetHeight;
					

				//	alert(offsetHeight); chat_con_text


					var s = $('#chat_con_text');

					var optionTop = s.find('div').last().offset().top;
					var selectTop = s.offset().top;
					s.scrollTop(s.scrollTop() + (optionTop - selectTop)-(s.css("height")-20));
					

				},
				error : function(xhr, error) {
					console.log(xhr, error);
				}

			});

}



function formatAMPM(hours,minutes) {

	  var ampm = hours >= 12 ? 'pm' : 'am';
	  hours = hours % 12;
	  hours = hours ? hours : 12; // the hour '0' should be '12'
	  minutes = minutes < 10 ? '0'+minutes : minutes;
	  var strTime = hours + ':' + minutes + ' ' + ampm;
	  return strTime;
	}

function getPdf(attachementId) {
	//console.log(attachementId);
	//window.location.href = urlAttachemnt + "/getpdf/" + attachementId;
}

function downloadFile(attachementId) {
	//console.log(attachementId);
	//window.location.href = urlAttachemnt + "/download/" + attachementId;
}

function sendMessage() {

	// if any receiver or group is selected.
	if (isReciverExists) {
		if ($('.textarea-control').text() != "") {

			if (isIndMessage) {

				// ind message sending
				var message = {};
				message.message = $('.textarea-control').text();
				message.receiveUserId = receiverId;
				message.type = "1";

				var messageContextPath = location.protocol + '//'
						+ location.host + location.pathname;
				$.ajax({
					method : 'POST',
					url : messageContextPath,
					contentType : "application/json; charset=utf-8",
					data : JSON.stringify(message),
					cache : false,
					contentType : false,
					processData : false,
					success : function(data) {
						console.log(data);

						createmessageview(data, message.receiveUserId, 1);
						$('.textarea-control').text("");
						// $("#message-" + id).val('');
					},
					error : function(xhr, error) {
						console.log(xhr, error);
					}

				});
			} else {
				// group message sending

				var message = {};

				message.message = $('.textarea-control').val();
				message.receiveUserId = receiverId;
				message.senderId = userId;

				message.groupId = groupId;
				message.senderName = userFullName;

				var messageContextPath = location.protocol + '//'
						+ location.host + location.pathname + '/sample';

				$.ajax({
					method : 'POST',
					url : messageContextPath,
					contentType : "application/json; charset=utf-8",
					data : JSON.stringify(message),
					success : function(data) {

						createmessageviewGrp(data, message.receiveUserId, 1);
						$('.textarea-control').text("");
					},
					error : function(xhr, error) {
						console.log(xhr, error);
					}

				});

			}

		}
	}

}

function sendPic() {

	var image = $('#file-input-data')[0].files[0];
	var text = $('.textarea-control').text().trim();

	if (image != undefined || text != "") {

		if (isIndMessage) {
			var message = {};
			message.message = $('.textarea-control').text();
			message.receiveUserId = receiverId;
			message.type = "1";

			var uploadAttachment = new FormData();
			uploadAttachment.append("file", image);
			uploadAttachment.append('threadPid', JSON.stringify(message));
			// uploadAttachment.append('receiverId',receiverId)
			
			var messageContextPath = location.protocol + '//'
			+ location.host + location.pathname + '/upload-attachment';

			$.ajax({
				type : 'POST',
				url : messageContextPath,
				data : uploadAttachment,
				cache : false,
				contentType : false,
				processData : false,
				success : function(data) {
					//console.log(data);
					createmessageview(data, message.receiveUserId, 1);
					$('.textarea-control').text("");

					$('#file-input-data').val('');
				},
				error : function(xhr, error) {
					console.log(xhr, error);
				}
			});
		}else{

			// group message sending
			var message = {};

			message.message = $('.textarea-control').val();
			message.receiveUserId = receiverId;
			message.senderId = userId;

			message.groupId = groupId;
			message.senderName = userFullName;
			
			
			var uploadAttachment = new FormData();
			uploadAttachment.append("file", image);
			uploadAttachment.append('threadPid', JSON.stringify(message));

			var messageContextPath = location.protocol + '//'
					+ location.host + location.pathname + '/sample';

			$.ajax({
				type : 'POST',
				url : messageContextPath,
				data : uploadAttachment,
				cache : false,
				contentType : false,
				processData : false,
				success : function(data) {
						console.log("Saved Grp Reposnse"+data)
					createmessageviewGrp(data, message.receiveUserId, 1);
					$('.textarea-control').text("");
				},
				error : function(xhr, error) {
					console.log(xhr, error);
				}

			});

		}
	}

}
function logout() {

	console.log(messageContextPath);
	window.location.href = '../login';

}

function voiceSaveMP3() {
	

	if (isIndMessage) {
		
		var message = {};
		message.message = $("#hidenInputMp3").val();
		message.receiveUserId = receiverId;
		message.type = "1";
	
		var messageContextPath1 = location.protocol + '//'
		+ location.host + location.pathname + '/saveMp3';
		
		$.ajax({
			method : 'POST',
			url : messageContextPath1,
			contentType : "application/json; charset=utf-8",
			data : JSON.stringify(message),
			success : function(data) {
				createmessageview(data);
				$('#myModal').modal('hide');
				$("#hidenInputMp3").val("");
				
				$('#voiceSendButton').hide();
				
			},
			error : function(xhr, error) {
				onError(xhr, error);
			}
		});
	}else{
		
		var message = {};
		message.message = $("#hidenInputMp3").val();
		//message.receiveUserId = receiverId;
		//message.type = "1";
		message.receiveUserId = receiverId;
		message.senderId = userId;

		message.groupId = groupId;
		message.senderName = userFullName;
	
		var messageContextPath1 = location.protocol + '//'
		+ location.host + location.pathname + '/saveToGroupMp3';
		
		$.ajax({
			method : 'POST',
			url : messageContextPath1,
			contentType : "application/json; charset=utf-8",
			data : JSON.stringify(message),
			success : function(data) {
				createmessageviewGrp(data);
				$('#myModal').modal('hide');
				$("#hidenInputMp3").val("");
				
				$('#voiceSendButton').hide();
				
			},
			error : function(xhr, error) {
				onError(xhr, error);
			}
		});
	
	}
	
	
}

function getMessageWindowGroup(name, groupUKId, gId) {
	isReciverExists = true;
	
	//$("#file-input-data").hide();
	$("#footerDiv").show();//display the  footer
	$("#messageContentDiv").show();//display the message content box
	$('#chat-wrapper').empty();
	//$(".image-upload").hide();

	isGroupMessge = true;
	isIndMessage = false;

	groupId = gId;//groupID
	receiverId = groupUKId;//GroupUKeyIDfor message sending 

	var message = "hey  " + name + "  welcome to Chat";

	// $('#currentChatHead').src="../resources/assets/img/profiles/0"+senderImage+".jpg";
	$("#currentChatHead").attr("src",
			"../resources/assets/img/profiles/group.jpg");

	$(".name").text(name);

	$.ajax({
				method : 'GET',
				url : urlMessageGroupAll + "/" + groupId,
				success : function(data) {
					console.log(data);
					var imageUrl = "../resources/assets/img/profiles/group.jpg";

					if (data != "") {
						
						$.map( data, function( val, key ) {
							var dateDiv='<div class="chat-row" style="text-align: center;" ><p>'+key+'</p></div>';
							$('#chat-wrapper').append(dateDiv);
							
							$.each(val,function(index, messageObj) {
								
							//	console.log(messageObj);

							//	$.each(messageObj1,function(index, messageObj) {		
								
								var senderId = messageObj["senderId"];
								
								var mesageHrMinuts= messageObj["timeOfMessage"].split(":");
								var timeOfMessage=formatAMPM(mesageHrMinuts[0],mesageHrMinuts[1]);

								if (userId == senderId) {
									
									if (messageObj.isAttachment) { // if attachemnt is exist
										var attachmentId = messageObj.attachemnt.id;

										var imgurl = urlAttachemnt + "/" + attachmentId;
										
										if (messageObj.attachemnt.extension == "image/jpeg" || messageObj.attachemnt.extension == "image/png") {
											var messageDiv = '<div class="chat-row " style="width: 30%;"><img src='
												+ imageUrl
												+ ' alt=""class="img-circle img-sm pull-right"><div class="bubble"><div  class="divImage">'
												+ '<img src="'
												+ imgurl
												+ '"></div><div class="message"><p>'
												+ messageObj.messageContent
												+ '</p></div><div class="date">'+timeOfMessage+'</div></div></div>';
										    $('#chat-wrapper').append(messageDiv);
										}else if (messageObj.attachemnt.extension == ".mp3") {
											
											var messageDiv = '<div class="chat-row " ><img src='
										        + imageUrl
										        + ' alt=""class="img-circle img-sm pull-right"><div class="bubble">'
												+ '<div style="text-align: left;"><audio class="audio1" controls=""><source src="'+ imgurl+'" type="audio/mpeg"></audio></div>'
												+ '<div>'+timeOfMessage+'</div></div></div>';
										$('#chat-wrapper')
												.append(messageDiv);
										}

										

									}else{
										var message = '<div class="chat-row" id='
											+ messageObj["id"]
											+ '><img src='
											+ imageUrl
											+ ' alt=""class="img-circle img-sm pull-right"><div class="bubble"><div class="message"><p class="currentMsgContentPara">'
											+ '</p></div><div class="date">'+timeOfMessage+'</div></div></div>';
									$('#chat-wrapper').append(
											message);
									
									$('.currentMsgContentPara').text(messageObj["messageContent"]);
									$('.currentMsgContentPara').removeClass('currentMsgContentPara');

									}
									
								
								} else {

									/*var messageDiv = '<div class="chat-row response" id='
											+ messageObj["id"]
											+ '><img src='
											+ imageUrl
											+ ' alt=""class="img-circle img-sm pull-left"><div class="bubble_response"><div class="message"> <b>'
											+ messageObj["senderName"]
											+ '</b><p>'
											+ messageObj["messageContent"]
											+ '</p></div><div class="date">'+timeOfMessage+'</div></div></div>';
									$('#chat-wrapper').append(
											messageDiv);*/
									

									
									/*var mesageHrMinuts= message["timeOfMessage"].split(":");
									var timeOfMessage=formatAMPM(mesageHrMinuts[0],mesageHrMinuts[1]);*/
									
									if (messageObj.isAttachment) { // if attachemnt is exist
										var attachmentId = messageObj.attachemnt.id;

										var imgurl = urlAttachemnt + "/" + attachmentId;
										
										if (messageObj.attachemnt.extension == "image/jpeg" || messageObj.attachemnt.extension == "image/png") {
											var messageDiv = '<div class="chat-row response" style="width: 30%;"><img src='
												+ imageUrl
												+ ' alt=""class="img-circle img-sm pull-left"><div class="bubble_response"><div  class="divImage">'
												+ '<img src="'
												+ imgurl
												+ '"></div><div class="message"><p>'
												+ messageObj.messageContent
												+ '</p></div><div class="date">'+timeOfMessage+'</div></div></div>';
										    $('#chat-wrapper').append(messageDiv);
										}else if (messageObj.attachemnt.extension == ".mp3") {
											
											var messageDiv = '<div class="chat-row response" ><img src='
										        + imageUrl
										        + ' alt=""class="img-circle img-sm pull-left"><div class="bubble_response">'
												+ '<div style="text-align: left;"><audio class="audio1" controls=""><source src="'+ imgurl+'" type="audio/mpeg"></audio></div>'
												+ '<div>'+timeOfMessage+'</div></div></div>';
										$('#chat-wrapper')
												.append(messageDiv);
										}

										

									} else{
									
										var messageDiv = '<div class="chat-row response"><img src='
											+ imageUrl
											+ ' alt=""class="img-circle img-sm pull-left"><div class="bubble_response"><div class="message"><b>'
											+ messageObj.senderName + '</b><p class="currentMsgContentPara">' 
											+ '</p></div><div class="date">'+timeOfMessage+'</div></div></div>';
									$('#chat-wrapper').append(messageDiv);
									
									$('.currentMsgContentPara').text(messageObj["messageContent"]);
									$('.currentMsgContentPara').removeClass('currentMsgContentPara');
									}
									
							}
								
			//});
								
					});
			
							
						});
						
						
					
						
						
						
						
						
						
					}

				},
				error : function(xhr, error) {
					console.log(xhr, error);
				}

			});

}

function createmessageview(message, id, align) {
	var imageUrl = "../resources/assets/img/profiles/0" + senderImage + ".jpg";

	if (align == 2) {// response chat upending
		var mesageHrMinuts= message["timeOfMessage"].split(":");
		var timeOfMessage=formatAMPM(mesageHrMinuts[0],mesageHrMinuts[1]);
		
		
		if (message.attachment) { // if attachemnt is exist
			var attachmentId = message.attachemnt;

			var imgurl = urlAttachemnt + "/" + attachmentId;
			
			if (message.attachmetExt == "image/jpeg" || message.attachmetExt == "image/png") {
				var messageDiv = '<div class="chat-row response" style="width: 30%;"><img src='
					+ imageUrl
					+ ' alt=""class="img-circle img-sm pull-left"><div class="bubble_response"><div  class="divImage">'
					+ '<img src="'
					+ imgurl
					+ '"></div><div class="message"><p>'
					+ message.messageContent
					+ '</p></div><div class="date">'+timeOfMessage+'</div></div></div>';
			    $('#chat-wrapper').append(messageDiv);
			}else if (message.attachmetExt == ".mp3") {
				
				var messageDiv = '<div class="chat-row response" ><img src='
			        + imageUrl
			        + ' alt=""class="img-circle img-sm pull-left"><div class="bubble_response">'
					+ '<div style="text-align: left;"><audio class="audio1" controls=""><source src="'+ imgurl+'" type="audio/mpeg"></audio></div>'
					+ '<div>'+timeOfMessage+'</div></div></div>';
			$('#chat-wrapper')
					.append(messageDiv);
			}

			

		} else {
			// if olny text message

			/*var messageDiv = '<div class="chat-row response"><img src='
					+ imageUrl
					+ ' alt=""class="img-circle img-sm pull-left"><div class="bubble_response"><div class="message"><p>'
					+ message.messageContent
					+ '</p></div><div class="date">'+timeOfMessage+'</div></div></div>';
			$('#chat-wrapper').append(messageDiv);*/
			
			var messageDiv = '<div class="chat-row response"><img src='
				+ imageUrl + ' alt=""class="img-circle img-sm pull-left"><div class="bubble_response"><div class="message"><p class="currentMsgContentPara">'
				+ '</p></div><div class="date">'+timeOfMessage+'</div></div></div>';
				$('#chat-wrapper').append(messageDiv);

				$('.currentMsgContentPara').text(message.messageContent);
				$('.currentMsgContentPara').removeClass('currentMsgContentPara');

		}

	} else {
		var message=message[0];
		var mesageHrMinuts= message["timeOfMessage"].split(":");
		var timeOfMessage=formatAMPM(mesageHrMinuts[0],mesageHrMinuts[1]);

		if (message.attachment) {

			var attachmentId = message.attachemnt;

			var imgurl = urlAttachemnt + "/" + attachmentId;
			
			if (message.attachmetExt == "image/jpeg"|| message.attachmetExt == "image/png") {
				var messageDiv = '<div class="chat-row" style="width: 30%;"><img src='
					+ imageUrl
					+ ' alt=""class="img-circle img-sm pull-right"><div class="bubble"><div  class="divImage">'
					+ '<img src="'
					+ imgurl
					+ '"></div><div class="message"><p>'
					+ message.messageContent
					+ '</p></div><div class="date">'+timeOfMessage+'</div></div></div>';
			$('#chat-wrapper').append(messageDiv);
			}else if (message.attachmetExt == ".mp3") {
			
				
				var messageDiv = '<div class="chat-row"><img src='
			        + imageUrl
			        + ' alt=""class="img-circle img-sm pull-right"><div class="bubble">'
					+ '<div style="text-align: left;"><audio class="audio1" controls=""><source src="'+ imgurl+'" type="audio/mpeg"></audio></div>'
					+ '<div class="date">'+timeOfMessage+'</div></div></div>';
			$('#chat-wrapper')
					.append(messageDiv);
			
			}

			

		} else {

			var messageDiv = '<div class="chat-row"><img src='
					+ imageUrl
					+ ' alt=""class="img-circle img-sm pull-right"><div class="bubble"><div class="message"><p class="currentMsgContentPara">'
					+ '</p></div><div class="date">'+timeOfMessage+'</div></div></div>';
			$('#chat-wrapper').append(messageDiv);
			
			$('.currentMsgContentPara').text(message.messageContent);
			$('.currentMsgContentPara').removeClass('currentMsgContentPara');

		}

	}

}

function createmessageviewGrp(message, id, align) {
	var imageUrl = "../resources/assets/img/profiles/group.jpg";

	
	if (align == 2) {
	
		var mesageHrMinuts= message["timeOfMessage"].split(":");
		var timeOfMessage=formatAMPM(mesageHrMinuts[0],mesageHrMinuts[1]);
		
		if (message.isAttachment) { // if attachemnt is exist
			var attachmentId = message.attachemnt.id;

			var imgurl = urlAttachemnt + "/" + attachmentId;
			
			if (message.attachemnt.extension == "image/jpeg" || message.attachemnt.extension == "image/png") {
				var messageDiv = '<div class="chat-row response" style="width: 30%;"><img src='
					+ imageUrl
					+ ' alt=""class="img-circle img-sm pull-left"><div class="bubble_response"><div  class="divImage">'
					+ '<img src="'
					+ imgurl
					+ '"></div><div class="message"><p>'
					+ message.messageContent
					+ '</p></div><div class="date">'+timeOfMessage+'</div></div></div>';
			    $('#chat-wrapper').append(messageDiv);
			}else if (message.attachemnt.extension == ".mp3") {
				
				var messageDiv = '<div class="chat-row response" ><img src='
			        + imageUrl
			        + ' alt=""class="img-circle img-sm pull-left"><div class="bubble_response">'
					+ '<div style="text-align: left;"><audio class="audio1" controls=""><source src="'+ imgurl+'" type="audio/mpeg"></audio></div>'
					+ '<div>'+timeOfMessage+'</div></div></div>';
			$('#chat-wrapper').append(messageDiv);
			
		
			}

			

		} else{
		
			var messageDiv = '<div class="chat-row response"><img src='
				+ imageUrl
				+ ' alt=""class="img-circle img-sm pull-left"><div class="bubble_response"><div class="message"><b>'
				+ message.senderName + '</b><p class="currentMsgContentPara" >' 
				+ '</p></div><div class="date">'+timeOfMessage+'</div></div></div>';
		$('#chat-wrapper').append(messageDiv);
		
		$('.currentMsgContentPara').text(message.messageContent);
		$('.currentMsgContentPara').removeClass('currentMsgContentPara');
		
		}
		
		
		
		
		
	} else {
		
		var message=message[0];
		var mesageHrMinuts= message["timeOfMessage"].split(":");
		var timeOfMessage=formatAMPM(mesageHrMinuts[0],mesageHrMinuts[1]);
		
		
		if (message.isAttachment) {

			var attachmentId = message.attachemnt.id;

			var imgurl = urlAttachemnt + "/" + attachmentId;
			
			if (message.attachemnt.extension == "image/jpeg"|| message.attachemnt.extension == "image/png") {
				var messageDiv = '<div class="chat-row" style="width: 30%;"><img src='
					+ imageUrl
					+ ' alt=""class="img-circle img-sm pull-right"><div class="bubble"><div  class="divImage">'
					+ '<img src="'
					+ imgurl
					+ '"></div><div class="message"><p>'
					+ message.messageContent
					+ '</p></div><div class="date">'+timeOfMessage+'</div></div></div>';
			$('#chat-wrapper').append(messageDiv);
			}else if (message.attachemnt.extension == ".mp3") {
			
				
				var messageDiv = '<div class="chat-row"><img src='
			        + imageUrl
			        + ' alt=""class="img-circle img-sm pull-right"><div class="bubble">'
					+ '<div style="text-align: left;"><audio class="audio1" controls=""><source src="'+ imgurl+'" type="audio/mpeg"></audio></div>'
					+ '<div class="date">'+timeOfMessage+'</div></div></div>';
			$('#chat-wrapper')
					.append(messageDiv);
			
			}

			

		} else {

		var message = '<div class="chat-row"><img src='
				+ imageUrl
				+ ' alt=""class="img-circle img-sm pull-right"><div class="bubble"><div class="message"><p class="currentMsgContentPara" >'
				+ '</p></div><div class="date">'+timeOfMessage+'</div></div></div>';
		$('#chat-wrapper').append(message);
		
		$('.currentMsgContentPara').text(message.messageContent);
		console.log("message from our side"+message.messageContent);
		$('.currentMsgContentPara').removeClass('currentMsgContentPara');
		}
	}

}



var stompClient = null;
function connect() {

	if (stompClient != null) {
		stompClient.disconnect();
	}
	alert(contextPath);
	var socket = new SockJS(contextPath + '/tracking');
	stompClient = Stomp.over(socket);
	stompClient.connect({}, function(frame) {
		stompClient.subscribe('/message/send/individual/' + loginUserUk,
				function(response) {
					var messageBody1 = JSON.parse(response.body);
					messageBody1.currentUser = false;
					
					 var messageBody=messageBody1[0];
					if (receiverId == messageBody.senderUserUkId) {
						createmessageview(messageBody,
								messageBody.senderUserUkId, 2);
						$("#" + messageBody.senderUserUkId).hide();

					} else {
					//when a new message recived push the contact to top of the contact pool display ballon icon with animation
						$("#" + messageBody.senderUserUkId).show();
					    $("#li-"+ messageBody.senderUserUkId).parent().
					             prepend($("#li-"+ messageBody.senderUserUkId));
					}

				});

		stompClient.subscribe('/message/send/group/' + loginUserUkGrp,
				function(response) {
					var messageBody1 = JSON.parse(response.body);
					messageBody1.currentUser = false;

					 var messageBody=messageBody1[0];
					if (userId != messageBody.senderId) {
						console.log("Grp message  recived");

						createmessageviewGrp(messageBody,
								messageBody.receiveUserId, 2);
					}

				});
	});
}